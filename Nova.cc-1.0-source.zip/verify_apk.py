import sys,zipfile,hashlib,json
from pathlib import Path
p=Path(sys.argv[1]);base=Path(__file__).resolve().parent
with zipfile.ZipFile(p) as z:
 names=z.namelist();native=z.read('lib/arm64-v8a/libnova_exec.so');jni=z.read('lib/arm64-v8a/libnova_license.so');dex=z.read('classes.dex')
 assert native[:4]==jni[:4]==b'\x7fELF' and native[18:20]==b'\xb7\x00'
 for text in [b'Nova.cc runtime 1.0',b'1.19.12025',b'NOVA-',b'PlayerManager',b'NetworkClient']:assert text in native,text
 assert b'Java_cc_nova_oxide_LicenseBridge_localCheck' in jni
 assert b'Lcc/nova/oxide/MainActivity;' in dex and b'Lcc/nova/oxide/OverlayService;' in dex
 assert z.read('assets/nova_logo.png').startswith(b'\x89PNG')
 for text in [b'Dofamine',b'DOFAMINE',b'p1084164.ihc.xyz',b'DFM-',b'https://t.me/DofamineCheat',b'NovaPanel 1']:
  assert text not in native and text not in jni and text not in dex,('old branding/licensing',text)
 keys=(base/'private/nova-keys.txt').read_text().splitlines();assert len(keys)==len(set(keys))==250
 for key in keys:
  raw=key.encode('ascii');assert raw not in native and raw not in jni and raw not in dex,'plaintext key packaged'
 assert not any('keys' in n.lower() or '.jks' in n.lower() or 'private/' in n.lower() for n in names)
 print('PASS: Nova.cc package, ARM64 modules, offline key verification, no plaintext keys/panel endpoint/old branding; APK SHA256='+hashlib.sha256(p.read_bytes()).hexdigest())
