#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to NDK r27c}"
"$ANDROID_NDK_HOME/ndk-build" -B NDK_PROJECT_PATH="$ROOT" APP_BUILD_SCRIPT="$ROOT/jni/Android.mk" NDK_APPLICATION_MK="$ROOT/jni/Application.mk" NDK_OUT="$ROOT/build/obj" NDK_LIBS_OUT="$ROOT/build/libs" -j"${JOBS:-2}"
mkdir -p "$ROOT/out/arm64-v8a"
cp "$ROOT/build/libs/arm64-v8a/Nova" "$ROOT/out/arm64-v8a/Nova"

cp "$ROOT/build/libs/arm64-v8a/libnova_license.so" "$ROOT/out/arm64-v8a/libnova_license.so"
