#pragma once
#include <cstdint>

namespace touch {
    bool init(int32_t _screen_w, int32_t _screen_h, uint8_t _orientation);
    void update(int32_t _screen_w, int32_t _screen_h, uint8_t _orientation);
    void updateOrientation(uint8_t _orientation);
    void shutdown();
    void pump();
}

namespace touch {
struct FlightInput {uint32_t generation=0;bool captured=false;float x=0,y=0,vertical=0,look_x=0,look_y=0;};
bool capture_flight(bool enable,int width,int height,int up_x,int up_y,int down_x,int down_y);
FlightInput flight_input();
}

#include <array>
namespace touch {struct SyntheticContact{bool down=false;float x=0,y=0;bool concurrent=false;};bool synthetic(const std::array<SyntheticContact,3>& contacts);bool physical_down();}
