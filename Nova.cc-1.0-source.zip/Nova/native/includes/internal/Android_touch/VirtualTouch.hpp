#pragma once
#include <linux/uinput.h>
#include <array>
#include <cmath>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <cstdio>
#include <cstring>
#include <cerrno>
namespace touch {
class VirtualTouch {
 int fd_=-1;long long ready_=0,retry_=0;std::array<bool,3> pressed_{};
public:
 bool usable()const{return fd_>=0;}
 bool ensure(long long time){if(fd_>=0)return time>=ready_;if(time<retry_)return false;retry_=time+10000;
  int fd=open("/dev/uinput",O_WRONLY|O_NONBLOCK|O_CLOEXEC);if(fd<0)fd=open("/dev/input/uinput",O_WRONLY|O_NONBLOCK|O_CLOEXEC);if(fd<0){fprintf(stderr,"OXIDE_INPUT uinput unavailable errno=%d; hardware fallback\n",errno);return false;}
  auto bit=[&](unsigned long request,int code){return ioctl(fd,request,code)==0;};bool ok=bit(UI_SET_EVBIT,EV_KEY)&&bit(UI_SET_KEYBIT,BTN_TOUCH)&&bit(UI_SET_KEYBIT,BTN_TOOL_FINGER)&&bit(UI_SET_EVBIT,EV_ABS)&&bit(UI_SET_PROPBIT,INPUT_PROP_DIRECT);
  for(int code:{ABS_X,ABS_Y,ABS_PRESSURE,ABS_MT_SLOT,ABS_MT_TRACKING_ID,ABS_MT_POSITION_X,ABS_MT_POSITION_Y,ABS_MT_PRESSURE,ABS_MT_TOUCH_MAJOR})ok=bit(UI_SET_ABSBIT,code)&&ok;
  uinput_user_dev dev{};snprintf(dev.name,sizeof(dev.name),"Nova Touch");dev.id.bustype=BUS_VIRTUAL;dev.id.vendor=0x18d1;dev.id.product=0xd0fa;dev.id.version=1;
  dev.absmax[ABS_X]=dev.absmax[ABS_Y]=dev.absmax[ABS_MT_POSITION_X]=dev.absmax[ABS_MT_POSITION_Y]=32767;dev.absmax[ABS_MT_SLOT]=2;dev.absmax[ABS_MT_TRACKING_ID]=65535;dev.absmax[ABS_PRESSURE]=dev.absmax[ABS_MT_PRESSURE]=dev.absmax[ABS_MT_TOUCH_MAJOR]=255;
  if(!ok||write(fd,&dev,sizeof(dev))!=ssize_t(sizeof(dev))||ioctl(fd,UI_DEV_CREATE)!=0){fprintf(stderr,"OXIDE_INPUT uinput setup failed errno=%d; hardware fallback\n",errno);close(fd);return false;}fd_=fd;ready_=time+850;fprintf(stderr,"OXIDE_INPUT virtual touchscreen created\n");return false;
 }
 // Normalized sensor coordinates, before Android applies display rotation.
 bool send(const std::array<SyntheticContact,3>& input){if(fd_<0)return false;std::vector<input_event> events;auto put=[&](unsigned short type,unsigned short code,int value){input_event e{};e.type=type;e.code=code;e.value=value;events.push_back(e);};std::array<bool,3> next{};bool any=false;
  for(unsigned i=0;i<3;++i){auto c=input[i];bool down=c.down&&std::isfinite(c.x)&&std::isfinite(c.y)&&c.x>=0&&c.x<=1&&c.y>=0&&c.y<=1;next[i]=down;if(!down&&!pressed_[i])continue;put(EV_ABS,ABS_MT_SLOT,int(i));if(!down){put(EV_ABS,ABS_MT_TRACKING_ID,-1);continue;}if(!pressed_[i])put(EV_ABS,ABS_MT_TRACKING_ID,101+int(i));put(EV_ABS,ABS_MT_POSITION_X,int(c.x*32767));put(EV_ABS,ABS_MT_POSITION_Y,int(c.y*32767));put(EV_ABS,ABS_MT_PRESSURE,60);put(EV_ABS,ABS_MT_TOUCH_MAJOR,8);any=true;}
  if(events.empty())return true;put(EV_KEY,BTN_TOUCH,any?1:0);put(EV_KEY,BTN_TOOL_FINGER,any?1:0);put(EV_SYN,SYN_REPORT,0);ssize_t n;do{n=write(fd_,events.data(),events.size()*sizeof(input_event));}while(n<0&&errno==EINTR);if(n!=ssize_t(events.size()*sizeof(input_event)))return false;pressed_=next;return true;
 }
 void close_device(){if(fd_>=0){send({});ioctl(fd_,UI_DEV_DESTROY);close(fd_);}fd_=-1;pressed_={};}
#ifdef OXIDE_TESTING
 void adopt_pipe(int fd){fd_=fd;ready_=0;pressed_={};}
#endif
 ~VirtualTouch(){close_device();}
};
}
