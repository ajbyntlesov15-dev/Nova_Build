#include "imgui.h"
#include "Android_touch/Touch.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <cerrno>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#include "Android_touch/VirtualTouch.hpp"
namespace touch {
struct Contact{bool active=false,fresh=true;bool synthetic=false;float x=0,y=0,last_x=0,last_y=0,anchor_x=0,anchor_y=0;};
struct Device{int fd=-1;input_absinfo ax{},ay{};std::thread worker;std::atomic<unsigned> physical{0};int slot_base=7,slot_count=10,synthetic_id=14007;std::array<bool,3> injected{};~Device(){if(fd>=0)::close(fd);}};
struct PointerEvent{float x,y;bool down;};
static std::vector<std::unique_ptr<Device>> devices;
static std::atomic<bool> running{false},captured{false};static std::atomic<unsigned> generation{0};
static std::atomic<int> screen_w{1},screen_h{1},rotation{0};static std::atomic<long long> heartbeat{0};
static std::mutex flight_mutex,control_mutex,queue_mutex;static std::deque<PointerEvent> queue;
static std::atomic<long long> synthetic_heartbeat{0};
static VirtualTouch virtual_touch;static bool virtual_allowed=true;
static FlightInput flight;static int ux=88,uy=40,dx=88,dy=68;static std::thread watchdog;
static long long clock_ms(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
static ImVec2 coordinates(const Device& d,const Contact& c){float x=std::clamp((c.x-d.ax.minimum)/(float(d.ax.maximum)-float(d.ax.minimum)),0.f,1.f),y=std::clamp((c.y-d.ay.minimum)/(float(d.ay.maximum)-float(d.ay.minimum)),0.f,1.f);switch(rotation.load()){case 1:return {y*screen_w,(1-x)*screen_h};case 2:return {(1-x)*screen_w,(1-y)*screen_h};case 3:return {(1-y)*screen_w,x*screen_h};default:return {x*screen_w,y*screen_h};}}
static void enqueue(PointerEvent e){std::lock_guard<std::mutex> lock(queue_mutex);if(queue.size()>=256){queue.clear();queue.push_back({e.x,e.y,false});}queue.push_back(e);}
void overlay_pointer(float x,float y,bool down){enqueue({x,y,down});}
void pump(){std::deque<PointerEvent> events;{std::lock_guard<std::mutex> lock(queue_mutex);events.swap(queue);}auto& io=ImGui::GetIO();for(auto e:events){io.AddMousePosEvent(e.x,e.y);io.AddMouseButtonEvent(0,e.down);}}
static void report(std::array<Contact,10>& slots,const Device& device){
 if(!captured)return;std::lock_guard<std::mutex> lock(flight_mutex);if(!captured)return;float mx=0,my=0,mz=0;
 for(auto& c:slots){if(!c.active||c.synthetic){c.fresh=true;continue;}auto p=coordinates(device,c);if(c.fresh){c.anchor_x=c.last_x=p.x;c.anchor_y=c.last_y=p.y;c.fresh=false;}float radius=std::max(32.f,screen_w*.032f);
  auto inside=[&](int x,int y){float a=p.x-screen_w*x*.01f,b=p.y-screen_h*y*.01f;return a*a+b*b<radius*radius;};
  if(inside(ux,uy))mz+=1;else if(inside(dx,dy))mz-=1;
  else if(c.anchor_x<screen_w*.4f&&c.anchor_y>screen_h*.45f){float r=std::max(40.f,screen_w*.05f);mx=(p.x-c.anchor_x)/r;my=-(p.y-c.anchor_y)/r;}
  else if(c.anchor_x>screen_w*.4f){flight.look_x+=p.x-c.last_x;flight.look_y+=p.y-c.last_y;}
  c.last_x=p.x;c.last_y=p.y;
 }
 float n=std::sqrt(mx*mx+my*my);if(n>1){mx/=n;my/=n;}if(n<.08f)mx=my=0;flight.x=mx;flight.y=my;flight.vertical=std::clamp(mz,-1.f,1.f);
}
static void input_loop(Device* device){std::array<Contact,10> contacts{};int slot=0,primary=-1;unsigned seen=generation;ImVec2 last{};
 while(running){pollfd poller{device->fd,POLLIN,0};int ready=poll(&poller,1,50);if(ready<0){if(errno==EINTR)continue;break;}if(!ready)continue;if(poller.revents&(POLLERR|POLLHUP|POLLNVAL))break;
  input_event events[64];ssize_t bytes=read(device->fd,events,sizeof(events));if(bytes<0){if(errno==EINTR||errno==EAGAIN)continue;break;}if(bytes==0)break;
  if(seen!=generation){contacts={};primary=-1;seen=generation;enqueue({last.x,last.y,false});}
  for(size_t i=0;i<size_t(bytes)/sizeof(input_event);++i){const auto& e=events[i];if(e.type==EV_ABS){if(e.code==ABS_MT_SLOT)slot=std::clamp(e.value,0,9);else if(e.code==ABS_MT_TRACKING_ID){contacts[slot].active=e.value>=0;if(e.value>=0)contacts[slot].synthetic=device->slot_base>=0&&slot>=device->slot_base&&slot<device->slot_base+3&&e.value==device->synthetic_id+slot-device->slot_base;contacts[slot].fresh=true;if(e.value>=0&&!contacts[slot].synthetic&&primary<0)primary=slot;}else if(e.code==ABS_MT_POSITION_X)contacts[slot].x=float(e.value);else if(e.code==ABS_MT_POSITION_Y)contacts[slot].y=float(e.value);}
   if(e.type==EV_SYN&&e.code==SYN_DROPPED){contacts={};primary=-1;enqueue({last.x,last.y,false});std::lock_guard<std::mutex> lock(flight_mutex);flight.x=flight.y=flight.vertical=0;}
   if(e.type==EV_SYN&&e.code==SYN_REPORT){unsigned mask=0;for(unsigned j=0;j<contacts.size();++j)if(contacts[j].active&&!contacts[j].synthetic)mask|=1U<<j;device->physical=mask;report(contacts,*device);bool down=primary>=0&&contacts[primary].active;if(down)last=coordinates(*device,contacts[primary]);enqueue({last.x,last.y,down});if(!down)primary=-1;}
  }
 }
 device->physical=0;enqueue({last.x,last.y,false});
}
bool physical_down(){for(auto& d:devices)if(d->physical.load())return true;return false;}
static bool inject_locked(const std::array<SyntheticContact,3>& requested){
 if(virtual_allowed&&(virtual_touch.usable()||std::any_of(requested.begin(),requested.end(),[](auto c){return c.down;}))){bool ready=virtual_touch.ensure(clock_ms());if(virtual_touch.usable()){std::array<SyntheticContact,3> mapped{};bool blocked=captured;const bool physical=physical_down();bool rejected=false;for(unsigned i=0;i<3;++i){auto c=requested[i];if(c.down&&physical&&!c.concurrent)rejected=true;if(!c.down||blocked||(physical&&!c.concurrent))continue;float x=c.x*.01f,y=c.y*.01f;switch(rotation.load()){case 1:{float t=x;x=1-y;y=t;break;}case 2:x=1-x;y=1-y;break;case 3:{float t=x;x=y;y=1-t;break;}}mapped[i]={true,x,y};}if(!ready){virtual_touch.send({});return false;}return virtual_touch.send(mapped)&&!blocked&&!rejected;}}
 if(devices.empty())return false;auto& d=*devices.front();if(d.slot_base<0)return false;bool blocked=captured;const bool physical=physical_down();bool rejected=false;std::vector<input_event> events;
 auto put=[&](unsigned short type,unsigned short code,int value){input_event e{};e.type=type;e.code=code;e.value=value;events.push_back(e);};
 bool any=false;for(unsigned i=0;i<3;++i){const auto& c=requested[i];const bool occupied=(d.physical.load()&(1U<<(d.slot_base+i)))!=0;if(c.down&&((physical&&!c.concurrent)||occupied))rejected=true;if(occupied){d.injected[i]=false;continue;}bool down=c.down&&!blocked&&(!physical||c.concurrent)&&std::isfinite(c.x)&&std::isfinite(c.y)&&c.x>=0&&c.x<=100&&c.y>=0&&c.y<=100;if(!down&&!d.injected[i])continue;put(EV_ABS,ABS_MT_SLOT,d.slot_base+i);if(!down){if(d.physical.load()&(1U<<(d.slot_base+i))){d.injected[i]=false;continue;}put(EV_ABS,ABS_MT_TRACKING_ID,-1);d.injected[i]=false;continue;}float x=c.x*.01f,y=c.y*.01f;switch(rotation.load()){case 1:{float t=x;x=1-y;y=t;break;}case 2:x=1-x;y=1-y;break;case 3:{float t=x;x=y;y=1-t;break;}}
 if(!d.injected[i])put(EV_ABS,ABS_MT_TRACKING_ID,d.synthetic_id+i);put(EV_ABS,ABS_MT_POSITION_X,d.ax.minimum+int(x*(d.ax.maximum-d.ax.minimum)));put(EV_ABS,ABS_MT_POSITION_Y,d.ay.minimum+int(y*(d.ay.maximum-d.ay.minimum)));d.injected[i]=true;any=true;}
 if(events.empty())return !blocked&&!rejected;put(EV_KEY,BTN_TOUCH,(any||physical_down())?1:0);put(EV_SYN,SYN_REPORT,0);bool ok=write(d.fd,events.data(),events.size()*sizeof(input_event))==ssize_t(events.size()*sizeof(input_event));if(!ok)fprintf(stderr,"OXIDE_INPUT write failed: %d\n",errno);return ok&&!blocked&&!rejected;
}
bool synthetic(const std::array<SyntheticContact,3>& contacts){synthetic_heartbeat=clock_ms();std::lock_guard<std::mutex> lock(control_mutex);return inject_locked(contacts);}
bool capture_flight(bool enable,int width,int height,int up_x,int up_y,int down_x,int down_y){heartbeat=clock_ms();std::scoped_lock lock(control_mutex,flight_mutex);screen_w=std::max(width,1);screen_h=std::max(height,1);ux=up_x;uy=up_y;dx=down_x;dy=down_y;
 if(enable==captured.load())return captured;
 if(enable){inject_locked({});std::vector<int> grabbed;for(auto& d:devices){std::vector<input_event> release;for(int i=0;i<d->slot_count;++i){input_event e{};e.type=EV_ABS;e.code=ABS_MT_SLOT;e.value=i;release.push_back(e);e.code=ABS_MT_TRACKING_ID;e.value=-1;release.push_back(e);}input_event key{};key.type=EV_KEY;key.code=BTN_TOUCH;release.push_back(key);key.type=EV_SYN;key.code=SYN_REPORT;release.push_back(key);
   if(write(d->fd,release.data(),release.size()*sizeof(input_event))!=ssize_t(release.size()*sizeof(input_event))||ioctl(d->fd,EVIOCGRAB,1)!=0){for(int fd:grabbed)ioctl(fd,EVIOCGRAB,0);flight={};return false;}grabbed.push_back(d->fd);
  }if(grabbed.empty())return false;flight={};flight.captured=true;captured=true;flight.generation=++generation;return true;
 }
 captured=false;++generation;for(auto& d:devices)ioctl(d->fd,EVIOCGRAB,0);flight={};return false;
}
FlightInput flight_input(){std::lock_guard<std::mutex> lock(flight_mutex);return flight;}
bool init(int32_t width,int32_t height,uint8_t orientation){if(running)return !devices.empty();screen_w=std::max(width,1);screen_h=std::max(height,1);rotation=orientation;DIR* dir=opendir("/dev/input");if(!dir)return false;
 while(auto* entry=readdir(dir)){if(strncmp(entry->d_name,"event",5))continue;std::string path=std::string("/dev/input/")+entry->d_name;auto d=std::make_unique<Device>();d->fd=open(path.c_str(),O_RDWR|O_NONBLOCK|O_CLOEXEC);input_absinfo tracking{},slots{};
  if(d->fd<0||ioctl(d->fd,EVIOCGABS(ABS_MT_POSITION_X),&d->ax)||ioctl(d->fd,EVIOCGABS(ABS_MT_POSITION_Y),&d->ay)||ioctl(d->fd,EVIOCGABS(ABS_MT_TRACKING_ID),&tracking)||d->ax.maximum<=d->ax.minimum||d->ay.maximum<=d->ay.minimum)continue;bool protocol_b=ioctl(d->fd,EVIOCGABS(ABS_MT_SLOT),&slots)==0&&slots.minimum==0;d->slot_count=protocol_b?std::clamp(slots.maximum+1,1,10):10;d->slot_base=protocol_b&&d->slot_count>=3&&tracking.maximum>=3?d->slot_count-3:-1;d->synthetic_id=std::max(1,std::min(tracking.maximum,32000)-2);devices.push_back(std::move(d));
 }closedir(dir);if(devices.empty())return false;running=true;for(auto& d:devices)d->worker=std::thread(input_loop,d.get());watchdog=std::thread([]{while(running){std::this_thread::sleep_for(std::chrono::milliseconds(100));if(clock_ms()-synthetic_heartbeat>350){std::lock_guard<std::mutex> lock(control_mutex);inject_locked({});}if(captured&&clock_ms()-heartbeat>600)capture_flight(false,screen_w,screen_h,88,40,88,68);}});return true;
}
void update(int32_t width,int32_t height,uint8_t orientation){screen_w=std::max(width,1);screen_h=std::max(height,1);rotation=orientation;}
void updateOrientation(uint8_t orientation){rotation=orientation;}
void shutdown(){synthetic({});capture_flight(false,screen_w,screen_h,88,40,88,68);running=false;if(watchdog.joinable())watchdog.join();for(auto& d:devices)if(d->worker.joinable())d->worker.join();virtual_touch.close_device();devices.clear();std::lock_guard<std::mutex> lock(queue_mutex);queue.clear();}
}
