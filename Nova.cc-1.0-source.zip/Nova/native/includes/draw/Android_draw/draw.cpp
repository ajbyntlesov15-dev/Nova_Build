#include <atomic>
#include "Android_draw/draw.h"
#include "fonts/menu/pixeloperator.h"
#include "fonts/menu/bold.hpp"
#include "fonts/esp/esp.h"



EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig config;
EGLSurface surface = EGL_NO_SURFACE;
EGLContext context = EGL_NO_CONTEXT;

ANativeWindow *native_window;
ImFont* fontBold;
ImFont* fontMedium;
ImFont* fontDesc;
ImFont* espFont;
ImFont* wiconFont;

int native_window_screen_x = 0;
int native_window_screen_y = 0;
android::ANativeWindowCreator::DisplayInfo displayInfo{0};
uint32_t orientation = 0;
bool g_Initialized = false;
ImGuiWindow *g_window = nullptr;

static bool public_surface=false;
static std::atomic<int> crop_x{0},crop_y{0},logical_w{1},logical_h{1};
void overlay_viewport(int w,int h,int x,int y){logical_w=std::max(1,w);logical_h=std::max(1,h);crop_x=x;crop_y=y;}

static bool init_window_egl();

bool init_overlay_surface(ANativeWindow* window){
    if(!window)return false;
    public_surface=true;
    native_window=window;
    ANativeWindow_acquire(native_window);
    if(init_window_egl()&&ImGui_init())return true;
    shutdown();
    return false;
}

bool initGUI_draw(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    orientation = displayInfo.orientation;

    if (!init_egl(_screen_x, _screen_y, log)) {
        return false;
    }

    if (!ImGui_init()) {
        return false;
    }

    return true;
}

bool init_egl(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    public_surface=false;
    ::native_window = android::ANativeWindowCreator::Create("Overlay", _screen_x, _screen_y, false, false);

    if(!native_window)return false;
    ANativeWindow_acquire(native_window);
    return init_window_egl();
}

static bool init_window_egl(){
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        return false;
    }

    if (eglInitialize(display, 0, 0) != EGL_TRUE) {
        return false;
    }

    EGLint num_config = 0;
    const EGLint attribList[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_BUFFER_SIZE, 32,
        EGL_DEPTH_SIZE, 16,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    const EGLint attrib_list[] = {
        EGL_CONTEXT_CLIENT_VERSION,
        3,
        EGL_NONE
    };

    if (eglChooseConfig(display, attribList, &config, 1, &num_config) != EGL_TRUE || num_config < 1) {
        return false;
    }

    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) {
        return false;
    }

    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) {
        return false;
    }

    if (!eglMakeCurrent(display, surface, surface, context)) {
        return false;
    }

    return true;
}

void screen_config() {
    displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
}

bool ImGui_init() {
    if (g_Initialized) {
        return true;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = NULL;
    io.ConfigWindowsMoveFromTitleBarOnly=true;

    ImFontConfig static_font;
    static_font.FontDataOwnedByAtlas = false;

    // Supplied bold typeface is used consistently for menu, labels and watermark.
    // Keep PixelOperator as a safe fallback if the embedded font blob is rejected.
    fontBold = io.Fonts->AddFontFromMemoryTTF(zir, sizeof(zir), 32, &static_font, io.Fonts->GetGlyphRangesCyrillic());
    if (!fontBold) fontBold = io.Fonts->AddFontFromMemoryTTF(pixeloperator, sizeof(pixeloperator), 32, &static_font, io.Fonts->GetGlyphRangesCyrillic());
    fontMedium = io.Fonts->AddFontFromMemoryTTF(zir, sizeof(zir), 28, &static_font, io.Fonts->GetGlyphRangesCyrillic());
    if (!fontMedium) fontMedium = io.Fonts->AddFontFromMemoryTTF(pixeloperator, sizeof(pixeloperator), 28, &static_font, io.Fonts->GetGlyphRangesCyrillic());
    fontDesc = io.Fonts->AddFontFromMemoryTTF(zir, sizeof(zir), 22, &static_font, io.Fonts->GetGlyphRangesCyrillic());
    if (!fontDesc) fontDesc = io.Fonts->AddFontFromMemoryTTF(pixeloperator, sizeof(pixeloperator), 22, &static_font, io.Fonts->GetGlyphRangesCyrillic());
    // Merge device fonts for Chinese, Arabic and Latin Extended labels.
    ImFontConfig merged;merged.MergeMode=true;merged.DstFont=fontMedium;
    static const ImWchar latin_ext[]={0x0100,0x024f,0};
    static const ImWchar arabic[]={0x0600,0x06ff,0xfb50,0xfdff,0xfe70,0xfeff,0};
    auto merge_device=[&](const char* const* files,int count,const ImWchar* ranges){for(int i=0;i<count;++i){FILE* test=fopen(files[i],"rb");if(!test)continue;fclose(test);if(io.Fonts->AddFontFromFileTTF(files[i],28,&merged,ranges)){fprintf(stderr,"OXIDE_FONT accepted device font: %s\n",files[i]);return true;}}return false;};
    const char* latin_files[]={"/system/fonts/Roboto-Regular.ttf","/system/fonts/NotoSans-Regular.ttf"};
    const char* arabic_files[]={"/system/fonts/NotoNaskhArabic-Regular.ttf","/system/fonts/NotoSansArabic-Regular.ttf","/system/fonts/NotoNaskhArabic-VF.ttf","/system/fonts/NotoSansArabic-VF.ttf"};
    const char* chinese_files[]={"/system/fonts/NotoSansCJK-Regular.ttc","/system/fonts/NotoSansCJK-VF.ttc"};
    merge_device(latin_files,2,latin_ext);merge_device(arabic_files,4,arabic);merge_device(chinese_files,2,io.Fonts->GetGlyphRangesChineseSimplifiedCommon());
    io.FontDefault = fontMedium;

    espFont = io.Fonts->AddFontFromMemoryTTF(esp, sizeof(esp), 18, &static_font, io.Fonts->GetGlyphRangesCyrillic());

    ImGui::GetStyle().ScaleAllSizes(3.0f);
    ::g_Initialized = true;
    return true;
}

void drawBegin() {
    if(public_surface){
        EGLint w=0,h=0;
        if(eglQuerySurface(display,surface,EGL_WIDTH,&w)&&eglQuerySurface(display,surface,EGL_HEIGHT,&h)&&w>0&&h>0){
            native_window_screen_x=displayInfo.width=logical_w.load();
            native_window_screen_y=displayInfo.height=logical_h.load();
        }
    }else screen_config();
    if (!public_surface&&::orientation != displayInfo.orientation) {
        ::orientation = displayInfo.orientation;
        touch::update(displayInfo.width, displayInfo.height, displayInfo.orientation);
        if (g_window) {
            g_window->Pos.x = 100;
            g_window->Pos.y = 125;
        }
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(native_window_screen_x, native_window_screen_y);
    touch::pump();
    ImGui::NewFrame();
}

void (*dof_scene_draw)()=nullptr;
void drawEnd() {
    ImGui::Render();
    glDisable(GL_SCISSOR_TEST);
    glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
    glClearColor(0.f,0.f,0.f,0.f);
    glDepthMask(GL_TRUE);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    if(dof_scene_draw)dof_scene_draw();
    auto* data=ImGui::GetDrawData();
    if(public_surface){EGLint w=1,h=1;eglQuerySurface(display,surface,EGL_WIDTH,&w);eglQuerySurface(display,surface,EGL_HEIGHT,&h);data->DisplayPos={float(crop_x.load()),float(crop_y.load())};data->DisplaySize={float(w),float(h)};}
    ImGui_ImplOpenGL3_RenderDrawData(data);
    eglSwapBuffers(display, surface);
}

void shutdown() {
    if(g_Initialized){
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        ImGui::DestroyContext();
    }
    g_window=nullptr;

    if (display != EGL_NO_DISPLAY) {
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT) {
            eglDestroyContext(display, context);
        }
        if (surface != EGL_NO_SURFACE) {
            eglDestroySurface(display, surface);
        }
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;

    if(native_window){
        ANativeWindow_release(native_window);
        if(!public_surface)android::ANativeWindowCreator::Destroy(native_window);
        native_window=nullptr;
    }
    public_surface=false;
    ::g_Initialized = false;
}
