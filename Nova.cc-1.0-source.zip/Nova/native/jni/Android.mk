# Android.mk

LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_MODULE           := Dofamine              # sometimes needed

LOCAL_SRC_FILES := \
 ../vendor/monocypher/monocypher.c \
 ../vendor/monocypher/monocypher-ed25519.c \
 ../src/main.cpp \
 ../src/ui/model_assets.S \
 ../includes/draw/Android_draw/draw.cpp \
 ../includes/draw/Android_touch/Touch.cpp \
 ../includes/draw/ImGui/imgui.cpp \
 ../includes/draw/ImGui/imgui_draw.cpp \
 ../includes/draw/ImGui/imgui_tables.cpp \
 ../includes/draw/ImGui/imgui_widgets.cpp \
 ../includes/draw/ImGui/backends/imgui_impl_android.cpp \
 ../includes/draw/ImGui/backends/imgui_impl_opengl3.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/../build/local-private \
    $(LOCAL_PATH)/../includes \
    $(LOCAL_PATH)/../includes/fonts \
    $(LOCAL_PATH)/../includes/internal \
    $(LOCAL_PATH)/../includes/internal/ImGui \
    $(LOCAL_PATH)/../includes/internal/ImGui/backends \
    $(LOCAL_PATH)/../includes/draw/ImGui \
    $(LOCAL_PATH)/../includes/draw/ImGui/backends \
    $(LOCAL_PATH)/../src \
    $(LOCAL_PATH)/../src/ui

LOCAL_ASFLAGS := -I$(LOCAL_PATH)/../assets/models
LOCAL_CPPFLAGS := \
    -flto=thin \
    -fstack-protector-strong \
    -D_FORTIFY_SOURCE=2 \
    -std=c++17 \
    -fno-rtti \
    -fno-exceptions \
    -fvisibility=hidden \
    -fvisibility-inlines-hidden \
    -Oz \
    -ffunction-sections \
    -fdata-sections \
    -fomit-frame-pointer \
    -Wno-error=format-security \
    -fno-color-diagnostics \
    -fmerge-all-constants \
    -fno-ident \
    

# If you really want -fexceptions (very rare in size-optimized Android native code)
# LOCAL_CPPFLAGS += -fexceptions

LOCAL_CFLAGS := -Oz -fvisibility=hidden -flto=thin -fstack-protector-strong -D_FORTIFY_SOURCE=2

LOCAL_LDFLAGS := -flto=thin \
    -Wl,--gc-sections \
    -Wl,--strip-all \
    -Wl,--build-id=none \
    -Wl,--no-undefined \
    -pie \
    -Wl,-z,max-page-size=16384 -Wl,-z,relro \
    -Wl,-z,now \
    -Wl,-z,noexecstack \
   

LOCAL_LDLIBS := -ldl  \
    -lz \
    -llog \
    -landroid \
    -lEGL \
    -lGLESv3 -laaudio

# Very aggressive stripping — sometimes causes issues, test carefully
# LOCAL_LDFLAGS += -s

include $(BUILD_EXECUTABLE)
include $(CLEAR_VARS)
LOCAL_MODULE := dofamine_license
LOCAL_SRC_FILES := \
 ../src/security/license_jni.cpp \
 ../src/security/virtual_probe.cpp \
 ../vendor/monocypher/monocypher.c \
 ../vendor/monocypher/monocypher-ed25519.c \
 ../src/main.cpp \
 ../src/ui/model_assets.S \
 ../includes/draw/Android_draw/draw.cpp \
 ../includes/draw/Android_touch/Touch.cpp \
 ../includes/draw/ImGui/imgui.cpp \
 ../includes/draw/ImGui/imgui_draw.cpp \
 ../includes/draw/ImGui/imgui_tables.cpp \
 ../includes/draw/ImGui/imgui_widgets.cpp \
 ../includes/draw/ImGui/backends/imgui_impl_android.cpp \
 ../includes/draw/ImGui/backends/imgui_impl_opengl3.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/../build/local-private \
    $(LOCAL_PATH)/../includes \
    $(LOCAL_PATH)/../includes/fonts \
    $(LOCAL_PATH)/../includes/internal \
    $(LOCAL_PATH)/../includes/internal/ImGui \
    $(LOCAL_PATH)/../includes/internal/ImGui/backends \
    $(LOCAL_PATH)/../includes/draw/ImGui \
    $(LOCAL_PATH)/../includes/draw/ImGui/backends \
    $(LOCAL_PATH)/../src \
    $(LOCAL_PATH)/../src/ui

LOCAL_ASFLAGS := -I$(LOCAL_PATH)/../assets/models
LOCAL_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti -fvisibility=hidden -fvisibility-inlines-hidden -Oz -flto=thin -fstack-protector-strong -D_FORTIFY_SOURCE=2
LOCAL_CFLAGS := -Oz -fvisibility=hidden -flto=thin -fstack-protector-strong -D_FORTIFY_SOURCE=2
LOCAL_LDFLAGS := -flto=thin -Wl,--gc-sections -Wl,--strip-all -Wl,-z,max-page-size=16384 -Wl,-z,relro -Wl,-z,now -Wl,-z,noexecstack
LOCAL_LDLIBS := -ldl  -lz -llog -landroid -lEGL -lGLESv3 -laaudio
include $(BUILD_SHARED_LIBRARY)

