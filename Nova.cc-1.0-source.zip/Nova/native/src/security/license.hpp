#pragma once
#include "../../vendor/monocypher/monocypher-ed25519.h"
#include <array>
#include <string>
#include <cstring>
#include <ctime>
namespace dof_license {
enum Feature:uint32_t { Visual=1,Aim=2,World=4,Camera=8,Automation=16,All=31 };
inline int nibble(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1;}
inline bool unhex(const std::string& text,uint8_t* out,size_t size){if(text.size()!=size*2)return false;for(size_t i=0;i<size;++i){int a=nibble(text[i*2]),b=nibble(text[i*2+1]);if(a<0||b<0)return false;out[i]=uint8_t(a*16+b);}return true;}
}
