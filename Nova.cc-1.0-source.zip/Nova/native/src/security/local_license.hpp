#pragma once
#include "license.hpp"
#include "local_key_core.hpp"
namespace nova_license {inline bool verify(const std::string& value){return verify_bytes(value.data(),value.size());}}
