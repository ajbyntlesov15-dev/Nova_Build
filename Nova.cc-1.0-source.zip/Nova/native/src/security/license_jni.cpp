#include "local_license.hpp"
#include <jni.h>
extern "C" JNIEXPORT jboolean JNICALL Java_cc_nova_oxide_LicenseBridge_localCheck(JNIEnv* e,jclass,jstring input){
 if(!input||e->GetStringUTFLength(input)>128)return false;
 const char* p=e->GetStringUTFChars(input,nullptr);if(!p)return false;
 std::string key(p);e->ReleaseStringUTFChars(input,p);return nova_license::verify(key);
}
