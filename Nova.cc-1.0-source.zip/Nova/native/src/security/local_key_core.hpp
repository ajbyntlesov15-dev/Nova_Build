#pragma once
#include "../../vendor/monocypher/monocypher-ed25519.h"
#include "nova_keys_generated.hpp"
#include <stddef.h>
namespace nova_license {
inline bool verify_bytes(const char* value,size_t size){
 if(!value)return false;
 if(size&&value[size-1]=='\n')--size;
 if(size!=37)return false;
 const char prefix[]="NOVA-";for(unsigned i=0;i<5;++i)if(value[i]!=prefix[i])return false;
 for(size_t i=5;i<size;++i)if(!((value[i]>='0'&&value[i]<='9')||(value[i]>='A'&&value[i]<='F')))return false;
 unsigned char hash[64]{};crypto_sha512(hash,reinterpret_cast<const unsigned char*>(value),size);
 unsigned match=0;
 for(const auto& allowed:hashes){unsigned diff=0;for(size_t i=0;i<64;++i)diff|=hash[i]^allowed[i];match|=unsigned(diff==0);}
 return match!=0;
}
}
