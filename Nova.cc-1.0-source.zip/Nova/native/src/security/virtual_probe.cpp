#include <jni.h>
#include "../runtime/live.hpp"

extern "C" JNIEXPORT jstring JNICALL
Java_cc_nova_oxide_LicenseBridge_probeVirtual(JNIEnv* env,jclass,jboolean beta){
    oxide::Live probe;
    const auto& profile=oxide_profile::current;
    auto result=probe.inspect_direct("com.catsbit.oxidesurvivalisland",profile);
    return env->NewStringUTF(result.c_str());
}
