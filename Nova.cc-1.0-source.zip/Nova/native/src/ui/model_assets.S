.section .rodata
.balign 16
.global dof_patrick, dof_patrick_end, dof_spongebob, dof_spongebob_end
.hidden dof_patrick, dof_patrick_end, dof_spongebob, dof_spongebob_end
dof_patrick:
.incbin "patrick.dfmodel"
dof_patrick_end:
.balign 16
dof_spongebob:
.incbin "spongebob.dfmodel"
dof_spongebob_end:
.section .note.GNU-stack,"",%progbits
