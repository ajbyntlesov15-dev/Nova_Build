#pragma once
#include <stddef.h>
#include <stdint.h>

// Check SFNT/TTC bounds before passing optional device data to stb_truetype.
// SFNT table offsets are absolute from the beginning of the file, also in TTC.
static inline uint16_t oxide_font_u16(const unsigned char* p){return (uint16_t)((p[0]<<8)|p[1]);}
static inline uint32_t oxide_font_u32(const unsigned char* p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static inline int oxide_font_sfnt_offset(const void* memory,size_t size,unsigned font_index){
 if(!memory||size<12||size>64u*1024u*1024u)return -1;
 const unsigned char* data=(const unsigned char*)memory;size_t offset=0;
 if(oxide_font_u32(data)==0x74746366u){
  if(size<16)return -1;
  uint32_t version=oxide_font_u32(data+4),count=oxide_font_u32(data+8);
  if((version!=0x00010000u&&version!=0x00020000u)||count==0||count>256||font_index>=count||12u+count*4u>size)return -1;
  offset=oxide_font_u32(data+12+font_index*4u);
 }else if(font_index!=0)return -1;
 if(offset>size-12)return -1;
 uint32_t tag=oxide_font_u32(data+offset);
 if(tag!=0x00010000u&&tag!=0x4f54544fu&&tag!=0x74727565u&&tag!=0x74797031u)return -1;
 unsigned tables=oxide_font_u16(data+offset+4);
 if(tables==0||tables>4096||tables>(size-offset-12)/16)return -1;
 unsigned required=0;int glyf=0,loca=0,cff=0;
 for(unsigned i=0;i<tables;++i){
  const unsigned char* entry=data+offset+12+i*16;
  uint32_t name=oxide_font_u32(entry),start=oxide_font_u32(entry+8),length=oxide_font_u32(entry+12);
  if(start>size||length>size-start)return -1;
  if(name==0x636d6170u){if(length<4)return -1;unsigned count=oxide_font_u16(data+start+2);if(count>(length-4)/8)return -1;for(unsigned j=0;j<count;++j){uint32_t sub=oxide_font_u32(data+start+4+j*8+4);if(sub>length-2)return -1;}required|=1;}
  if(name==0x68656164u){if(length<54)return -1;required|=2;}
  if(name==0x68686561u){if(length<36)return -1;required|=4;}
  if(name==0x686d7478u){if(length<4)return -1;required|=8;}
  if(name==0x6d617870u){if(length<6)return -1;required|=16;}
  if(name==0x676c7966u&&length)glyf=1;
  if(name==0x6c6f6361u&&length)loca=1;
  if(name==0x43464620u&&length)cff=1;
 }
 // CFF2-only variable fonts are not supported by this stb_truetype backend.
 if(required!=31||(!cff&&!(glyf&&loca)))return -1;
 return (int)offset;
}
