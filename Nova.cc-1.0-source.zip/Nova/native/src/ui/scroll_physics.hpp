#pragma once
namespace dof_menu {
inline float scroll_abs(float value){return value<0?-value:value;}
inline float scroll_clamp(float value,float lo,float hi){return value<lo?lo:value>hi?hi:value;}
struct ScrollMotion {
 float velocity=0;
 // Pending taps become either vertical list scrolling or horizontal control drags.
 int axis=0;
 void reset(){velocity=0;axis=0;}
 int direction(float x,float y){
  if(!axis){float ax=scroll_abs(x),ay=scroll_abs(y);if(ay>=10&&ay>=ax*.9f)axis=1;else if(ax>=10&&ax>ay*1.2f)axis=2;}
  return axis;
 }
 void sample(float pixels,float dt,bool first){
  if(dt<=0||dt!=dt)return;float target=scroll_clamp(pixels/dt,-2600,2600);
  float weight=dt/(.025f+dt);velocity=first?target:velocity+(target-velocity)*weight;
 }
 // Exact constant-deceleration integration: same fling distance at 30/60/120 Hz.
 float step(float dt){
  if(dt<=0||dt!=dt||velocity==0)return 0;dt=scroll_clamp(dt,0,.05f);
  const float sign=velocity<0?-1.f:1.f,deceleration=5800.f;
  float stop=scroll_abs(velocity)/deceleration;if(dt>stop)dt=stop;
  float distance=velocity*dt-sign*deceleration*dt*dt*.5f;
  velocity-=sign*deceleration*dt;if(scroll_abs(velocity)<.01f)velocity=0;
  return distance;
 }
};
}
