#pragma once
#include "imgui.h"

#include <cstdio>
#include <algorithm>
#include <cmath>

// DrawRadialGradientEsp and accentColor are defined in antilose_compat.cpp



// ────────────────────────────────────────────────────────────────────────────
//  Nova watermark  —  zenin-style redesign
//  Layout: [N] Nova.cc | icon label | icon label | icon label | icon label
//  Icons drawn with ImDrawList primitives (no font needed)
// ────────────────────────────────────────────────────────────────────────────

namespace oxide_watermark {
namespace wm_icons {

static inline void draw_tag(ImDrawList* dl, ImVec2 pos, float sz, ImU32 col, float th) {
    const float x = pos.x, y = pos.y;
    const ImVec2 pts[] = {
        ImVec2(x + sz*.16f, y + sz*.18f), ImVec2(x + sz*.53f, y + sz*.18f),
        ImVec2(x + sz*.87f, y + sz*.52f), ImVec2(x + sz*.53f, y + sz*.87f),
        ImVec2(x + sz*.16f, y + sz*.53f), ImVec2(x + sz*.16f, y + sz*.18f)
    };
    dl->AddPolyline(pts, 6, col, ImDrawFlags_None, th);
    dl->AddCircleFilled(ImVec2(x + sz*.33f, y + sz*.33f), sz*.065f, col);
}

static inline void draw_globe(ImDrawList* dl, ImVec2 pos, float sz, ImU32 col, float th) {
    ImVec2 c(pos.x + sz*.5f, pos.y + sz*.5f);
    float  r = sz*.41f;
    dl->AddCircle(c, r, col, 32, th);
    dl->AddLine(ImVec2(c.x - r, c.y), ImVec2(c.x + r, c.y), col, th*.75f);
    dl->AddEllipse(c, sz*.20f, r, col, 0.f, 32, th*.75f);
    dl->AddLine(ImVec2(c.x - sz*.34f, c.y - sz*.19f), ImVec2(c.x + sz*.34f, c.y - sz*.19f), col, th*.6f);
    dl->AddLine(ImVec2(c.x - sz*.34f, c.y + sz*.19f), ImVec2(c.x + sz*.34f, c.y + sz*.19f), col, th*.6f);
}

static inline void draw_git(ImDrawList* dl, ImVec2 pos, float sz, ImU32 col, float th) {
    const float x = pos.x, y = pos.y;
    dl->AddLine(ImVec2(x + sz*.28f, y + sz*.19f), ImVec2(x + sz*.28f, y + sz*.75f), col, th);
    const ImVec2 pts[] = {
        ImVec2(x + sz*.28f, y + sz*.48f), ImVec2(x + sz*.47f, y + sz*.48f),
        ImVec2(x + sz*.70f, y + sz*.31f), ImVec2(x + sz*.70f, y + sz*.19f)
    };
    dl->AddPolyline(pts, 4, col, ImDrawFlags_None, th);
    dl->AddCircle(ImVec2(x + sz*.28f, y + sz*.19f), sz*.10f, col, 20, th);
    dl->AddCircle(ImVec2(x + sz*.70f, y + sz*.19f), sz*.10f, col, 20, th);
    dl->AddCircle(ImVec2(x + sz*.28f, y + sz*.75f), sz*.10f, col, 20, th);
}

static inline void draw_monitor(ImDrawList* dl, ImVec2 pos, float sz, ImU32 col, float th) {
    const float x = pos.x, y = pos.y;
    dl->AddRect(ImVec2(x + sz*.05f, y + sz*.08f), ImVec2(x + sz*.95f, y + sz*.70f), col, sz*.03f, 0, th);
    dl->AddLine(ImVec2(x + sz*.5f, y + sz*.70f), ImVec2(x + sz*.5f, y + sz*.84f), col, th);
    dl->AddLine(ImVec2(x + sz*.32f, y + sz*.89f), ImVec2(x + sz*.68f, y + sz*.89f), col, th);
}

} // namespace wm_icons

inline void draw_actor_badge(float width,int percent,size_t players,size_t bots,ImVec4 accent) {
    const float scale=std::clamp(width/1920.f,.70f,1.35f)*percent*.01f;
    const float height=32.f*scale,pad=11.f*scale,icon=14.f*scale,gap=6.f*scale;
    const float font=13.f*scale;
    char labels[2][24];
    snprintf(labels[0],sizeof(labels[0]),"%zu",players);
    snprintf(labels[1],sizeof(labels[1]),"%zu",bots);
    auto* face=ImGui::GetFont();
    float widths[2];
    for(int i=0;i<2;++i)widths[i]=face->CalcTextSizeA(font,FLT_MAX,0,labels[i]).x;
    const float total=pad*3+2*(icon+gap)+widths[0]+widths[1];
    const ImVec2 pos{(width-total)*.5f,10.f*scale};
    const ImVec2 end{pos.x+total,pos.y+height};
    auto* draw=ImGui::GetForegroundDrawList();
    draw->AddRectFilled(pos,end,IM_COL32(15,17,23,219),8.f*scale);
    draw->AddRect(pos,end,IM_COL32(119,127,149,96),8.f*scale);
    const ImU32 tint=ImGui::ColorConvertFloat4ToU32(accent);
    const float x=pos.x+pad,y=pos.y+(height-icon)*.5f;
    draw->AddCircleFilled({x+icon*.5f,y+icon*.27f},icon*.18f,tint);
    draw->AddRectFilled({x+icon*.15f,y+icon*.52f},{x+icon*.85f,y+icon*.94f},tint,3.f*scale);
    const float robot=x+icon+gap+widths[0]+pad;
    draw->AddLine({robot-pad*.5f,y},{robot-pad*.5f,y+icon},IM_COL32(119,127,149,110));
    draw->AddRect({robot+icon*.1f,y+icon*.25f},{robot+icon*.9f,y+icon*.93f},tint,2.f*scale);
    draw->AddLine({robot+icon*.5f,y},{robot+icon*.5f,y+icon*.25f},tint,scale);
    for(float eye:{.34f,.66f})draw->AddCircleFilled({robot+icon*eye,y+icon*.57f},1.1f*scale,tint);
    const float ty=pos.y+(height-font)*.5f;
    draw->AddText(face,font,{x+icon+gap,ty},IM_COL32(237,237,241,255),labels[0]);
    draw->AddText(face,font,{robot+icon+gap,ty},IM_COL32(237,237,241,255),labels[1]);
}

class Watermark {
public:
    void Render(ImVec4 accentColor,ImTextureID logo=nullptr) {
        ImGuiIO& io   = ImGui::GetIO();

        ImDrawList* dl = ImGui::GetForegroundDrawList();

        // ── Scale to display ──────────────────────────────────────────────────
        const float sc        = (io.DisplaySize.x / 1920.f) * 1.0f;  // smaller watermark
        const float h         = 34.f * sc;
        const float rx        = 12.f * sc;
        const float ry        = 10.f * sc;
        const float pad       = 12.f * sc;
        const float text_sz   = 11.5f * sc;
        const float divider_h = 18.f * sc;
        const float icon_sz   = 13.f * sc;
        const float icon_gap  = 5.f  * sc;
        const float div_gap   = 10.f * sc;
        const float item_gap  = 5.f  * sc;
        const float logo_sz   = 20.f * sc;

        // ── Accent: taken from menu accent (set via accentColor) ──────────────
        const ImU32 col_accent = IM_COL32(
            (int)(accentColor.x * 255.f),
            (int)(accentColor.y * 255.f),
            (int)(accentColor.z * 255.f),
            255);
        const ImU32 col_blue  = IM_COL32(89, 108, 255, 255);
        const ImU32 col_gray  = IM_COL32(200, 203, 208, 255);
        const ImU32 col_text  = IM_COL32(237, 237, 238, 255);

        // ── Labels ────────────────────────────────────────────────────────────
        char fps_buf[40];
        snprintf(fps_buf,sizeof(fps_buf),"Overlay %.0f FPS",io.Framerate);
        const char* labels[] = { "Nova.cc", "Oxide", fps_buf, "External" };

        // ── Measure total width ───────────────────────────────────────────────
        float content_w = logo_sz + pad + pad;  // logo + left/right padding
        ImVec2 label_sizes[4];
        for (int i = 0; i < 4; i++) {
            ImVec2 ts = ImGui::CalcTextSize(labels[i]);
            label_sizes[i] = ts;
            content_w += div_gap + icon_sz + icon_gap + ts.x + item_gap;
        }

        // ── Background ───────────────────────────────────────────────────────
        dl->AddRectFilled(
            ImVec2(rx,       ry),
            ImVec2(rx + content_w, ry + h),
            IM_COL32(4, 5, 8, 242), 14.f * sc);
        dl->AddRect(
            ImVec2(rx,       ry),
            ImVec2(rx + content_w, ry + h),
            IM_COL32(255, 255, 255, 18), 14.f * sc, 0, 1.f * sc);

        float cur_x = rx + pad;

        // ── Logo: dark circle + letter "N" ────────────────────────────────────
        {
            ImVec2 lp(cur_x, ry + (h - logo_sz) * .5f);
            ImVec2 lc(lp.x + logo_sz * .5f, lp.y + logo_sz * .5f);
            if(logo)dl->AddImageRounded(logo,lp,{lp.x+logo_sz,lp.y+logo_sz},{0,0},{1,1},IM_COL32_WHITE,4.f*sc);
            else{const char* mark="N";auto size=ImGui::CalcTextSize(mark);dl->AddText({lc.x-size.x*.5f,lc.y-size.y*.5f},col_accent,mark);}
            cur_x += logo_sz + pad * .5f;
        }

        // ── 4 sections: divider | icon  label ────────────────────────────────
        for (int i = 0; i < 4; i++) {
            // vertical divider
            dl->AddLine(
                ImVec2(cur_x, ry + (h - divider_h) * .5f),
                ImVec2(cur_x, ry + (h + divider_h) * .5f),
                IM_COL32(255, 255, 255, 45), 1.f * sc);
            cur_x += div_gap;

            // icon color: i0=accent, i1=blue, i2=accent, i3=gray
            const ImU32 ic_col = (i == 1) ? col_blue : (i == 3 ? col_gray : col_accent);
            ImVec2 icon_pos(cur_x, ry + (h - icon_sz) * .5f);
            const float th_ic  = 1.25f * sc;

            if (i == 0) wm_icons::draw_tag    (dl, icon_pos, icon_sz, ic_col, th_ic);
            if (i == 1) wm_icons::draw_globe   (dl, icon_pos, icon_sz, ic_col, th_ic);
            if (i == 2) wm_icons::draw_git     (dl, icon_pos, icon_sz, ic_col, th_ic);
            if (i == 3) wm_icons::draw_monitor (dl, icon_pos, icon_sz, ic_col, th_ic);
            cur_x += icon_sz + icon_gap;

            // label text
            dl->AddText(
                ImVec2(cur_x, ry + (h - label_sizes[i].y) * .5f),
                col_text, labels[i]);
            cur_x += label_sizes[i].x + item_gap;
        }
    }
};

} // namespace oxide_watermark
