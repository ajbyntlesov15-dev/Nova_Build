#include "../runtime/container_box.hpp"
#include "../runtime/weapon_names.hpp"
#pragma once
#include "imgui.h"
#include "imgui_internal.h"
#include "../runtime/core.hpp"
#include "../runtime/visibility.hpp"
#include "../runtime/world.hpp"
#include "../runtime/automation.hpp"
#include <fstream>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <unordered_set>
#include "languages.hpp"
#include "watermark.hpp"
#include "menu_widgets.hpp"
#include "touch_scroll.hpp"
#include <fcntl.h>
#include <unistd.h>
namespace ui {
inline bool hide_overlay_requested=false;inline std::string touch_input_status;inline bool opened=true,exit_requested=false;inline int recorder_action=0;inline bool recorder_ui_active=false;inline bool record_fresh=false;inline int record_state=0,record_width=0,record_height=0,record_fps=0;inline long long record_seconds=0;inline uintptr_t avatar=0;
#define OX_BOOLS(X) X(nonroot_full_visuals) X(trigger_ignore_team) X(trigger_ignore_clan) X(trigger_animals) X(trigger_bots) X(silent_visibility) X(silent_animals) X(silent_bots) X(silent_ignore_team) X(silent_ignore_clan) X(silent_predict) X(silent_sticky) X(silent_draw_fov) X(silent_marker) X(touch_visibility) X(touch_animals) X(touch_bots) X(touch_ignore_team) X(touch_ignore_clan) X(touch_predict) X(touch_sticky) X(touch_draw_fov) X(touch_marker) X(aim360_visibility) X(aim360_animals) X(aim360_bots) X(aim360_ignore_team) X(aim360_ignore_clan) X(aim360_predict) X(aim360_sticky) X(aim360_draw_fov) X(aim360_marker) X(vip_predict) X(aim_visibility) X(vip_box_glow) X(vip_chams_glow) X(vip_hit_mark) X(vip_kill_sound) X(vip_touch_aim) X(vip_silent) X(vip_aim_360) X(vip_chams) X(vip_autoheal) X(vip_build_hp) X(vip_recoil) X(vip_melee) X(vip_tracers) X(vip_daylight) X(vip_home_search) X(vip_player_outline) X(vip_loot_outline) X(name_background) X(distance_background) X(actor_badge) X(armor) X(death_loot) X(unlock_fps) X(menu_animations) X(menu_dim_background) X(spin) X(movement_boost) X(player_arrows) X(player_clan) X(player_status) X(hide_allies) X(bot_lines) X(bot_rig) X(bot_names) X(bot_distance) X(bot_arrows) X(world_distance) X(sticky_aim) X(aim_marker) X(no_spread) X(fast_switch) X(fast_draw) X(ignore_team) X(ignore_clan) X(sky_tint) X(aim_animals) X(aim_bots) X(no_sway) X(fast_reload) X(rapid_fire) X(hand_position) X(trigger) X(trigger_ads) X(container_boxes) X(cupboard_boxes) X(box) X(name) X(health) X(distance) X(lines) X(skeleton) X(weapon) X(small) X(large) X(cupboard) X(rgb) X(aim) X(no_recoil) X(draw_fov) X(freecam) X(debug) X(watermark) X(free_button) X(custom_fov) X(thirdperson) X(sulfur) X(stone) X(metal) X(barrels) X(wood) X(highmetal) X(animals) X(autofarm) X(quickloot) X(calibration) X(always_day) X(farm_sulfur) X(farm_stone) X(farm_metal) X(farm_barrels) X(farm_wood) X(farm_highmetal) X(bots) X(vehicles) X(sleepers) X(turrets)
#define OX_INTS(X) X(ui_revision) X(tracer_length) X(tracer_lifetime) X(tracer_width) X(trigger_distance) X(heal_threshold) X(heal_interval) X(silent_fov) X(silent_distance) X(silent_bone) X(silent_mode) X(silent_activation) X(silent_smooth) X(silent_lead_ms) X(touch_fov) X(touch_distance) X(touch_bone) X(touch_mode) X(touch_activation) X(touch_smooth) X(touch_lead_ms) X(aim360_fov) X(aim360_distance) X(aim360_bone) X(aim360_mode) X(aim360_activation) X(aim360_smooth) X(aim360_lead_ms) X(aim_area_ax) X(aim_area_ay) X(aim_area_bx) X(aim_area_by) X(aim_touch_gain) X(heal_slot_x) X(heal_slot_y) X(heal_use_x) X(heal_use_y) X(vip_lead_ms) X(vip_animals) X(snow_size) X(snow_speed) X(caption_transparency) X(actor_badge_scale) X(line_origin) X(fps_limit) X(menu_animation_percent) X(spin_speed) X(player_model) X(movement_percent) X(arrow_radius) X(world_limit) X(world_range) X(world_mode) X(day_hour) X(box_style) X(line_weight) X(menu_scale) X(menu_opacity) X(menu_x) X(menu_y) X(fire_multiplier) X(hand_x) X(hand_y) X(hand_z) X(trigger_delay) X(trigger_interval) X(max_distance) X(aim_distance) X(fov) X(smooth) X(target_bone) X(target_mode) X(free_speed) X(scrollbar) X(menu_theme) X(open_method) X(activation) X(recoil_x) X(recoil_y) X(language) X(camera_fov) X(third_distance) X(third_height) X(third_shoulder) X(watermark_style) X(joy_x) X(joy_y) X(joy_radius) X(look_x) X(look_y) X(hit_x) X(hit_y) X(turn_scale) X(farm_reach)
inline constexpr int aim_area_width=10,aim_area_height=12;
struct Settings{bool nonroot_full_visuals=false;int ui_revision=90;int tracer_length=200,tracer_lifetime=1500,tracer_width=20;bool trigger_ignore_team=true,trigger_ignore_clan=true,trigger_animals=false,trigger_bots=false;int trigger_distance=300,heal_threshold=100,heal_interval=1800;bool silent_visibility=false,silent_animals=false,silent_bots=false,silent_ignore_team=true,silent_ignore_clan=true,silent_predict=false,silent_sticky=false,silent_draw_fov=false,silent_marker=false;int silent_fov=60,silent_distance=300,silent_bone=0,silent_mode=0,silent_activation=1,silent_smooth=1,silent_lead_ms=0;bool touch_visibility=false,touch_animals=false,touch_bots=false,touch_ignore_team=true,touch_ignore_clan=true,touch_predict=false,touch_sticky=false,touch_draw_fov=false,touch_marker=false;int touch_fov=60,touch_distance=300,touch_bone=0,touch_mode=0,touch_activation=1,touch_smooth=1,touch_lead_ms=0;bool aim360_visibility=false,aim360_animals=false,aim360_bots=false,aim360_ignore_team=true,aim360_ignore_clan=true,aim360_predict=false,aim360_sticky=false,aim360_draw_fov=false,aim360_marker=false;int aim360_fov=60,aim360_distance=300,aim360_bone=0,aim360_mode=0,aim360_activation=1,aim360_smooth=1,aim360_lead_ms=0;bool vip_predict=false;bool aim_visibility=false;bool vip_box_glow=false,vip_chams_glow=false,vip_hit_mark=false,vip_kill_sound=false;bool vip_touch_aim=false,vip_aim_360=false,vip_silent=false;int aim_area_ax=66,aim_area_ay=35,aim_area_bx=76,aim_area_by=47,aim_touch_gain=20;bool vip_chams=false;bool vip_autoheal=false;int heal_slot_x=0,heal_slot_y=0,heal_use_x=0,heal_use_y=0;bool vip_build_hp=false,vip_recoil=false,vip_melee=false;bool vip_tracers=false,vip_daylight=false;bool vip_home_search=false;int vip_lead_ms=0;bool vip_player_outline=false,vip_loot_outline=false;int vip_animals=127;int snow_size=180,snow_speed=100;bool name_background=true,distance_background=true;int caption_transparency=50;
 bool actor_badge=true;int actor_badge_scale=150,line_origin=0;
 bool armor=true,death_loot=true,unlock_fps=false;int fps_limit=144;
 bool menu_animations=true,menu_dim_background=true;
 int menu_animation_percent=100;
bool spin=false;int spin_speed=180,player_model=0;
bool movement_boost=false;int movement_percent=130;
 bool player_arrows=false,player_clan=false,player_status=false,hide_allies=false;
 bool bot_lines=false,bot_rig=false,bot_names=true,bot_distance=true,bot_arrows=false;
 bool world_distance=true,sticky_aim=false,aim_marker=false;
 int arrow_radius=160,world_limit=40,world_range=350,world_mode=2;bool no_spread=false,fast_switch=false,fast_draw=false;int day_hour=12,box_style=0,line_weight=15;int menu_scale=100,menu_opacity=100,menu_x=50,menu_y=50;bool ignore_team=true,ignore_clan=true;bool sky_tint=false;bool aim_animals=false,aim_bots=false,no_sway=false,fast_reload=false,rapid_fire=false,hand_position=false,trigger=false,trigger_ads=true;int fire_multiplier=2,hand_x=100,hand_y=100,hand_z=100,trigger_delay=0,trigger_interval=150;bool container_boxes=false,cupboard_boxes=false;ImVec2 free_position{.92f,.19f};bool bots=true,vehicles=true,sleepers=true,turrets=true;bool always_day=false,farm_sulfur=true,farm_stone=true,farm_metal=true,farm_barrels=true,farm_wood=true,farm_highmetal=true;int third_height=40,third_shoulder=40,watermark_style=1;ImVec2 points[3]={{-1,-1},{-1,-1},{-1,-1}};bool free_button=true,custom_fov=false,thirdperson=false,sulfur=true,stone=true,metal=true,barrels=true,wood=true,highmetal=true,animals=false,autofarm=false,quickloot=false,calibration=false;int camera_fov=90,third_distance=300,joy_x=16,joy_y=75,joy_radius=6,look_x=66,look_y=48,hit_x=88,hit_y=55,turn_scale=35,farm_reach=25;bool box=true,name=true,health=true,distance=true,lines=false,skeleton=false,weapon=true,small=true,large=true,cupboard=true,rgb=false,aim=false,no_recoil=false,draw_fov=false,freecam=false,debug=false,watermark=true;int max_distance=350,aim_distance=300,fov=60,smooth=1,target_bone=0,target_mode=0,free_speed=4,scrollbar=14,menu_theme=0,open_method=1,activation=1,recoil_x=100,recoil_y=100,language=9;ImVec4 colors[25]={{.2f,.85f,1,1},{1,1,1,1},{.2f,1,.2f,1},{1,.25f,.2f,1},{1,.8f,.2f,1},{.3f,1,.6f,1},{1,.5f,.2f,1},{.7f,.5f,1,1},{.96f,.9f,.25f,1},{.8f,.8f,.84f,1},{.43f,.7f,.92f,1},{.96f,.59f,.27f,1},{.35f,.86f,.41f,1},{.86f,.53f,1,1},{1,.55f,.59f,1},{1,.45f,.2f,1},{.4f,.85f,1,1},{1,.2f,.4f,1},{.65f,.65f,.85f,1},{.2f,.3f,.6f,1},{.2f,.95f,.3f,1},{1,.2f,.25f,1},{.65f,.65f,.7f,1},{1.f,.58f,.2f,1.f},{.3f,.68f,1.f,1.f}};};
inline bool vip_mode=false;
inline int tracked_pid=0;
inline uint64_t tracked_identity=0;
inline uint32_t tracked_id=0;
inline constexpr const char* vip_species[]={"Медведь","Кабан","Волк","Олень","Заяц","Курица","Животное"};
inline bool tracked(const oxide::Frame& frame,const oxide::Actor& actor){
 return vip_mode&&tracked_identity&&frame.pid==tracked_pid&&actor.identity==tracked_identity&&actor.id==tracked_id;
}
inline Settings cfg;inline ImGuiID scroll_toggle=0;inline std::string config_path,config_message;inline int tab=0;inline float menu_alpha=1;
inline void fixed_settings(Settings& v){
 v.caption_transparency=50;v.actor_badge_scale=150;v.player_status=false;v.always_day=false;v.menu_scale=100;v.menu_theme=0;v.watermark_style=1;v.menu_animations=true;v.menu_animation_percent=100;v.trigger_delay=0;v.trigger_interval=0;v.actor_badge=true;v.arrow_radius=160;v.turn_scale=35;v.farm_reach=25;
 v.sticky_aim=v.silent_sticky=v.touch_sticky=v.aim360_sticky=false;v.aim_marker=v.silent_marker=v.touch_marker=v.aim360_marker=false;
 v.aim_distance=std::clamp(v.aim_distance,10,350);v.silent_distance=std::clamp(v.silent_distance,10,350);v.touch_distance=std::clamp(v.touch_distance,10,350);v.aim360_distance=std::clamp(v.aim360_distance,10,350);v.trigger_distance=std::clamp(v.trigger_distance,10,350);
}
inline const char* tr(const char* key){return oxide_ui_strings::translated(key,cfg.language);}
inline const char* label(const char* key){static thread_local std::string out;out=tr(key);out+="###";out+=key;return out.c_str();}

struct AimControls{bool visibility,animals,bots,ignore_team,ignore_clan,predict,sticky,draw_fov,marker;int fov,distance,bone,mode,activation,smooth,lead_ms;};
inline int aim_kind(){return vip_mode&&cfg.vip_silent?1:vip_mode&&cfg.vip_touch_aim?2:vip_mode&&cfg.vip_aim_360?3:0;}
inline void enable_aim_kind(int kind,bool enabled){if(!enabled)return;cfg.aim=kind==0;cfg.vip_silent=kind==1;cfg.vip_touch_aim=kind==2;cfg.vip_aim_360=kind==3;}
inline AimControls aim_controls(int kind){
 if(kind==1)return {cfg.silent_visibility,cfg.silent_animals,cfg.silent_bots,cfg.silent_ignore_team,cfg.silent_ignore_clan,cfg.silent_predict,cfg.silent_sticky,cfg.silent_draw_fov,cfg.silent_marker,cfg.silent_fov,cfg.silent_distance,cfg.silent_bone,cfg.silent_mode,cfg.silent_activation,cfg.silent_smooth,cfg.silent_lead_ms};
 if(kind==2)return {cfg.touch_visibility,cfg.touch_animals,cfg.touch_bots,cfg.touch_ignore_team,cfg.touch_ignore_clan,cfg.touch_predict,cfg.touch_sticky,cfg.touch_draw_fov,cfg.touch_marker,cfg.touch_fov,cfg.touch_distance,cfg.touch_bone,cfg.touch_mode,cfg.touch_activation,cfg.touch_smooth,cfg.touch_lead_ms};
 if(kind==3)return {cfg.aim360_visibility,cfg.aim360_animals,cfg.aim360_bots,cfg.aim360_ignore_team,cfg.aim360_ignore_clan,cfg.aim360_predict,cfg.aim360_sticky,cfg.aim360_draw_fov,cfg.aim360_marker,cfg.aim360_fov,cfg.aim360_distance,cfg.aim360_bone,cfg.aim360_mode,cfg.aim360_activation,cfg.aim360_smooth,cfg.aim360_lead_ms};
 return {cfg.aim_visibility,cfg.aim_animals,cfg.aim_bots,cfg.ignore_team,cfg.ignore_clan,cfg.vip_predict,cfg.sticky_aim,cfg.draw_fov,cfg.aim_marker,cfg.fov,cfg.aim_distance,cfg.target_bone,cfg.target_mode,cfg.activation,cfg.smooth,cfg.vip_lead_ms};
}
inline AimControls active_aim_controls(){return aim_controls(aim_kind());}
inline void store_aim_controls(int kind,const AimControls& v){
 if(kind==1){cfg.silent_visibility=v.visibility;cfg.silent_animals=v.animals;cfg.silent_bots=v.bots;cfg.silent_ignore_team=v.ignore_team;cfg.silent_ignore_clan=v.ignore_clan;cfg.silent_predict=v.predict;cfg.silent_sticky=v.sticky;cfg.silent_draw_fov=v.draw_fov;cfg.silent_marker=v.marker;cfg.silent_fov=v.fov;cfg.silent_distance=v.distance;cfg.silent_bone=v.bone;cfg.silent_mode=v.mode;cfg.silent_activation=v.activation;cfg.silent_smooth=v.smooth;cfg.silent_lead_ms=v.lead_ms;return;}
 if(kind==2){cfg.touch_visibility=v.visibility;cfg.touch_animals=v.animals;cfg.touch_bots=v.bots;cfg.touch_ignore_team=v.ignore_team;cfg.touch_ignore_clan=v.ignore_clan;cfg.touch_predict=v.predict;cfg.touch_sticky=v.sticky;cfg.touch_draw_fov=v.draw_fov;cfg.touch_marker=v.marker;cfg.touch_fov=v.fov;cfg.touch_distance=v.distance;cfg.touch_bone=v.bone;cfg.touch_mode=v.mode;cfg.touch_activation=v.activation;cfg.touch_smooth=v.smooth;cfg.touch_lead_ms=v.lead_ms;return;}
 if(kind==3){cfg.aim360_visibility=v.visibility;cfg.aim360_animals=v.animals;cfg.aim360_bots=v.bots;cfg.aim360_ignore_team=v.ignore_team;cfg.aim360_ignore_clan=v.ignore_clan;cfg.aim360_predict=v.predict;cfg.aim360_sticky=v.sticky;cfg.aim360_draw_fov=v.draw_fov;cfg.aim360_marker=v.marker;cfg.aim360_fov=v.fov;cfg.aim360_distance=v.distance;cfg.aim360_bone=v.bone;cfg.aim360_mode=v.mode;cfg.aim360_activation=v.activation;cfg.aim360_smooth=v.smooth;cfg.aim360_lead_ms=v.lead_ms;return;}
cfg.aim_visibility=v.visibility;cfg.aim_animals=v.animals;cfg.aim_bots=v.bots;cfg.ignore_team=v.ignore_team;cfg.ignore_clan=v.ignore_clan;cfg.vip_predict=v.predict;cfg.sticky_aim=v.sticky;cfg.draw_fov=v.draw_fov;cfg.aim_marker=v.marker;cfg.fov=v.fov;cfg.aim_distance=v.distance;cfg.target_bone=v.bone;cfg.target_mode=v.mode;cfg.activation=v.activation;cfg.smooth=v.smooth;cfg.vip_lead_ms=v.lead_ms;}
inline bool load(const std::string& path){std::ifstream file(path,std::ios::binary|std::ios::ate);if(!file||file.tellg()<0||file.tellg()>16384)return false;file.seekg(0);std::string magic;if(!std::getline(file,magic)||(magic!="OxideConfig 1"&&magic!="OxideConfig 2"&&magic!="OxideConfig 3"&&magic!="OxideConfig 4"&&magic!="OxideConfig 5"&&magic!="OxideConfig 6"))return false;Settings v;v.ui_revision=0;bool legacy_distance=false;std::string row;bool preset_seen=false;unsigned lines=0;while(std::getline(file,row)){if(++lines>512||row.size()>256)return false;std::istringstream r(row);std::string k;r>>k;if(k.rfind("silent_",0)==0||k.rfind("touch_",0)==0||k.rfind("aim360_",0)==0)preset_seen=true;int n=0;bool known=false;
#define B(key) if(k==#key){if(!(r>>n)||(n!=0&&n!=1))return false;v.key=n!=0;known=true;}
 OX_BOOLS(B)
#undef B
#define I(key) if(k==#key){if(!(r>>n)||n<0||n>10000)return false;v.key=n;known=true;}
 OX_INTS(I)
 if(k=="third_distance")legacy_distance=true;
#undef I
 if(k=="free_position"){float x,y;if(!(r>>x>>y)||!std::isfinite(x)||!std::isfinite(y)||x<0||x>1||y<0||y>1)return false;v.free_position={x,y};known=true;}
 if(k=="point"){int i;float x,y;if(!(r>>i>>x>>y)||i<0||i>7||!std::isfinite(x)||!std::isfinite(y)||x< -1||y< -1||x>100||y>100)return false;if(i<3)v.points[i]={x,y};known=true;}
 if(k=="color"){int i;if(!(r>>i)||i<0||i>24||!(r>>v.colors[i].x>>v.colors[i].y>>v.colors[i].z>>v.colors[i].w))return false;for(float c:{v.colors[i].x,v.colors[i].y,v.colors[i].z,v.colors[i].w})if(!std::isfinite(c)||c<0||c>1)return false;known=true;}if(known){r>>std::ws;if(!r.eof())return false;}}
 for(int* point:{&v.heal_slot_x,&v.heal_slot_y,&v.heal_use_x,&v.heal_use_y})*point=std::clamp(*point,0,100);
 v.aim_touch_gain=std::clamp(v.aim_touch_gain,1,100);
 if(v.aim_area_ax==0&&v.aim_area_ay==0&&v.aim_area_bx==0&&v.aim_area_by==0){
  v.aim_area_ax=66;v.aim_area_ay=35;
 }else{
  v.aim_area_ax=std::clamp(std::min(v.aim_area_ax,v.aim_area_bx),0,100-aim_area_width);
  v.aim_area_ay=std::clamp(std::min(v.aim_area_ay,v.aim_area_by),0,100-aim_area_height);
 }
 v.aim_area_bx=v.aim_area_ax+aim_area_width;
 v.aim_area_by=v.aim_area_ay+aim_area_height;
 v.vip_lead_ms=std::clamp(v.vip_lead_ms,0,180);
 v.vip_animals=std::clamp(v.vip_animals,0,127);
 v.snow_size=std::clamp(v.snow_size,50,300);v.snow_speed=std::clamp(v.snow_speed,25,250);
 v.caption_transparency=std::clamp(v.caption_transparency,0,100);
 v.actor_badge_scale=std::clamp(v.actor_badge_scale,65,250);v.line_origin=std::clamp(v.line_origin,0,1);
 v.fps_limit=std::clamp(v.fps_limit,30,144);
 v.arrow_radius=std::clamp(v.arrow_radius,40,600);v.world_limit=std::clamp(v.world_limit,1,500);v.world_range=std::clamp(v.world_range,20,350);v.world_mode=std::clamp(v.world_mode,0,2);
 v.spin_speed=std::clamp(v.spin_speed,30,720);
 v.player_model=std::clamp(v.player_model,0,2);
 v.movement_percent=std::clamp(v.movement_percent,100,150);
 v.day_hour=std::clamp(v.day_hour,0,23);v.box_style=std::clamp(v.box_style,0,3);v.line_weight=std::clamp(v.line_weight,5,40);
 v.menu_scale=std::clamp(v.menu_scale,70,110);v.menu_opacity=std::clamp(v.menu_opacity,50,100);v.menu_x=std::clamp(v.menu_x,0,100);v.menu_y=std::clamp(v.menu_y,0,100);v.fire_multiplier=std::clamp(v.fire_multiplier,2,5);v.hand_x=std::clamp(v.hand_x,0,200);v.hand_y=std::clamp(v.hand_y,0,200);v.hand_z=std::clamp(v.hand_z,0,200);v.trigger_delay=std::clamp(v.trigger_delay,50,500);v.trigger_interval=std::clamp(v.trigger_interval,80,1000);
 v.vip_recoil=false;v.menu_opacity=100;v.max_distance=std::clamp(v.max_distance,20,350);v.aim_distance=std::clamp(v.aim_distance,10,500);v.fov=std::clamp(v.fov,1,170);v.smooth=std::clamp(v.smooth,1,20);v.target_bone=std::clamp(v.target_bone,0,1);v.target_mode=std::clamp(v.target_mode,0,2);v.free_speed=std::clamp(v.free_speed,1,20);v.scrollbar=std::clamp(v.scrollbar,6,32);v.menu_theme=std::clamp(v.menu_theme,0,11);v.open_method=std::clamp(v.open_method,0,1);v.activation=std::clamp(v.activation,0,2);v.recoil_x=std::clamp(v.recoil_x,0,100);v.recoil_y=std::clamp(v.recoil_y,0,100);v.language=std::clamp(v.language,0,9);if(magic=="OxideConfig 1"&&v.target_mode)v.target_mode=3-v.target_mode;v.camera_fov=std::clamp(v.camera_fov,50,130);if(magic!="OxideConfig 5"&&magic!="OxideConfig 6"&&legacy_distance)v.third_distance*=10;v.third_distance=std::clamp(v.third_distance,100,500);v.third_height=std::clamp(v.third_height,0,100);v.third_shoulder=std::clamp(v.third_shoulder,0,100);v.watermark_style=std::clamp(v.watermark_style,0,1);
 for(int* coordinate:{&v.joy_x,&v.joy_y,&v.look_x,&v.look_y,&v.hit_x,&v.hit_y})*coordinate=std::clamp(*coordinate,1,99);
 v.joy_radius=std::clamp(v.joy_radius,1,15);v.turn_scale=std::clamp(v.turn_scale,5,100);v.farm_reach=std::clamp(v.farm_reach,10,40); if(!preset_seen){
v.silent_visibility=v.aim_visibility; v.silent_animals=v.aim_animals; v.silent_bots=v.aim_bots; v.silent_ignore_team=v.ignore_team; v.silent_ignore_clan=v.ignore_clan; v.silent_predict=v.vip_predict; v.silent_sticky=v.sticky_aim; v.silent_draw_fov=v.draw_fov; v.silent_marker=v.aim_marker; v.silent_fov=v.fov; v.silent_distance=v.aim_distance; v.silent_bone=v.target_bone; v.silent_mode=v.target_mode; v.silent_activation=v.activation; v.silent_smooth=v.smooth; v.silent_lead_ms=v.vip_lead_ms;
v.touch_visibility=v.aim_visibility; v.touch_animals=v.aim_animals; v.touch_bots=v.aim_bots; v.touch_ignore_team=v.ignore_team; v.touch_ignore_clan=v.ignore_clan; v.touch_predict=v.vip_predict; v.touch_sticky=v.sticky_aim; v.touch_draw_fov=v.draw_fov; v.touch_marker=v.aim_marker; v.touch_fov=v.fov; v.touch_distance=v.aim_distance; v.touch_bone=v.target_bone; v.touch_mode=v.target_mode; v.touch_activation=v.activation; v.touch_smooth=v.smooth; v.touch_lead_ms=v.vip_lead_ms;
v.aim360_visibility=v.aim_visibility; v.aim360_animals=v.aim_animals; v.aim360_bots=v.aim_bots; v.aim360_ignore_team=v.ignore_team; v.aim360_ignore_clan=v.ignore_clan; v.aim360_predict=v.vip_predict; v.aim360_sticky=v.sticky_aim; v.aim360_draw_fov=v.draw_fov; v.aim360_marker=v.aim_marker; v.aim360_fov=v.fov; v.aim360_distance=v.aim_distance; v.aim360_bone=v.target_bone; v.aim360_mode=v.target_mode; v.aim360_activation=v.activation; v.aim360_smooth=v.smooth; v.aim360_lead_ms=v.vip_lead_ms;
 }
 v.silent_fov=std::clamp(v.silent_fov,1,170);
 v.silent_distance=std::clamp(v.silent_distance,10,500);
 v.silent_bone=std::clamp(v.silent_bone,0,1);
 v.silent_mode=std::clamp(v.silent_mode,0,2);
 v.silent_activation=std::clamp(v.silent_activation,0,2);
 v.silent_smooth=std::clamp(v.silent_smooth,1,20);
 v.silent_lead_ms=std::clamp(v.silent_lead_ms,1,180);
 v.touch_fov=std::clamp(v.touch_fov,1,170);
 v.touch_distance=std::clamp(v.touch_distance,10,500);
 v.touch_bone=std::clamp(v.touch_bone,0,1);
 v.touch_mode=std::clamp(v.touch_mode,0,2);
 v.touch_activation=std::clamp(v.touch_activation,0,2);
 v.touch_smooth=std::clamp(v.touch_smooth,1,20);
 v.touch_lead_ms=std::clamp(v.touch_lead_ms,1,180);
 v.aim360_fov=std::clamp(v.aim360_fov,1,170);
 v.aim360_distance=std::clamp(v.aim360_distance,10,500);
 v.aim360_bone=std::clamp(v.aim360_bone,0,1);
 v.aim360_mode=std::clamp(v.aim360_mode,0,2);
 v.aim360_activation=std::clamp(v.aim360_activation,0,2);
 v.aim360_smooth=std::clamp(v.aim360_smooth,1,20);
 v.aim360_lead_ms=std::clamp(v.aim360_lead_ms,1,180);
 if(v.vip_silent){v.aim=false;v.vip_touch_aim=v.vip_aim_360=false;}else if(v.vip_aim_360){v.aim=false;v.vip_touch_aim=false;}else if(v.vip_touch_aim)v.aim=false;
v.trigger_distance=std::clamp(v.trigger_distance,10,500);v.heal_threshold=std::clamp(v.heal_threshold,1,100);v.heal_interval=std::clamp(v.heal_interval,500,5000);v.tracer_length=std::clamp(v.tracer_length,10,500);v.tracer_lifetime=std::clamp(v.tracer_lifetime,100,3000);v.tracer_width=std::clamp(v.tracer_width,5,40);if(v.ui_revision<90){v.smooth=v.silent_smooth=v.touch_smooth=v.aim360_smooth=1;v.language=9;v.vip_lead_ms=v.silent_lead_ms=v.touch_lead_ms=v.aim360_lead_ms=0;}v.ui_revision=90;fixed_settings(v);cfg=v;return true;}
inline std::string encoded(){fixed_settings(cfg);std::ostringstream out;out<<std::setprecision(9);out<<"OxideConfig 6\n";
#define E(key) out<<#key<<' '<<cfg.key<<'\n';
 OX_BOOLS(E) OX_INTS(E)
#undef E
 out<<"free_position "<<cfg.free_position.x<<' '<<cfg.free_position.y<<'\n';
 for(unsigned i=0;i<3;++i)out<<"point "<<i<<' '<<cfg.points[i].x<<' '<<cfg.points[i].y<<'\n';
 for(unsigned i=0;i<25;++i){auto c=cfg.colors[i];out<<"color "<<i<<' '<<c.x<<' '<<c.y<<' '<<c.z<<' '<<c.w<<'\n';}return out.str();}
inline bool save(const std::string& path){auto data=encoded();std::string temp=path+".XXXXXX";int fd=mkstemp(&temp[0]);if(fd<0)return false;size_t done=0;while(done<data.size()){ssize_t n=write(fd,data.data()+done,data.size()-done);if(n<0&&errno==EINTR)continue;if(n<=0){close(fd);unlink(temp.c_str());return false;}done+=size_t(n);}bool ok=fsync(fd)==0;if(close(fd))ok=false;if(ok)ok=rename(temp.c_str(),path.c_str())==0;if(!ok)unlink(temp.c_str());return ok;}
inline bool consume_reload(const std::string& path){if(access((path+".reload").c_str(),F_OK)!=0)return false;bool accepted=load(path);config_message=accepted?"Настройки применены":"Ошибка загрузки";if(accepted)unlink((path+".reload").c_str());return accepted;}
inline ImU32 color(unsigned i){auto c=cfg.colors[i];if(cfg.rgb){float h=float(fmod(ImGui::GetTime()*.12+i*.08,1));ImGui::ColorConvertHSVtoRGB(h,.8f,1.f,c.x,c.y,c.z);}return ImGui::ColorConvertFloat4ToU32(c);}
inline constexpr float theme_colors[12][3]={{.30f,.81f,.94f},{1,.43f,.12f},{1,.73f,.13f},{.65f,.9f,.17f},{.18f,.8f,.38f},{.1f,.75f,.63f},{.13f,.8f,.93f},{.25f,.52f,1},{.43f,.38f,.94f},{.68f,.35f,.93f},{.95f,.35f,.67f},{.85f,.88f,.94f}};
inline ImVec4 accent(){return {.52f,.39f,1.f,1};}
inline void style(){
 static bool initialized=false;auto& s=ImGui::GetStyle();
 if(!initialized){ImGui::StyleColorsDark();s.WindowPadding={18,16};s.FramePadding={16,14};s.ItemSpacing={16,14};s.ItemInnerSpacing={10,8};s.WindowBorderSize=s.ChildBorderSize=1;s.FrameBorderSize=0;s.WindowRounding=20;s.ChildRounding=14;s.FrameRounding=7;s.PopupRounding=10;s.GrabRounding=5;s.GrabMinSize=24;s.ScrollbarRounding=8;
 s.Colors[ImGuiCol_Text]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_TextDisabled]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_WindowBg]={.035f,.045f,.085f,1};s.Colors[ImGuiCol_ChildBg]={.055f,.065f,.12f,1};s.Colors[ImGuiCol_PopupBg]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_Border]={.08f,.08f,.08f,.65f};s.Colors[ImGuiCol_Separator]={.08f,.08f,.08f,.55f};s.Colors[ImGuiCol_FrameBg]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_FrameBgHovered]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_FrameBgActive]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_Button]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_ScrollbarBg]={0,0,0,0};s.Colors[ImGuiCol_ScrollbarGrab]={.08f,.08f,.08f,1};initialized=true;}
 s.Colors[ImGuiCol_Text]={.95f,.95f,.95f,1};s.Colors[ImGuiCol_TextDisabled]={.55f,.55f,.55f,1};s.Colors[ImGuiCol_Border]={.16f,.19f,.30f,1};auto a=accent();s.ScrollbarSize=float(cfg.scrollbar);s.Colors[ImGuiCol_CheckMark]=s.Colors[ImGuiCol_SliderGrab]=a;s.Colors[ImGuiCol_SliderGrabActive]={std::min(a.x+.12f,1.f),std::min(a.y+.12f,1.f),std::min(a.z+.12f,1.f),1};s.Colors[ImGuiCol_Header]={a.x*.25f,a.y*.25f,a.z*.25f,1};s.Colors[ImGuiCol_HeaderHovered]={a.x*.4f,a.y*.4f,a.z*.4f,1};s.Colors[ImGuiCol_HeaderActive]={a.x*.5f,a.y*.5f,a.z*.5f,1};s.Colors[ImGuiCol_ButtonHovered]={a.x*.22f,a.y*.22f,a.z*.22f,1};s.Colors[ImGuiCol_ButtonActive]={a.x*.35f,a.y*.35f,a.z*.35f,1};s.Colors[ImGuiCol_TextSelectedBg]={a.x,a.y,a.z,.3f};
}
inline void setting_caption(const char* text){ImGui::PushID(text);ImGui::PushTextWrapPos(0);ImGui::TextUnformatted(text,strstr(text,"###"));ImGui::PopTextWrapPos();ImGui::SetNextItemWidth(-1);}
inline bool setting_int(const char* text,int* value,int lo,int hi,const char* format="%d"){setting_caption(text);const auto id=ImGui::GetID("##value");int before=*value;bool changed=ImGui::SliderInt("##value",value,lo,hi,format);changed=dof_menu::touch_scroll().slider(id,before,*value,changed);ImGui::PopID();return changed;}
inline bool setting_float(const char* text,float* value,float lo,float hi,const char* format="%.3f"){setting_caption(text);const auto id=ImGui::GetID("##value");float before=*value;bool changed=ImGui::SliderFloat("##value",value,lo,hi,format);changed=dof_menu::touch_scroll().slider(id,before,*value,changed);ImGui::PopID();return changed;}
inline bool setting_combo(const char* text,int* value,const char* items){std::string translated;for(const char* p=items;*p;p+=strlen(p)+1){translated+=tr(p);translated+=char(0);}translated+=char(0);setting_caption(text);bool changed=ImGui::Combo("##value",value,translated.c_str());ImGui::PopID();return changed;}
inline bool setting_combo(const char* text,int* value,const char* const items[],int count){setting_caption(text);std::vector<const char*> choices;for(int i=0;i<count;++i)choices.push_back(tr(items[i]));bool changed=ImGui::Combo("##value",value,choices.data(),count);ImGui::PopID();return changed;}
inline void toggle(const char* label,bool& value){
 ImGui::PushID(label);const auto p=ImGui::GetCursorScreenPos();const float width=std::max(100.f,ImGui::GetContentRegionAvail().x),sw=62.f,sh=34.f;
 const char* text=tr(label);const float wrap=std::max(30.f,width-sw-24.f);const auto text_size=ImGui::CalcTextSize(text,nullptr,false,wrap);const float height=std::max(60.f,text_size.y+22.f);
 const bool click=ImGui::InvisibleButton("##switch",{width,height});if(ImGui::IsItemActive())scroll_toggle=ImGui::GetItemID();if(click&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64)value=!value;
 auto* d=ImGui::GetWindowDrawList();d->AddRectFilled(p,{p.x+width,p.y+height},ImGui::IsItemHovered()?IM_COL32(34,39,65,255):IM_COL32(21,25,43,255),7);
 d->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{p.x+4,p.y+(height-text_size.y)*.5f},ImGui::GetColorU32(ImGuiCol_Text),text,nullptr,wrap);
 auto* storage=ImGui::GetStateStorage();auto key=ImGui::GetID("##switch_progress");float t=storage->GetFloat(key,value?1.f:0.f);float goal=value?1.f:0.f;t=cfg.menu_animations?t+(goal-t)*std::min(1.f,ImGui::GetIO().DeltaTime*18.f):goal;storage->SetFloat(key,t);
 auto a=accent();ImVec4 track{.15f+.37f*t,.17f+.22f*t,.24f+.76f*t,1};
 const ImVec2 at{p.x+width-sw-3,p.y+(height-sh)*.5f};d->AddRectFilled(at,{at.x+sw,at.y+sh},ImGui::GetColorU32(track),sh*.5f);
 d->AddCircleFilled({at.x+sh*.5f+(sw-sh)*t,at.y+sh*.5f},sh*.5f-3,IM_COL32(234,231,255,255),24);ImGui::PopID();
}
inline void opener(float w,float h){
 if(cfg.open_method==1){static ImVec2 icon(24,130);float size=std::clamp(80.f*w/1920.f,72.f,112.f);icon.x=std::clamp(icon.x,8.f,std::max(8.f,w-size-8));icon.y=std::clamp(icon.y,8.f,std::max(8.f,h-size-8));ImGui::SetNextWindowPos(icon);ImGui::SetNextWindowSize({size,size});ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});ImGui::Begin("##oxide_opener",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);auto p=ImGui::GetCursorScreenPos();bool tap=ImGui::InvisibleButton("##open",{size,size});if(ImGui::IsItemActive()&&ImGui::IsMouseDragging(0,8)){icon.x+=ImGui::GetIO().MouseDelta.x;icon.y+=ImGui::GetIO().MouseDelta.y;}if(tap&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64)opened=!opened;auto* d=ImGui::GetWindowDrawList();if(avatar)d->AddImageRounded(reinterpret_cast<ImTextureID>(avatar),p,{p.x+size,p.y+size},{0,0},{1,1},IM_COL32_WHITE,size*.5f);else d->AddCircleFilled({p.x+size*.5f,p.y+size*.5f},size*.5f,IM_COL32(0,0,0,255));if(avatar)d->AddCircle({p.x+size*.5f,p.y+size*.5f},size*.5f,ImGui::GetColorU32(accent()),48,2);ImGui::End();ImGui::PopStyleVar();}
 else{float bw=std::clamp(350.f*w/1920.f,180.f,420.f);ImVec2 pos((w-bw)*.5f-30,h-80),size(bw+60,80);ImGui::SetNextWindowPos(pos);ImGui::SetNextWindowSize(size);ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});ImGui::Begin("##oxide_bottom_strip",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);auto p=ImGui::GetCursorScreenPos();bool tap=ImGui::InvisibleButton("##bottom_open",size);if(tap&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64)opened=!opened;ImGui::GetWindowDrawList()->AddRectFilled({p.x+30,p.y+60},{p.x+30+bw,p.y+70},IM_COL32(255,255,255,64),20);ImGui::End();ImGui::PopStyleVar();}
}
inline void scroll_end(){ImGui::EndChild();}
inline void panel(const char* id,ImVec2 size){
 ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding,12.f);
 ImGui::BeginChild(id,size,true,ImGuiWindowFlags_AlwaysVerticalScrollbar);
 ImGui::PopStyleVar();
 if(id[0]!='#'){
  ImGui::Spacing();
  ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.87f,.94f,.98f,1));
  ImGui::TextWrapped("%s",tr(id));
  ImGui::PopStyleColor();
  ImGui::Spacing();ImGui::Separator();ImGui::Spacing();
 }
}
inline bool navigation_button(const char* name,bool selected,ImVec2 size){
 ImGui::PushID(name);const auto p=ImGui::GetCursorScreenPos();bool hit=ImGui::InvisibleButton("##section",size);auto* d=ImGui::GetWindowDrawList();auto a=accent();
 if(selected||ImGui::IsItemHovered())d->AddRectFilled(p,{p.x+size.x,p.y+size.y},selected?ImGui::GetColorU32(ImVec4(a.x*.16f,a.y*.16f,a.z*.16f,1)):IM_COL32(36,36,36,255),7);
 if(selected)d->AddRectFilled({p.x+12,p.y+size.y-3},{p.x+size.x-12,p.y+size.y},ImGui::GetColorU32(a),2);
 auto text=tr(name);auto ts=ImGui::CalcTextSize(text);d->PushClipRect(p,{p.x+size.x,p.y+size.y},true);d->AddText({p.x+(size.x-ts.x)*.5f,p.y+(size.y-ts.y)*.5f},ImGui::GetColorU32(selected?a:ImVec4(.56f,.64f,.74f,1)),text);d->PopClipRect();ImGui::PopID();return hit&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64;
}
inline bool collapsible(const char* text,ImGuiTreeNodeFlags flags=0){
 ImGui::PushID(text);auto* storage=ImGui::GetStateStorage();auto key=ImGui::GetID("##fold_state");bool open=storage->GetInt(key,(flags&ImGuiTreeNodeFlags_DefaultOpen)?1:0)!=0;
 auto p=ImGui::GetCursorScreenPos();float width=ImGui::GetContentRegionAvail().x;const char* end=strstr(text,"###");auto ts=ImGui::CalcTextSize(text,end,false,std::max(30.f,width-50));float height=std::max(58.f,ts.y+20);
 if(ImGui::InvisibleButton("##fold",{width,height})&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64&&!dof_menu::touch_scroll().scrolling())open=!open;
 auto* d=ImGui::GetWindowDrawList();d->AddRectFilled(p,{p.x+width,p.y+height},ImGui::IsItemHovered()?IM_COL32(48,48,48,255):IM_COL32(31,31,31,255),8);
 float x=p.x+18,y=p.y+height*.5f;ImU32 c=IM_COL32(215,215,215,255);
 if(open){d->AddLine({x-5,y-3},{x,y+3},c,2);d->AddLine({x,y+3},{x+5,y-3},c,2);}else{d->AddLine({x-3,y-5},{x+3,y},c,2);d->AddLine({x+3,y},{x-3,y+5},c,2);}
 d->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{p.x+38,p.y+(height-ts.y)*.5f},ImGui::GetColorU32(ImGuiCol_Text),text,end,std::max(30.f,width-50));storage->SetInt(key,open?1:0);ImGui::PopID();return open;
}
inline std::string automation_status;
inline int pick_target=-1;inline bool pick_wait_release=false,pick_pressed=false;inline uint64_t farm_target=0;
inline void begin_pick(int target){if(target<0||target>5)return;pick_target=target;pick_wait_release=true;pick_pressed=false;opened=false;menu_alpha=0;}
inline void accept_pick(ImVec2 p,float w,float h){
 if(pick_target<0||pick_target>4||w<=0||h<=0)return;
 const ImVec2 point{std::clamp(p.x/w*100.f,0.f,100.f),std::clamp(p.y/h*100.f,0.f,100.f)};
 const int x=int(std::round(point.x)),y=int(std::round(point.y));
 if(pick_target<3)cfg.points[pick_target]=point;
 switch(pick_target){
  case 0:cfg.joy_x=x;cfg.joy_y=y;break;
  case 1:cfg.look_x=x;cfg.look_y=y;break;
  case 2:cfg.hit_x=x;cfg.hit_y=y;break;
  case 3:cfg.heal_slot_x=std::clamp(x,1,99);cfg.heal_slot_y=std::clamp(y,1,99);break;
  case 4:cfg.heal_use_x=std::clamp(x,1,99);cfg.heal_use_y=std::clamp(y,1,99);break;
 }
 pick_target=-1;pick_pressed=false;opened=true;menu_alpha=1;if(!config_path.empty())save(config_path);
}
inline void point_button(const char* title,int target){ImGui::PushID(target);if(ImGui::Button(label(title),{ImGui::GetContentRegionAvail().x,0}))begin_pick(target);ImGui::PopID();}
inline bool picking(float w,float h){if(pick_target<0)return false;auto& io=ImGui::GetIO();ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize({w,h});ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});ImGui::Begin("##point_picker",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
 if(pick_target==5){
  const float area_w=w*aim_area_width*.01f,area_h=h*aim_area_height*.01f;
  const ImVec2 min{w*cfg.aim_area_ax*.01f,h*cfg.aim_area_ay*.01f};
  const ImVec2 max{min.x+area_w,min.y+area_h};
  auto* draw=ImGui::GetWindowDrawList();
  draw->AddRectFilled({0,0},{w,h},IM_COL32(13,13,13,110));
  draw->AddRectFilled(min,max,IM_COL32(132,132,132,70),8.f);
  draw->AddRect(min,max,IM_COL32(175,175,175,255),8.f,0,2.f);
  draw->AddText({20,22},IM_COL32_WHITE,tr("Перетащи область тач AIM"));
  ImGui::SetCursorScreenPos(min);
  ImGui::InvisibleButton("##aim_area_drag",{area_w,area_h});
  static ImVec2 drag_offset{};
  if(ImGui::IsItemActivated())drag_offset={io.MousePos.x-min.x,io.MousePos.y-min.y};
  if(ImGui::IsItemActive()&&w>0&&h>0){
   cfg.aim_area_ax=std::clamp(int(std::lround((io.MousePos.x-drag_offset.x)*100.f/w)),0,100-aim_area_width);
   cfg.aim_area_ay=std::clamp(int(std::lround((io.MousePos.y-drag_offset.y)*100.f/h)),0,100-aim_area_height);
   cfg.aim_area_bx=cfg.aim_area_ax+aim_area_width;
   cfg.aim_area_by=cfg.aim_area_ay+aim_area_height;
  }
  ImGui::SetCursorScreenPos({max.x>w-156.f&&min.y<64.f?16.f:w-156.f,16.f});
  if(ImGui::Button(label("Готово"),{140.f,48.f})){
   pick_target=-1;opened=true;menu_alpha=1;
   if(!config_path.empty())save(config_path);
  }
  ImGui::End();ImGui::PopStyleVar();return true;
 }
 ImGui::InvisibleButton("##pick_surface",{w,h});
 if(pick_wait_release){if(!io.MouseDown[0])pick_wait_release=false;}else{if(ImGui::IsMouseClicked(0))pick_pressed=true;if(ImGui::IsMouseReleased(0)&&pick_pressed){auto p=io.MousePos;if(p.x>w-180&&p.y<90){pick_target=-1;opened=true;menu_alpha=1;}else if(io.MouseDragMaxDistanceSqr[0]<64)accept_pick(p,w,h);pick_pressed=false;}}
 const char* names[]={"Джойстик","Поворот","Удар","Выбрать аптечку","Выбрать применение"};if(pick_target>=0){std::string title=std::string(tr("Коснись точки"))+": "+tr(names[pick_target]);auto size=ImGui::CalcTextSize(title.c_str());ImGui::GetWindowDrawList()->AddText({(w-size.x)*.5f,30},IM_COL32_WHITE,title.c_str());ImGui::GetWindowDrawList()->AddText({w-160,30},IM_COL32_WHITE,tr("Отмена"));}ImGui::End();ImGui::PopStyleVar();return true;
}
inline unsigned resource_mask(){return (cfg.sulfur?1:0)|(cfg.stone?2:0)|(cfg.metal?4:0)|(cfg.barrels?8:0)|(cfg.wood?16:0)|(cfg.highmetal?32:0);}
inline unsigned farm_mask(){return (cfg.farm_sulfur?1:0)|(cfg.farm_stone?2:0)|(cfg.farm_metal?4:0)|(cfg.farm_barrels?8:0)|(cfg.farm_wood?16:0)|(cfg.farm_highmetal?32:0);}
inline oxide::AutomationConfig automation_config(){oxide::AutomationConfig c;c.farm=cfg.autofarm;c.paused=opened||menu_alpha>.08f||pick_target>=0;c.freecam=cfg.freecam;c.resources=farm_mask();c.joy_x=cfg.joy_x;c.joy_y=cfg.joy_y;c.joy_radius=cfg.joy_radius;c.look_x=cfg.look_x;c.look_y=cfg.look_y;c.hit_x=cfg.hit_x;c.hit_y=cfg.hit_y;c.turn_scale=cfg.turn_scale;c.reach=cfg.farm_reach;auto assign=[&](int i,float& x,float& y){if(cfg.points[i].x>=0&&cfg.points[i].y>=0){x=cfg.points[i].x;y=cfg.points[i].y;}};assign(0,c.joy_x,c.joy_y);assign(1,c.look_x,c.look_y);assign(2,c.hit_x,c.hit_y);return c;}
inline void screen_controls(float w,float h){
 if(cfg.free_button){float side=std::clamp(w/1920.f*64.f,56.f,88.f);ImVec2 p(std::clamp(cfg.free_position.x*w,0.f,std::max(0.f,w-side)),std::clamp(cfg.free_position.y*h,0.f,std::max(0.f,h-side)));ImGui::SetNextWindowPos(p);ImGui::SetNextWindowSize({side,side});ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});ImGui::Begin("##freecam_button",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoMove);bool tap=ImGui::InvisibleButton("##freecam_drag",{side,side});if(ImGui::IsItemActive()&&ImGui::IsMouseDragging(0,8)){auto delta=ImGui::GetIO().MouseDelta;cfg.free_position={std::clamp(p.x+delta.x,0.f,w-side)/w,std::clamp(p.y+delta.y,0.f,h-side)/h};}if(tap&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64){cfg.freecam=!cfg.freecam;if(cfg.freecam)cfg.thirdperson=false;}auto* d=ImGui::GetWindowDrawList();d->AddRectFilled(p,{p.x+side,p.y+side},cfg.freecam?ImGui::GetColorU32(accent()):IM_COL32(27,27,27,220),12);d->AddRect(p,{p.x+side,p.y+side},ImGui::GetColorU32(accent()),12,0,2);auto text=ImGui::CalcTextSize("FC");d->AddText({p.x+(side-text.x)*.5f,p.y+(side-text.y)*.5f},IM_COL32_WHITE,"FC");ImGui::End();ImGui::PopStyleVar();}
 if(cfg.calibration){auto c=automation_config();auto* d=ImGui::GetForegroundDrawList();auto mark=[&](float x,float y,const char* label,ImU32 color){ImVec2 p(w*x*.01f,h*y*.01f);d->AddCircle(p,13,color,24,2);d->AddText({p.x+15,p.y},color,label);};mark(c.joy_x,c.joy_y,"MOVE",IM_COL32(133,133,133,255));mark(c.look_x,c.look_y,"LOOK",IM_COL32(170,170,170,255));mark(c.hit_x,c.hit_y,"HIT",IM_COL32(136,136,136,255));}

}
inline void player_box(ImDrawList* draw,ImVec2 top,ImVec2 bottom,ImU32 tint){
 const float stroke=cfg.line_weight*.1f;
 if(cfg.box_style>=2)draw->AddRectFilled(top,bottom,(tint&0x00ffffff)|0x26000000);
 auto outline=[&](ImU32 shade,float width){
  if((cfg.box_style&1)==0){draw->AddRect(top,bottom,shade,1,0,width);return;}
  const float dx=(bottom.x-top.x)*.27f,dy=(bottom.y-top.y)*.20f;
  for(int row=0;row<2;++row)for(int column=0;column<2;++column){
   ImVec2 point{column?bottom.x:top.x,row?bottom.y:top.y};
   draw->AddLine(point,{point.x+(column?-dx:dx),point.y},shade,width);
   draw->AddLine(point,{point.x,point.y+(row?-dy:dy)},shade,width);
  }
 };
 if(vip_mode&&cfg.vip_box_glow){
  outline((tint&0xffffff)|0x18000000,stroke+8.f);
  outline((tint&0xffffff)|0x36000000,stroke+4.f);
 }
 outline(tint,stroke);
}
inline void line_origin_picker(bool enabled){
 if(enabled)setting_combo(label("Начало линий"),&cfg.line_origin,"Снизу\0Сверху\0");
}
inline float esp_caption(ImDrawList* draw,float center,float y,const char* text,ImU32 tint,bool background,bool above=false){
 const auto size=ImGui::CalcTextSize(text);
 const float x=center-size.x*.5f;
 const int opacity=100-std::clamp(cfg.caption_transparency,0,100);
 const bool show=background&&opacity>0;
 const float pad_y=show?3.f:0.f;
 if(above)y-=size.y+2*pad_y;
 if(show){
  constexpr float pad_x=6.f;
  const ImVec2 min{x-pad_x,y},max{x+size.x+pad_x,y+size.y+2*pad_y};
  draw->AddRectFilled(min,max,IM_COL32(16,19,26,(255*opacity+50)/100),5.f);
  draw->AddRect(min,max,IM_COL32(150,158,180,(122*opacity+50)/100),5.f);
 }
 draw->AddText({x,y+pad_y},tint,text);
 return size.y+2*pad_y+2.f;
}
inline void preview(float height){
 panel("Предпросмотр",{0,height});
 const auto pos=ImGui::GetCursorScreenPos(),avail=ImGui::GetContentRegionAvail();
 auto* draw=ImGui::GetWindowDrawList();
 draw->PushClipRect(pos,{pos.x+avail.x,pos.y+avail.y},true);
 for(float x=pos.x;x<pos.x+avail.x;x+=32)draw->AddLine({x,pos.y},{x,pos.y+avail.y},IM_COL32(80,80,80,24));
 for(float y=pos.y;y<pos.y+avail.y;y+=32)draw->AddLine({pos.x,y},{pos.x+avail.x,y},IM_COL32(80,80,80,24));
 draw->PopClipRect();
 const float cx=pos.x+avail.x*.5f,cy=pos.y+avail.y*.49f;
 const float unit=std::max(1.f,std::min(avail.x*.38f,avail.y*.55f));
 const ImVec2 top{cx-unit*.24f,cy-unit*.53f},bottom{cx+unit*.24f,cy+unit*.53f};
 const auto tint=color(0);
 if(cfg.box)player_box(draw,top,bottom,tint);
 if(cfg.skeleton){
  const ImVec2 bones[]={{0,-.39f},{0,-.22f},{0,.05f},{-.23f,-.05f},{.23f,-.05f},{-.15f,.48f},{.15f,.48f}};
  const unsigned edges[][2]={{0,1},{1,2},{1,3},{1,4},{2,5},{2,6}};
  for(auto& edge:edges){
   auto point=[&](unsigned i){return ImVec2{cx+bones[i].x*unit,cy+bones[i].y*unit};};
   draw->AddLine(point(edge[0]),point(edge[1]),tint,cfg.line_weight*.1f);
  }
 }
 if(cfg.health)draw->AddRectFilledMultiColor({top.x-9,top.y},{top.x-4,bottom.y},color(2),color(2),color(3),color(3));
 if(cfg.lines)draw->AddLine({cx,cfg.line_origin?pos.y:pos.y+avail.y},cfg.line_origin?top:bottom,color(4),1);
 if(cfg.name)esp_caption(draw,cx,top.y-4,tr("Игрок"),color(1),cfg.name_background,true);
 if(cfg.distance)esp_caption(draw,cx,bottom.y+4,"35 m",color(1),cfg.distance_background);
 if(cfg.weapon)draw->AddText({cx-26,bottom.y+ImGui::GetTextLineHeight()+6},color(4),"АК-47");
 scroll_end();
}
inline void scale_menu_draw(ImGuiWindow* window,ImVec2 center,float scale){
 auto project=[&](ImVec2 point){return ImVec2(center.x+(point.x-center.x)*scale,center.y+(point.y-center.y)*scale);};
 for(auto& vertex:window->DrawList->VtxBuffer)vertex.pos=project(vertex.pos);
 for(auto& command:window->DrawList->CmdBuffer){
  const auto a=project({command.ClipRect.x,command.ClipRect.y});
  const auto b=project({command.ClipRect.z,command.ClipRect.w});
  command.ClipRect={a.x,a.y,b.x,b.y};
 }
 for(auto* child:window->DC.ChildWindows)scale_menu_draw(child,center,scale);
}
inline void render_old(float w,float h,const oxide::Frame& frame,bool embedded=false){if(recorder_ui_active)return;
 fixed_settings(cfg);style();if(picking(w,h)){dof_menu::touch_scroll().reset();return;}if(!embedded){opener(w,h);screen_controls(w,h);}
 if(cfg.watermark){if(cfg.watermark_style){oxide_watermark::Watermark mark;mark.Render(accent(),reinterpret_cast<ImTextureID>(avatar));}else ImGui::GetForegroundDrawList()->AddText({16,12},IM_COL32(241,241,241,210),"Nova.cc  /  OXIDE");}
 if(cfg.debug){std::string status=frame.status+" · "+std::to_string(frame.players.size())+" игроков · "+std::to_string(frame.containers.size())+" контейнеров";ImGui::GetForegroundDrawList()->AddText({16,44},IM_COL32(193,193,193,255),status.c_str());ImGui::GetForegroundDrawList()->AddText({16,74},IM_COL32(193,193,193,255),frame.aim_status.c_str());ImGui::GetForegroundDrawList()->AddText({16,104},IM_COL32(193,193,193,255),frame.camera_status.c_str());}
 const float step=5.f*std::clamp(cfg.menu_animation_percent,50,200)*.01f*std::clamp(ImGui::GetIO().DeltaTime,0.f,.1f);
 menu_alpha=cfg.menu_animations?std::clamp(menu_alpha+(opened?step:-step),0.f,1.f):(opened?1.f:0.f);
 if(menu_alpha==0.f&&!opened){dof_menu::touch_scroll().reset();return;}
 const float reveal=menu_alpha*menu_alpha*(3.f-2.f*menu_alpha);
 // Enlarge only the menu; restore the global scale before returning to ESP.
 auto& menu_io=ImGui::GetIO();const float previous_font_scale=menu_io.FontGlobalScale;menu_io.FontGlobalScale=previous_font_scale*1.25f;ImGui::PushFont(ImGui::GetFont());
 if(cfg.menu_dim_background)ImGui::GetBackgroundDrawList()->AddRectFilled({0,0},{w,h},IM_COL32(0,0,0,int(96*reveal)));ImGui::PushStyleVar(ImGuiStyleVar_Alpha,reveal);
 float scale=std::clamp(cfg.menu_scale,70,110)*.01f;ImVec2 maxsize(std::min(1640.f*scale,w*.95f),std::min(960.f*scale,h*.92f));ImVec2 minsize(std::min(1020.f*std::min(scale,1.f),maxsize.x),std::min(580.f*std::min(scale,1.f),maxsize.y));ImGui::SetNextWindowSizeConstraints(maxsize,maxsize);
 static int last_scale=-1,last_x=-1,last_y=-1;static float last_w=0,last_h=0;bool resize=last_scale!=cfg.menu_scale||last_w!=w||last_h!=h;
 if(resize)ImGui::SetNextWindowSize(maxsize);auto* existing_menu=ImGui::FindWindowByName("##oxide_menu");ImVec2 position_size=(!resize&&existing_menu)?existing_menu->Size:maxsize;if(resize||last_x!=cfg.menu_x||last_y!=cfg.menu_y)ImGui::SetNextWindowPos({std::max(0.f,w-position_size.x)*cfg.menu_x*.01f,std::max(0.f,h-position_size.y)*cfg.menu_y*.01f});
 last_scale=cfg.menu_scale;last_x=cfg.menu_x;last_y=cfg.menu_y;last_w=w;last_h=h;
 ImGui::Begin("##oxide_menu",nullptr,ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoCollapse|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|(menu_alpha<1.f?ImGuiWindowFlags_NoInputs:0));
 auto* root=ImGui::GetCurrentWindow();dof_menu::touch_scroll().begin(root,opened&&menu_alpha>.99f);
 const auto tint=accent();
 root->DrawList->AddRect(root->Pos,{root->Pos.x+root->Size.x,root->Pos.y+root->Size.y},ImGui::GetColorU32(ImVec4(tint.x,tint.y,tint.z,.22f)),20.f);
 ImGui::BeginChild("##oxide_title",{0,92},false,ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse);auto title_pos=ImGui::GetWindowPos(),title_size=ImGui::GetWindowSize();
 // The drag region excludes the close control, so a tap never moves the menu.
 ImGui::InvisibleButton("##move_menu",{std::max(1.f,ImGui::GetContentRegionAvail().x-78),58});{
  static ImVec2 drag_origin{},pointer_origin{};
  if(ImGui::IsItemActivated()){drag_origin=root->Pos;pointer_origin=ImGui::GetIO().MouseClickedPos[0];}
  if(ImGui::IsItemActive()&&ImGui::IsMouseDragging(0,6.f)){
   auto pointer=ImGui::GetIO().MousePos;float mx=std::max(0.f,w-root->Size.x),my=std::max(0.f,h-root->Size.y);
   if(mx>0)cfg.menu_x=int(std::lround(std::clamp(drag_origin.x+pointer.x-pointer_origin.x,0.f,mx)/mx*100));
   if(my>0)cfg.menu_y=int(std::lround(std::clamp(drag_origin.y+pointer.y-pointer_origin.y,0.f,my)/my*100));
  }
 }
 auto* hd=ImGui::GetWindowDrawList();float cy=title_pos.y+title_size.y*.5f;
 if(avatar)hd->AddImageRounded(reinterpret_cast<ImTextureID>(avatar),{title_pos.x+2,cy-34},{title_pos.x+70,cy+34},{0,0},{1,1},IM_COL32_WHITE,12);
 hd->AddText(ImGui::GetIO().Fonts->Fonts[0],36.f,{title_pos.x+88,cy-32},IM_COL32(243,243,243,255),"Nova.cc");hd->AddText(ImGui::GetFont(),ImGui::GetFontSize()*.8f,{title_pos.x+89,cy+12},IM_COL32(139,139,139,255),"RELEASE 12025  /  NOVA INTERFACE");
 ImGui::SameLine();ImGui::SetCursorScreenPos({title_pos.x+title_size.x-66,cy-28});auto cp=ImGui::GetCursorScreenPos();if(ImGui::InvisibleButton("##close_menu",{56,56}))opened=false;
 hd->AddRectFilled(cp,{cp.x+56,cp.y+56},ImGui::IsItemHovered()?IM_COL32(51,51,51,255):IM_COL32(36,36,36,255),10);dof_menu::icon(hd,{cp.x+13,cp.y+13},30,7,IM_COL32(184,184,184,255));
 hd->AddLine({title_pos.x,title_pos.y+title_size.y-1},{title_pos.x+title_size.x,title_pos.y+title_size.y-1},IM_COL32(60,60,60,150));ImGui::EndChild();
 const char* pages[]={"Визуалы","Наведение","Мир","Настройки","Игрок","Конфиги","Помощники"};
 const int order[]={0,1,2,4,3,5};tab=std::clamp(tab,0,5);
 const float tab_width=(ImGui::GetContentRegionAvail().x-ImGui::GetStyle().ItemSpacing.x*5.f)/6.f;
 ImGui::BeginChild("##oxide_tabs",{0,66},false,ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse);
 for(int n=0;n<6;++n){if(n)ImGui::SameLine();int index=order[n];if(navigation_button(pages[index],tab==index,{tab_width,54}))tab=index;}
 ImGui::EndChild();
 const float height=std::max(1.f,ImGui::GetContentRegionAvail().y-42);
 ImGui::BeginChild("##oxide_content",{0,height},false,ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse);
 ImGui::TextUnformatted(tr(pages[tab]));ImGui::Spacing();
 static std::array<int,7> sub{};
 auto sections=[&](std::initializer_list<const char*> names){
  const float available=ImGui::GetContentRegionAvail().x;
  float minimum=110.f;for(auto name:names)minimum=std::max(minimum,ImGui::CalcTextSize(tr(name)).x+40.f);
  const int columns=std::max(1,std::min(std::min(3,int(names.size())),int((available+ImGui::GetStyle().ItemSpacing.x)/(minimum+ImGui::GetStyle().ItemSpacing.x))));
  const float width=(available-ImGui::GetStyle().ItemSpacing.x*(columns-1))/columns;
  sub[tab]=std::clamp(sub[tab],0,int(names.size())-1);
  int index=0;for(auto name:names){if(index%columns)ImGui::SameLine();if(navigation_button(name,sub[tab]==index,{width,58}))sub[tab]=index;++index;}
 };
 if(tab==0){if(vip_mode)sections({"Игрок","Снаряжение","Боты","Стиль","Эффекты","Поиск построек"});else sections({"Игрок","Снаряжение","Боты","Стиль"});}
 if(tab==1){if(vip_mode)sections({"Аимбот","Silent","Тач AIM","360°","Триггер","Эффекты"});else sections({"Аимбот","Триггер"});}
 if(tab==2)sections({"Объекты","Небо"});
 if(tab==3){
  if(embedded&&ImGui::Button(label("Скрыть меню"),{ImGui::GetContentRegionAvail().x,42})){
   opened=false;
  }
  if(embedded&&ImGui::Button(label("Скрыть окна Android"),{ImGui::GetContentRegionAvail().x,52})){hide_overlay_requested=true;opened=false;}
  sections({"Интерфейс","Производительность","Диагностика"});
 }
 if(tab==4){if(vip_mode)sections({"Камера","Движение","Автофарм","Автохилл"});else sections({"Камера","Движение","Автофарм"});}
 
 const float body=ImGui::GetContentRegionAvail().y;
 const float half=(ImGui::GetContentRegionAvail().x-ImGui::GetStyle().ItemSpacing.x)*.5f;
 if(tab==0&&sub[0]==0){
  panel("ESP",{half,body});
  toggle("Рамки",cfg.box);toggle("Имя",cfg.name);toggle("Полоса здоровья",cfg.health);toggle("Дистанция",cfg.distance);
  if(cfg.name)toggle("Фон ника",cfg.name_background);
  if(cfg.distance)toggle("Фон дистанции",cfg.distance_background);
  toggle("Линии к игрокам",cfg.lines);line_origin_picker(cfg.lines);toggle("Скелет",cfg.skeleton);setting_int(label("Дальность ESP"),&cfg.max_distance,20,350);toggle("Спящие игроки",cfg.sleepers);toggle("Клан",cfg.player_clan);toggle("Скрывать своих",cfg.hide_allies);toggle("ESP 360",cfg.player_arrows);
  scroll_end();ImGui::SameLine();preview(body);
 }
 if(tab==0&&sub[0]==1){
  panel("Снаряжение",{0,body});
  toggle("Оружие",cfg.weapon);toggle("Броня противника",cfg.armor);
  scroll_end();
 }
 if(tab==0&&sub[0]==2){
  panel("Боты",{0,body});
  toggle("Показывать ботов",cfg.bots);toggle("Линии к ботам",cfg.bot_lines);line_origin_picker(cfg.bot_lines);toggle("Скелет ботов",cfg.bot_rig);toggle("Имена ботов",cfg.bot_names);toggle("Дистанция до ботов",cfg.bot_distance);toggle("ESP 360",cfg.bot_arrows);ImGui::ColorEdit4(label("Цвет ботов"),&cfg.colors[15].x,ImGuiColorEditFlags_NoInputs);
  scroll_end();
 }
 if(tab==0&&sub[0]==3){
  panel("Стиль",{half,body});
  setting_combo(label("Форма рамки"),&cfg.box_style,"Полная\0Углы\0Полная с заливкой\0Углы с заливкой\0");
  float stroke=cfg.line_weight*.1f;
  if(setting_float(label("Толщина линий"),&stroke,.5f,4.f,"%.1f"))cfg.line_weight=int(std::lround(stroke*10.f));
  toggle("RGB",cfg.rgb);const char* labels[]={"Рамки и скелет","Имя и дистанция","Здоровье: верх","Здоровье: низ","Линии и оружие","Маленький сундук","Большой сундук","Шкаф"};for(unsigned i=0;i<8;++i)ImGui::ColorEdit4(label(labels[i]),&cfg.colors[i].x,ImGuiColorEditFlags_NoInputs);const char* entity_colors[]={"Цвет ботов","Цвет машин","Цвет турелей","Цвет спящих игроков"};for(int i=0;i<4;++i)ImGui::ColorEdit4(label(entity_colors[i]),&cfg.colors[15+i].x,ImGuiColorEditFlags_NoInputs);
  scroll_end();ImGui::SameLine();preview(body);
 }

 if(vip_mode&&tab==0&&sub[0]==4){panel("VIP-эффекты ESP",{0,body});
  toggle("Контур силуэта игрока",cfg.vip_player_outline);
  toggle("Чамсы",cfg.vip_chams);
  toggle("Свечение рамок ESP",cfg.vip_box_glow);
  if(cfg.vip_chams)toggle("Свечение чамсов",cfg.vip_chams_glow);
  if(cfg.vip_chams)ImGui::ColorEdit4(label("Цвет чамсов"),&cfg.colors[24].x,ImGuiColorEditFlags_NoInputs);
scroll_end();}
 if(tab==1&&(sub[1]==0||(vip_mode&&sub[1]>=1&&sub[1]<=3))){
  const int kind=sub[1];const char* titles[]={"Обычный аимбот","Silent AIM","Тач AIM","Аимкилл 360°"};
  panel(titles[kind],{0,body});ImGui::PushID(kind);
  toggle("Убрать раскачивание прицела",cfg.no_sway);
  bool* enabled=kind==1?&cfg.vip_silent:kind==2?&cfg.vip_touch_aim:kind==3?&cfg.vip_aim_360:&cfg.aim;
  const bool before=*enabled;toggle("Включить режим",*enabled);if(!before&&*enabled)enable_aim_kind(kind,true);
  if(kind==1)ImGui::TextWrapped("%s",tr(embedded?"Отдельный режим. Несовместим с фрикамом и третьим лицом.":"Работает от первого и третьего лица, с обычным и своим FOV камеры."));
  if(kind==1&&!embedded&&*enabled&&!frame.aim_status.empty())ImGui::TextWrapped("%s",frame.aim_status.c_str());
  if(kind==2&&embedded)ImGui::TextWrapped("%s",tr("Тач AIM доступен только при внешнем запуске с root."));
  if(kind==3)ImGui::TextWrapped("%s",tr("Наведение на игроков и ботов при стрельбе во всех направлениях. FOV не применяется."));
  auto a=aim_controls(kind);
  if(collapsible(label("Цели и фильтры"),ImGuiTreeNodeFlags_DefaultOpen)){
   toggle("Только видимые цели",a.visibility);if(a.visibility&&!frame.visibility_status.empty())ImGui::TextWrapped("%s",frame.visibility_status.c_str());
   if(kind!=3)toggle("AIM на животных",a.animals);toggle("AIM на ботов",a.bots);if(a.bots&&a.visibility)ImGui::TextWrapped("%s",tr("Боты без подтверждённой видимости пропускаются."));
   toggle("Не наводиться на тиммейтов",a.ignore_team);toggle("Не наводиться на сокланов",a.ignore_clan);
   setting_combo(label("Точка"),&a.bone,"Голова\0Тело\0");
   if(kind!=3)setting_combo(label("Выбор цели"),&a.mode,"Ближе к прицелу\0Меньше здоровья\0Ближе по дистанции\0");
   setting_int(label("Дальность AIM"),&a.distance,10,350);
  }
  if(collapsible(label("Наведение и активация"),ImGuiTreeNodeFlags_DefaultOpen)){
   if(kind!=3){setting_combo(label("Когда наводиться"),&a.activation,"В прицеле\0Всегда\0При стрельбе\0");setting_int(label("FOV"),&a.fov,1,170);}
   if(kind==0||kind==2)setting_int(label("Плавность"),&a.smooth,1,20);
      if(vip_mode){toggle("Предикт",a.predict);if(a.predict)setting_int(label("Поправка задержки (мс)"),&a.lead_ms,0,180,"%d ms");}
   if(kind==0&&vip_mode){toggle("AIM с инструментами",cfg.vip_melee);if(cfg.vip_melee)ImGui::TextWrapped("%s",tr("Для беты: выбери активацию «Всегда»."));}
   if(kind==2&&!embedded){if(!touch_input_status.empty())ImGui::TextWrapped("%s",touch_input_status.c_str());point_button("Переместить область тач AIM",5);setting_int(label("Чувствительность тач AIM"),&cfg.aim_touch_gain,1,100);}
  }
  if(collapsible(label("Отображение"),ImGuiTreeNodeFlags_DefaultOpen)){if(kind!=3)toggle("Показать FOV",a.draw_fov);}
  if(ImGui::Button(label("Сбросить настройки режима"))){a={false,false,false,true,true,false,false,false,false,60,300,0,0,1,1,0};}
  store_aim_controls(kind,a);ImGui::PopID();scroll_end();
 }
 if(tab==1&&sub[1]==(vip_mode?4:1)){
  panel("Триггербот",{0,body});toggle("Триггербот",cfg.trigger);
  toggle("Только в прицеле",cfg.trigger_ads);toggle("Не наводиться на тиммейтов",cfg.trigger_ignore_team);toggle("Не наводиться на сокланов",cfg.trigger_ignore_clan);toggle("AIM на животных",cfg.trigger_animals);toggle("AIM на ботов",cfg.trigger_bots);setting_int(label("Дальность триггера"),&cfg.trigger_distance,10,350);point_button("Выбрать кнопку огня",2);scroll_end();
 }
 if(vip_mode&&tab==1&&sub[1]==5){
  panel("Эффекты выстрелов",{0,body});toggle("Крупная метка попадания",cfg.vip_hit_mark);toggle("Звук убийства",cfg.vip_kill_sound);toggle("Трассеры выстрелов",cfg.vip_tracers);if(cfg.vip_tracers){ImGui::ColorEdit4(label("Цвет трассера"),&cfg.colors[23].x,ImGuiColorEditFlags_NoInputs);setting_int(label("Длина при промахе (м)"),&cfg.tracer_length,10,500);setting_int(label("Время трассера (мс)"),&cfg.tracer_lifetime,100,3000);setting_int(label("Толщина трассера"),&cfg.tracer_width,5,40,"%d / 10 px");}scroll_end();
 }
 if(tab==2&&sub[2]==0){
  panel("Ресурсы и животные",{half,body});

  toggle("Сера",cfg.sulfur);toggle("Камень",cfg.stone);toggle("Металл",cfg.metal);toggle("Скрап / бочки",cfg.barrels);toggle("Дерево",cfg.wood);toggle("МВК",cfg.highmetal);toggle("Животные с именами",cfg.animals);
  if(vip_mode){
  if(collapsible(label("Виды животных"))){
   if(!cfg.animals)ImGui::TextWrapped("%s",tr("Включи животных во вкладке «Мир»"));
   for(int i=0;i<7;++i){
    const int bit=1<<i;
    bool enabled=(cfg.vip_animals&bit)!=0;
    toggle(vip_species[i],enabled);
    if(enabled)cfg.vip_animals|=bit;
    else cfg.vip_animals&=~bit;
   }
  }
  }
ImGui::Separator();const char* world_colors[]={"Цвет серы","Цвет камня","Цвет металла","Цвет бочек","Цвет дерева","Цвет МВК","Цвет животных"};for(int i=0;i<7;++i)ImGui::ColorEdit4(label(world_colors[i]),&cfg.colors[8+i].x,ImGuiColorEditFlags_NoInputs);ImGui::Separator();if(cfg.debug)ImGui::TextWrapped("%s",tr(automation_status.c_str()));
  scroll_end();
  ImGui::SameLine();panel("Объекты и текстуры",{0,body});
  setting_combo(label("Показывать"),&cfg.world_mode,"Иконки\0Текст\0Иконки и текст\0");
  toggle("Дистанция до объектов",cfg.world_distance);
  setting_int(label("Дальность объектов"),&cfg.world_range,20,350);
  setting_int(label("Максимум на экране"),&cfg.world_limit,1,500);
  toggle("Лут погибших игроков",cfg.death_loot);toggle("Маленькие сундуки",cfg.small);toggle("Большие сундуки",cfg.large);toggle("Шкафы",cfg.cupboard);toggle("3D-рамки сундуков",cfg.container_boxes);toggle("3D-рамки шкафов",cfg.cupboard_boxes);toggle("Машины",cfg.vehicles);toggle("Турели",cfg.turrets);if(vip_mode){ImGui::Separator();toggle("Контур мешков",cfg.vip_loot_outline);toggle("HP построек",cfg.vip_build_hp);}
  scroll_end();
 }
 if(tab==2&&sub[2]==1){
  panel("Небо и освещение",{0,body});
  if(vip_mode)toggle("Визуальный день",cfg.vip_daylight);ImGui::Separator();
  toggle("Цветное небо",cfg.sky_tint);if(cfg.sky_tint)ImGui::ColorEdit4(label("Цвет неба"),&cfg.colors[19].x,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoAlpha);
  scroll_end();
 }
 if(tab==3&&sub[3]==0){
  panel("Интерфейс",{half,body});

  toggle("Затемнять фон",cfg.menu_dim_background);
  // Legacy nonroot_full_visuals remains importable; rendering no longer depends on it.

  
  
  toggle("Ватермарка",cfg.watermark);
  scroll_end();
  ImGui::SameLine();panel("Система",{0,body});
  setting_combo(label("Язык"),&cfg.language,oxide_ui_strings::names,10);setting_combo(label("Открывать меню"),&cfg.open_method,"Полоска снизу\0Аватарка\0");ImGui::Separator();ImGui::Separator();{float bw=ImGui::GetContentRegionAvail().x;ImGui::SetCursorPosX(ImGui::GetCursorPosX()+std::max(0.f,(ImGui::GetContentRegionAvail().x-bw)*.5f));ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,10.f);ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(.18f,.18f,.18f,1));ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(.28f,.28f,.28f,1));ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(.38f,.38f,.38f,1));if(ImGui::Button(label("Остановить софт"),{bw,80}))exit_requested=true;ImGui::PopStyleColor(3);ImGui::PopStyleVar();}
  scroll_end();
 }
 if(tab==3&&sub[3]==1){panel("Производительность",{0,body});toggle("Лимит FPS игры",cfg.unlock_fps);if(cfg.unlock_fps){setting_int(label("Максимум FPS"),&cfg.fps_limit,30,144);ImGui::TextWrapped("%s",frame.fps_status.c_str());}scroll_end();}
 if(tab==3&&sub[3]==2){
  panel("Диагностика",{0,body});
  toggle("Отладочная информация",cfg.debug);if(cfg.debug){ImGui::TextWrapped("%s",tr(frame.status.c_str()));ImGui::TextWrapped("%s",tr(frame.aim_status.c_str()));ImGui::TextWrapped("%s",tr(frame.camera_status.c_str()));ImGui::TextWrapped("%s",tr(frame.day_status.c_str()));}
  scroll_end();
 }
 if(tab==4&&sub[4]==0){
  panel("Камера",{0,body});
  const char* models[]={tr("Обычная"),tr("Патрик"),tr("Спанч Боб")};
  setting_combo(label("Модель персонажа"),&cfg.player_model,models,3);
  if(vip_mode){
   if(cfg.player_model!=0){toggle("Визуальное вращение 360°",cfg.spin);if(cfg.spin)setting_int(label("Скорость вращения"),&cfg.spin_speed,30,720,"%d °/s");}
   
  }
  toggle("Свободная камера",cfg.freecam);toggle("Кнопка фрикама на экране",cfg.free_button);if(cfg.freecam){setting_int(label("Скорость камеры"),&cfg.free_speed,1,20);}ImGui::Separator();toggle("Свой FOV камеры",cfg.custom_fov);if(cfg.custom_fov)setting_int(label("Угол обзора камеры"),&cfg.camera_fov,50,130);toggle("Третье лицо",cfg.thirdperson);if(cfg.thirdperson){cfg.freecam=false;setting_int(label("Дистанция камеры (см)"),&cfg.third_distance,100,500);setting_int(label("Высота камеры (см)"),&cfg.third_height,0,100);setting_int(label("Смещение плеча (см)"),&cfg.third_shoulder,0,100);if(!frame.camera_status.empty())ImGui::TextWrapped("%s",frame.camera_status.c_str());}
  scroll_end();
 }
 if(tab==4&&sub[4]==2){
  panel("Управление фармом и подбором",{0,body});
  toggle("Быстрый подбор",cfg.quickloot);ImGui::Separator();
  toggle("Автофарм",cfg.autofarm);toggle("Показать координаты",cfg.calibration);ImGui::Separator();
 point_button("Выбрать джойстик",0);point_button("Выбрать поворот",1);point_button("Выбрать удар",2);
 
 ImGui::Separator();ImGui::TextUnformatted(tr("Что добывать"));toggle("Добывать серу",cfg.farm_sulfur);toggle("Добывать камень",cfg.farm_stone);toggle("Добывать металл",cfg.farm_metal);toggle("Добывать бочки",cfg.farm_barrels);toggle("Добывать дерево",cfg.farm_wood);toggle("Добывать МВК",cfg.farm_highmetal);
  scroll_end();
 }
 if(tab==4&&sub[4]==1){
  panel("Движение",{0,body});
  toggle("Ускорение движения",cfg.movement_boost);
  if(cfg.movement_boost)setting_int(label("Скорость ходьбы и бега"),&cfg.movement_percent,100,150,"%d%%");
  scroll_end();
 }
 if(vip_mode&&((tab==4&&sub[4]==3)||(tab==0&&sub[0]==5))){
  panel(tab==4?"Автохилл":"Поиск построек",{0,body});
  if(tab==4){
  if(embedded)ImGui::TextWrapped("%s",tr("Автохилл требует root"));
  else{
   toggle("Автохилл",cfg.vip_autoheal);
   if(cfg.vip_autoheal){
    setting_int(label("Лечить при HP ниже (%)"),&cfg.heal_threshold,1,100,"%d%%");setting_int(label("Пауза между лечением (мс)"),&cfg.heal_interval,500,5000);
    ImGui::TextWrapped("%s",tr("Выбери аптечку и кнопку применения касанием экрана."));
    point_button("Выбрать аптечку",3);
    point_button("Выбрать применение",4);
    
    
    
    
   }
  }
  }else{
  toggle("Поиск построек игрока",cfg.vip_home_search);
  if(cfg.vip_home_search&&!tracked_identity)ImGui::TextWrapped("%s",tr("Выбери игрока из списка ниже"));
  if(collapsible(label("Игроки, доступные клиенту"))){
   if(ImGui::Button(label("Снять отметку")))tracked_identity=0;
   for(const auto& actor:frame.players){
    if(actor.local||actor.hp<=0||actor.sleeping||!actor.identity)continue;
    ImGui::PushID(int(actor.id));
    bool selected=tracked(frame,actor);
    const bool before=selected;
    toggle(actor.name.c_str(),selected);
    if(selected!=before){
     if(selected){tracked_pid=frame.pid;tracked_id=actor.id;tracked_identity=actor.identity;}
     else tracked_identity=0;
    }
    ImGui::PopID();
   }
  }
  }
  scroll_end();
 }
 if(tab==5){
  panel("Конфиги",{0,body});
  if(ImGui::Button(label("Профили настроек"))){recorder_action=3;opened=false;menu_alpha=0;}if(ImGui::Button(label("Сохранить настройки")))config_message=save(config_path)?"Настройки сохранены":"Ошибка сохранения";if(ImGui::Button(label("Загрузить настройки")))config_message=load(config_path)?"Настройки загружены":"Ошибка загрузки";if(ImGui::Button(label("Сбросить настройки"))){cfg={};config_message="Настройки сброшены";}ImGui::TextWrapped("%s",tr(config_message.c_str()));
  scroll_end();
 }
 ImGui::EndChild();
 const auto fp=ImGui::GetCursorScreenPos();auto* fd=ImGui::GetWindowDrawList();
 fd->AddLine(fp,{fp.x+ImGui::GetContentRegionAvail().x,fp.y},IM_COL32(60,60,60,130));
 const auto scene_now=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
 const bool fresh=frame.camera&&frame.time>0&&scene_now>=frame.time&&scene_now-frame.time<=350;
 fd->AddCircleFilled({fp.x+7,fp.y+15},3,fresh?IM_COL32(156,156,156,255):IM_COL32(164,164,164,255));
 fd->AddText(ImGui::GetFont(),ImGui::GetFontSize()*.8f,{fp.x+18,fp.y+7},IM_COL32(154,154,154,255),tr(fresh?"Сцена подключена":"Ожидание сцены"));
 const char* version="NOVA.CC  /  1.0";auto vs=ImGui::CalcTextSize(version);fd->AddText(ImGui::GetFont(),ImGui::GetFontSize()*.8f,{root->Pos.x+root->Size.x-vs.x*.8f-20,fp.y+7},IM_COL32(119,119,119,255),version);
 ImGui::End();ImGui::PopStyleVar();

 if(menu_alpha<1.f)scale_menu_draw(root,{root->Pos.x+root->Size.x*.5f,root->Pos.y+root->Size.y*.5f},.28f+.72f*reveal);
 dof_menu::touch_scroll().finish();menu_io.FontGlobalScale=previous_font_scale;ImGui::PopFont();
}

inline bool world_enabled(int kind){switch(kind){case oxide::Animal:return cfg.animals;case oxide::Bot:return cfg.bots;case oxide::Vehicle:return cfg.vehicles;case oxide::Turret:return cfg.turrets;default:return kind>=1&&kind<=6&&(resource_mask()&(1U<<(kind-1)));}}
inline int esp_range(){return std::clamp(cfg.max_distance,20,350);}
template<class Project>
inline void player_silhouette(ImDrawList* draw,const oxide::Actor& actor,Project project,float height,ImU32 tint,bool outline,bool filled,ImU32 fill){
 struct Limb{ImVec2 a,b;float radius;};
 std::array<Limb,32> limbs{};
 size_t count=0;
 for(const auto& edge:actor.edges){
  if(count==limbs.size())break;
  if(edge.first>=actor.bones.size()||edge.second>=actor.bones.size())continue;
  ImVec2 a,b;
  const auto& first=actor.bones[edge.first].position;
  const auto& second=actor.bones[edge.second].position;
  if(!project(first,a)||!project(second,b))continue;
  const float middle=(first.y+second.y)*.5f;
  const bool torso=std::abs((first.x+second.x)*.5f-actor.body.x)<.17f&&
                   std::abs((first.z+second.z)*.5f-actor.body.z)<.17f&&std::abs(middle-actor.body.y)<.36f;
  limbs[count++]={a,b,std::clamp(height*(torso?.095f:.043f),1.5f,45.f)};
 }
 if(!count)return;
 ImVec2 head;
 if(count<limbs.size()&&project(actor.head,head))limbs[count++]={head,head,std::clamp(height*.07f,1.5f,36.f)};
 auto inside=[&](ImVec2 p,const Limb& limb){
  const float x=limb.b.x-limb.a.x,y=limb.b.y-limb.a.y;
  const float dx=p.x-limb.a.x,dy=p.y-limb.a.y;
  const float t=std::clamp((dx*x+dy*y)/std::max(.001f,x*x+y*y),0.f,1.f);
  const float px=dx-t*x,py=dy-t*y;
  return px*px+py*py<limb.radius*limb.radius*.95f;
 };
 for(size_t i=0;i<count;++i){
  const auto& limb=limbs[i];
  const float angle=std::atan2(limb.b.y-limb.a.y,limb.b.x-limb.a.x);
  ImVec2 ring[18];
  for(int j=0;j<18;++j){
   const float theta=angle-1.5707963f+(j%9)*.39269908f+(j>=9?3.1415926f:0.f);
   const auto center=j<9?limb.b:limb.a;
   ring[j]={center.x+std::cos(theta)*limb.radius,center.y+std::sin(theta)*limb.radius};
  }
  if(filled)draw->AddConvexPolyFilled(ring,18,fill);
  const bool glow=filled&&cfg.vip_chams_glow;
  if(!outline&&!glow)continue;
  for(int j=0;j<18;++j){
   const auto a=ring[j],b=ring[(j+1)%18];
   const ImVec2 mid{(a.x+b.x)*.5f,(a.y+b.y)*.5f};
   bool covered=false;
   for(size_t k=0;k<count&&!covered;++k)if(k!=i)covered=inside(mid,limbs[k]);
   if(covered)continue;
   if(glow){draw->AddLine(a,b,(fill&0xffffff)|0x20000000,7.f);draw->AddLine(a,b,(fill&0xffffff)|0x55000000,3.f);}
   if(outline){draw->AddLine(a,b,IM_COL32(0,0,0,210),3.f);draw->AddLine(a,b,tint,1.5f);}
  }
 }
}
inline void armor_icons(ImDrawList* draw,float cx,float y,uint8_t slots,ImU32 tint){
 constexpr float stride=18.f;
 const int count=bool(slots&1)+bool(slots&2)+bool(slots&4)+bool(slots&8);
 float x=cx-(count-1)*stride*.5f;
 for(int slot=0;slot<4;++slot){
  if(!(slots&(1<<slot)))continue;
  draw->AddRectFilled({x-8,y},{x+8,y+16},IM_COL32(20,24,31,205),4.f);
  switch(slot){
   case 0:
    draw->AddCircleFilled({x,y+7},4.6f,tint,12);
    draw->AddRectFilled({x-4.5f,y+7},{x+5.5f,y+9},tint,1.f);
    break;
   case 1:{
    const ImVec2 vest[]={{x-3,y+3},{x+3,y+3},{x+6,y+6},{x+4,y+13},{x-4,y+13},{x-6,y+6}};
    draw->AddConvexPolyFilled(vest,6,tint);
    break;
   }
   case 2:
    draw->AddRectFilled({x-4.5f,y+3},{x+4.5f,y+7},tint);
    draw->AddRectFilled({x-4.5f,y+6},{x-1,y+13},tint);
    draw->AddRectFilled({x+1,y+6},{x+4.5f,y+13},tint);
    break;
   case 3:
    draw->AddRectFilled({x-3,y+3},{x+2,y+10},tint,1.f);
    draw->AddRectFilled({x-3,y+8},{x+6,y+13},tint,1.f);
    break;
  }
  x+=stride;
 }
}
inline void esp(const oxide::Frame& f,float w,float h,long long now){if(recorder_ui_active)return;auto* d=ImGui::GetBackgroundDrawList();const auto aim_display=active_aim_controls();
 if(aim_display.draw_fov&&aim_kind()!=3){float radius=std::min(std::min(w,h)*2.f,std::tan(std::min(aim_display.fov*.5f,89.f)*.0174532925f)*std::min(w,h)*.5f);d->AddCircle({w*.5f,h*.5f},radius,color(0),96,1);}
 if(!f.camera||now<f.time||now-f.time>350)return;auto project=[&](oxide::V p,ImVec2& v){return oxide::project(f.view,f.projection,p,w,h,v.x,v.y);};auto origin=oxide::origin(f.view);
 if(vip_mode&&cfg.vip_hit_mark&&f.hit_at>0&&now>=f.hit_at&&now-f.hit_at<420){
  const int alpha=int(255.f*(1.f-float(now-f.hit_at)/420.f));
  const auto tint=f.hit_kill?IM_COL32(255,77,88,alpha):IM_COL32(255,216,112,alpha);
  const float extent=f.hit_kill?23.f:18.f;
  for(float x:{-1.f,1.f})for(float y:{-1.f,1.f}){
   const ImVec2 from{w*.5f+x*7.f,h*.5f+y*7.f},to{w*.5f+x*extent,h*.5f+y*extent};
   d->AddLine(from,to,IM_COL32(0,0,0,alpha),5.f);
   d->AddLine(from,to,tint,3.f);
  }
 }
 if(vip_mode&&cfg.vip_tracers){
  for(const auto& line:f.shot_segments){
   const auto age=now-line.time;
   if(age<0||age>=cfg.tracer_lifetime)continue;
   ImVec2 a,b;
   if(!oxide::project_edge(f.view,f.projection,line.from,line.to,w,h,a.x,a.y,b.x,b.y))continue;
   auto tint=cfg.colors[23];
   tint.w*=1.f-float(age)/float(cfg.tracer_lifetime);
   d->AddLine(a,b,ImGui::ColorConvertFloat4ToU32(tint),cfg.tracer_width*.1f);
  }
 }
 auto in_screen=[&](ImVec2 point){return point.x>=0&&point.x<=w&&point.y>=0&&point.y<=h;};
 auto arrow=[&](oxide::V position,ImU32 tint,bool selected=false){
  const auto v=oxide::view_point(f.view,position);
  float x=v.x,y=-v.y;
  if(v.z>0&&std::abs(x)+std::abs(y)<.01f)y=1.f;
  const float length=std::hypot(x,y);
  if(!std::isfinite(length)||length<.01f)return;
  x/=length;y/=length;
  const float radius=selected?std::min((w*.5f-30.f)/std::max(.001f,std::abs(x)),(h*.5f-30.f)/std::max(.001f,std::abs(y))):std::min(float(cfg.arrow_radius),std::min(w,h)*.5f-20.f);
  if(radius<=0)return;
  const ImVec2 point{w*.5f+x*radius,h*.5f+y*radius};
  d->AddTriangleFilled({point.x+x*10,point.y+y*10},
    {point.x-x*8-y*6,point.y-y*8+x*6},
    {point.x-x*8+y*6,point.y-y*8-x*6},tint);
 };
 std::unordered_set<uint32_t> visible_players,visible_bots;
 const oxide::Actor* local=nullptr;
 for(const auto& actor:f.players)if(actor.local){local=&actor;break;}
 if(aim_display.marker&&f.aim_point_valid){ImVec2 point;if(project(f.aim_point,point)&&in_screen(point))d->AddCircle(point,8,color(0),24,2);}
 for(const auto& a:f.players){if(a.local||a.hp<=0||(a.sleeping&&!cfg.sleepers))continue;if(cfg.hide_allies&&local&&a.relations_valid&&local->relations_valid&&!oxide::affiliation_allows(*local,a,true,true))continue;float distance=oxide::len(oxide::sub(a.feet,origin));const bool pinned=tracked(f,a);
  if(pinned){
   ImVec2 point;
   if(!project(a.head,point)||!in_screen(point)||distance>esp_range())arrow(a.head,IM_COL32(255,210,100,255),true);
  }
  if(distance>esp_range())continue;ImVec2 bottom,top;if(!project(a.feet,bottom)||!project(oxide::add(a.head,{0,.17f,0}),top)||(!in_screen(bottom)&&!in_screen(top))){if(cfg.player_arrows&&!pinned)arrow(a.head,color(0));continue;}float height=bottom.y-top.y,half=height*.23f,cx=(top.x+bottom.x)*.5f;
  if(a.sleeping){float minx=std::min(top.x,bottom.x),maxx=std::max(top.x,bottom.x),miny=std::min(top.y,bottom.y),maxy=std::max(top.y,bottom.y);for(const auto& bone:a.bones){ImVec2 point;if(project(bone.position,point)){minx=std::min(minx,point.x);maxx=std::max(maxx,point.x);miny=std::min(miny,point.y);maxy=std::max(maxy,point.y);}}top={cx,miny-3};bottom={cx,maxy+3};height=bottom.y-top.y;half=std::max((maxx-minx)*.5f+3,height*.23f);cx=(minx+maxx)*.5f;}
  if(height<4||height>h*3)continue;
  ImU32 actor_color=color(a.sleeping?18:0);
  if(cfg.box||cfg.name||cfg.health||cfg.distance||cfg.lines||(cfg.skeleton&&!a.edges.empty())||
     (cfg.weapon&&!a.weapon.empty())||(cfg.armor&&(a.armor_slots||a.armor_valid))||(cfg.player_clan&&!a.clan_label.empty())||
     (cfg.player_status&&a.sleeping)||(vip_mode&&(cfg.vip_player_outline||cfg.vip_chams)&&!a.edges.empty()))
   visible_players.insert(a.id);
  if(vip_mode&&(cfg.vip_player_outline||cfg.vip_chams))
   player_silhouette(d,a,project,height,actor_color,cfg.vip_player_outline,cfg.vip_chams,ImGui::ColorConvertFloat4ToU32(cfg.colors[24]));
  if(cfg.box)player_box(d,{cx-half,top.y},{cx+half,bottom.y},actor_color);
  if(cfg.name)esp_caption(d,cx,top.y-4,a.name.c_str(),color(1),cfg.name_background,true);
  if(cfg.health){float fraction=std::clamp(a.hp/a.max_hp,0.f,1.f);d->AddRectFilled({cx-half-10,top.y},{cx-half-4,bottom.y},IM_COL32(0,0,0,160));d->AddRectFilledMultiColor({cx-half-9,bottom.y-height*fraction},{cx-half-5,bottom.y},color(2),color(2),color(3),color(3));}
  float text_y=bottom.y+3;if(cfg.distance){char s[32];snprintf(s,sizeof(s),"%.0f м",distance);text_y+=esp_caption(d,cx,text_y,s,color(1),cfg.distance_background);}
  if(cfg.player_clan&&!a.clan_label.empty()){auto size=ImGui::CalcTextSize(a.clan_label.c_str());d->AddText({cx-size.x*.5f,text_y},color(1),a.clan_label.c_str());text_y+=size.y;}
  if(cfg.player_status&&a.sleeping){auto caption=tr("Спит");auto size=ImGui::CalcTextSize(caption);d->AddText({cx-size.x*.5f,text_y},color(18),caption);text_y+=size.y;}
  if(cfg.weapon&&!a.weapon.empty()){auto size=ImGui::CalcTextSize(oxide::weapon_name_ru(a.weapon).c_str());d->AddText({cx-size.x*.5f,text_y},color(4),oxide::weapon_name_ru(a.weapon).c_str());text_y+=size.y;}
  if(cfg.armor){if(a.armor_slots){armor_icons(d,cx,text_y+2,a.armor_slots,color(1));text_y+=24;}if(a.armor_valid){char protection[64];snprintf(protection,sizeof(protection),"%s %.0f%%",tr("Броня"),a.armor_protection*100.f);esp_caption(d,cx,text_y+2,protection,color(1),true);}}
  if(cfg.lines)d->AddLine({w*.5f,cfg.line_origin?0.f:h},cfg.line_origin?top:bottom,color(4),1);
  if(cfg.skeleton)for(auto [i,j]:a.edges){if(i>=a.bones.size()||j>=a.bones.size())continue;ImVec2 x,y;if(project(a.bones[i].position,x)&&project(a.bones[j].position,y))d->AddLine(x,y,actor_color,cfg.line_weight*.1f);}
 }
 if(cfg.debug&&(f.display_stale||now-f.time>250))d->AddText({16,h-32},IM_COL32(255,200,90,230),tr("ESP: сохранён последний кадр"));
 for(const auto& actor:f.npc_targets)if(cfg.bots&&actor.kind==oxide::Bot&&oxide::len(oxide::sub(actor.feet,origin))<=esp_range()){
  ImVec2 point;const bool head_visible=project(actor.head,point)&&in_screen(point);
  if(cfg.bot_lines||(cfg.bot_rig&&!actor.edges.empty()))visible_bots.insert(actor.id);
  if(cfg.bot_lines&&head_visible)d->AddLine({w*.5f,cfg.line_origin?0.f:h},point,color(15),1);
  if(cfg.bot_rig)for(auto edge:actor.edges){
   if(edge.first>=actor.bones.size()||edge.second>=actor.bones.size())continue;
   ImVec2 a,b;if(oxide::project_edge(f.view,f.projection,actor.bones[edge.first].position,actor.bones[edge.second].position,w,h,a.x,a.y,b.x,b.y))
    d->AddLine(a,b,color(15),cfg.line_weight*.1f);
  }
 }
 int drawn=0;
 for(const auto& item:f.world){if(!world_enabled(item.kind))continue;:
 if(vip_mode&&item.kind==oxide::Animal){
  int species=0;
  while(species<6&&item.name!=vip_species[species])++species;
  if(!(cfg.vip_animals&(1<<species)))continue;
 }
 float distance=oxide::len(oxide::sub(item.position,origin));if(distance>cfg.world_range)continue;ImVec2 p;if(!project(item.position,p)||!in_screen(p)){if(item.kind==oxide::Bot&&cfg.bot_arrows&&drawn<cfg.world_limit){arrow(item.position,color(15));++drawn;}continue;}
 if(drawn>=cfg.world_limit&&item.object!=farm_target)continue;
 ++drawn;
 char text[192]{};
 const char* item_name=item.kind==oxide::Bot?tr("Бот"):tr(item.name.c_str());
 const bool show_name=item.kind!=oxide::Bot||cfg.bot_names;
 const bool show_distance=cfg.world_distance&&(item.kind!=oxide::Bot||cfg.bot_distance);
 if(show_name&&show_distance)snprintf(text,sizeof(text),"%s · %.0f м",item_name,distance);
 else if(show_name)snprintf(text,sizeof(text),"%s",item_name);
 else if(show_distance)snprintf(text,sizeof(text),"%.0f м",distance);
 if(item.kind==oxide::Bot&&(cfg.world_mode!=1||(cfg.world_mode!=0&&text[0])))visible_bots.insert(item.id);
 ImU32 c=color(7+std::clamp(item.kind,1,10));if(cfg.autofarm&&item.object==farm_target){d->AddCircle(p,18,IM_COL32(255,235,70,255),32,3);d->AddLine({p.x-25,p.y},{p.x-12,p.y},IM_COL32_WHITE,2);d->AddLine({p.x+12,p.y},{p.x+25,p.y},IM_COL32_WHITE,2);if(item.hit_valid){ImVec2 hit;if(project(item.hit_position,hit)){d->AddCircle(hit,9,IM_COL32(255,235,70,255),24,2);d->AddLine(p,hit,IM_COL32(255,235,70,200),1);}}}auto sz=ImGui::CalcTextSize(text);if(cfg.world_mode!=1)d->AddCircle(p,7,c,16,2);if(cfg.world_mode!=0&&text[0]){d->AddText({p.x-sz.x*.5f+1,p.y+11},IM_COL32_BLACK,text);d->AddText({p.x-sz.x*.5f,p.y+10},c,text);}}
 if(vip_mode&&cfg.vip_build_hp&&now-f.time<=700){
  std::vector<std::pair<float,const oxide::Container*>> nearby;
  for(const auto& c:f.containers)if(c.hp>0&&c.max_hp>0)nearby.emplace_back(oxide::len(oxide::sub(c.position,origin)),&c);
  std::sort(nearby.begin(),nearby.end(),[](const auto& a,const auto& b){return a.first<b.first;});
  int shown=0;
  for(const auto& entry:nearby){
   ImVec2 point;
   const auto& c=*entry.second;
   if(entry.first>60||shown>=10)break;
   if(!project(c.position,point)||!in_screen(point))continue;
   char line[220];
   const int charges=int(std::ceil(c.hp/300.f));
   const int rockets=int(std::ceil(c.hp/150.f));
   snprintf(line,sizeof(line),"HP %.0f / %.0f · C4 %d · %s %d",c.hp,c.max_hp,charges,tr("Ракеты"),rockets);
   esp_caption(d,point.x,point.y,line,color(1),true);
   ++shown;
  }
 }
 const oxide::Container* nearest_home=nullptr;
 float nearest_distance=0;
 if(vip_mode&&cfg.vip_home_search&&f.pid==tracked_pid&&tracked_identity){
  for(const auto& c:f.containers){
   if(c.matched_owner!=tracked_identity||c.matched_owner_id!=tracked_id)continue;
   const float distance=oxide::len(oxide::sub(c.position,origin));
   const bool cupboard=c.kind==3||c.kind==7;
   const bool best_cupboard=nearest_home&&(nearest_home->kind==3||nearest_home->kind==7);
   if(!nearest_home||(cupboard&&!best_cupboard)||(cupboard==best_cupboard&&distance<nearest_distance)){
    nearest_home=&c;nearest_distance=distance;
   }
  }
  if(nearest_home){
   ImVec2 point;
   if(project(nearest_home->position,point)){
    ImVec2 clipped{std::clamp(point.x,12.f,w-12.f),std::clamp(point.y,12.f,h-12.f)};
    d->AddLine({w*.5f,h*.92f},clipped,IM_COL32(0,0,0,210),7.f);
    d->AddLine({w*.5f,h*.92f},clipped,color(5),4.f);
    if(in_screen(point)){
     char tag[96];snprintf(tag,sizeof(tag),"%s · %.0f м",tr((nearest_home->kind==3||nearest_home->kind==7)?"Шкаф игрока":"Постройка игрока"),nearest_distance);
     esp_caption(d,point.x,point.y,tag,color(5),true);
    }
   }else arrow(nearest_home->position,color(5),true);
  }else if(f.owner_scan_complete==tracked_identity){
   esp_caption(ImGui::GetForegroundDrawList(),w*.5f,h*.16f,tr("Постройки игрока не найдены рядом"),color(1),true);
  }
 }
 if(cfg.actor_badge&&(!visible_players.empty()||!visible_bots.empty()))oxide_watermark::draw_actor_badge(w,cfg.actor_badge_scale,visible_players.size(),visible_bots.size(),accent());
 for(const auto& c:f.containers){
 if(c.kind>=6)continue;
 if((c.kind==1&&!cfg.small)||(c.kind==2&&!cfg.large)||(c.kind==3&&!cfg.cupboard)||(c.kind==4&&!cfg.death_loot&&!(vip_mode&&cfg.vip_loot_outline)))continue;float dist=oxide::len(oxide::sub(c.position,origin));if(dist>esp_range())continue;if(c.bounds_valid&&(c.kind==3?cfg.cupboard_boxes:cfg.container_boxes||(vip_mode&&c.kind==4&&cfg.vip_loot_outline))){for(unsigned i=0;i<8;++i)for(unsigned bit:{1U,2U,4U})if(!(i&bit)){ImVec2 a,b;if(oxide::project_edge(f.view,f.projection,c.corners[i],c.corners[i|bit],w,h,a.x,a.y,b.x,b.y)){d->AddLine(a,b,IM_COL32(0,0,0,190),3.5f);d->AddLine(a,b,color(c.kind==4?6:c.kind+4),1.5f);}}}ImVec2 p;if(!project(c.position,p))continue;
 if(vip_mode&&c.kind==4&&cfg.vip_loot_outline){
  d->AddRect({p.x-10,p.y-8},{p.x+10,p.y+8},IM_COL32(0,0,0,220),4.f,0,4.f);
  d->AddRect({p.x-10,p.y-8},{p.x+10,p.y+8},color(6),4.f,0,1.5f);
 }
 char label[96];snprintf(label,sizeof(label),"%s · %.0f м",c.kind==1?"Маленький сундук":c.kind==2?"Большой сундук":c.kind==4?"Лут игрока":"Шкаф",dist);const char* visible=tr(label);auto size=ImGui::CalcTextSize(visible);d->AddCircle(p,5,color(c.kind==4?6:c.kind+4),16,2);d->AddText({p.x-size.x*.5f,p.y+8},color(c.kind==4?6:c.kind+4),label);}
 if(f.freecam){d->AddText({w*.5f-70,24},IM_COL32(255,210,100,255),"FREECAM");for(int i=0;i<2;++i){ImVec2 p(w*.88f,h*(i?.68f:.4f));d->AddCircleFilled(p,w*.032f,IM_COL32(25,28,40,160),32);d->AddText({p.x-30,p.y-12},IM_COL32_WHITE,i?"DOWN":"UP");}}
}
}
inline void render(float w, float h, const oxide::Frame& frame, bool embedded = false) {
    if (record_ui_active) return;
    if (cfg.menu_alpha < 0.01f) return;

    static int currentTab = 0;

    ImGui::SetNextWindowSize(ImVec2(720, 460), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(w * 0.5f, h * 0.5f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowBgAlpha(0.96f);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 10.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 5.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 7.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14, 14));

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.055f, 0.060f, 0.075f, 0.98f));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.075f, 0.082f, 0.100f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.15f, 0.17f, 0.21f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.91f, 0.93f, 0.97f, 1.0f));

    if (ImGui::Begin("Nova.cc", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar)) {
        
        auto Toggle = [](const char* label, bool* value) {
            ImGui::PushID(label);
            ImGui::TextUnformatted(label);
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 42);
            ImVec2 p = ImGui::GetCursorScreenPos();
            ImDrawList* draw = ImGui::GetWindowDrawList();
            float width = 36.0f;
            float height = 19.0f;
            ImGui::InvisibleButton("##toggle", ImVec2(width, height));
            if (ImGui::IsItemClicked()) *value = !*value;
            ImU32 color = *value ? IM_COL32(45, 125, 230, 255) : IM_COL32(65, 70, 82, 255);
            draw->AddRectFilled(p, ImVec2(p.x + width, p.y + height), color, height * 0.5f);
            float radius = 7.0f;
            float circleX = *value ? p.x + width - 10.0f : p.x + 10.0f;
            draw->AddCircleFilled(ImVec2(circleX, p.y + height * 0.5f), radius, IM_COL32(245, 247, 250, 255));
            ImGui::PopID();
        };

        ImGui::BeginGroup();
        ImGui::TextColored(ImVec4(0.25f, 0.55f, 0.95f, 1.0f), "N");
        ImGui::SameLine();
        ImGui::Text("Nova.cc");
        ImGui::SameLine(ImGui::GetWindowWidth() - 115);
        ImGui::TextDisabled("PRIVATE BUILD");
        ImGui::EndGroup();

        ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();

        const char* tabs[] = {"Visuals", "Aimbot", "World", "Settings"};
        for (int i = 0; i < 4; i++) {
            if (i > 0) ImGui::SameLine();
            if (currentTab == i) {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.34f, 0.62f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.16f, 0.40f, 0.72f, 1.0f));
            } else {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.10f, 0.11f, 0.14f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.16f, 0.18f, 0.23f, 1.0f));
            }
            if (ImGui::Button(tabs[i], ImVec2(105, 34))) currentTab = i;
            ImGui::PopStyleColor(2);
        }

        ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();

        if (currentTab == 0) {
            ImGui::BeginChild("VisualSettings", ImVec2(330, 0), true);
            ImGui::TextColored(ImVec4(0.35f, 0.62f, 0.95f, 1.0f), "PLAYER ESP");
            ImGui::Spacing();
            Toggle("Name", &cfg.name);
            Toggle("Health", &cfg.health);
            Toggle("Distance", &cfg.distance);
            Toggle("Name Background", &cfg.name_background);
            Toggle("Distance Background", &cfg.distance_background);
            ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(0.35f, 0.62f, 0.95f, 1.0f), "VISUALS");
            ImGui::Spacing();
            Toggle("Skeleton", &cfg.skeleton);
            Toggle("ESP Box", &cfg.box);
            Toggle("Lines", &cfg.lines);
            Toggle("Weapon", &cfg.weapon);
            Toggle("Armor", &cfg.armor);
            ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
            
            ImGui::TextColored(ImVec4(0.35f, 0.62f, 0.95f, 1.0f), "BOTS");
            ImGui::Spacing();
            Toggle("Bots", &cfg.bots);
            Toggle("Bot Lines", &cfg.bot_lines);
            Toggle("Bot Skeleton", &cfg.bot_skeleton);
            ImGui::EndChild();

            ImGui::SameLine();
            ImGui::BeginChild("PlayerPreview", ImVec2(0, 0), true);
            ImGui::Text("Player Preview");
            ImGui::Separator();
            ImVec2 canvasSize = ImGui::GetContentRegionAvail();
            ImVec2 canvasPos = ImGui::GetCursorScreenPos();
            ImDrawList* draw = ImGui::GetWindowDrawList();
            draw->AddRectFilled(canvasPos, ImVec2(canvasPos.x + canvasSize.x, canvasPos.y + canvasSize.y - 40), IM_COL32(17, 21, 29, 255), 6.0f);
            draw->AddRect(canvasPos, ImVec2(canvasPos.x + canvasSize.x, canvasPos.y + canvasSize.y - 40), IM_COL32(48, 57, 72, 255), 6.0f);
            const char* previewText = "Player Model";
            ImVec2 textSize = ImGui::CalcTextSize(previewText);
            draw->AddText(ImVec2(canvasPos.x + (canvasSize.x - textSize.x) * 0.5f, canvasPos.y + (canvasSize.y - 40 - textSize.y) * 0.5f), IM_COL32(135, 148, 168, 255), previewText);
            ImGui::Dummy(ImVec2(0, canvasSize.y - 40));
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(0.35f, 0.65f, 0.98f, 1.0f), "Player [28m]");
            ImGui::EndChild();
        }
        else if (currentTab == 1) { ImGui::Text("Aimbot"); }
        else if (currentTab == 2) { ImGui::Text("World"); }
        else if (currentTab == 3) { ImGui::Text("Settings"); }
    }
    ImGui::End();
    ImGui::PopStyleColor(4);
    ImGui::PopStyleVar(4);
}