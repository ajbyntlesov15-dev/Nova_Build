#pragma once
#include "../runtime/custom_model.hpp"
#include <cstdio>
#include <GLES3/gl3.h>
#include <cstddef>
extern "C" const unsigned char dof_patrick[],dof_patrick_end[],dof_spongebob[],dof_spongebob_end[];
namespace custom_model {
class Renderer {
 struct Gpu {Asset asset;GLuint vao=0,vbo=0,ibo=0;std::vector<GLuint> textures;};
 Gpu gpu_[2];GLuint program_=0;bool failed_=false,prepared_=false;int selected_=0,width_=0,height_=0,surface_height_=0;oxide::M model_{};oxide::M view_{},projection_{};
 GLint transform_=-1,view_location_=-1,projection_location_=-1,color_=-1,kind_=-1,part_=-1;
 static GLuint shader(GLenum type,const char* source){GLuint s=glCreateShader(type);glShaderSource(s,1,&source,nullptr);glCompileShader(s);GLint okay=0;glGetShaderiv(s,GL_COMPILE_STATUS,&okay);if(!okay){char log[1024];glGetShaderInfoLog(s,sizeof(log),nullptr,log);fprintf(stderr,"shader=%s",log);glDeleteShader(s);return 0;}return s;}
 bool init(){
  if(program_)return true;if(failed_)return false;failed_=true;
  const char* vs=R"(#version 300 es
precision highp float;
layout(location=0) in vec3 position;layout(location=1) in vec3 normal;layout(location=2) in vec2 uv;
uniform mat4 model;uniform mat4 view;uniform mat4 projection;out vec2 texcoord;out vec3 restPosition;out float light;
void main(){mat4 m=model;vec3 n=normalize(mat3(m)*normal);light=.72+.28*max(dot(n,normalize(vec3(.3,.8,.5))),0.);texcoord=uv;restPosition=position;gl_Position=projection*view*m*vec4(position,1.);})";
  const char* fs=R"(#version 300 es
precision mediump float;in vec2 texcoord;in vec3 restPosition;in float light;uniform sampler2D image;uniform vec4 color;uniform int modelKind;uniform int part;out vec4 outputColor;
void main(){vec4 c=texture(image,texcoord)*color;
 if(modelKind==1&&part==3)c=vec4(.45,.8,.22,1.);
 if(modelKind==2&&(part==8||part==15)){
  vec2 p=restPosition.xy;c=vec4(1.,.93,.12,1.);
  if(length((p-vec2(-.43,1.69))/vec2(.05,.035))<1.||length((p-vec2(.41,1.63))/vec2(.04,.055))<1.||length((p-vec2(-.4,1.08))/vec2(.04,.055))<1.||length((p-vec2(.4,.96))/vec2(.045,.03))<1.)c.rgb=vec3(.67,.71,.15);
  if(restPosition.z>.12){
   float eye=min(length((p-vec2(-.19,1.46))/vec2(.16,.17)),length((p-vec2(.19,1.46))/vec2(.16,.17)));
   if(eye<1.)c.rgb=vec3(1.);
   float iris=min(length(p-vec2(-.19,1.46)),length(p-vec2(.19,1.46)));
   if(iris<.066)c.rgb=vec3(.12,.63,.95);if(iris<.031)c.rgb=vec3(.02);if(min(length(p-vec2(-.204,1.48)),length(p-vec2(.176,1.48)))<.012)c.rgb=vec3(1.);
   if(abs(p.x)<.32&&abs(p.y-(1.145+.65*p.x*p.x))<.013)c.rgb=vec3(.4,.17,.04);
   if(abs(p.y-1.104)<.045&&((p.x>-.10&&p.x<-.014)||(p.x>.014&&p.x<.10)))c.rgb=vec3(1.);
   if(length((p-vec2(0.,1.32))/vec2(.058,.115))<1.)c.rgb=vec3(1.,.9,.13);
  }
 }
 if(c.a<.1)discard;float a=c.a;outputColor=vec4(c.rgb*light*a,a);})";
  GLuint v=shader(GL_VERTEX_SHADER,vs),f=shader(GL_FRAGMENT_SHADER,fs);if(!v||!f){if(v)glDeleteShader(v);if(f)glDeleteShader(f);return false;}
  program_=glCreateProgram();glAttachShader(program_,v);glAttachShader(program_,f);glLinkProgram(program_);glDeleteShader(v);glDeleteShader(f);GLint okay=0;glGetProgramiv(program_,GL_LINK_STATUS,&okay);if(!okay){fprintf(stderr,"shader link failed");return false;}
  transform_=glGetUniformLocation(program_,"model");view_location_=glGetUniformLocation(program_,"view");projection_location_=glGetUniformLocation(program_,"projection");color_=glGetUniformLocation(program_,"color");kind_=glGetUniformLocation(program_,"modelKind");part_=glGetUniformLocation(program_,"part");
  for(int k=0;k<2;++k){Gpu& g=gpu_[k];const unsigned char* begin=k?dof_spongebob:dof_patrick;const unsigned char* end=k?dof_spongebob_end:dof_patrick_end;
   if(!load(begin,size_t(reinterpret_cast<uintptr_t>(end)-reinterpret_cast<uintptr_t>(begin)),g.asset))return false;
   glGenVertexArrays(1,&g.vao);glBindVertexArray(g.vao);glGenBuffers(1,&g.vbo);glBindBuffer(GL_ARRAY_BUFFER,g.vbo);glBufferData(GL_ARRAY_BUFFER,g.asset.vertices.size()*sizeof(Vertex),g.asset.vertices.data(),GL_STATIC_DRAW);
   glGenBuffers(1,&g.ibo);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,g.ibo);glBufferData(GL_ELEMENT_ARRAY_BUFFER,g.asset.indices.size()*4,g.asset.indices.data(),GL_STATIC_DRAW);
   glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),nullptr);
   glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)12);
   glEnableVertexAttribArray(2);glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)24);
   g.textures.resize(g.asset.materials.size());glGenTextures(g.textures.size(),g.textures.data());
   for(size_t i=0;i<g.textures.size();++i){auto& m=g.asset.materials[i];glBindTexture(GL_TEXTURE_2D,g.textures[i]);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,m.width,m.height,0,GL_RGBA,GL_UNSIGNED_BYTE,m.pixels.data());}
  }
  glBindVertexArray(0);glBindBuffer(GL_ARRAY_BUFFER,0);glBindTexture(GL_TEXTURE_2D,0);if(glGetError()!=GL_NO_ERROR)return false;failed_=false;return true;
 }
public:
 bool ready(){return init()&&!failed_;}
 void prepare(const oxide::Frame& frame,int selected,int width,int height,int surface_height,long long now){
  prepared_=false;
  if(selected<1||selected>2||!frame.camera||frame.freecam||!frame.third_person||
     !frame.model_heading_valid||now<frame.time||now-frame.time>120||!ready())return;
  for(const auto& actor:frame.players){
   if(!actor.local||actor.object!=frame.local||actor.hp<=0||!oxide::finite(actor.feet))continue;
   const float angle=(frame.model_yaw+frame.model_spin)*.0174532925f;
   const float c=std::cos(angle),s=std::sin(angle);
   model_={{c,0,-s,0,0,1,0,0,s,0,c,0,actor.feet.x,actor.feet.y,actor.feet.z,1}};
   selected_=selected-1;view_=frame.view;projection_=frame.projection;
   width_=width;height_=height;surface_height_=surface_height;prepared_=true;
   return;
  }
 }
 void draw(){
  if(!prepared_||failed_)return;Gpu& g=gpu_[selected_];
  glViewport(0,std::max(0,surface_height_-height_),width_,height_);glDisable(GL_SCISSOR_TEST);glDisable(GL_CULL_FACE);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_TRUE);glClearDepthf(1);glClear(GL_DEPTH_BUFFER_BIT);glEnable(GL_BLEND);glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
  glUseProgram(program_);glUniform1i(glGetUniformLocation(program_,"image"),0);glUniformMatrix4fv(transform_,1,GL_FALSE,model_.v);glUniformMatrix4fv(view_location_,1,GL_FALSE,view_.v);glUniformMatrix4fv(projection_location_,1,GL_FALSE,projection_.v);glBindVertexArray(g.vao);glActiveTexture(GL_TEXTURE0);
  glUniform1i(kind_,selected_+1);int part_index=0;
  for(auto p:g.asset.primitives){glUniform1i(part_,part_index++);glBindTexture(GL_TEXTURE_2D,g.textures[p.material]);glUniform4fv(color_,1,g.asset.materials[p.material].color);glDrawElements(GL_TRIANGLES,p.count,GL_UNSIGNED_INT,reinterpret_cast<void*>(size_t(p.first)*4));}
  if(glGetError()!=GL_NO_ERROR){failed_=true;}
  glBindVertexArray(0);glBindTexture(GL_TEXTURE_2D,0);glUseProgram(0);glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);
 }
 bool healthy()const{return prepared_&&!failed_;}
 void shutdown(){for(auto& g:gpu_){if(g.vbo)glDeleteBuffers(1,&g.vbo);if(g.ibo)glDeleteBuffers(1,&g.ibo);if(g.vao)glDeleteVertexArrays(1,&g.vao);if(!g.textures.empty())glDeleteTextures(g.textures.size(),g.textures.data());g={};}if(program_)glDeleteProgram(program_);program_=0;prepared_=false;}
};
}
