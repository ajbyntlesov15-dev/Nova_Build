#pragma once
#include "imgui.h"
#include <cmath>
// Resolution-independent identity and navigation. No external icon font or textures.
namespace dof_menu {
inline void companion(ImDrawList* d,ImVec2 p,float size,double time){
 // Original adult anime-inspired fashion portrait; opaque evening dress, long hair.
 float breath=std::sin(float(time)*1.8f)*.006f,sway=std::sin(float(time)*.9f)*.012f;
 auto pt=[&](float x,float y){return ImVec2{p.x+(x+sway*(1.f-y*.3f))*size,p.y+(y+breath)*size};};
 const ImU32 hair=IM_COL32(25,25,25,255),ink=IM_COL32(12,12,12,255),skin=IM_COL32(222,222,222,255),light=IM_COL32(245,245,245,255),silver=IM_COL32(160,160,160,255);
 d->PushClipRect(p,{p.x+size,p.y+size*1.5f},true);
 d->AddEllipse(pt(.5f,.75f),size*.44f,size*.63f,IM_COL32(66,66,66,150),0,64,1);
 d->AddEllipseFilled(pt(.49f,.49f),size*.31f,size*.45f,hair,0,56);
 d->AddBezierCubic(pt(.30f,.16f),pt(.08f,.34f),pt(.15f,.75f),pt(.05f,1.05f),hair,size*.12f);
 d->AddBezierCubic(pt(.68f,.16f),pt(.91f,.39f),pt(.75f,.81f),pt(.89f,1.13f),hair,size*.13f);
 // Arms and shoulders are behind the fitted dress.
 d->AddBezierCubic(pt(.26f,.68f),pt(.10f,.95f),pt(.17f,1.20f),pt(.32f,1.12f),skin,size*.095f);
 d->AddBezierCubic(pt(.72f,.68f),pt(.93f,.88f),pt(.89f,1.06f),pt(.66f,1.12f),skin,size*.09f);
 ImVec2 shoulders[]={pt(.23f,.68f),pt(.41f,.57f),pt(.58f,.57f),pt(.76f,.68f),pt(.66f,.90f),pt(.33f,.90f)};d->AddConvexPolyFilled(shoulders,6,skin);
 d->AddRectFilled(pt(.42f,.44f),pt(.57f,.65f),skin,size*.04f);
 d->AddBezierCubic(pt(.29f,.68f),pt(.37f,.62f),pt(.43f,.66f),pt(.48f,.69f),silver,1.1f);
 d->AddBezierCubic(pt(.52f,.69f),pt(.57f,.65f),pt(.63f,.63f),pt(.70f,.68f),silver,1.1f);
 ImVec2 left_bodice[]={pt(.26f,.73f),pt(.48f,.82f),pt(.48f,1.04f),pt(.36f,1.04f)},right_bodice[]={pt(.48f,.82f),pt(.73f,.72f),pt(.61f,1.04f),pt(.48f,1.04f)};d->AddConvexPolyFilled(left_bodice,4,ink);d->AddConvexPolyFilled(right_bodice,4,ink);
 ImVec2 skirt[]={pt(.36f,1.01f),pt(.61f,1.01f),pt(.79f,1.49f),pt(.18f,1.49f)};d->AddConvexPolyFilled(skirt,4,ink);
 d->AddBezierCubic(pt(.29f,.77f),pt(.37f,.90f),pt(.42f,.97f),pt(.36f,1.04f),silver,1);
 d->AddBezierCubic(pt(.64f,.91f),pt(.59f,1.05f),pt(.67f,1.25f),pt(.70f,1.48f),IM_COL32(78,78,78,255),1.4f);
 d->AddLine(pt(.38f,1.04f),pt(.59f,1.04f),silver,1.2f);
 // Face uses narrower, mature proportions rather than the previous chibi design.
 d->PathLineTo(pt(.32f,.17f));d->PathBezierCubicCurveTo(pt(.26f,.29f),pt(.32f,.47f),pt(.49f,.54f));d->PathBezierCubicCurveTo(pt(.64f,.47f),pt(.70f,.29f),pt(.64f,.17f));d->PathFillConvex(skin);
 d->AddBezierCubic(pt(.28f,.23f),pt(.35f,.06f),pt(.54f,.07f),pt(.68f,.23f),hair,size*.10f);
 ImVec2 bang1[]={pt(.30f,.16f),pt(.48f,.10f),pt(.43f,.32f)};d->AddConvexPolyFilled(bang1,3,hair);
 ImVec2 bang2[]={pt(.45f,.12f),pt(.63f,.14f),pt(.69f,.35f)};d->AddConvexPolyFilled(bang2,3,hair);
 d->AddBezierCubic(pt(.28f,.21f),pt(.13f,.52f),pt(.31f,.78f),pt(.18f,.96f),IM_COL32(85,85,85,255),1.1f);
 d->AddBezierCubic(pt(.67f,.23f),pt(.77f,.49f),pt(.62f,.84f),pt(.80f,.99f),IM_COL32(85,85,85,255),1.1f);
 bool blink=std::fmod(time,5.1)>4.94;
 for(float x:{.39f,.58f}){
  d->AddBezierCubic(pt(x-.057f,.315f),pt(x-.015f,.283f),pt(x+.02f,.285f),pt(x+.055f,.31f),ink,1.7f);
  if(!blink){d->AddEllipseFilled(pt(x,.335f),size*.028f,size*.039f,ink,0,20);d->AddCircleFilled(pt(x-.008f,.322f),size*.01f,light,12);d->AddLine(pt(x-.04f,.365f),pt(x+.035f,.36f),silver,1);}
  d->AddBezierCubic(pt(x-.05f,.265f),pt(x-.02f,.25f),pt(x+.02f,.25f),pt(x+.04f,.263f),hair,1.2f);
 }
 d->AddLine(pt(.48f,.36f),pt(.46f,.42f),silver,1);d->AddLine(pt(.46f,.42f),pt(.49f,.427f),silver,1);
 d->AddBezierCubic(pt(.45f,.465f),pt(.48f,.453f),pt(.52f,.477f),pt(.55f,.46f),IM_COL32(82,82,82,255),1.5f);
 d->AddLine(pt(.48f,.482f),pt(.52f,.482f),light,1);
 // Silver earrings, necklace and a relaxed hand at the waist.
 d->AddCircle(pt(.30f,.43f),size*.021f,silver,20,1.2f);d->AddCircle(pt(.67f,.43f),size*.021f,silver,20,1.2f);
 d->AddBezierCubic(pt(.40f,.61f),pt(.43f,.72f),pt(.56f,.72f),pt(.59f,.61f),silver,1);d->AddCircleFilled(pt(.50f,.70f),size*.013f,light,12);
 d->AddEllipseFilled(pt(.66f,1.115f),size*.065f,size*.03f,skin,-.3f,20);
 for(int i=0;i<3;++i)d->AddLine(pt(.63f+i*.016f,1.105f),pt(.61f+i*.016f,1.13f),silver,.8f);
 float twinkle=.55f+.45f*std::sin(float(time)*1.3f);ImU32 star=IM_COL32(190,190,190,int(160*twinkle));
 d->AddLine(pt(.08f,.45f),pt(.08f,.53f),star,1);d->AddLine(pt(.045f,.49f),pt(.115f,.49f),star,1);
 d->PopClipRect();
}
inline void icon(ImDrawList* d,ImVec2 p,float s,int kind,ImU32 c){
 auto pt=[&](float x,float y){return ImVec2{p.x+x*s,p.y+y*s};};
 auto line=[&](float x,float y,float a,float b){d->AddLine(pt(x,y),pt(a,b),c,1.8f);};
 auto circle=[&](float x,float y,float r){d->AddCircle(pt(x,y),r*s,c,24,1.8f);};
 switch(kind){
 case 0: // Eye
  d->AddBezierCubic(pt(.08f,.5f),pt(.3f,.1f),pt(.7f,.1f),pt(.92f,.5f),c,1.8f);
  d->AddBezierCubic(pt(.08f,.5f),pt(.3f,.9f),pt(.7f,.9f),pt(.92f,.5f),c,1.8f);circle(.5f,.5f,.14f);break;
 case 1: circle(.5f,.5f,.29f);line(.5f,.03f,.5f,.3f);line(.5f,.7f,.5f,.97f);line(.03f,.5f,.3f,.5f);line(.7f,.5f,.97f,.5f);break;
 case 2: circle(.5f,.5f,.4f);d->AddEllipse(pt(.5f,.5f),s*.18f,s*.4f,c,0,24,1.8f);line(.12f,.36f,.88f,.36f);line(.12f,.64f,.88f,.64f);break;
 case 3: circle(.5f,.5f,.17f);circle(.5f,.5f,.35f);for(int i=0;i<8;++i){float a=i*3.14159265f/4;line(.5f+.35f*cosf(a),.5f+.35f*sinf(a),.5f+.46f*cosf(a),.5f+.46f*sinf(a));}break;
 case 4: circle(.5f,.23f,.14f);d->AddBezierCubic(pt(.16f,.9f),pt(.12f,.3f),pt(.88f,.3f),pt(.84f,.9f),c,1.8f);line(.16f,.9f,.84f,.9f);break;
 case 5: d->AddRect(pt(.16f,.12f),pt(.84f,.9f),c,3,0,1.8f);line(.32f,.34f,.68f,.34f);line(.32f,.52f,.68f,.52f);line(.32f,.7f,.56f,.7f);break;
 case 6: line(.5f,.08f,.86f,.3f);line(.86f,.3f,.76f,.72f);line(.76f,.72f,.5f,.94f);line(.5f,.94f,.24f,.72f);line(.24f,.72f,.14f,.3f);line(.14f,.3f,.5f,.08f);line(.33f,.5f,.46f,.64f);line(.46f,.64f,.7f,.38f);break;
 case 7: line(.25f,.25f,.75f,.75f);line(.75f,.25f,.25f,.75f);break;
 default: line(.2f,.5f,.8f,.5f);break;
 }
}
inline bool nav(const char* id,const char* text,int kind,bool active,ImVec2 size,ImVec4 accent,ImGuiID* drag_id=nullptr){
 ImGui::PushID(id);auto p=ImGui::GetCursorScreenPos();bool hit=ImGui::InvisibleButton("##nav",size);if(drag_id&&ImGui::IsItemActive())*drag_id=ImGui::GetItemID();
 auto* d=ImGui::GetWindowDrawList();auto c=ImGui::ColorConvertFloat4ToU32(accent);
 d->AddRectFilled(p,{p.x+size.x,p.y+size.y},active?IM_COL32(234,234,234,255):ImGui::IsItemHovered()?IM_COL32(42,42,42,255):IM_COL32(23,23,23,255),10);
 d->AddRect(p,{p.x+size.x,p.y+size.y},active?IM_COL32(250,250,250,255):IM_COL32(65,65,65,255),10);
 icon(d,{p.x+14,p.y+(size.y-28)*.5f},28,kind,active?IM_COL32(18,18,18,255):IM_COL32(175,175,175,255));
 d->PushClipRect({p.x+54,p.y},{p.x+size.x-8,p.y+size.y},true);
 d->AddText({p.x+58,p.y+(size.y-ImGui::GetFontSize())*.5f},active?IM_COL32(18,18,18,255):IM_COL32(220,220,220,255),text);d->PopClipRect();
 ImGui::PopID();return hit&&ImGui::GetIO().MouseDragMaxDistanceSqr[0]<64;
}
}
