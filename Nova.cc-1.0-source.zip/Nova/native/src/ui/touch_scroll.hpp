#pragma once
#include "imgui.h"
#include "imgui_internal.h"
#include "scroll_physics.hpp"
namespace dof_menu {
class TouchScroll {
 ImGuiContext* context_=nullptr;ImGuiWindow* owner_=nullptr;
 ScrollMotion motion_;ImVec2 start_{};float last_y_=0,original_value_=0;
 ImGuiID gesture_=0,pressed_item_=0;double last_motion_=0;
 bool dragging_=false,ending_=false,cancel_controls_=false,has_original_=false;
 void move(float delta){
  if(!owner_||owner_->ScrollMax.y<=0){motion_.velocity=0;return;}
  float next=scroll_clamp(owner_->Scroll.y+delta,0,owner_->ScrollMax.y);
  if((next<=0&&delta<0)||(next>=owner_->ScrollMax.y&&delta>0))motion_.velocity=0;
  ImGui::SetScrollY(owner_,next);
 }
 void capture(){
  if(ImGui::GetActiveID()!=gesture_)ImGui::SetActiveID(gesture_,owner_);
  ImGui::KeepAliveID(gesture_);
  ImGui::SetKeyOwner(ImGuiKey_MouseLeft,gesture_,ImGuiInputFlags_LockUntilRelease);
 }
public:
 void reset(){
  if(context_==ImGui::GetCurrentContext()&&gesture_&&ImGui::GetActiveID()==gesture_)ImGui::ClearActiveID();
  owner_=nullptr;motion_.reset();dragging_=ending_=cancel_controls_=has_original_=false;pressed_item_=gesture_=0;
 }
 void begin(ImGuiWindow* menu,bool interactive){
  auto* context=ImGui::GetCurrentContext();if(context_!=context){owner_=nullptr;gesture_=0;context_=context;reset();}
  auto& io=ImGui::GetIO();cancel_controls_=ending_=false;
  if(!interactive||!ImGui::IsMousePosValid()){reset();return;}
  if(ImGui::IsMouseClicked(0)){
   reset();auto* hovered=context->HoveredWindow;
   // A vertical swipe starting on the content tabs scrolls the card beneath that column.
   if(hovered&&(hovered->Flags&ImGuiWindowFlags_NoScrollWithMouse)&&strstr(hovered->Name,"##oxide_content")){
    for(auto* child:hovered->DC.ChildWindows)if(child->WasActive&&child->ScrollMax.y>0&&io.MousePos.x>=child->Pos.x&&io.MousePos.x<=child->Pos.x+child->Size.x){hovered=child;break;}
   }
   if(hovered&&ImGui::IsWindowChildOf(hovered,menu,true)&&hovered->ScrollMax.y>0&&
      !(hovered->Flags&ImGuiWindowFlags_NoScrollWithMouse)&&
      !(hovered->ScrollbarY&&io.MousePos.x>=hovered->Pos.x+hovered->Size.x-ImGui::GetStyle().ScrollbarSize)){
    owner_=hovered;start_=io.MousePos;last_y_=start_.y;gesture_=ImHashStr("##touch_scroll",0,owner_->ID);
   }
  }
  if(!owner_)return;
  if(!owner_->WasActive&&!owner_->Active){reset();return;}
  if(io.MouseDown[0]){
   int axis=motion_.direction(io.MousePos.x-start_.x,io.MousePos.y-start_.y);
   if(axis==1){
    bool first=!dragging_;dragging_=true;cancel_controls_=true;
    if(first&&!(owner_->Flags&ImGuiWindowFlags_Popup))ImGui::ClosePopupsOverWindow(owner_,false);
    capture();float delta=last_y_-io.MousePos.y;last_y_=io.MousePos.y;
    if(scroll_abs(delta)>.01f){motion_.sample(delta,io.DeltaTime,first);last_motion_=ImGui::GetTime();move(delta);}
   }
  }else if(ImGui::IsMouseReleased(0)&&dragging_){
   cancel_controls_=ending_=true;capture();if(ImGui::GetTime()-last_motion_>.08)motion_.velocity=0;
  }else if(!dragging_){
   if(io.MouseWheel!=0)motion_.velocity=0;
   else move(motion_.step(io.DeltaTime));
  }
 }
 template<class T>bool slider(ImGuiID id,T before,T& after,bool changed){
  if(owner_==ImGui::GetCurrentWindow()&&ImGui::IsItemActivated()){
   pressed_item_=id;original_value_=float(before);has_original_=true;
  }
  if(cancel_controls_&&has_original_&&pressed_item_==id){after=T(original_value_);return false;}
  return changed;
 }
 bool scrolling()const{return cancel_controls_;}
 void finish(){if(ending_){if(ImGui::GetActiveID()==gesture_)ImGui::ClearActiveID();dragging_=false;ending_=false;}}
};
inline TouchScroll& touch_scroll(){static TouchScroll instance;return instance;}
}
