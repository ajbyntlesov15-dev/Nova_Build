#include "Android_draw/draw.h"
#include "runtime/live.hpp"
#include "runtime/presentation.hpp"
#include "runtime/automation.hpp"
#include "runtime/trigger.hpp"
#include "runtime/access_receipt.hpp"
#include <dlfcn.h>
#include "runtime/recording_bridge.hpp"
#include <sys/wait.h>
#include <aaudio/AAudio.h>
#include "ui/ui.hpp"
#include "ui/avatar_pixels.hpp"
#include "ui/custom_model_renderer.hpp"
extern void (*dof_scene_draw)();
static custom_model::Renderer avatar_model;
#include <sys/file.h>
#include <csignal>
#include <jni.h>
#include <android/native_window_jni.h>
static void play_kill_sound(){
 AAudioStreamBuilder* builder=nullptr;
 if(AAudio_createStreamBuilder(&builder)!=AAUDIO_OK)return;
 AAudioStreamBuilder_setDirection(builder,AAUDIO_DIRECTION_OUTPUT);
 AAudioStreamBuilder_setChannelCount(builder,1);
 AAudioStreamBuilder_setSampleRate(builder,48000);
 AAudioStreamBuilder_setFormat(builder,AAUDIO_FORMAT_PCM_I16);
 AAudioStream* stream=nullptr;
 const auto opened=AAudioStreamBuilder_openStream(builder,&stream);
 AAudioStreamBuilder_delete(builder);
 if(opened!=AAUDIO_OK)return;
 if(AAudioStream_requestStart(stream)==AAUDIO_OK){
  std::array<int16_t,5760> samples{};
  for(size_t i=0;i<samples.size();++i){
   const float t=float(i)/48000.f;
   const float amplitude=7000.f*std::min(1.f,t*350.f)*std::max(0.f,1.f-t/.11f);
   samples[i]=int16_t(amplitude*(.7f*std::sin(5655.f*t)+.3f*std::sin(8482.f*t)));
  }
  AAudioStream_write(stream,samples.data(),samples.size(),200000000);
  std::this_thread::sleep_for(std::chrono::milliseconds(140));
 }
 AAudioStream_close(stream);
}
static volatile sig_atomic_t stopping=0;
static void signal_stop(int){stopping=1;}
static int startup_error(const char* reason){
 fprintf(stderr,"Nova startup: %s\n",reason);
 return 64;
}
static std::atomic<bool> public_menu_open{false},public_full_visuals{false};
static std::atomic<bool> public_suspended{false},public_hide_request{false};
static std::atomic<int> public_input_bounds[4]{};
static std::atomic<unsigned> public_menu_requests{0};
static std::atomic<bool> public_freecam_button{false},public_freecam{false},virtual_flight_toggle{false};
static std::mutex virtual_flight_mutex;
static touch::FlightInput virtual_flight;
namespace touch { void overlay_pointer(float,float,bool); }
static int run_overlay(int argc,char** argv,ANativeWindow* window){
 const bool embedded=window!=nullptr;if(argc==3&&std::string(argv[1])=="--check-config")return ui::load(argv[2])?0:65;std::string control,access_file,record_state_file,package,game_build;bool live=false,direct=false,vip=false,launch_no_vegetation=false;
 for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--live")live=true;else if(a=="--vip")vip=true;else if(a=="--no-vegetation")launch_no_vegetation=true;else if(a=="--virtual-direct")direct=true;else if(a=="--control-dir"&&i+1<argc)control=argv[++i];else if(a=="--access-file"&&i+1<argc)access_file=argv[++i];else if(a=="--record-state-file"&&i+1<argc)record_state_file=argv[++i];else if(a=="--game-build"&&i+1<argc)game_build=argv[++i];else if(a=="--game-package"&&i+1<argc)package=argv[++i];else if(a=="--apk-path"&&i+1<argc)++i;else return startup_error("unknown option or missing argument");}
 const auto* profile=oxide_profile::select(game_build.c_str());if(!profile)return startup_error("unknown game profile");
 if(!live||(!direct&&control.rfind("/data/local/tmp/nova-",0)!=0)||control.find("..")!=std::string::npos||package.empty()||package.size()>160)return startup_error("invalid launch mode, game package, or control directory");
 for(unsigned char c:package)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='.'||c=='_'))return startup_error("invalid game package characters");
 access_receipt::CommonLease lease;access_receipt::Lease vip_lease;uint32_t uid=0;if(direct){
  struct stat st{};
  if(control.empty()||control.front()!='/'||control.rfind("/data/local/tmp/",0)==0)
   return startup_error("virtual mode requires an absolute private control directory");
  if(lstat(control.c_str(),&st)!=0){
   const int error=errno;
   fprintf(stderr,"Virtual: control directory lstat failed (errno=%d: %s).\n",error,strerror(error));
   return 64;
  }
  if(!S_ISDIR(st.st_mode))return startup_error("virtual control path is not a directory");
  if(st.st_uid!=geteuid()){
   fprintf(stderr,"Virtual: control directory UID mismatch (owner=%u, real=%u, effective=%u).\n",
           unsigned(st.st_uid),unsigned(getuid()),unsigned(geteuid()));
   return 64;
  }
  if(st.st_mode&0077){
   fprintf(stderr,"Virtual: control directory is not private (mode=%04o; expected 0700).\n",unsigned(st.st_mode&0777));
   return 64;
  }
  uid=geteuid();
 }else if(!access_receipt::control_uid(control,uid))return startup_error("invalid root control directory owner suffix");
 std::string module="/proc/self/exe";
 if(embedded){Dl_info info{};if(!dladdr(reinterpret_cast<void*>(run_overlay),&info)||!info.dli_fname)return 77;module=info.dli_fname;auto slash=module.find_last_of('/');if(slash==std::string::npos)return 77;module=module.substr(0,slash+1)+"libnova_exec.so";}
 if(!lease.start(access_file,uid)||(vip&&!vip_lease.start(access_file+".vip",uid,module))){fprintf(stderr,"Nova: signed panel receipt rejected\n");return 77;}
 int lock=open((control+"/instance.lock").c_str(),O_CREAT|O_RDWR|O_CLOEXEC|O_NOFOLLOW,0600);if(lock<0)return 73;if(flock(lock,LOCK_EX|LOCK_NB)){close(lock);return 73;}
 auto ready=control+"/ready",stop=control+"/stop",config=control+"/oxide.conf";unlink(ready.c_str());if(!embedded){signal(SIGTERM,signal_stop);signal(SIGINT,signal_stop);}
 oxide::Live runtime;
 int w=0,h=0;
 if(embedded){
  if(!init_overlay_surface(window)){close(lock);return 70;}
  w=ANativeWindow_getWidth(window);h=ANativeWindow_getHeight(window);
  native_window_screen_x=displayInfo.width=w;
  native_window_screen_y=displayInfo.height=h;
  public_menu_requests=0;
  public_menu_open=false;public_full_visuals=false;
  public_freecam_button=false;
  public_freecam=false;
  virtual_flight_toggle=false;
  {std::lock_guard<std::mutex> lock(virtual_flight_mutex);virtual_flight={};}
 }else{
  screen_config();w=std::max(displayInfo.width,displayInfo.height);h=std::min(displayInfo.width,displayInfo.height);
  if(w<=0||h<=0){close(lock);return 74;}
  native_window_screen_x=native_window_screen_y=w;
  if(!initGUI_draw(w,w,true)){close(lock);return 70;}
  if(!touch::init(w,h,uint8_t(displayInfo.orientation))){shutdown();close(lock);return 71;}
 }

 GLuint avatar=0;glGenTextures(1,&avatar);glBindTexture(GL_TEXTURE_2D,avatar);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,menu_avatar::width,menu_avatar::height,0,GL_RGBA,GL_UNSIGNED_BYTE,menu_avatar::rgba);glBindTexture(GL_TEXTURE_2D,0);ui::avatar=avatar;
 ui::vip_mode=vip;ui::tracked_pid=0;ui::tracked_identity=0;ui::tracked_id=0;ui::tab=0;
 ui::exit_requested=false;ui::opened=!embedded;ui::menu_alpha=embedded?0.f:1.f;ui::config_path=config;ui::load(config);if(access(config.c_str(),F_OK)!=0&&!ui::save(config))fprintf(stderr,"Cannot create initial settings file\n");std::string saved=ui::encoded();oxide::Presentation presentation;oxide::Automation automation;oxide::Trigger trigger;oxide::Options initial;initial.no_vegetation=false;runtime.configure(initial);runtime.start(package,[&]{return lease.valid()&&(!vip||vip_lease.valid());},*profile,direct);if(FILE* file=fopen(ready.c_str(),"w")){fprintf(file,"%d\n",getpid());fclose(file);}fprintf(stderr,"Nova.cc runtime 1.0: package=%s profile=%s game=%s\n",package.c_str(),profile->channel,profile->version);long long access_check=0,save_check=0,record_check=0,record_ui_guard=0;bool recorder_ui=false;pid_t recorder_child=-1;
 int aim_swipe_phase=0;
 int heal_phase=0;long long heal_due=0;
 long long played_kill=0;
 std::thread kill_sound;std::atomic<bool> sound_running{false};
 while(!stopping&&!ui::exit_requested&&access(stop.c_str(),F_OK)!=0){auto started=oxide::now();if(started>=access_check){access_check=started+1000;if(!lease.valid()||(vip&&!vip_lease.valid()))break;}
  if(recorder_child>0&&waitpid(recorder_child,nullptr,WNOHANG)!=0)recorder_child=-1;
  if(started>=record_check){record_check=started+500;if(!record_state_file.empty()){auto slash=record_state_file.find_last_of('/');recorder_ui=slash!=std::string::npos&&recording_bridge::ui_active(record_state_file.substr(0,slash)+"/recording.ui",uid,started);}recording_bridge::Status status;ui::record_fresh=!record_state_file.empty()&&recording_bridge::read(record_state_file,uid,started,status);if(ui::record_fresh){ui::record_state=status.state;ui::record_width=status.width;ui::record_height=status.height;ui::record_fps=status.fps;ui::record_seconds=std::max(0LL,(started-status.started)/1000);}}
  if(recorder_ui)record_ui_guard=0;ui::recorder_ui_active=recorder_ui||started<record_ui_guard;
  if(ui::consume_reload(config))saved=ui::encoded();
  drawBegin();
  if(embedded){w=displayInfo.width;h=displayInfo.height;public_full_visuals.store(ui::cfg.nonroot_full_visuals);if(public_menu_requests.exchange(0)&1u)ui::opened=!ui::opened;
   if(virtual_flight_toggle.exchange(false)){
    ui::cfg.freecam=!ui::cfg.freecam;
    if(ui::cfg.freecam)ui::cfg.thirdperson=false;
   }
   public_freecam_button=ui::cfg.free_button&&lease.allows(dof_license::Camera);
   public_freecam=ui::cfg.freecam&&lease.allows(dof_license::Camera)&&!ui::opened&&ui::pick_target<0&&displayInfo.width>0;
  }
  else{w=std::max(displayInfo.width,displayInfo.height);h=std::min(displayInfo.width,displayInfo.height);}auto frame=runtime.snapshot();const auto sampled_at=oxide::now();
  if(ui::vip_mode&&ui::cfg.vip_kill_sound&&lease.allows(dof_license::Visual)&&frame.hit_kill&&
     frame.hit_at>played_kill&&started>=frame.hit_at&&started-frame.hit_at<350){
   played_kill=frame.hit_at;
   if(!sound_running){
    if(kill_sound.joinable())kill_sound.join();
    sound_running=true;
    kill_sound=std::thread([&]{play_kill_sound();sound_running=false;});
   }
  }
  const bool custom_avatar=ui::cfg.player_model!=0&&lease.allows(dof_license::Visual)&&
      lease.allows(dof_license::Camera)&&!ui::cfg.freecam&&avatar_model.ready();
  avatar_model.prepare(frame,custom_avatar?ui::cfg.player_model:0,w,h,native_window_screen_y,sampled_at);
  dof_scene_draw=[](){avatar_model.draw();};auto display=presentation.update(frame,sampled_at,true);if(lease.allows(dof_license::Visual))ui::esp(display,float(w),float(h),sampled_at);ui::render(float(w),float(h),frame,embedded);if(embedded&&ui::hide_overlay_requested){public_hide_request.store(true);ui::hide_overlay_requested=false;}if(embedded){public_menu_open=ui::opened||ui::pick_target>=0;
 ImVec2 lo{},hi{};bool found=false;
 if(ui::pick_target>=0){hi={float(w),float(h)};found=true;}
 else if(ui::opened){auto* menu=ImGui::FindWindowByName("##oxide_menu");if(menu){lo=menu->Pos;hi={lo.x+menu->Size.x,lo.y+menu->Size.y};found=true;}
 for(auto* window:ImGui::GetCurrentContext()->Windows)if(window->Active&&(window->Flags&ImGuiWindowFlags_Popup)){lo.x=std::min(lo.x,window->Pos.x);lo.y=std::min(lo.y,window->Pos.y);hi.x=std::max(hi.x,window->Pos.x+window->Size.x);hi.y=std::max(hi.y,window->Pos.y+window->Size.y);}}
 public_input_bounds[0]=std::max(0,int(lo.x));public_input_bounds[1]=std::max(0,int(lo.y));public_input_bounds[2]=found?std::max(1,std::min(w,int(hi.x))-public_input_bounds[0].load()):0;public_input_bounds[3]=found?std::max(1,std::min(h,int(hi.y))-public_input_bounds[1].load()):0;
 }
  if(embedded)ui::recorder_action=0;
  if(ui::recorder_action){int action=ui::recorder_action;ui::recorder_action=0;if(action!=2)record_ui_guard=started+5000;if(ui::save(config))saved=ui::encoded();if(recorder_child<0){char user[16];snprintf(user,sizeof(user),"%u",uid/100000);recorder_child=fork();if(recorder_child==0){execl("/system/bin/am","am","start","--user",user,"-n","cc.nova.oxide/.RecordingControlActivity","--es","action",action==2?"stop":action==3?"profiles":action==4?"layout":action==5?"history":"config",(char*)nullptr);_exit(127);}}}
  if(!embedded)touch::capture_flight(!(recorder_ui||started<record_ui_guard)&&(ui::pick_target>=0||(lease.allows(dof_license::Camera)&&ui::cfg.freecam&&display.camera&&display.local&&frame.pid==display.pid)),w,h,88,40,88,68);auto input=touch::flight_input();
  if(embedded){
   std::lock_guard<std::mutex> lock(virtual_flight_mutex);
   input=virtual_flight;
   input.captured=public_freecam.load()&&frame.camera&&frame.local;
  }if(!embedded&&ui::pick_target>=0&&!input.captured){ui::pick_target=-1;ui::opened=!embedded;ui::menu_alpha=embedded?0.f:1.f;ui::config_message="Не удалось захватить касания";}oxide::Options o;const auto ac=ui::active_aim_controls();
  o.require_visibility=ac.visibility;
  o.armor_icons=ui::cfg.armor&&lease.allows(dof_license::Visual);
  o.hit_feedback=ui::vip_mode&&(ui::cfg.vip_hit_mark||ui::cfg.vip_kill_sound)&&lease.allows(dof_license::Visual);
  if(ui::vip_mode){
   o.lead_ms=ac.predict?(ac.lead_ms+1):0;
   o.no_vegetation=false;
   o.silent_aim=ui::cfg.vip_silent&&lease.allows(dof_license::Aim)&&lease.allows(dof_license::Camera);
   o.aim_360=ui::cfg.vip_aim_360&&!o.silent_aim;
   o.touch_aim=!embedded&&ui::cfg.vip_touch_aim&&!o.aim_360&&!o.silent_aim;
   o.building_hp=ui::cfg.vip_build_hp&&lease.allows(dof_license::Visual);
   o.aim_melee=ui::cfg.vip_melee&&ui::aim_kind()==0;
   o.aim_recoil=false;o.recoil_x=ui::cfg.recoil_x;o.recoil_y=ui::cfg.recoil_y;
   o.shot_tracers=ui::cfg.vip_tracers&&lease.allows(dof_license::Visual);o.tracer_length=ui::cfg.tracer_length;o.tracer_lifetime=ui::cfg.tracer_lifetime;
   if(ui::cfg.vip_home_search&&frame.pid==ui::tracked_pid){
    o.search_owner_identity=ui::tracked_identity;o.search_owner_id=ui::tracked_id;
   }
  }
  o.custom_model=custom_avatar;o.spin=ui::vip_mode&&custom_avatar&&ui::cfg.spin&&lease.allows(dof_license::Camera);o.spin_speed=ui::cfg.spin_speed;o.unlock_fps=lease.allows(dof_license::Visual)&&ui::cfg.unlock_fps;o.fps_limit=ui::cfg.fps_limit;o.movement_boost=ui::cfg.movement_boost&&lease.allows(dof_license::Camera);o.movement_percent=ui::cfg.movement_percent;o.sticky_aim=ac.sticky;o.show_bot_rig=ui::cfg.bots&&(ui::cfg.bot_lines||ui::cfg.bot_rig);o.ignore_team=ac.ignore_team;o.ignore_clan=ac.ignore_clan;o.sky_tint=lease.allows(dof_license::Visual)&&ui::cfg.sky_tint;o.sky_color={ui::cfg.colors[19].x,ui::cfg.colors[19].y,ui::cfg.colors[19].z};o.aim_animals=ac.animals;o.aim_bots=ac.bots;o.trigger=lease.allows(dof_license::Aim)&&ui::cfg.trigger&&!ui::cfg.autofarm;o.trigger_ads=ui::cfg.trigger_ads;o.trigger_distance=ui::cfg.trigger_distance;o.trigger_ignore_team=ui::cfg.trigger_ignore_team;o.trigger_ignore_clan=ui::cfg.trigger_ignore_clan;o.trigger_animals=ui::cfg.trigger_animals;o.trigger_bots=ui::cfg.trigger_bots;o.farm_target=lease.allows(dof_license::Automation)&&ui::cfg.autofarm?automation.target():0;o.capture_generation=input.generation;o.custom_fov=lease.allows(dof_license::Camera)&&ui::cfg.custom_fov;o.camera_fov=float(ui::cfg.camera_fov);o.thirdperson=lease.allows(dof_license::Camera)&&(ui::cfg.thirdperson||custom_avatar);o.third_distance=ui::cfg.third_distance*.01f;o.third_height=ui::cfg.third_height*.01f;o.third_shoulder=ui::cfg.third_shoulder*.01f;const bool vip_day=ui::vip_mode&&ui::cfg.vip_daylight;o.always_day=lease.allows(dof_license::World)&&(ui::cfg.always_day||vip_day);o.day_hour=vip_day?12:ui::cfg.day_hour;o.quickloot=lease.allows(dof_license::Automation)&&ui::cfg.quickloot;o.debug=ui::cfg.debug;o.activation=ac.activation;o.aim=lease.allows(dof_license::Aim)&&(ui::cfg.aim||o.silent_aim||o.touch_aim||o.aim_360)&&!(lease.allows(dof_license::Automation)&&ui::cfg.autofarm);o.paused=(embedded&&public_suspended.load())||recorder_ui||started<record_ui_guard||ui::opened||ui::menu_alpha>.08f||ui::pick_target>=0;o.freecam=lease.allows(dof_license::Camera)&&ui::cfg.freecam;o.captured=input.captured;o.x=input.x;o.y=input.y;o.up=input.vertical;o.look_x=input.look_x;o.look_y=input.look_y;o.speed=float(ui::cfg.free_speed);o.bone=ac.bone;o.mode=ac.mode;o.fov=float(ac.fov);o.smooth=ui::cfg.trigger?1.f:float(ac.smooth);o.distance=float(ac.distance);if(embedded){o.trigger=false;o.farm_target=0;}o.no_sway=ui::cfg.no_sway;runtime.configure(o);
  const auto command_at=oxide::now();auto automation_cfg=ui::automation_config();automation_cfg.paused=automation_cfg.paused||recorder_ui||started<record_ui_guard;automation_cfg.farm=automation_cfg.farm&&lease.allows(dof_license::Automation);automation_cfg.aspect=float(w)/std::max(1,h);auto commands=automation.step(frame,automation_cfg,command_at,touch::physical_down());oxide::TriggerConfig trigger_cfg;trigger_cfg.enabled=lease.allows(dof_license::Aim)&&ui::cfg.trigger&&!ui::cfg.autofarm;trigger_cfg.paused=automation_cfg.paused||ui::cfg.freecam;trigger_cfg.scoped_only=ui::cfg.trigger_ads;trigger_cfg.delay=ui::cfg.trigger_delay;trigger_cfg.interval=ui::cfg.trigger_interval;trigger_cfg.x=automation_cfg.hit_x;trigger_cfg.y=automation_cfg.hit_y;auto fire=trigger.step(frame,trigger_cfg,command_at,touch::physical_down());if(fire.down)commands[2]=fire;std::array<touch::SyntheticContact,3> contacts{};for(unsigned i=0;i<3;++i)contacts[i]={commands[i].down,commands[i].x,commands[i].y};bool healing=false;
  if(!embedded&&ui::vip_mode&&ui::cfg.vip_autoheal&&lease.allows(dof_license::Automation)&&
     !automation_cfg.paused&&!ui::cfg.freecam&&!frame.loot_session&&frame.local&&
     frame.time<=command_at&&command_at-frame.time<=150&&ui::cfg.heal_slot_x&&ui::cfg.heal_slot_y&&ui::cfg.heal_use_x&&ui::cfg.heal_use_y&&
     !touch::physical_down()&&!contacts[0].down&&!contacts[1].down&&!contacts[2].down){
   const auto local=std::find_if(frame.players.begin(),frame.players.end(),[](const auto& a){return a.local&&a.hp>0&&a.hp<a.max_hp*ui::cfg.heal_threshold*.01f&&a.hp<a.max_hp;});
   if(local==frame.players.end()){heal_phase=0;heal_due=0;}
   else{
    if(heal_phase==0&&started>=heal_due&&frame.input_unlocked){heal_phase=1;heal_due=started+35;}
    else if(heal_phase==1&&started>=heal_due){heal_phase=2;heal_due=started+40;}
    else if(heal_phase==2&&started>=heal_due){heal_phase=3;heal_due=started+35;}
    else if(heal_phase==3&&started>=heal_due){heal_phase=0;heal_due=started+ui::cfg.heal_interval;}
    if(heal_phase==1||heal_phase==3){
     const bool select=heal_phase==1;
     contacts[2]={true,float(select?ui::cfg.heal_slot_x:ui::cfg.heal_use_x),float(select?ui::cfg.heal_slot_y:ui::cfg.heal_use_y)};
     healing=true;
    }
   }
  }else if(heal_phase){heal_phase=0;heal_due=0;}
  const float aim_min_x=float(std::min(ui::cfg.aim_area_ax,ui::cfg.aim_area_bx));
  const float aim_max_x=float(std::max(ui::cfg.aim_area_ax,ui::cfg.aim_area_bx));
  const float aim_min_y=float(std::min(ui::cfg.aim_area_ay,ui::cfg.aim_area_by));
  const float aim_max_y=float(std::max(ui::cfg.aim_area_ay,ui::cfg.aim_area_by));
  if(o.touch_aim&&o.aim&&frame.aim_swipe_valid&&!o.paused&&!o.freecam&&frame.input_unlocked&&
     frame.time<=command_at&&command_at-frame.time<=120&&
     aim_max_x-aim_min_x>=2.f&&aim_max_y-aim_min_y>=2.f&&
     !contacts[0].down&&!contacts[1].down&&!contacts[2].down){
   const float center_x=(aim_min_x+aim_max_x)*.5f,center_y=(aim_min_y+aim_max_y)*.5f;
   const float gain=.15f+ui::cfg.aim_touch_gain*.03f;
   if(aim_swipe_phase==0)contacts[1]={true,center_x,center_y,true};
   if(aim_swipe_phase==1)contacts[1]={true,std::clamp(center_x+frame.aim_swipe_x*gain,aim_min_x,aim_max_x),
                                            std::clamp(center_y+frame.aim_swipe_y*gain*float(w)/std::max(h,1),aim_min_y,aim_max_y),true};
   aim_swipe_phase=(aim_swipe_phase+1)%3;
  }else aim_swipe_phase=0;
  bool injected=!embedded&&touch::synthetic(contacts);
  if(o.touch_aim)ui::touch_input_status=!frame.aim_swipe_valid?frame.aim_status:injected?"Короткие свайпы активны":"Тач-ввод недоступен или слот занят";else ui::touch_input_status.clear();
  if(!injected)aim_swipe_phase=0;
  if(healing&&!injected){heal_phase=0;heal_due=0;}
  if(!injected&&(contacts[0].down||contacts[1].down||contacts[2].down)){automation.input_failed();trigger.reset();}ui::farm_target=automation.target();ui::automation_status=automation.status;if(!injected&&(ui::cfg.autofarm||ui::cfg.quickloot))ui::automation_status+=" · ввод недоступен / занят касанием";
  if(started>=save_check){save_check=started+1000;auto current=ui::encoded();if(current!=saved&&ui::save(config))saved=current;}
  drawEnd();
  const bool interactive=ui::opened||ui::menu_alpha>.08f||ui::pick_target>=0||o.freecam||automation_cfg.farm;
  const auto frame_period=o.touch_aim&&o.aim&&!o.paused?8:interactive||(ui::vip_mode&&!embedded&&ui::cfg.vip_autoheal&&heal_phase)?16:33;
  std::this_thread::sleep_until(std::chrono::steady_clock::time_point(std::chrono::milliseconds(started+frame_period)));
 }
 if(!embedded){touch::synthetic({});touch::capture_flight(false,w,h,88,40,88,68);}runtime.stop();if(kill_sound.joinable())kill_sound.join();ui::consume_reload(config);ui::save(config);touch::shutdown();if(avatar)glDeleteTextures(1,&avatar);avatar_model.shutdown();shutdown();unlink(ready.c_str());close(lock);return 0;
}

int main(int argc,char** argv){return run_overlay(argc,argv,nullptr);}

extern "C" JNIEXPORT jint JNICALL
Java_cc_nova_oxide_LicenseBridge_runVirtual(JNIEnv* env,jclass,jstring build,jstring dir,jstring receipt,jobject surface){
 const auto to_string=[&](jstring input){
  if(!input)return std::string{};
  const char* chars=env->GetStringUTFChars(input,nullptr);
  if(!chars)return std::string{};
  std::string value(chars);
  env->ReleaseStringUTFChars(input,chars);
  return value;
 };
 auto selected_build=to_string(build);
 const bool no_vegetation=selected_build.size()>6&&selected_build.compare(selected_build.size()-6,6,"-noveg")==0;
 if(no_vegetation)selected_build.resize(selected_build.size()-6);
 const bool vip=selected_build.size()>4&&selected_build.compare(selected_build.size()-4,4,"-vip")==0;
 if(vip)selected_build.resize(selected_build.size()-4);
 std::string args[]={"Nova","--live","--virtual-direct",
  "--game-build",selected_build,"--game-package","com.catsbit.oxidesurvivalisland",
  "--control-dir",to_string(dir),"--access-file",to_string(receipt)};
 std::vector<std::string> values(std::begin(args),std::end(args));if(vip)values.emplace_back("--vip");if(vip&&no_vegetation)values.emplace_back("--no-vegetation");std::vector<char*> argv;for(auto& value:values)argv.push_back(value.data());
 ANativeWindow* window=surface?ANativeWindow_fromSurface(env,surface):nullptr;
 if(!window)return 70;
 int result=run_overlay(int(argv.size()),argv.data(),window);
 ANativeWindow_release(window);
 return result;
}

extern "C" JNIEXPORT void JNICALL
Java_cc_nova_oxide_LicenseBridge_virtualPointer(JNIEnv*,jclass,jfloat x,jfloat y,jboolean down){
 touch::overlay_pointer(x,y,down);
}
extern "C" JNIEXPORT jboolean JNICALL
Java_cc_nova_oxide_LicenseBridge_virtualMenuOpen(JNIEnv*,jclass){return public_menu_open.load();}
extern "C" JNIEXPORT void JNICALL
Java_cc_nova_oxide_LicenseBridge_toggleVirtualMenu(JNIEnv*,jclass){public_menu_requests.fetch_add(1);}

extern "C" JNIEXPORT jint JNICALL
Java_cc_nova_oxide_LicenseBridge_virtualFreecamState(JNIEnv*,jclass){
 return (public_freecam_button.load()?1:0)|(public_freecam.load()?2:0);
}
extern "C" JNIEXPORT void JNICALL
Java_cc_nova_oxide_LicenseBridge_toggleVirtualFreecam(JNIEnv*,jclass){virtual_flight_toggle=true;}
extern "C" JNIEXPORT void JNICALL
Java_cc_nova_oxide_LicenseBridge_virtualFlight(JNIEnv*,jclass,jfloat x,jfloat y,jfloat look_x,jfloat look_y){
 std::lock_guard<std::mutex> lock(virtual_flight_mutex);
 virtual_flight.x=x;virtual_flight.y=y;
 virtual_flight.look_x=look_x;virtual_flight.look_y=look_y;
}

extern "C" JNIEXPORT void JNICALL Java_cc_nova_oxide_LicenseBridge_virtualInputBounds(JNIEnv* env,jclass,jintArray out){if(!out||env->GetArrayLength(out)<4)return;jint values[4];for(int i=0;i<4;++i)values[i]=public_input_bounds[i].load();env->SetIntArrayRegion(out,0,4,values);}

extern void overlay_viewport(int,int,int,int);
extern "C" JNIEXPORT void JNICALL Java_cc_nova_oxide_LicenseBridge_virtualViewport(JNIEnv*,jclass,jint w,jint h,jint x,jint y){overlay_viewport(w,h,x,y);}

extern "C" JNIEXPORT void JNICALL Java_cc_nova_oxide_LicenseBridge_virtualSuspend(JNIEnv*,jclass,jboolean paused){public_suspended.store(paused);}

extern "C" JNIEXPORT jboolean JNICALL Java_cc_nova_oxide_LicenseBridge_virtualHideRequested(JNIEnv*,jclass){return public_hide_request.exchange(false);}

extern "C" JNIEXPORT jboolean JNICALL Java_cc_nova_oxide_LicenseBridge_virtualFullVisuals(JNIEnv*,jclass){return public_full_visuals.load();}
