#pragma once
#include "core.hpp"
namespace oxide {
class ValueOverrides {
 struct Entry{uint64_t owner=0,type=0,address=0;size_t size=0;std::array<unsigned char,16> original{},applied{};bool seen=false;};
 std::vector<Entry> entries_;
 template<class R> bool valid(R r,const Entry& e){return pointer(r,e.owner)==e.type;}
public:
 void begin(){for(auto& e:entries_)e.seen=false;}
 template<class R,class T> bool original(R r,uint64_t owner,unsigned offset,T& value){
  static_assert(sizeof(T)<=16);if(!get(r,owner+offset,value))return false;
  for(auto& e:entries_)if(e.owner==owner&&e.address==owner+offset&&e.size==sizeof(T)&&valid(r,e)){
   if(memcmp(&value,e.applied.data(),sizeof(T)))memcpy(e.original.data(),&value,sizeof(T));
   memcpy(&value,e.original.data(),sizeof(T));break;
  }
  return true;
 }
 template<class R,class W,class T> bool set(R r,W w,uint64_t owner,unsigned offset,const T& value){
  static_assert(sizeof(T)<=16);auto type=pointer(r,owner);if(!type||entries_.size()>128)return false;
  for(auto& e:entries_)if(e.owner==owner&&e.address==owner+offset&&e.size==sizeof(T)&&e.type==type){
   std::array<unsigned char,16> current{};if(!r(e.address,current.data(),e.size))return false;
   if(memcmp(current.data(),e.applied.data(),e.size))e.original=current;
   e.seen=true;if(!w(e.address,&value,sizeof(T)))return false;memcpy(e.applied.data(),&value,sizeof(T));return true;
  }
  Entry e;e.owner=owner;e.type=type;e.address=owner+offset;e.size=sizeof(T);e.seen=true;
  if(!r(e.address,e.original.data(),e.size)||!w(e.address,&value,sizeof(T)))return false;
  memcpy(e.applied.data(),&value,sizeof(T));entries_.push_back(e);return true;
 }
 template<class R,class W> void end(R r,W w){
  for(auto it=entries_.begin();it!=entries_.end();){
   if(it->seen){++it;continue;}if(!valid(r,*it)){it=entries_.erase(it);continue;}
   std::array<unsigned char,16> current{};
   if(!r(it->address,current.data(),it->size)){++it;continue;}
   if(memcmp(current.data(),it->applied.data(),it->size)||w(it->address,it->original.data(),it->size))it=entries_.erase(it);else ++it;
  }
 }
 template<class R,class W> void restore(R r,W w){begin();end(r,w);}
 void forget(){entries_.clear();}
};
}
