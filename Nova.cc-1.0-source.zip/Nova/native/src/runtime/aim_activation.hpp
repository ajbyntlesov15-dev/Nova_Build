#pragma once
#include <cstdint>
namespace oxide {
// Fire mode follows observed shot-consumption events, never assumes an unknown input is pressed.
class AimActivation {
 uint64_t weapon_=0,counter_=0;int shots_=0;long long seen_=0,until_=0;
public:
 void reset(){weapon_=counter_=0;shots_=0;seen_=until_=0;}
 bool accept(int mode,bool ads_known,bool ads,uint64_t weapon,uint64_t counter,int shots,long long now){
  if(mode==1){reset();return true;}
  if(mode==0){reset();return ads_known&&ads;}
  if(mode!=2||!weapon||!counter||shots<0||shots>1000000){reset();return false;}
  if(weapon_!=weapon||counter_!=counter||now<seen_||now-seen_>250){weapon_=weapon;counter_=counter;shots_=shots;seen_=now;until_=0;return false;}
  if(shots>shots_)until_=now+180;shots_=shots;seen_=now;return now<until_;
 }
};
}
