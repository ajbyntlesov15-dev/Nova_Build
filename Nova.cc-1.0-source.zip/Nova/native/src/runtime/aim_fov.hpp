#pragma once
#include "core.hpp"
namespace oxide {
// Distance from the screen centre, measured in half the shorter viewport edge.
// Use the active projection, including zoom and off-centre third-person views.
inline bool aim_fov(const M& p,V view,float degrees,float& error){
 error=1e30f;
 if(!finite(view)||!std::isfinite(degrees)||p.v[0]<=.01f||p.v[5]<=.01f)return false;
 float w=p.v[3]*view.x+p.v[7]*view.y+p.v[11]*view.z+p.v[15];
 if(!std::isfinite(w)||w<.02f)return false;
 float aspect=std::fabs(p.v[5]/p.v[0]);
 float x=(p.v[0]*view.x+p.v[4]*view.y+p.v[8]*view.z+p.v[12])/w*std::max(1.f,aspect);
 float y=(p.v[1]*view.x+p.v[5]*view.y+p.v[9]*view.z+p.v[13])/w*std::max(1.f,1.f/aspect);
 float square=x*x+y*y;
 if(!std::isfinite(square))return false;
 error=square;
 float radius=std::min(4.f,std::tan(std::clamp(degrees*.5f,.5f,89.f)*.0174532925f));
 return square<=radius*radius;
}
}
