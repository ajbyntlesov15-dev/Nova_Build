#pragma once
#include "automation.hpp"
namespace oxide {
struct TriggerConfig{bool enabled=false,paused=true,scoped_only=true;int delay=0,interval=0;float x=88,y=55;};
class Trigger {
 uint64_t target_=0;int pid_=0;long long acquired_=0,last_=0,pulse_=0,clock_=0;
public:
 void reset(){target_=0;pid_=0;acquired_=last_=pulse_=clock_=0;}
 ScreenContact step(const Frame& f,const TriggerConfig& c,long long time,bool physical){
  bool valid=c.enabled&&!c.paused&&!physical&&f.camera&&f.local&&f.pid>0&&f.input_unlocked&&!f.loot_session&&!f.freecam&&f.trigger_target&&time>=f.time&&time-f.time<=80&&(!c.scoped_only||f.trigger_ads_active)&&std::isfinite(c.x)&&std::isfinite(c.y)&&c.x>0&&c.x<100&&c.y>0&&c.y<100;
  if(!valid||time<clock_){reset();return {};}
  if(target_!=f.trigger_target||pid_!=f.pid||time-clock_>100){target_=f.trigger_target;pid_=f.pid;acquired_=time;last_=pulse_=0;}
  clock_=time;
  if(pulse_){if(time<pulse_)return {true,c.x,c.y};pulse_=0;return {};}
  if(time-acquired_<std::clamp(c.delay,0,500)||(last_&&time-last_<std::clamp(c.interval,0,1000)))return {};
  last_=time;pulse_=time+40;return {true,c.x,c.y};
 }
};
}
