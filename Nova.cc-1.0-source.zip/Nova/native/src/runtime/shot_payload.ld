SECTIONS {
 . = 0;
 .text : { *(.text*) *(.rodata*) }
 . = 0x4000;
 .shot_state : { *(.shot_state) }
 /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) *(.ARM.attributes) }
}
