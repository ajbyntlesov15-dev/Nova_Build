#pragma once
#include "core.hpp"
namespace oxide {
// Unity Bounds stores a local centre followed by half-extents.
template<class R> bool container_corners(R read,uint64_t building,std::array<V,8>& result){
 V center{},extents{};
 if(!get(read,building+0xd0,center)||!get(read,building+0xdc,extents)||!finite(center)||!finite(extents))return false;
 if(extents.x<=.01f||extents.y<=.01f||extents.z<=.01f||std::max({extents.x,extents.y,extents.z})>20||len(center)>30)return false;
 auto native=component_transform(read,building);auto data=pointer(read,native+0x28);int index=-1;
 if(!data||!get(read,native+0x30,index)||index<0||index>1048576)return false;
 auto entries=pointer(read,data+0x18),parents=pointer(read,data+0x20);if(!entries||!parents)return false;
 std::array<V,8> points{};for(unsigned i=0;i<8;++i)points[i]=add(center,{(i&1)?extents.x:-extents.x,(i&2)?extents.y:-extents.y,(i&4)?extents.z:-extents.z});
 std::array<int,128> visited{};unsigned count=0;
 while(index>=0){
  if(index>1048576||count==visited.size())return false;for(unsigned i=0;i<count;++i)if(visited[i]==index)return false;visited[count++]=index;
  TRS t{};if(!get(read,entries+uint64_t(index)*48,t))return false;
  float norm=t.q.x*t.q.x+t.q.y*t.q.y+t.q.z*t.q.z+t.q.w*t.q.w;
  if(!finite({t.p[0],t.p[1],t.p[2]})||!finite({t.s[0],t.s[1],t.s[2]})||!std::isfinite(norm)||norm<.8f||norm>1.2f)return false;
  for(auto& v:points){v=add(rotate(t.q,{v.x*t.s[0],v.y*t.s[1],v.z*t.s[2]}),{t.p[0],t.p[1],t.p[2]});if(!finite(v))return false;}
  if(!get(read,parents+uint64_t(index)*4,index))return false;
 }
 if(index!=-1)return false;result=points;return true;
}
// Clip the edge before perspective division, including near-plane crossings.
inline bool project_edge(const M& view,const M& projection,V a,V b,float width,float height,float& ax,float& ay,float& bx,float& by){
 struct Clip{float x,y,w;};auto clip=[&](V v){v=view_point(view,v);return Clip{projection.v[0]*v.x+projection.v[4]*v.y+projection.v[8]*v.z+projection.v[12],projection.v[1]*v.x+projection.v[5]*v.y+projection.v[9]*v.z+projection.v[13],projection.v[3]*v.x+projection.v[7]*v.y+projection.v[11]*v.z+projection.v[15]};};
 auto p=clip(a),q=clip(b);for(float v:{p.x,p.y,p.w,q.x,q.y,q.w})if(!std::isfinite(v))return false;
 float lo=0,hi=1;auto plane=[&](float x,float y){if(x<0&&y<0)return false;if((x<0)!=(y<0)){float t=x/(x-y);if(x<0)lo=std::max(lo,t);else hi=std::min(hi,t);}return lo<=hi;};
 if(!plane(p.w-.02f,q.w-.02f)||!plane(p.w+p.x,q.w+q.x)||!plane(p.w-p.x,q.w-q.x)||!plane(p.w+p.y,q.w+q.y)||!plane(p.w-p.y,q.w-q.y))return false;
 auto screen=[&](float t,float& x,float& y){float w=p.w+(q.w-p.w)*t;if(w<.019f)return false;x=width*(.5f+.5f*(p.x+(q.x-p.x)*t)/w);y=height*(.5f-.5f*(p.y+(q.y-p.y)*t)/w);return std::isfinite(x)&&std::isfinite(y);};
 return screen(lo,ax,ay)&&screen(hi,bx,by);
}
}
