#pragma once
#include "world.hpp"
#include <array>
#include <unordered_map>
namespace oxide {
struct ScreenContact{bool down=false;float x=0,y=0;};
struct AutomationConfig{
 bool farm=false,paused=true,freecam=false;unsigned resources=63;
 float joy_x=16,joy_y=75,look_x=66,look_y=48,hit_x=88,hit_y=55;int joy_radius=6,turn_scale=35,reach=25;
 float aspect=1.7777778f;
};
class Automation{
 bool moving_=false,arrived_=false;uint64_t target_=0;long long progress_=0,step_time_=0,attack_started_=0;
 float closest_=1e9,look_vx_=0,look_vy_=0,joy_dx_=0,joy_dy_=0;
 std::array<ScreenContact,3> last_{};int last_pid_=0;std::unordered_map<uint64_t,long long> blocked_;
 void release(){moving_=false;arrived_=false;last_={};step_time_=0;attack_started_=0;look_vx_=look_vy_=joy_dx_=joy_dy_=0;}
 static float damp(float value,float target,float dt,float tau){return value+(target-value)*(1-std::exp(-dt/tau));}
public:
 uint64_t target()const{return target_;}
 void input_failed(){release();}
 std::string status;std::array<ScreenContact,3> step(const Frame& f,const AutomationConfig& c,long long time,bool physical=false){
  std::array<ScreenContact,3> out{};
  if(c.paused||c.freecam||physical||!c.farm||!f.camera||!f.local||time<f.time||f.loot_session){status="Пауза";target_=0;release();return out;}
  if(time-f.time>150){if(time-f.time<=350&&f.pid==last_pid_&&last_[0].down){out[0]=last_[0];last_=out;step_time_=time;look_vx_=look_vy_=0;return out;}release();return out;}
  if(!f.input_unlocked){status="Ожидание";target_=0;release();return out;}
  if(last_pid_&&last_pid_!=f.pid){target_=0;release();blocked_.clear();}
  float dt=step_time_&&time>step_time_?std::clamp((time-step_time_)*.001f,.001f,.05f):.016f;step_time_=time;
  for(auto it=blocked_.begin();it!=blocked_.end();)if(it->second<=time)it=blocked_.erase(it);else ++it;
  V base{};bool local=false;for(const auto& a:f.players)if(a.local&&a.hp>0){base=a.feet;local=true;break;}if(!local){release();return out;}
  const WorldObject* best=nullptr;float distance=350;
  for(const auto& w:f.world){if(w.kind<1||w.kind>6||!(c.resources&(1U<<(w.kind-1)))||blocked_.count(w.object)||!finite(w.position))continue;auto d=sub(w.position,base);d.y=0;float n=len(d);if(std::fabs(w.position.y-base.y)>6.f)continue;if(n<distance){best=&w;distance=n;}}
  if(!best){target_=0;release();status="Фарм: поблизости нет выбранных ресурсов";return out;}
  if(target_!=best->object){target_=best->object;progress_=time;closest_=distance;arrived_=false;attack_started_=0;}
  if(distance<closest_-.2f){closest_=distance;progress_=time;}
  float reach=std::clamp(c.reach*.1f,1.f,4.f);
  if(distance<=reach)arrived_=true;else if(distance>reach+.45f)arrived_=false;
  if(!arrived_&&time-progress_>8000){blocked_[target_]=time+15000;target_=0;release();status="Фарм: цель недоступна, выбираю другую";return out;}
  // Camera feedback is integrated into one held drag. Only an edge forces a lift.
  V point=best->hit_valid?best->hit_position:add(best->position,{0,1,0});
  V delta=sub(point,origin(f.view)),forward{-f.view.v[2],-f.view.v[6],-f.view.v[10]};
  float yaw=atan2f(forward.x,forward.z)*57.2957795f;
  float angle=angle_delta(atan2f(delta.x,delta.z)*57.2957795f,yaw);
  float pitch=-atan2f(delta.y,std::max(.1f,std::sqrt(delta.x*delta.x+delta.z*delta.z)))*57.2957795f;
  float error_y=pitch+asinf(std::clamp(forward.y,-1.f,1.f))*57.2957795f;
  if(!std::isfinite(angle)||!std::isfinite(error_y)){release();return out;}
  float gain=std::clamp(c.turn_scale,5,100)*.01f;
  auto rate=[&](float error){return std::fabs(error)<.6f?0.f:std::clamp(error*6.f,-100.f,100.f)*gain;};
  look_vx_=damp(look_vx_,rate(angle),dt,.06f);look_vy_=damp(look_vy_,rate(error_y),dt,.06f);
  if(last_[1].down){
   float x=last_[1].x+look_vx_*dt,y=last_[1].y+look_vy_*dt;
   float ax=std::clamp(c.look_x,5.f,95.f),ay=std::clamp(c.look_y,5.f,95.f);
   if(x>=3&&x<=97&&y>=3&&y<=97&&std::fabs(x-ax)<24&&std::fabs(y-ay)<20)out[1]={true,x,y};
   else look_vx_=look_vy_=0; // Lift for one frame, then re-anchor; never drag backwards to reset.
  }else if(std::fabs(angle)>.8f||std::fabs(error_y)>.8f)out[1]={true,std::clamp(c.look_x,5.f,95.f),std::clamp(c.look_y,5.f,95.f)};
  if(!arrived_){
   V approach=sub(best->position,base);float heading=angle_delta(atan2f(approach.x,approach.z)*57.2957795f,yaw)*.0174532925f;
   float radius=float(std::max(c.joy_radius,10));
   // Full travel at range, smooth arrival near the tool's reach. Spark movement cannot steer the feet.
   float speed=std::clamp((distance-reach)/1.4f,.55f,1.f);
   // If forward travel stalls, try a short lateral approach before rejecting the target.
   const float avoidance=time-progress_>2500?((target_&1)? .7f:-.7f):0.f;
   joy_dx_=damp(joy_dx_,std::clamp(std::sin(heading)+avoidance,-1.f,1.f)*radius/std::max(1.f,c.aspect)*speed,dt,.12f);
   joy_dy_=damp(joy_dy_,-std::cos(heading)*radius*speed,dt,.12f);
   out[0]={true,std::clamp(c.joy_x+(moving_?joy_dx_:0),1.f,99.f),std::clamp(c.joy_y+(moving_?joy_dy_:0),1.f,99.f)};moving_=true;status="Фарм: движение к "+best->name;
  }else{
   moving_=false;joy_dx_=joy_dy_=0;
   float tolerance=best->hit_valid?3.5f:15.f;
   if((best->kind==Barrel||best->hit_checked)&&std::fabs(angle)<tolerance&&std::fabs(error_y)<tolerance){if(!attack_started_)attack_started_=time;out[2]={(time-attack_started_)%150<90,c.hit_x,c.hit_y};}
   status="Фарм: добыча "+best->name;progress_=time;
  }
  last_=out;last_pid_=f.pid;return out;
 }
};
}
