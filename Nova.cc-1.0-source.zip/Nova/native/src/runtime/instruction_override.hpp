#pragma once
#include <cstdint>
namespace oxide {
// A single aligned ARM64 instruction; never accepts an unrecognized binary.
class InstructionOverride {
 uint64_t address_=0;uint32_t original_=0,applied_=0;
public:
 template<class R,class W>bool restore(R read,W write){
  if(!address_)return true;
  uint32_t current=0;if(!read(address_,&current,4))return false;
  if(current==applied_&&!write(address_,&original_,4))return false;
  address_=0;return true;
 }
 template<class R,class W>bool set(R read,W write,uint64_t address,uint32_t expected,uint32_t replacement){
  if(address_&&address_!=address&&!restore(read,write))return false;
  uint32_t current=0;if(!read(address,&current,4))return false;
  if(current!=expected&&current!=replacement)return false;
  if(current==expected&&!write(address,&replacement,4))return false;
  address_=address;original_=expected;applied_=replacement;
  return read(address,&current,4)&&current==replacement;
 }
 void forget(){address_=0;}
};
}
