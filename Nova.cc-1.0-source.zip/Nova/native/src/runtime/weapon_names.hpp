#pragma once
#include <string>
#include <algorithm>
#include <cctype>
#include <cstring>
namespace oxide {
// Display names only. Identifiers used by gameplay and inventory are untouched.
inline std::string weapon_name_ru(const std::string& english){
 struct Pair {const char* english;const char* russian;};
 static constexpr Pair names[]={
  {"assault_rifle","Штурмовая винтовка"},{"automatic rifle","Автоматическая винтовка"},{"rifle","Винтовка"},{"semi auto rifle","Полуавтоматическая винтовка"},{"semi auto pistol","Полуавтоматический пистолет"},{"bolt rifle","Винтовка с затвором"},{"double shotgun","Двуствольный дробовик"},{"pipe shotgun","Самодельный дробовик"},{"machine gun","Пулемёт"},{"rocket launcher","Ракетница"},{"grenade launcher","Гранатомёт"},{"nailgun","Гвоздомёт"},{"nail gun","Гвоздомёт"},{"ak47","АК-47"},{"ak 47","АК-47"},{"ak-47","АК-47"},{"ak74","АК-74"},{"ak-74","АК-74"},{"akm","АКМ"},
  {"m4","М4"},{"m4a1","М4А1"},{"m16","М16"},{"m16a4","М16А4"},{"lr300","ЛР-300"},{"lr-300","ЛР-300"},
  {"mp5","МП5"},{"mp5a4","МП5А4"},{"mp5k","МП5К"},{"m249","М249"},{"m39","М39"},{"l96","Л96"},
  {"spas12","СПАС-12"},{"spas-12","СПАС-12"},{"glock","Глок"},{"glock 17","Глок-17"},{"glock17","Глок-17"},
  {"desert eagle","Дезерт Игл"},{"deagle","Дезерт Игл"},{"python revolver","Револьвер «Питон»"},{"python","Питон"},
  {"rifle.ak","АК-47"},{"rifle.bolt","Винтовка с затвором"},{"rifle.semiauto","Полуавтоматическая винтовка"},
  {"shotgun.pump","Помповый дробовик"},{"shotgun.double","Двуствольный дробовик"},{"pistol.semiauto","Полуавтоматический пистолет"},
  {"pistol.revolver","Револьвер"},{"smg.thompson","Томпсон"},{"smg.mp5","МП5"},

  {"assault rifle","Штурмовая винтовка"},{"bolt action rifle","Винтовка с затвором"},
  {"bolt-action rifle","Винтовка с затвором"},{"hunting rifle","Охотничья винтовка"},
  {"semi automatic rifle","Полуавтоматическая винтовка"},{"semi-automatic rifle","Полуавтоматическая винтовка"},
  {"semi automatic pistol","Полуавтоматический пистолет"},{"semi-automatic pistol","Полуавтоматический пистолет"},
  {"pistol","Пистолет"},{"revolver","Револьвер"},{"submachine gun","Пистолет-пулемёт"},
  {"custom smg","Самодельный пистолет-пулемёт"},{"smg","Пистолет-пулемёт"},
  {"thompson","Томпсон"},{"pump shotgun","Помповый дробовик"},
  {"pump action shotgun","Помповый дробовик"},{"double barrel shotgun","Двуствольный дробовик"},
  {"double-barrel shotgun","Двуствольный дробовик"},{"shotgun","Дробовик"},
  {"waterpipe shotgun","Самодельный дробовик"},{"hunting bow","Охотничий лук"},
  {"bow","Лук"},{"compound bow","Блочный лук"},{"crossbow","Арбалет"},
  {"wooden spear","Деревянное копьё"},{"stone spear","Каменное копьё"},{"spear","Копьё"},
  {"rocket launcher","Ракетница"},{"flare gun","Сигнальный пистолет"},
  {"grenade","Граната"},{"f1 grenade","Граната Ф-1"},{"hatchet","Топор"},
  {"stone hatchet","Каменный топор"},{"pickaxe","Кирка"},{"stone pickaxe","Каменная кирка"},
  {"rock","Камень"},{"torch","Факел"},{"knife","Нож"},{"combat knife","Боевой нож"},
  {"machete","Мачете"},{"chainsaw","Бензопила"},{"hammer","Молоток"},{"hands","Руки"},
  {"explosive charge","Взрывной заряд"},{"satchel charge","Сумка со взрывчаткой"}
 };
 auto key=english;std::transform(key.begin(),key.end(),key.begin(),[](unsigned char c){return char(std::tolower(c));});
 for(auto& entry:names)if(key==entry.english)return entry.russian;
 // Accept common item-label separators without changing actual inventory IDs.
 auto clean=key;for(char& c:clean)if(c=='_'||c=='-')c=' ';
 while(!clean.empty()&&std::isspace(static_cast<unsigned char>(clean.front())))clean.erase(clean.begin());
 while(!clean.empty()&&std::isspace(static_cast<unsigned char>(clean.back())))clean.pop_back();
 if(auto clone=clean.find("(clone)");clone!=std::string::npos)clean.erase(clone);
 while(!clean.empty()&&std::isspace(static_cast<unsigned char>(clean.back())))clean.pop_back();
 for(const char* prefix:{"weapon ","item "})if(clean.rfind(prefix,0)==0)clean.erase(0,strlen(prefix));
 while(clean.find("  ")!=std::string::npos)clean.erase(clean.find("  "),1);
 for(auto& entry:names)if(clean==entry.english)return entry.russian;

 return english;
}
}
