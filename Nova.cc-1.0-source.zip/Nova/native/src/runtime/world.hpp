#pragma once
#include "core.hpp"
#include <cctype>
namespace oxide {
enum WorldKind {Sulfur=1,Stone=2,Metal=3,Barrel=4,Wood=5,HighMetal=6,Animal=7,Bot=8,Vehicle=9,Turret=10};
inline int entity_kind(const std::string& type){if(type=="NPCBrainAnimal")return Animal;if((type=="NPCBrainCombat"||type=="NPCBrainHumanoid"))return Bot;if(type=="VehicleManager")return Vehicle;if(type=="AutoTurret"||type=="AutoTurretShotgun"||type=="AutoSnowballTurret"||type=="AutoSamTurret")return Turret;return 0;}
inline std::string normalized(const std::string& text){std::string r;for(unsigned char c:text)if(c<128&&std::isalnum(c))r+=char(std::tolower(c));return r;}
inline int resource_kind(const std::string& item){auto s=normalized(item);if(s.find("highquality")!=s.npos||s.find("hqmetal")!=s.npos||s.find("metalhq")!=s.npos||s.find("refinedmetal")!=s.npos||s.find("metalrefined")!=s.npos||s=="mvk")return HighMetal;if(s.find("sulfur")!=s.npos||s.find("sulphur")!=s.npos)return Sulfur;if(s.find("metal")!=s.npos||s.find("iron")!=s.npos)return Metal;if(s.find("stone")!=s.npos||s.find("rock")!=s.npos)return Stone;if(s.find("scrap")!=s.npos||s.find("barrel")!=s.npos)return Barrel;if(s.find("wood")!=s.npos||s.find("tree")!=s.npos)return Wood;return 0;}
inline const char* world_label(int kind){switch(kind){case Sulfur:return "Сера";case Stone:return "Камень";case Metal:return "Металл";case Barrel:return "Скрап / бочка";case Wood:return "Дерево";case HighMetal:return "МВК";case Bot:return "Бот";case Vehicle:return "Машина";case Turret:return "Турель";default:return "Животное";}}
inline const char* animal_label(const std::string& name){auto s=normalized(name);std::string lower;
 for(size_t i=0;i<name.size();++i){
  const auto c=static_cast<unsigned char>(name[i]);
  const auto next=i+1<name.size()?static_cast<unsigned char>(name[i+1]):0;
  if(c==0xd0&&next>=0x90&&next<=0xaf){lower+=char(next<=0x9f?0xd0:0xd1);lower+=char(next<=0x9f?next+0x20:next-0x20);++i;}
  else lower+=name[i];
 }
 if(lower.find("медвед")!=lower.npos)return "Медведь";
 if(lower.find("кабан")!=lower.npos)return "Кабан";
 if(lower.find("волк")!=lower.npos)return "Волк";
 if(lower.find("олень")!=lower.npos)return "Олень";
 if(lower.find("заяц")!=lower.npos)return "Заяц";
 if(lower.find("курица")!=lower.npos)return "Курица";
 if(s.find("bear")!=s.npos)return "Медведь";if(s.find("boar")!=s.npos||s.find("pig")!=s.npos)return "Кабан";if(s.find("wolf")!=s.npos)return "Волк";if(s.find("deer")!=s.npos||s.find("stag")!=s.npos)return "Олень";if(s.find("hare")!=s.npos||s.find("rabbit")!=s.npos)return "Заяц";if(s.find("chicken")!=s.npos)return "Курица";return "Животное";}
}
