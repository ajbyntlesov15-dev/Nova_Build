#pragma once
#include "access_receipt.hpp"
#include <sstream>
namespace recording_bridge {
struct Status{int state=0,pid=0,width=0,height=0,fps=0,bitrate=0;long long stamp=0,started=0;};
inline bool parse(const std::string& data,long long now,Status& result){
 if(data.size()>512)return false;std::istringstream input(data);std::string header;if(!std::getline(input,header)||header!="NovaRecording 1")return false;
 Status s;if(!(input>>s.state>>s.pid>>s.stamp>>s.started>>s.width>>s.height>>s.fps>>s.bitrate))return false;input>>std::ws;if(!input.eof())return false;
 if(s.state<0||s.state>4||s.pid<=0||s.stamp<0||s.started<0||s.started>s.stamp||s.stamp>now+1000||now-s.stamp>4000)return false;
 if(s.width<0||s.width>8192||s.height<0||s.height>8192||s.fps<0||s.fps>60||s.bitrate<0||s.bitrate>50000000)return false;
 if(s.state==2&&(s.started==0||s.width<240||s.height<240||s.fps<1||s.bitrate<100000))return false;
 result=s;return true;
}
inline bool ui_active(const std::string& path,uint32_t uid,long long now){std::string data;if(!access_receipt::read_owned(path,uid,256,data))return false;std::istringstream in(data);std::string header;long long stamp=0;int pid=0,active=0;if(!std::getline(in,header)||header!="NovaCaptureUi 1"||!(in>>pid>>stamp>>active))return false;in>>std::ws;return in.eof()&&pid>0&&active==1&&stamp>=0&&stamp<=now+1000&&now-stamp<=4000;}
inline bool read(const std::string& path,uint32_t uid,long long now,Status& out){std::string data;return access_receipt::read_owned(path,uid,512,data)&&parse(data,now,out);}
}
