#pragma once
#include "../security/local_license.hpp"
#include <limits>
#include <algorithm>
#include <cerrno>
#include <mutex>
#include <chrono>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
namespace access_receipt {
inline bool control_uid(const std::string& control,uint32_t& uid){
 const std::string prefix="/data/local/tmp/nova-";if(control.compare(0,prefix.size(),prefix)||control.size()==prefix.size())return false;
 uint64_t value=0;for(size_t i=prefix.size();i<control.size();++i){char c=control[i];if(c<'0'||c>'9')return false;value=value*10+unsigned(c-'0');if(value>UINT32_MAX)return false;}if(value%100000<10000)return false;uid=uint32_t(value);return true;
}
inline bool read_owned(const std::string& path,uint32_t owner,size_t maximum,std::string& out){
 if(path.empty()||path[0]!='/'||path.find("..")!=std::string::npos)return false;
 int fd=::open(path.c_str(),O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_NONBLOCK);if(fd<0)return false;
 struct stat st{};bool ok=::fstat(fd,&st)==0&&S_ISREG(st.st_mode)&&st.st_uid==owner&&!(st.st_mode&0077)&&st.st_nlink==1&&st.st_size>0&&uint64_t(st.st_size)<=maximum;
 std::string data;if(ok){data.resize(size_t(st.st_size));size_t used=0;while(used<data.size()){ssize_t n=::read(fd,&data[used],data.size()-used);if(n<0&&errno==EINTR)continue;if(n<=0){ok=false;break;}used+=size_t(n);}char extra;if(ok&&::read(fd,&extra,1)!=0)ok=false;}
 ::close(fd);if(ok)out=std::move(data);return ok;
}
inline bool file_hash(const std::string& path,std::array<uint8_t,64>& hash){
 int fd=::open(path.c_str(),O_RDONLY|O_CLOEXEC);if(fd<0)return false;crypto_sha512_ctx ctx;crypto_sha512_init(&ctx);uint8_t buffer[16384];size_t size=0;bool ok=true;
 for(;;){ssize_t n=::read(fd,buffer,sizeof(buffer));if(n<0&&errno==EINTR)continue;if(n<0){ok=false;break;}if(!n)break;size+=size_t(n);if(size>32*1024*1024){ok=false;break;}crypto_sha512_update(&ctx,buffer,size_t(n));}::close(fd);if(ok&&size)crypto_sha512_final(&ctx,hash.data());else ok=false;return ok;
}

class CommonLease{
 std::mutex mutex_;std::string path_;uint32_t uid_=0;bool active_=false;std::chrono::steady_clock::time_point next_{};
 bool reload(){std::string data;return read_owned(path_,uid_,128,data)&&nova_license::verify(data);}
public:
 bool start(const std::string& path,uint32_t uid){std::lock_guard<std::mutex> lock(mutex_);path_=path;uid_=uid;active_=reload();next_=std::chrono::steady_clock::now();return active_;}
 bool valid(){std::lock_guard<std::mutex> lock(mutex_);if(!active_)return false;auto now=std::chrono::steady_clock::now();if(now>=next_){next_=now+std::chrono::seconds(1);active_=reload();}return active_;}
 bool allows(uint32_t feature){return feature&&!(feature&~dof_license::All)&&valid();}
};
class Lease:public CommonLease{
public: bool start(const std::string& path,uint32_t uid,const std::string&){return CommonLease::start(path,uid);}
};
}
