#include "prediction.hpp"
#include "value_overrides.hpp"
#include "weapon_names.hpp"
#include "instruction_override.hpp"
#include "vegetation_profile.hpp"
#include "container_box.hpp"
#include "loot_classification.hpp"
#pragma once
#include <utility>
#include <functional>
#include <cctype>
#include "core.hpp"
#include "profile.hpp"
#include "aim_activation.hpp"
#include "visibility.hpp"
#include "silent_view.hpp"
#include "shot_redirect.hpp"
#include "aim_fov.hpp"
#include "world.hpp"
#include "scoped_patch.hpp"
#include <atomic>
#include <chrono>
#include <mutex>
#include <thread>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <cstdio>
#include <unordered_map>
#include <unordered_set>
namespace oxide {
inline long long now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}

class Live {
 std::thread thread_;std::atomic<bool> stop_{false};std::mutex mutex_;Frame frame_;Options options_;std::string package_;const oxide_profile::Profile* profile_=&oxide_profile::current;
 std::unordered_map<uint64_t,std::string> class_names_;std::unordered_set<std::string> unknown_prefabs_;
 ValueOverrides weapon_values_,movement_values_;uint64_t ray_record_=0;long long ray_seen_=0;
 ShotRedirect shot_redirect_;
 SilentView silent_;
 bool release_silent(){return silent_.release([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);});}
 AimActivation activation_;uint32_t sticky_id_=0;uint64_t sticky_identity_=0;uint64_t aim_look_=0;float aim_written_[2]{};V aim_camera_{};long long aim_sent_=0;
 int name_offset_=-1;uint64_t client_class_=0;std::string registry_status_;long long registry_log_=0;
 bool direct_=false;
 std::string direct_status_;
 int pid_=0,fd_=-1,wfd_=-1;uint64_t game_=0,unity_=0;long long retry_=0,scan_=0;std::vector<std::pair<uint32_t,uint64_t>> identities_;
 struct PlayerRef{uint64_t object,identity;uint32_t id;};std::vector<PlayerRef> player_refs_;std::vector<Container> containers_;std::vector<WorldObject> world_;long long scene_scan_=0,last_good_=0;uint64_t scene_local_=0;
 struct SceneBuild{bool active=false;uint64_t local=0;size_t cursor=0;std::vector<std::pair<uint32_t,uint64_t>> identities;std::vector<PlayerRef> players;std::vector<Container> containers;std::vector<WorldObject> world;} build_;
 std::unordered_map<uint64_t,WorldObject> world_metadata_;
 std::array<CollectDelayPatch,2> collect_patches_;uint64_t day_cell_=0,mode_cell_=0;long long collect_error_=0;
 InstructionOverride sky_color_writer_,day_fraction_writer_,day_hour_writer_;
 template<class P>bool restore_instruction(P& patch){return patch.restore([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);});}
 template<class P>bool instruction(P& patch,uint64_t offset,uint32_t expected){return patch.set([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);},game_+offset,expected,0xd503201fU);}
 std::array<InstructionOverride,2> vegetation_patches_;
 bool vegetation(bool enabled){
  auto read_fn=[&](uint64_t a,void* b,size_t n){return read(a,b,n);};auto write_fn=[&](uint64_t a,const void* b,size_t n){return write(a,b,n);};
  auto restore_all=[&]{bool ok=true;for(auto& patch:vegetation_patches_)ok=patch.restore(read_fn,write_fn)&&ok;return ok;};
  if(!enabled)return restore_all();
  const auto* patches=profile_==&oxide_profile::beta?vegetation_beta:vegetation_current;
  for(size_t i=0;i<2;++i){
   unsigned char current[16]{};uint32_t first=0;const auto& patch=patches[i];
   if(!read(game_+patch.address,current,sizeof(current))){restore_all();return false;}
   memcpy(&first,current,4);
   if(memcmp(current+4,patch.guard+4,12)||(memcmp(current,patch.guard,4)&&first!=0xd65f03c0U)){restore_all();return false;}
  }
  for(size_t i=0;i<2;++i){uint32_t expected=0;memcpy(&expected,patches[i].guard,4);if(!vegetation_patches_[i].set(read_fn,write_fn,game_+patches[i].address,expected,0xd65f03c0U)){restore_all();return false;}}
  return true;
 }
 struct SkyState{int mode=0;std::array<float,4> color{};};
 static_assert(sizeof(SkyState)==20);
 struct SkyBackup{uint64_t camera=0;int id=0;SkyState original{},applied{};bool active=false;} sky_;
 bool restore_sky(){
  if(!sky_.camera)return restore_instruction(sky_color_writer_);
  int id=0;SkyState current{};
  if(!val(sky_.camera+8,id))return false;
  if(id==sky_.id&&sky_.active){
   if(!val(sky_.camera+0x408,current))return false;
   auto restored=current;
   if(current.mode==sky_.applied.mode)restored.mode=sky_.original.mode;
   if(current.color==sky_.applied.color)restored.color=sky_.original.color;
   if((restored.mode!=current.mode||restored.color!=current.color)&&
      !write(sky_.camera+0x408,&restored,sizeof(restored)))return false;
  }
  sky_={};return restore_instruction(sky_color_writer_);
 }
 void sky(Frame& f,const Options& o){
  if(!o.sky_tint){restore_sky();return;}
  // A missed camera sample is not a camera switch.
  if(!f.camera_native||!finite(o.sky_color))return;
  int id=0;SkyState current{};
  if(!val(f.camera_native+8,id)||!val(f.camera_native+0x408,current)||current.mode<1||current.mode>4)return;
  for(float value:current.color)if(!std::isfinite(value)||value<0||value>16)return;
  if(sky_.camera==f.camera_native&&sky_.id!=id)sky_={};
  if(sky_.camera&&sky_.camera!=f.camera_native&&!restore_sky())return;
  if(!sky_.camera){sky_.camera=f.camera_native;sky_.id=id;sky_.original=current;}
  if(sky_.active){
   if(current.mode!=sky_.applied.mode)sky_.original.mode=current.mode;
   if(current.color!=sky_.applied.color)sky_.original.color=current.color;
  }
  // HQ.Update resets this camera background to transparent black every frame.
  // Suppress that specific call only; other cameras and the sky simulation keep running.
  instruction(sky_color_writer_,profile_->sky_writer_address,profile_->sky_writer_expected);
  SkyState desired{2,{std::clamp(o.sky_color.x,0.f,1.f),std::clamp(o.sky_color.y,0.f,1.f),std::clamp(o.sky_color.z,0.f,1.f),1.f}};
  if(current.mode==desired.mode&&current.color==desired.color)return;
  if(write(f.camera_native+0x408,&desired,sizeof(desired))){sky_.applied=desired;sky_.active=true;}
 }
 // Verified against the supplied Unity build, GetTargetFrameRate/QualitySettings bindings.
 struct IntBackup{uint64_t address=0;int original=0,applied=0;uint64_t manager=0,levels=0;};
 std::vector<IntBackup> fps_values_;
 void restore_fps(){
  for(auto it=fps_values_.begin();it!=fps_values_.end();){if(it->manager&&(p(unity_+profile_->fps_manager_cell)!=it->manager||p(it->manager+0x20)!=it->levels)){it=fps_values_.erase(it);continue;}int current=0;if(!val(it->address,current)){++it;continue;}if(current!=it->applied||write(it->address,&it->original,4))it=fps_values_.erase(it);else ++it;}
 }
 void frame_limit(Frame& f,const Options& o){
  if(!o.unlock_fps){restore_fps();return;}
  const auto& guard=profile_->guards[profile_->guard_count-1];
  uint8_t code[12]{};
  if(!guard.unity||guard.size!=sizeof(code)||!read(unity_+guard.address,code,sizeof(code))||memcmp(code,guard.bytes,sizeof(code))){f.fps_status="FPS: версия Unity не подтверждена";return;}
  auto apply=[&](uint64_t address,int value,int min,int max,uint64_t manager=0,uint64_t levels=0){
   int current=0;if(!val(address,current)||current<min||current>max)return false;
   auto it=std::find_if(fps_values_.begin(),fps_values_.end(),[&](const auto& e){return e.address==address;});
   if(it==fps_values_.end()){fps_values_.push_back({address,current,value,manager,levels});it=fps_values_.end()-1;}
   else if(current!=it->applied)it->original=current;
   if(current!=value&&!write(address,&value,4))return false;it->applied=value;return true;
  };
  bool ok=apply(unity_+profile_->fps_target_cell,std::clamp(o.fps_limit,30,144),-1,1000);
  // GetQualitySettings() is manager 11; only touch the active quality level.
  auto manager=p(unity_+profile_->fps_manager_cell);int level=-1;auto levels=p(manager+0x20);
  if(manager&&levels&&val(manager+0x64,level)&&level>=0&&level<16)ok=apply(levels+uint64_t(level)*0x108+0x88,0,0,4,manager,levels)&&ok;
  f.fps_status=ok?"Лимит игры: "+std::to_string(std::clamp(o.fps_limit,30,144))+" FPS":"FPS: запись недоступна";
 }
 struct DayBackup{uint64_t object=0;float fraction=0,rate=0;uint8_t stopped=0;long long observed=0;int hour=0;float applied=-1.f;} day_;
 std::string day_status_;
 uint64_t day_object(){
  auto resolve=[&](uint64_t cell){
   std::vector<uint64_t> pending;auto slot=p(game_+cell);if(slot){pending.push_back(slot);if(auto value=p(slot))pending.push_back(value);}
   std::unordered_set<uint64_t> visited;
   for(size_t i=0;i<pending.size()&&i<48;++i){
    auto type=pending[i];if(!type||!visited.insert(type).second)continue;
    if(name(type)=="TimeOfDay")return type;
    auto stat=p(type+0xb8);if(auto instance=p(stat))if(name(instance)=="TimeOfDay")return instance;
    // MethodInfo::klass, Il2CppClass::parent and initialized RGCTX class entries.
    for(unsigned off:{0x20U,0x58U})if(auto owner=p(type+off))pending.push_back(owner);
    auto context=p(type+0xc0);
    for(unsigned off=0;context&&off<0x80;off+=8)if(auto owner=p(context+off))pending.push_back(owner);
   }
   return uint64_t(0);
  };
  if(day_cell_)if(auto object=resolve(day_cell_))return object;
  for(size_t i=0;i<profile_->day_count;++i)if(auto object=resolve(profile_->day_cells[i])){day_cell_=profile_->day_cells[i];return object;}
  return 0;
 }
 uint64_t game_modes(){
  auto resolve=[&](uint64_t cell){auto candidate=p(p(p(p(p(game_+cell))+0xb8)+profile_->controller_static)+profile_->controller_modes);return name(candidate)=="GameModes"?candidate:uint64_t(0);};
  if(mode_cell_)if(auto object=resolve(mode_cell_))return object;
  for(size_t i=0;i<profile_->mode_count;++i)if(auto object=resolve(profile_->mode_cells[i])){mode_cell_=profile_->mode_cells[i];return object;}
  return 0;
 }
 bool restore_day(){
  bool fraction_restored=restore_instruction(day_fraction_writer_),hour_restored=restore_instruction(day_hour_writer_);if(!fraction_restored||!hour_restored)return false;
  if(!day_.object)return true;if(day_object()!=day_.object){day_={};return true;}
  float fraction=0,rate=0;uint8_t stopped=0;int hour=0;
  if(!val(day_.object+0xb8,fraction)||!val(day_.object+0xbc,rate)||!val(day_.object+0x38,stopped)||!val(day_.object+0x3c,hour))return false;
  if(fraction==day_.applied){float original=day_.fraction;if(!day_.stopped)original=std::fmod(original+std::max(0LL,now()-day_.observed)*.001f*day_.rate,1.f);int restored_hour=int(original*24);if(!write(day_.object+0xb8,&original,4)||!write(day_.object+0x3c,&restored_hour,4))return false;}
  if(rate==0&&!write(day_.object+0xbc,&day_.rate,4))return false;
  if(stopped==1&&!write(day_.object+0x38,&day_.stopped,1))return false;
  day_={};return true;
 }
 void daylight(bool enabled,int selected_hour){
  day_status_.clear();if(!enabled){if(!restore_day())day_status_="День: восстановление не завершено";return;}
  auto object=day_object();if(!object){day_status_="День: TimeOfDay не найден";return;}
  if(day_.object&&day_.object!=object&&!restore_day()){day_status_="День: ожидается восстановление";return;}
  float fraction=0,rate=0;uint8_t stopped=0;int hour=0;
  if(!val(object+0xb8,fraction)||!val(object+0xbc,rate)||!val(object+0x38,stopped)||!val(object+0x3c,hour)||!std::isfinite(fraction)||fraction<0||fraction>=1||!std::isfinite(rate)||rate<0||rate>1||stopped>1){day_status_="День: параметры недоступны";return;}
  {
   // Incoming time synchronization calls the setter even while StopTime is enabled.
   if(!instruction(day_fraction_writer_,profile_->day_fraction.address,profile_->day_fraction.expected)||!instruction(day_hour_writer_,profile_->day_hour.address,profile_->day_hour.expected)){day_status_="День: защита времени недоступна";}
  }
  if(!day_.object)day_={object,fraction,rate,stopped,now(),hour};
  else {if(fraction!=day_.applied){day_.fraction=fraction;day_.observed=now();}if(rate!=0)day_.rate=rate;}
  // Update() still evaluates fog, ambient, sun and skybox while m_StopTime is set.
  // Freeze both the accumulator and its rate so an engine tick cannot advance it.
  uint8_t stop=1;float zero=0;int fixed_hour=std::clamp(selected_hour,0,23);float fixed_fraction=fixed_hour/24.f;
  if(!write(object+0xbc,&zero,4)||!write(object+0x38,&stop,1)||!write(object+0x3c,&fixed_hour,4)||!write(object+0xb8,&fixed_fraction,4))day_status_="День: запись отклонена";
  else {day_.applied=fixed_fraction;day_status_="Время суток: "+std::to_string(fixed_hour)+":00";}
 }
 struct OrbitBackup{uint64_t owner=0,stat=0;V original[2]{},applied[2]{};} orbit_;
 bool restore_orbit(){if(!orbit_.stat)return true;if(p(orbit_.owner+0xb8)!=orbit_.stat){orbit_.owner=orbit_.stat=0;return true;}V current[2]{};if(!val(orbit_.stat,current))return false;for(unsigned i=0;i<2;++i)if(!memcmp(&current[i],&orbit_.applied[i],sizeof(V))&&!write(orbit_.stat+i*12,&orbit_.original[i],sizeof(V)))return false;orbit_.owner=orbit_.stat=0;return true;}
 bool orbit(uint64_t controller,const Options& o){auto owner=p(p(game_+profile_->orbit_cell));if(owner!=p(controller))return false;auto stat=p(owner+0xb8);V values[2]{};if(!stat||!val(stat,values))return false;for(auto v:values)if(!finite(v)||v.z>-.5f||v.z< -20)return false;
  if(orbit_.stat&&(orbit_.stat!=stat||orbit_.owner!=owner)&&!restore_orbit())return false;if(!orbit_.stat){orbit_.owner=owner;orbit_.stat=stat;memcpy(orbit_.original,values,sizeof(values));memcpy(orbit_.applied,values,sizeof(values));}
  V next{std::clamp(o.third_shoulder,0.f,1.f),std::clamp(o.third_height,0.f,1.f),-std::clamp(o.third_distance,1.f,5.f)};V both[2]{next,next};if(memcmp(both,values,sizeof(both))){if(!write(stat,both,sizeof(both)))return false;memcpy(orbit_.applied,both,sizeof(both));}return true;
 }
 struct FovBackup{uint64_t manager=0,camera=0;int camera_id=0;float original[2]{},applied[2]{};} fov_backup_;
 bool restore_fov(){if(!fov_backup_.manager)return true;float current[2]{};if(name(fov_backup_.manager)!="FPManager"||p(p(fov_backup_.manager+0x20)+0x10)!=fov_backup_.camera){fov_backup_={};return true;}int id=0;if(!val(fov_backup_.camera+8,id)||id!=fov_backup_.camera_id){fov_backup_={};return true;}if(!val(fov_backup_.manager+0xac,current))return false;for(unsigned i=0;i<2;++i)if(current[i]==fov_backup_.applied[i]&&!write(fov_backup_.manager+0xac+i*4,&fov_backup_.original[i],4))return false;fov_backup_={};return true;}
 struct ThirdBackup{uint64_t mode=0,controller=0,player=0;uint8_t original=0;} third_backup_;
 bool restore_third(){if(!restore_orbit())return false;if(!third_backup_.mode)return true;uint8_t mode=0;if(name(third_backup_.mode)!="GameModes"){third_backup_={};return true;}if(!val(third_backup_.mode+profile_->third_mode,mode))return false;if(mode==2&&!write(third_backup_.mode+profile_->third_mode,&third_backup_.original,1))return false;third_backup_={};return true;}
 struct CameraBackup{uint32_t capture_generation=0;int mode=0;uint64_t camera=0;int id=0;M original{},applied{};uint8_t flag=1;V position{};float yaw=0,pitch=0,lx=0,ly=0;long long time=0;} backup_;
 bool read(uint64_t a,void* b,size_t n){if(pid_<=0||a<65536||n>16*1024*1024||a>UINT64_MAX-n)return false;if(fd_>=0&&pread(fd_,b,n,off_t(a))==ssize_t(n))return true;iovec l{b,n},r{reinterpret_cast<void*>(a),n};return syscall(__NR_process_vm_readv,pid_,&l,1,&r,1,0)==ssize_t(n);}
 bool write(uint64_t a,const void* b,size_t n){if(pid_<=0)return false;if(wfd_<0){char path[64];snprintf(path,sizeof(path),"/proc/%d/mem",pid_);wfd_=open(path,O_RDWR|O_CLOEXEC);}if(wfd_>=0&&pwrite(wfd_,b,n,off_t(a))==ssize_t(n))return true;iovec l{const_cast<void*>(b),n},r{reinterpret_cast<void*>(a),n};return syscall(__NR_process_vm_writev,pid_,&l,1,&r,1,0)==ssize_t(n);}
 template<class T>bool val(uint64_t a,T& v){return get([&](uint64_t x,void* y,size_t z){return read(x,y,z);},a,v);}
 uint64_t p(uint64_t a){uint64_t v=0;if(!val(a,v))return 0;v=untag(v);return ptr(v)?v:0;}
 std::string name(uint64_t o){auto k=p(o);if(!k||name_offset_<0)return {};auto it=class_names_.find(k);if(it!=class_names_.end())return it->second;auto value=ascii([&](uint64_t x,void* y,size_t z){return read(x,y,z);},byte_pointer([&](uint64_t x,void* y,size_t z){return read(x,y,z);},k+uint64_t(name_offset_)));if(!value.empty()&&class_names_.size()<4096)class_names_[k]=value;return value;}
 std::string str(uint64_t a){return text([&](uint64_t x,void* y,size_t z){return read(x,y,z);},a);}
 bool position(uint64_t o,V& v){return component_position([&](uint64_t x,void* y,size_t z){return read(x,y,z);},o,v);}
 bool restore(){if(!backup_.camera)return true;int id=0;uint8_t flag=1;M current{};
  if(!val(backup_.camera+8,id)||id!=backup_.id){backup_={};return true;}
  if(!val(backup_.camera+0x502,flag)||!val(backup_.camera+0x70,current))return false;
  if(flag==0){if(!write(backup_.camera+0x70,&backup_.original,sizeof(M))||!write(backup_.camera+0x502,&backup_.flag,1))return false;}
  backup_={};return true;
 }
 MarkerVisibility visibility_;
 void close_process(){shot_redirect_.disable([&](uint64_t a,const void* b,size_t n){return write(a,b,n);});shot_redirect_.forget();trace_weapon_=trace_counter_=trace_local_=0;trace_count_=-1;trace_stamp_=-1;trace_direction_time_=0;release_silent();silent_.forget();vegetation(false);for(auto& p:vegetation_patches_)p.forget();visibility_.reset();combat_queue_=0;combat_version_=0;hit_at_=0;shot_segments_.clear();last_aim_trace_=0;last_trace_identity_=0;aim_samples_.clear();search_identity_=owner_scan_complete_=0;search_id_=0;restore_fps();fps_values_.clear();movement_features(Frame{},Options{});movement_values_.forget();restore_sky();weapon_values_.restore([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);});weapon_values_.forget();ray_record_=0;ray_seen_=0;restore_day();for(auto& patch:collect_patches_){patch.restore([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);});patch.forget();}restore_third();restore_fov();restore();backup_={};third_backup_={};orbit_.owner=orbit_.stat=0;fov_backup_={};spin_time_=0;spin_player_=0;spin_angle_=0;if(fd_>=0)close(fd_);if(wfd_>=0)close(wfd_);fd_=wfd_=-1;pid_=0;game_=unity_=0;activation_.reset();sticky_id_=0;sticky_identity_=0;name_offset_=-1;client_class_=0;day_cell_=mode_cell_=0;aim_look_=0;class_names_.clear();day_={};day_status_.clear();item_labels_.clear();item_database_=0;item_lookup_after_=0;sky_={};sky_color_writer_.forget();day_fraction_writer_.forget();day_hour_writer_.forget();unknown_prefabs_.clear();scan_=0;identities_.clear();player_refs_.clear();containers_.clear();scene_scan_=0;scene_local_=0;world_.clear();world_metadata_.clear();build_={};last_good_=0;}
 std::string describe_guard_bytes(uint64_t base,uint64_t offset,const unsigned char* expected,size_t size){
  unsigned char bytes[32]{};
  errno=0;
  const bool ok=read(base+offset,bytes,size);
  const int error=errno;
  char label[80];
  snprintf(label,sizeof(label),"base+0x%llx: ",(unsigned long long)offset);
  std::string result=label;
  if(!ok)return result+"read failed (errno="+std::to_string(error)+")";
  static constexpr char digits[]="0123456789abcdef";
  for(size_t i=0;i<size;++i){
   result+=digits[bytes[i]>>4];
   result+=digits[bytes[i]&15];
  }
  return result+(memcmp(bytes,expected,size)==0?" [MATCH]":" [MISMATCH]");
 }
 bool guards(){
  for(size_t i=0;i<profile_->guard_count;++i){
   const auto& g=profile_->guards[i];
   unsigned char bytes[32]{};
   const char* library=g.unity?"libunity.so":"libil2cpp.so";
   if(g.size>sizeof(bytes))return false;
   errno=0;
   const bool read_ok=read((g.unity?unity_:game_)+g.address,bytes,g.size);
   const int error=errno;
   if(read_ok&&!memcmp(bytes,g.bytes,g.size))continue;
   if(direct_){
    char detail[256];
    if(!read_ok){
     snprintf(detail,sizeof(detail),"%s: guard %zu, %s+0x%llx, read failed (%s, errno=%d)",
              profile_->version,i+1,library,(unsigned long long)g.address,error?strerror(error):"short read",error);
    }else{
     unsigned j=0;while(bytes[j]==g.bytes[j])++j;
     snprintf(detail,sizeof(detail),"%s: guard %zu, %s+0x%llx, byte %u mismatch (expected %02x, got %02x)",
              profile_->version,i+1,library,(unsigned long long)g.address,j,unsigned(g.bytes[j]),unsigned(bytes[j]));
    }
    std::string report=detail;
    if(profile_==&oxide_profile::beta&&!g.unity&&g.address==0xd2b3c20&&g.size==32){
     // The beta ELF's executable PT_LOAD maps this RVA to file offset 0xd2afc20.
     report+="\n"+describe_guard_bytes(game_,g.address,g.bytes,g.size);
     report+="\n"+describe_guard_bytes(game_,0xd2afc20,g.bytes,g.size);
    }
    direct_error(report);
   }
   return false;
  }
  return true;
 }
 using AddressRange=std::pair<uint64_t,uint64_t>;
 uint64_t verified_loaded_base(const std::vector<uint64_t>& candidates,
                               const std::vector<AddressRange>& executable,bool unity){
  for(auto base:candidates){
   bool valid=true;
   for(size_t i=0;i<profile_->guard_count;++i){
    const auto& guard=profile_->guards[i];
    if(guard.unity!=unity)continue;
    const auto address=base+guard.address;
    const bool needs_executable=i>=2;
    if(needs_executable&&std::none_of(executable.begin(),executable.end(),[&](const auto& range){
       return address>=range.first&&address<range.second&&guard.size<=range.second-address;
    })){valid=false;break;}
    unsigned char bytes[32]{};
    if(guard.size>sizeof(bytes)||!read(address,bytes,guard.size)||memcmp(bytes,guard.bytes,guard.size)){
     valid=false;break;
    }
   }
   if(valid)return base;
  }
  return 0;
 }
 void direct_error(const std::string& status){direct_status_=status;fprintf(stderr,"Virtual: %s\n",status.c_str());}
 bool attach(){char path[96],cmd[256]{};
  if(pid_){snprintf(path,sizeof(path),"/proc/%d/cmdline",pid_);int f=open(path,O_RDONLY|O_CLOEXEC);int n=f>=0?int(::read(f,cmd,sizeof(cmd)-1)):-1;if(f>=0)close(f);if(n>0&&package_==cmd)return true;close_process();}
  if(now()<retry_)return false;retry_=now()+1000;
  DIR* d=opendir("/proc");
  if(!d){if(direct_)direct_error(std::string("/proc: ")+strerror(errno));return false;}
  std::vector<int> candidates;
  while(auto* entry=readdir(d)){
   char* end=nullptr;
   long id=strtol(entry->d_name,&end,10);
   if(id<=0||id>INT32_MAX||*end)continue;
   snprintf(path,sizeof(path),"/proc/%ld/cmdline",id);
   int fd=open(path,O_RDONLY|O_CLOEXEC);
   if(fd<0)continue;
   memset(cmd,0,sizeof(cmd));
   const auto count=::read(fd,cmd,sizeof(cmd)-1);
   close(fd);
   if(count>0&&package_==cmd)candidates.push_back(int(id));
  }
  closedir(d);
  if(candidates.empty()){if(direct_)direct_error("Oxide PID not visible");return false;}
  for(int id:candidates)if(attach_candidate(id))return true;
  return false;
 }
 bool attach_candidate(int id){
  pid_=id;
  char path[96];
  snprintf(path,sizeof(path),"/proc/%d/mem",pid_);fd_=open(path,O_RDONLY|O_CLOEXEC);if(fd_<0&&direct_)perror("Virtual /proc/pid/mem");
  snprintf(path,sizeof(path),"/proc/%d/maps",pid_);FILE* f=fopen(path,"r");if(!f){if(direct_)direct_error(std::string("Oxide maps: ")+strerror(errno));close_process();return false;}char line[1024];unsigned long long a=0,b=0,off=0;char permissions[5]{};
  uint64_t named_game=0,named_unity=0;
  std::vector<uint64_t> game_candidates,unity_candidates;
  std::vector<AddressRange> executable;
  while(fgets(line,sizeof(line),f)){
   if(sscanf(line,"%llx-%llx %4s %llx",&a,&b,permissions,&off)!=4||permissions[0]!='r')continue;
   if(direct_&&permissions[2]=='x'&&a<b)executable.emplace_back(a,b);
   unsigned char magic[4]{};
   if(read(a,magic,sizeof(magic))&&memcmp(magic,"\177ELF",sizeof(magic))==0){
    unsigned char bytes[32]{};
    const auto& gg=profile_->guards[0];
    const auto& ug=profile_->guards[1];
    if((direct_||!game_)&&read(a+gg.address,bytes,gg.size)&&!memcmp(bytes,gg.bytes,gg.size)){
     if(!game_)game_=a;
     if(direct_)game_candidates.push_back(a);
    }
    if((direct_||!unity_)&&read(a+ug.address,bytes,ug.size)&&!memcmp(bytes,ug.bytes,ug.size)){
     if(!unity_)unity_=a;
     if(direct_)unity_candidates.push_back(a);
    }
   }
   if(a>=off&&strstr(line,"libil2cpp.so")&&(!named_game||a-off<named_game))named_game=a-off;
   if(a>=off&&strstr(line,"libunity.so")&&(!named_unity||a-off<named_unity))named_unity=a-off;
  }fclose(f);
  if(!game_)game_=named_game;
  if(!unity_)unity_=named_unity;
  if(!game_||!unity_){
   if(direct_)direct_error(std::string("Oxide libraries not located: ")+(!game_?"libil2cpp.so ":"")+(!unity_?"libunity.so":""));
   close_process();
   return false;
  }
  if(direct_){
   const auto loaded_game=verified_loaded_base(game_candidates,executable,false);
   const auto loaded_unity=verified_loaded_base(unity_candidates,executable,true);
   if(loaded_game&&loaded_unity){
    game_=loaded_game;unity_=loaded_unity;
    if(guards())return true;
   }else{
    guards();
    std::string report=direct_status_;
    if(!report.empty())report+="\n";
    report+="Loaded executable mapping: libil2cpp=";
    report+=loaded_game?"verified":"not verified";
    report+=" ("+std::to_string(game_candidates.size())+" ELF candidates), libunity=";
    report+=loaded_unity?"verified":"not verified";
    report+=" ("+std::to_string(unity_candidates.size())+" ELF candidates).";
    direct_error(report);
   }
   close_process();
   return false;
  }
  if(!guards()){close_process();return false;}
  return true;
 }

 bool registry(uint64_t& local){
  auto r=[&](uint64_t a,void* b,size_t n){return read(a,b,n);};
  auto fail=[&](const char* stage){registry_status_=stage;if(now()>=registry_log_){registry_log_=now()+1000;fprintf(stderr,"OXIDE_REGISTRY %s game=0x%llx class=0x%llx nameOffset=%d\n",stage,(unsigned long long)game_,(unsigned long long)client_class_,name_offset_);}return false;};
  uint64_t slot=p(game_+profile_->network_client_cell),k=p(slot);if(!slot||!k)return fail("Сцена: слот NetworkClient ещё не инициализирован");
  if(client_class_!=k||name_offset_<0){int offset=discover_name_offset(r,k,"NetworkClient");if(offset<0){client_class_=k;return fail("Сцена: не найдено поле имени NetworkClient");}client_class_=k;name_offset_=offset;class_names_.clear();}
  uint64_t stat=p(k+0xb8);if(!stat)return fail("Сцена: статические поля NetworkClient недоступны");
  uint64_t dict=p(stat+0x30);if(!dict)return fail("Сцена: реестр spawned недоступен");local=p(stat+0x48);if(!local)return fail("Сцена: localPlayer отсутствует");
  if(now()<scan_&&!identities_.empty())return true;
  auto entries=p(dict+0x18);int count=0,version=0,after=0;uint64_t capacity=0;
  if(!val(dict+0x20,count)||!val(dict+0x24,version)||count<0||count>16384)return fail("Сцена: некорректный размер реестра");
  if(count==0){identities_.clear();scan_=now()+100;return fail("Сцена: реестр spawned пуст");}
  if(!entries||!val(entries+0x18,capacity)||capacity<uint64_t(count)||capacity>32768)return fail("Сцена: массив реестра недоступен");
  std::vector<std::pair<uint32_t,uint64_t>> found;std::vector<unsigned char> bytes(size_t(count)*24);if(!read(entries+0x20,bytes.data(),bytes.size()))return fail("Сцена: ошибка чтения элементов реестра");
  for(int i=0;i<count;++i){int hash=0;uint32_t id=0;uint64_t object=0;memcpy(&hash,bytes.data()+i*24,4);memcpy(&id,bytes.data()+i*24+8,4);memcpy(&object,bytes.data()+i*24+16,8);object=untag(object);if(hash>=0&&id&&ptr(object))found.push_back({id,object});}
  if(!val(dict+0x24,after)||version!=after||p(dict+0x18)!=entries)return fail("Сцена: реестр изменился во время чтения");
  identities_=std::move(found);scan_=now()+400;registry_status_.clear();return true;
 }

 std::vector<uint64_t> components(uint64_t identity,uint32_t expected){uint32_t id=0;uint8_t client=0;if(!val(identity+0x58,id)||id!=expected||!val(identity+0x48,client)||client!=1||name(identity)!="NetworkIdentity")return {};uint64_t array=p(identity+0x80),count=0;if(!val(array+0x18,count)||count>128)return {};std::vector<uint64_t> list(count);if(count&&!read(array+0x20,list.data(),count*8))return {};return list;}
 void skeleton(Actor& a,uint64_t vitals){
  auto read_memory=[&](uint64_t address,void* output,size_t bytes){return read(address,output,bytes);};
  std::array<int,5> area_counts{};
  std::vector<int> areas;
  auto read_boxes=[&](uint64_t array){
   uint64_t count=0;
   if(!val(array+0x18,count)||count==0||count>128)return;
   std::array<uint64_t,128> boxes{};
   if(!read(array+0x20,boxes.data(),count*sizeof(uint64_t)))return;
   for(size_t i=0;i<count;++i){
    auto box=untag(boxes[i]);Node bone;
    if(name(box)!="HitBox"||!node(read_memory,component_transform(read_memory,box),bone)||
       len(sub(bone.position,a.feet))>4)continue;
    a.hit_gameobjects.push_back(p(p(box+0x10)+0x20));
    if(std::any_of(a.bones.begin(),a.bones.end(),[&](const Node& existing){
      return existing.data==bone.data&&existing.index==bone.index;
    }))continue;
    int area=-1;
    if(val(box+0x68,area)&&area>=0&&area<int(area_counts.size()))++area_counts[area];
    a.bones.push_back(bone);areas.push_back(area);
   }
  };
  read_boxes(p(vitals+0xa8));
  if(a.bones.size()<6){
   for(auto component:components(a.identity,a.id)){
    auto type=name(component);
    if(type=="HitBoxRecorderRoot"||type=="SingleHitBoxRecorderRoot")read_boxes(p(component+0x68));
   }
  }
  auto closest=[&](size_t index,int area){
   int match=-1;float distance=1.3f;
   for(size_t j=0;j<a.bones.size();++j){
    if(j==index||areas[j]!=area)continue;
    float current=len(sub(a.bones[index].position,a.bones[j].position));
    if(current>.025f&&current<distance){distance=current;match=int(j);}
   }
   return match;
  };
  float highest=-1e9f;
  for(size_t i=0;i<a.bones.size();++i){
   const auto& bone=a.bones[i];
   if((areas[i]==0||!area_counts[0])&&bone.position.y>highest){
    highest=bone.position.y;a.head=bone.position;a.exact_head=true;
   }
   auto parents=p(bone.data+0x20);int parent=bone.index,match=-1;
   for(unsigned depth=0;depth<64&&parent>=0&&parent<=1048576;++depth){
    if(!val(parents+uint64_t(parent)*4,parent)||parent<0)break;
    for(size_t j=0;j<a.bones.size();++j)
     if(i!=j&&a.bones[j].data==bone.data&&a.bones[j].index==parent){match=int(j);break;}
    if(match>=0)break;
   }
   // Sibling collider transforms can share a rig parent without being ancestors.
   if(match<0){
    if(areas[i]==3)match=closest(i,2);
    if(match<0&&(areas[i]==0||areas[i]==2||areas[i]==4))match=closest(i,1);
   }
   if(match>=0){
    std::pair<unsigned,unsigned> pair{std::min(unsigned(i),unsigned(match)),std::max(unsigned(i),unsigned(match))};
    if(std::find(a.edges.begin(),a.edges.end(),pair)==a.edges.end())a.edges.push_back(pair);
   }
  }
 }
 std::unordered_map<int,std::string> item_labels_;
 uint64_t item_database_=0;
 long long item_lookup_after_=0;
 std::string item_label(uint64_t data){
  if(name(data)!="ItemData")return {};
  auto phrase=p(data+0x40);
  if(name(phrase)=="Phrase"){
   auto display=str(p(phrase+0x18));
   if(!display.empty())return display;
  }
  for(unsigned offset:{0x18U,0x20U}){
   auto label=str(p(data+offset));
   if(std::any_of(label.begin(),label.end(),[](unsigned char ch){return std::isalpha(ch)||ch>=128;}))return label;
  }
  return {};
 }
 uint8_t armor_slots(uint64_t equipment){
  const auto view=p(equipment+0x90);
  const auto dictionary=p(view+0x10),entries=p(dictionary+0x18);
  if(name(dictionary)!="Dictionary`2")return 0;
  int count=0,version=0,after=0;uint64_t capacity=0;
  if(!val(dictionary+0x20,count)||count<=0||count>64||
     !val(dictionary+0x24,version)||!val(entries+0x18,capacity)||capacity<uint64_t(count))return 0;
  struct Entry{int hash,next,key,padding;uint64_t value;};
  std::array<Entry,64> records{};
  if(!read(entries+0x20,records.data(),count*sizeof(Entry)))return 0;
  auto classify=[](std::string label){
   for(char& c:label)if(c>='A'&&c<='Z')c=char(c-'A'+'a');
   if(label.find("helmet")!=std::string::npos||label.find("balaclava")!=std::string::npos)return 1;
   if(label.find("chestplate")!=std::string::npos||label.find("vest")!=std::string::npos||label.find("jacket")!=std::string::npos)return 2;
   if(label.find("pants")!=std::string::npos||label.find("leggings")!=std::string::npos||label.find("trousers")!=std::string::npos)return 4;
   if(label.find("boots")!=std::string::npos||label.find("shoes")!=std::string::npos)return 8;
   return 0;
  };
  uint8_t result=0;
  auto reader=[&](uint64_t x,void* y,size_t z){return read(x,y,z);};
  for(int i=0;i<count&&result!=15;++i){
   const auto& entry=records[i];
   const auto piece=untag(entry.value);
   if(entry.hash<0||entry.next<-1||!piece)continue;
   const auto list=p(piece+0x18),array=p(list+0x10);
   int size=0;uint64_t cap=0;
   if(name(list)!="List`1"||!val(list+0x18,size)||size<=0||size>32||!val(array+0x18,cap)||cap<uint64_t(size))continue;
   for(int j=0;j<size;++j){
    const auto go=p(array+0x20+j*8);
    if(name(go)!="GameObject")continue;
    const auto address=byte_pointer(reader,p(go+0x10)+0x60);
    if(address)result|=classify(ascii(reader,address));
   }
  }
  return val(dictionary+0x24,after)&&after==version?result:0;
 }
 uint64_t combat_queue_=0;
 uint32_t combat_version_=0;
 int combat_tail_=0;
 long long hit_at_=0;
 bool hit_kill_=false;
 void sample_combat(Frame& f,bool enabled){
  if(!enabled||!f.local){combat_queue_=0;hit_at_=0;return;}
  const auto combat=p(f.local+0x210);
  if(p(combat+0x18)!=f.local)return;
  const auto queue=p(combat+0x10),array=p(queue+0x10);
  if(name(queue)!="Queue`1")return;
  uint64_t capacity=0;
  struct QueueState{int head,tail,size;uint32_t version;} state{},check{};
  if(!val(queue+0x18,state)||!val(array+0x18,capacity)||capacity==0||capacity>4096||
     state.head<0||uint64_t(state.head)>=capacity||state.tail<0||uint64_t(state.tail)>=capacity||
     state.size<0||uint64_t(state.size)>capacity||
     (uint64_t(state.head)+state.size)%capacity!=uint64_t(state.tail))return;
  if(combat_queue_!=queue){combat_queue_=queue;combat_version_=state.version;combat_tail_=state.tail;hit_at_=0;}
  const auto changes=state.version-combat_version_;
  const auto added=uint32_t((uint64_t(state.tail)+capacity-combat_tail_)%capacity);
  if(changes&&added&&state.size){
   struct Event{double time;uint64_t attacker,target,attacker_name,target_name,weapon,ammo,bone;float distance,before,after;};
   const auto local_id=str(p(f.local+0x2e8));
   bool head=false,kill=false;
   for(uint32_t i=0;i<std::min({added,changes,uint32_t(state.size),8U});++i){
    Event event{};
    const auto index=(uint64_t(state.tail)+capacity-1-i)%capacity;
    if(!val(array+0x20+index*0x60,event)||!std::isfinite(event.time)||
       !std::isfinite(event.before)||!std::isfinite(event.after)||event.before<=event.after||
       local_id.empty()||str(untag(event.attacker))!=local_id)continue;
    const auto target_id=str(untag(event.target));
    if(target_id.empty()||target_id==local_id)continue;
    auto bone=str(untag(event.bone));
    for(char& c:bone)if(c>='A'&&c<='Z')c=char(c-'A'+'a');
    head|=bone.find("head")!=std::string::npos||bone.find("skull")!=std::string::npos;
    kill|=event.after<=0;
   }
   if(!val(queue+0x18,check)||check.version!=state.version||p(queue+0x10)!=array)return;
   if(head||kill){hit_at_=f.time;hit_kill_=kill;}
  }
  combat_version_=state.version;combat_tail_=state.tail;
  f.hit_at=hit_at_;f.hit_kill=hit_kill_;
 }
 std::string weapon_label(uint64_t object,uint64_t identity){
  auto ref=p(object+0x130);uint64_t weapon=0;
  for(unsigned off:{0x10U,0x18U,0x20U}){
   auto candidate=p(ref+off);
   if(name(candidate)=="PlayerWeapon"&&p(candidate+0x40)==identity){weapon=candidate;break;}
  }
  if(!weapon){
   uint32_t id=0;
   if(val(identity+0x58,id))for(auto candidate:components(identity,id))
    if(name(candidate)=="PlayerWeapon"&&p(candidate+0x40)==identity){weapon=candidate;break;}
  }
  if(!weapon)return {};
  uint8_t equipped=0,empty=0;int16_t number=0;
  if(val(weapon+0x150,equipped)&&equipped==1&&val(weapon+0x160,empty)&&empty==0)
   val(weapon+0x152,number);
  if(number<=0)val(weapon+0x148,number);
  auto data=p(p(weapon+0x140)+0x20);int item_id=0;
  if(val(data+0x58,item_id)&&(number<=0||item_id==number)){
   auto label=item_label(data);if(!label.empty())return label;
  }
  auto found=item_labels_.find(number);
  return found==item_labels_.end()?std::string{}:found->second;
 }
 void refresh_item_labels(){
  if(now()<item_lookup_after_)return;
  item_lookup_after_=now()+1000;
  uint64_t database=0;
  for(size_t i=0;i<profile_->mode_count;++i){
   auto statics=p(p(p(game_+profile_->mode_cells[i]))+0xb8);
   auto candidate=p(statics+profile_->item_database);
   if(name(candidate)==profile_->database_type){database=candidate;break;}
  }
  if(!database||database==item_database_)return;
  auto dictionary=p(database+0x28),entries=p(dictionary+0x18);
  int count=0,version=0;uint64_t capacity=0;
  if(!val(dictionary+0x20,count)||count<=0||count>32768||
     !val(dictionary+0x24,version)||!val(entries+0x18,capacity)||capacity<uint64_t(count))return;
  struct Entry{int hash,next,key,padding;uint64_t value;};
  std::vector<Entry> records(count);
  if(!read(entries+0x20,records.data(),records.size()*sizeof(Entry)))return;
  std::unordered_map<int,std::string> labels;
  for(auto& entry:records){
   if(entry.hash<0||entry.key<=0)continue;
   int id=0;auto data=untag(entry.value);
   if(!val(data+0x58,id)||id!=entry.key)continue;
   auto label=item_label(data);if(!label.empty())labels.emplace(id,std::move(label));
  }
  int after=0;
  if(!labels.empty()&&val(dictionary+0x24,after)&&after==version&&p(database+0x28)==dictionary){
   item_labels_=std::move(labels);item_database_=database;
  }
 }
 bool relation_id(uint64_t object,unsigned offset,std::string& out){
  uint64_t raw=0;if(!val(object+offset,raw))return false;raw=untag(raw);if(!raw){out.clear();return true;}if(!ptr(raw))return false;
  int count=0;if(!val(raw+0x10,count)||count<0||count>128)return false;
  std::array<uint16_t,128> chars{};if(count&&!read(raw+0x14,chars.data(),size_t(count)*2))return false;
  // Preserve exact UTF-16 IDs, including non-ASCII characters, without truncation.
  out.assign(reinterpret_cast<const char*>(chars.data()),size_t(count)*2);
  uint64_t after=0;return val(object+offset,after)&&untag(after)==raw;
 }
 bool relations(Actor& a){return relation_id(a.object,0x2f0,a.team_id)&&relation_id(a.object,0x300,a.clan_id);}
 bool fresh_eligible(const Actor& local,const Actor& target,const Options& o){
  if(target.kind!=0){uint32_t id=0;float hp=0;const auto entity=p(target.object+0x68),health=p(entity+0x98);return p(target.object+0x40)==target.identity&&val(target.identity+0x58,id)&&id==target.id&&val(health+0x20,hp)&&std::isfinite(hp)&&hp>0;}
  if(!o.ignore_team&&!o.ignore_clan)return true;
  Actor l=local,t=target;l.relations_valid=relations(l);t.relations_valid=relations(t);return affiliation_allows(l,t,o.ignore_team,o.ignore_clan);
 }
 bool player(uint64_t object,uint64_t identity,uint32_t id,uint64_t local,Actor& a,bool armor_icons){if(name(object)!="PlayerManager"||p(object+0x40)!=identity)return false;a.object=object;a.identity=identity;a.id=id;a.local=identity==local;a.relations_valid=relations(a);a.clan_label=str(p(object+0x300));if(!node([&](uint64_t x,void* y,size_t z){return read(x,y,z);},component_transform([&](uint64_t x,void* y,size_t z){return read(x,y,z);},object),a.root))return false;a.feet=a.root.position;
  uint64_t handler=p(object+0xb8),health=p(handler+0x98),vitals=p(object+0x108);if(!val(health+0x20,a.hp)||!val(vitals+0x88,a.max_hp)||!std::isfinite(a.hp)||!std::isfinite(a.max_hp)||a.max_hp<=0||a.max_hp>10000||a.hp<0||a.hp>a.max_hp)return false;
  uint8_t sleeping=0;auto sleep=p(handler+profile_->handler_sleep);if(sleep&&val(sleep+0x10,sleeping)&&sleeping<=1)a.sleeping=sleeping!=0;
  a.name=str(p(handler+0x88));if(a.name.empty())a.name=str(p(object+0x280));if(a.name.empty())a.name="Игрок #"+std::to_string(id);
  a.head=add(a.feet,{0,1.65f,0});a.body=add(a.feet,{0,1,0});a.look=p(object+0xb0);if(!a.local)skeleton(a,vitals);
  a.weapon=weapon_name_ru(weapon_label(object,identity));
  auto equipment=p(object+0x128);float protection=0;
  if(p(equipment+0x68)==object&&val(equipment+0x70,protection)&&std::isfinite(protection)&&protection>=0&&protection<=1){a.armor_valid=true;a.armor_protection=protection;}
  if(armor_icons&&!a.local&&p(equipment+0x68)==object)a.armor_slots=armor_slots(equipment);
  return true;
 }
 std::string gameobject_name(uint64_t object){auto r=[&](uint64_t x,void* y,size_t z){return read(x,y,z);};auto native=p(object+0x10),go=p(native+0x20);return ascii(r,byte_pointer(r,go+0x60));}
 int resource(uint64_t object,const std::string& type){if(type=="MineableTree")return Wood;for(unsigned off:{0xa0U,0xa8U}){auto list=p(object+off),array=p(list+0x10);int count=0;uint64_t cap=0;if(!val(list+0x18,count)||count<0||count>128||!val(array+0x18,cap)||cap<uint64_t(count))continue;int result=0;float best=-1;for(int i=0;i<count;++i){auto item=p(array+0x20+i*8);if(name(item)!="LootItem")continue;int kind=resource_kind(str(p(item+0x10)));float amount=0;val(item+0x1c,amount);if(!std::isfinite(amount)||amount<0)amount=0;if(kind&&amount>best){best=amount;result=kind;}}if(result)return result;}return resource_kind(gameobject_name(object));}

 bool npc_target(const WorldObject& world,Actor& a){
  if(world.kind!=Animal&&world.kind!=Bot)return false;
  a.kind=world.kind;a.object=world.object;a.identity=world.identity;a.id=world.id;a.feet=world.position;a.name=world.name;
  auto entity=p(world.object+0x68),health=p(entity+0x98);if(!val(health+0x20,a.hp)||!std::isfinite(a.hp)||a.hp<=0||a.hp>100000)return false;a.max_hp=a.hp;
  auto r=[&](uint64_t x,void* y,size_t z){return read(x,y,z);};node(r,component_transform(r,world.object),a.root);auto type=name(world.object);
  uint64_t model=type=="NPCBrainCombat"?p(world.object+0xa0):type=="NPCBrainHumanoid"?p(world.object+0x148):0;
  if(name(model)=="NPCHumanoidModelInfo"){Node h,b;if(node(r,p(p(model+0x20)+0x10),h)&&node(r,p(p(model+0x40)+0x10),b)&&len(sub(h.position,a.feet))<5&&len(sub(b.position,a.feet))<5){a.head=h.position;a.body=b.position;a.exact_head=true;a.bones.push_back(h);a.bones.push_back(b);}}
  uint64_t recorder=world.kind==Animal||type=="NPCBrainHumanoid"?p(world.object+0x90):0;
  // HitBoxRecorderRoot is a separate network component for some bot prefabs.
  if(!recorder)for(auto object:components(world.identity,world.id)){auto t=name(object);if(t=="HitBoxRecorderRoot"||t=="SingleHitBoxRecorderRoot"){recorder=object;break;}}
  auto array=p(recorder+0x68);if(!array){auto vitals=p(world.object+(type=="NPCBrainCombat"?0x1b0:0x88));if(p(vitals+0x68)==entity)array=p(vitals+0xa8);}uint64_t count=0;V center{};unsigned accepted=0;float best=-1;
  if(val(array+0x18,count)&&count<=128)for(uint64_t i=0;i<count;++i){auto box=p(array+0x20+i*8);if(name(box)!="HitBox"||p(box+0x48)!=entity)continue;Node n;if(!node(r,component_transform(r,box),n)||len(sub(n.position,a.feet))>8)continue;
   a.hit_gameobjects.push_back(p(p(box+0x10)+0x20));a.bones.push_back(n);center=add(center,n.position);++accepted;
   float damage=0;if(val(box+0x20,damage)&&std::isfinite(damage)&&damage>best){best=damage;if(world.kind==Animal||!a.exact_head)a.head=n.position;}
  }
  if(world.kind==Bot){
   // Build actual parent links, including rig joints which have no collider.
   for(size_t i=0;i<a.bones.size()&&a.bones.size()<160;++i){
    const Node bone=a.bones[i];int parent=-1;auto parents=p(bone.data+0x20);
    if(!parents||!val(parents+uint64_t(bone.index)*4,parent)||parent<0||parent==bone.index)continue;
    Node joint;if(!rig_node(r,bone.data,parent,joint)||len(sub(joint.position,a.feet))>5||len(sub(joint.position,bone.position))>1.5f)continue;
    auto it=std::find_if(a.bones.begin(),a.bones.end(),[&](const Node& n){return n.data==joint.data&&n.index==joint.index;});
    unsigned j=unsigned(it-a.bones.begin());if(it==a.bones.end()){j=unsigned(a.bones.size());a.bones.push_back(joint);}
    if(i!=j&&len(sub(joint.position,bone.position))>.01f)a.edges.emplace_back(unsigned(i),j);
   }
  }
  if(!a.exact_head&&accepted){a.body=mul(center,1.f/accepted);a.exact_head=best>0;}
  return a.exact_head&&finite(a.head)&&finite(a.body);
 }
 void movement_features(const Frame& frame,const Options& options){
  auto read_value=[&](uint64_t address,void* output,size_t bytes){return read(address,output,bytes);};
  auto write_value=[&](uint64_t address,const void* input,size_t bytes){return write(address,input,bytes);};
  movement_values_.begin();
  if(options.movement_boost&&frame.local&&!options.freecam&&profile_==&oxide_profile::current){
   const auto reference=p(frame.local+0xf0);
   for(unsigned slot:{0x10U,0x18U}){
    const auto motor=p(reference+slot);
    if(name(motor)!="KCC"||p(motor+0x78)!=frame.local)continue;
    const auto config=p(motor+0x80);
    if(name(config)!="CharacterSpeedConfig")continue;
    const float multiplier=std::clamp(options.movement_percent,100,150)*.01f;
    for(unsigned offset:{0x18U,0x1cU,0x20U}){
     float original=0;
     if(movement_values_.original(read_value,config,offset,original)&&original>.1f&&original<25.f)
      movement_values_.set(read_value,write_value,config,offset,original*multiplier);
    }
    break;
   }
  }
  movement_values_.end(read_value,write_value);
 }
 unsigned fp_offset(unsigned legacy)const{
  if(legacy>=0x120)return legacy+profile_->fp_derived_delta;
  if(legacy>=0xd8)return legacy+profile_->fp_base_delta;
  return legacy;
 }
 void weapon_features(Frame& f,const Options& o){
  auto r=[&](uint64_t a,void* b,size_t n){return read(a,b,n);};auto w=[&](uint64_t a,const void* b,size_t n){return write(a,b,n);};if(!o.no_spread&&!o.fast_switch&&!o.fast_draw&&!o.no_sway&&!o.fast_reload&&!o.rapid_fire&&!o.hand_position&&!o.no_recoil){
   weapon_values_.restore(r,w);
   return;
  }
  weapon_values_.begin();
  uint64_t local=f.local,handler=p(local+0xb8),fp=p(local+0xd0),weapon=0;
  std::string weapon_type;
  if(local&&handler&&name(fp)=="FPManager"){
   for(unsigned offset:{0x50U,0x58U}){
    auto candidate=p(fp+offset);
    auto type=name(candidate);
    if((type=="FPHitscan"||type=="FPBow"||type=="FPMelee"||type=="FPHands"||type=="FPTool"||type=="FPChainsaw"||type=="FPSpear"||type=="FPRocketLauncher")&&p(candidate+0xc0)==local&&
       (p(candidate+0xc8)==handler||p(fp+0x40)==handler)){weapon=candidate;weapon_type=type;break;}
   }
  }
  if(!weapon){f.weapon_status="Оружие: нет активного FPObject";weapon_values_.end(r,w);return;}
  f.weapon_status="Оружие: "+weapon_type;
  unsigned writes=0,failed=0;auto set=[&](uint64_t owner,unsigned offset,const auto& value){++writes;bool ok=weapon_values_.set(r,w,owner,offset,value);if(!ok)++failed;return ok;};
  auto positive=[&](uint64_t object,unsigned offset,float value){float original=0;if(weapon_values_.original(r,object,offset,original)&&std::isfinite(original)&&original>=0&&original<100000)set(object,offset,value);};
  if(o.fast_switch){
   positive(weapon,0xa0,.08f);
   positive(weapon,0xa4,.08f);
   positive(weapon,0x50,.08f);positive(weapon,0x54,.08f);
  }
  if(weapon_type=="FPBow"&&o.fast_draw){
   float speed=0;
   if(weapon_values_.original(r,weapon,fp_offset(0x144),speed)&&speed>.001f&&speed<100.f)
    positive(weapon,fp_offset(0x144),std::max(speed,std::min(100.f,speed*6.f)));
  }
  const bool hitscan=weapon_type=="FPHitscan";
  auto config=hitscan?p(weapon+fp_offset(0x130)):0;
  if(o.no_spread&&name(config)=="HitscanWeaponConfig"){
   positive(config,0x3c,0.f);
   auto dispersion=p(config+0x68);
   if(name(dispersion)=="DispersionConfig")
    for(unsigned offset:{0x18U,0x1cU,0x20U,0x24U,0x28U,0x30U,0x34U,0x38U,0x3cU})positive(dispersion,offset,0.f);
  }
  if(o.no_spread){auto dispersion_state=p(weapon+fp_offset(0x1f8));if(name(dispersion_state)==profile_->dispersion_state)positive(dispersion_state,0x20,0.f);}
  if(o.fast_reload){
   positive(weapon,fp_offset(0x104),.05f);
   // Reload() consumes the already resolved duration on an equipped weapon.
   float resolved=0;
   if(weapon_values_.original(r,weapon,fp_offset(0xe8),resolved)&&resolved>.05f&&resolved<60)
    positive(weapon,fp_offset(0xe8),.05f);
   if(name(config)=="HitscanWeaponConfig"){
    positive(config,0x48,.05f);
    positive(config,0x4c,.05f);
   }
  }
  if(hitscan&&o.rapid_fire){
   const float multiplier=std::clamp(o.fire_multiplier,2,5);
   auto shorten=[&](uint64_t owner,unsigned offset){
    float original=0;
    if(weapon_values_.original(r,owner,offset,original)&&std::isfinite(original)&&original>.02f&&original<60)
     set(owner,offset,std::max(.02f,original/multiplier));
   };
   shorten(weapon,fp_offset(0x140));
   shorten(weapon,fp_offset(0x148));
   shorten(weapon,fp_offset(0x14c));
   auto wait=p(weapon+fp_offset(0x1f0));
   if(name(wait)=="WaitForSeconds")shorten(wait,0x10);
  }
  uint64_t animator=hitscan?p(weapon+fp_offset(0x1e8)):0;
  if(!animator)for(unsigned offset=0x128;offset<0x200;offset+=8){auto candidate=p(weapon+fp_offset(offset));auto type=name(candidate);if(type.find("Animator")!=std::string::npos&&p(candidate+0x60)==weapon){animator=candidate;break;}}
  // Clip lengths describe the original animation. Keeping them intact lets the
  // animator compute a higher playback speed from the shorter action period.
  auto ik=p(animator+0x48),motion=p(ik+0x40);
  if(name(ik)=="FPHandsIK"&&name(motion)=="FPMotion"&&(p(motion+0xd0)==weapon||p(motion+0xd8)==weapon)){
   if(o.no_sway){auto disable=[&](uint64_t object,const char* type,unsigned offset){uint8_t flag=0;if(name(object)==type&&val(object+offset,flag)&&flag<=1){set(object,offset,uint8_t(0));if(std::string(type)=="Sway"){std::array<float,2> zero{};set(object,0x10,zero);set(object,0x34,zero);}else if(std::string(type)=="TrigonometricBob")set(object,0x34,V{});}};disable(p(motion+0x88),"Sway",0x18);disable(p(motion+0x90),"TrigonometricBob",0x10);auto aim=p(motion+0x38);if(name(aim)=="WeaponAimMotionProfile"){positive(aim,0x20,0.f);disable(p(aim+0x18),"Sway",0x18);disable(p(aim+0x28),"TrigonometricBob",0x10);}}
   if(o.hand_position&&finite(o.hand_offset)&&len(o.hand_offset)<2){
    std::unordered_set<uint64_t> changed;
    for(unsigned offset:{0x40U,0x48U,0x50U,0x58U,0x60U,0x68U,0x70U,0xe8U,0xf0U,0xf8U,0x100U,0x108U}){
     auto position=p(motion+offset);if(!changed.insert(position).second)continue;
     auto type=name(position);V original{};
     if((type=="TransformOffset"||type=="IKTransformOffset")&&weapon_values_.original(r,position,0x24,original)&&finite(original)&&len(original)<5)set(position,0x24,add(original,o.hand_offset));
    }
   }
  }else if(o.hand_position||o.no_sway)f.weapon_status+=" · FPMotion недоступен";
  if(hitscan&&o.no_recoil){
   auto recoil_config=p(weapon+fp_offset(0x200));if(name(recoil_config)!="RecoilConfig")recoil_config=p(config+0x70);
   if(name(recoil_config)=="RecoilConfig"){
    bool recoil_applied=true;
    for(unsigned offset:{0x18U,0x20U}){struct XY{float x,y;};XY original{};if(weapon_values_.original(r,recoil_config,offset,original)&&std::isfinite(original.x)&&std::isfinite(original.y)){original.x*=1-std::clamp(o.recoil_x,0,100)*.01f;original.y*=1-std::clamp(o.recoil_y,0,100)*.01f;recoil_applied=set(recoil_config,offset,original)&&recoil_applied;}else recoil_applied=false;}
    for(unsigned offset:{0x28U,0x2cU}){float original=0;if(weapon_values_.original(r,recoil_config,offset,original)&&std::isfinite(original))set(recoil_config,offset,original*(1-std::clamp(o.recoil_x,0,100)*.01f));}
    f.recoil_source_active=recoil_applied;
   }else f.weapon_status+=" · RecoilConfig недоступен";
  }
  if(failed)f.weapon_status+=" · запись отклонена: "+std::to_string(failed)+"/"+std::to_string(writes);
  else if(writes)f.weapon_status+=" · параметры применены: "+std::to_string(writes);
  weapon_values_.end(r,w);
 }
 void trigger_target(Frame& f,const Options& shared){
  auto o=shared;o.distance=o.trigger_distance;o.ignore_team=o.trigger_ignore_team;o.ignore_clan=o.trigger_ignore_clan;o.aim_animals=o.trigger_animals;o.aim_bots=o.trigger_bots;
  if(!o.trigger||o.paused||o.freecam||!f.input_unlocked)return;
  uint64_t handler=p(f.local+0xb8),signal=p(handler+0x160),data=p(signal+0x20);if(!data)data=p(p(handler+0x168)+0x20);uint8_t hit=0;
  auto ray_type=name(data);if(ray_type!=profile_->ray_type||!val(data+0x10,hit)||hit!=1)return;
  if(ray_record_!=data){ray_record_=data;ray_seen_=now();}if(now()-ray_seen_>100)return;
  auto weapon=p(p(f.local+0xd0)+0x50);if(name(weapon)!="FPHitscan"||p(weapon+0xc0)!=f.local)return;
  uint8_t ads=0;f.trigger_ads_active=val(p(handler+profile_->handler_aim)+0x10,ads)&&ads==1;if(o.trigger_ads&&!f.trigger_ads_active)return;
  auto player=p(data+0x40),go=p(p(data+0x18)+0x10);
  auto match=[&](const Actor& a){if(!a.object||a.local||a.sleeping||a.hp<=0||len(sub(a.feet,origin(f.view)))>o.distance)return false;return player==a.object||std::find(a.hit_gameobjects.begin(),a.hit_gameobjects.end(),go)!=a.hit_gameobjects.end();};
  const Actor* local_actor=nullptr;for(const auto& a:f.players)if(a.local)local_actor=&a;
  for(const auto& a:f.players)if(local_actor&&affiliation_allows(*local_actor,a,o.ignore_team,o.ignore_clan)&&fresh_eligible(*local_actor,a,o)&&match(a)){f.trigger_target=a.object;return;}
  for(const auto& a:f.npc_targets)if((a.kind==Animal?o.aim_animals:o.aim_bots)&&match(a)){f.trigger_target=a.object;return;}
 }
 void hotspot(WorldObject& world){world.hit_valid=false;world.hit_checked=true;auto extensions=p(world.object+0xe8);uint64_t count=0,array=extensions;auto items=p(extensions+0x10);int size=0;uint64_t capacity=0;
  if(items&&val(extensions+0x18,size)&&size>=0&&size<=128&&val(items+0x18,capacity)&&capacity>=uint64_t(size)&&capacity<=1024){array=items;count=uint64_t(size);}else if(!val(array+0x18,count)||count>128)return;
  auto r=[&](uint64_t x,void* y,size_t z){return read(x,y,z);};
  for(uint64_t i=0;i<count;++i){auto extension=p(array+0x20+i*8);auto type=name(extension);uint64_t marker=0;bool tree=false;if(type=="MineableObjectExtension_OreHitstreaks"&&p(extension+0x40)==world.object){marker=p(extension+0x30);if(name(marker)!="MineableObjectExtension_OreHitstreaksMarker"||p(marker+0x38)!=extension)continue;}else if(type=="MineableObjectExtension_TreeHitstreaks"){tree=true;marker=p(extension+0x50);if(name(marker)!="MineableObjectExtension_HitMarkerItem")continue;}else continue;
   auto native=p(marker+0x10),go=p(native+0x20);uint8_t active=0;if(!val(go+0x47,active)||active!=1)continue;V point{};bool valid=false;if(tree){auto transform=p(marker+0x38);Node n;if(transform&&node(r,p(transform+0x10),n)){point=n.position;valid=true;}}if(!valid)valid=position(marker,point);if(valid&&finite(point)&&len(sub(point,world.position))<8){world.hit_position=point;world.hit_valid=true;return;}}
 }

 void fov(Frame& f,const Options& o){if(!o.custom_fov||!f.camera||!f.local){restore_fov();return;}auto manager=p(f.local+0xd0);if(name(manager)!="FPManager"||p(p(manager+0x20)+0x10)!=f.camera_native)return;
  if(fov_backup_.manager&&(fov_backup_.manager!=manager||fov_backup_.camera!=f.camera_native)&&!restore_fov())return;
  float fields[2]{},modifier=0;int id=0;if(!val(manager+0xac,fields)||!val(manager+0xc4,modifier)||!val(f.camera_native+8,id)||!std::isfinite(modifier)||std::fabs(modifier)>90)return;for(float value:fields)if(!std::isfinite(value)||value<1||value>179)return;
  if(!fov_backup_.manager){fov_backup_.manager=manager;fov_backup_.camera=f.camera_native;fov_backup_.camera_id=id;memcpy(fov_backup_.original,fields,8);memcpy(fov_backup_.applied,fields,8);}if(id!=fov_backup_.camera_id){fov_backup_={};return;}
  float requested=std::clamp(o.camera_fov,50.f,130.f)+modifier;requested=std::clamp(requested,1.f,179.f);for(unsigned i=0;i<2;++i){if(fields[i]!=fov_backup_.applied[i])fov_backup_.original[i]=fields[i];if(write(manager+0xac+i*4,&requested,4))fov_backup_.applied[i]=requested;}
 }
 void third_person(Frame& f,const Options& o){if(!o.thirdperson||o.freecam||!f.local){restore_third();return;}auto controller=p(f.local+0xa0);uint64_t modes=game_modes();auto type=name(controller);if(type!=profile_->camera_type||p(controller+0x30)!=f.local||name(modes)!="GameModes"){f.camera_status="Контроллер камеры недоступен";return;}
  if(third_backup_.mode&&(third_backup_.mode!=modes||third_backup_.player!=f.local)&&!restore_third())return;uint8_t mode=0;if(!val(modes+profile_->third_mode,mode)||mode>2)return;if(!third_backup_.mode)third_backup_={modes,controller,f.local,mode};uint8_t forced=2;if(mode!=2&&!write(modes+profile_->third_mode,&forced,1)){f.camera_status="Переключение камеры отклонено";return;}bool positioned=orbit(controller,o);f.third_person=true;f.camera_status=positioned?"Третье лицо":"Третье лицо: настройки позиции не применены";
 }
 void flight(Frame& f,const Options& o){if(now()<f.time||now()-f.time>120){f.camera_status="Кадр устарел";return;}if(!o.freecam||!o.captured||!f.local){if(!restore())f.camera_status="Не удалось восстановить камеру";return;}
  if(backup_.camera&&(backup_.camera!=f.camera_native||backup_.mode!=(o.freecam?1:2))&&!restore()){f.camera_status="Ошибка восстановления камеры";return;}
  if(!backup_.camera){uint8_t flag=0;int id=0;if(!val(f.camera_native+0x502,flag)||flag!=1||!val(f.camera_native+8,id)){f.camera_status="Камера занята";return;}backup_.mode=o.freecam?1:2;backup_.camera=f.camera_native;backup_.id=id;backup_.original=backup_.applied=f.view;backup_.flag=flag;backup_.position=origin(f.view);V forward{-f.view.v[2],-f.view.v[6],-f.view.v[10]};backup_.yaw=atan2f(forward.x,forward.z);backup_.pitch=-asinf(std::clamp(forward.y,-1.f,1.f));backup_.lx=o.look_x;backup_.ly=o.look_y;backup_.time=now();}
  int current_id=0;uint8_t current_flag=0;if(!val(backup_.camera+8,current_id)||current_id!=backup_.id){backup_={};f.camera_status="Камера изменилась";return;}
  if(!val(backup_.camera+0x502,current_flag)){f.camera_status="Камера недоступна";return;}if(current_flag==1)backup_.original=f.view;
  if(backup_.capture_generation!=o.capture_generation){backup_.capture_generation=o.capture_generation;backup_.lx=o.look_x;backup_.ly=o.look_y;backup_.time=now();}
  float dt=std::clamp((now()-backup_.time)*.001f,0.f,.05f);backup_.time=now();if(o.freecam&&!o.paused){backup_.yaw+=(o.look_x-backup_.lx)*o.sensitivity;backup_.pitch=std::clamp(backup_.pitch+(o.look_y-backup_.ly)*o.sensitivity,-1.5f,1.5f);V forward{std::sin(backup_.yaw)*std::cos(backup_.pitch),-std::sin(backup_.pitch),std::cos(backup_.yaw)*std::cos(backup_.pitch)},right{std::cos(backup_.yaw),0,-std::sin(backup_.yaw)};V d=add(mul(forward,o.y),mul(right,o.x));d.y+=o.up;float l=len(d);if(l>1)d=mul(d,1/l);backup_.position=add(backup_.position,mul(d,std::clamp(o.speed,1.f,20.f)*dt));}backup_.lx=o.look_x;backup_.ly=o.look_y;

  M next=camera_view(backup_.position,backup_.yaw,backup_.pitch);uint8_t zero=0;
  // Record the matrix immediately after its successful write, so a flag-write error can be restored.
  if(!write(f.camera_native+0x70,&next,sizeof(M))){f.camera_status="Запись камеры отклонена";return;}backup_.applied=next;
  if(!write(f.camera_native+0x502,&zero,1)){restore();f.camera_status="Фрикам не включён";return;}f.view=next;f.freecam=o.freecam;f.camera_status=o.freecam?"Свободная камера":"Камера от третьего лица";
 }
 void recoil(Frame& f,const Options& o){
  if(!(o.no_recoil||(o.aim_recoil&&o.aim&&f.aim_point_valid))||o.paused||o.freecam||now()<f.time||now()-f.time>120)return;
  for(const auto& a:f.players)if(a.local&&a.hp>0){auto handler=p(a.object+0xb8);auto recoil=p(handler+0x138);struct Vector2{float x,y;};Vector2 value{},zero{};
   if(!a.look||p(a.look+0x20)!=handler||!recoil||!val(recoil+0x20,value)||!std::isfinite(value.x)||!std::isfinite(value.y)||std::fabs(value.x)>90||std::fabs(value.y)>90){f.recoil_status="Отдача: привязка недоступна";return;}
   if((value.x==0||o.recoil_x==0)&&(value.y==0||o.recoil_y==0)){f.recoil_status="Отдача: ожидание выстрела";return;}
   if(p(a.object+0x40)!=a.identity||p(handler+0x138)!=recoil)return;
   zero={value.x*(f.recoil_source_active?(o.recoil_x>=100?0.f:1.f):1-std::clamp(o.recoil_x,0,100)*.01f),value.y*(f.recoil_source_active?(o.recoil_y>=100?0.f:1.f):1-std::clamp(o.recoil_y,0,100)*.01f)};
   f.recoil_status=write(recoil+0x20,&zero,sizeof(zero))?"Накопленная отдача подавлена":"Запись отдачи отклонена";return;
  }
 }
 bool activation(const Actor& local,const Options& o){
  auto handler=p(local.object+0xb8);uint8_t ads=0;auto ads_signal=p(handler+profile_->handler_aim);bool ads_known=ads_signal&&val(ads_signal+0x10,ads)&&ads<=1;
  uint64_t weapon=0,counter=0;int shots=-1;if(o.activation==2){auto fp=p(local.object+0xd0);weapon=p(fp+0x50);
   if(weapon&&name(weapon)=="FPHitscan"&&p(weapon+0xc0)==local.object&&p(weapon+0xc8)==handler){counter=p(weapon+fp_offset(0x238));if(!val(counter+0x14,shots))shots=-1;}
  }
  return activation_.accept(o.activation,ads_known,ads==1,weapon,counter,shots,now());
 }
 long long spin_time_=0;
 uint64_t spin_player_=0;
 float spin_angle_=0;
 void avatar_heading(Frame& f,const Options& o){
  const long long previous=std::exchange(spin_time_,0);
  if(!o.spin||spin_player_!=f.local)spin_angle_=0;
  spin_player_=f.local;
  if((!o.spin&&!o.custom_model)||o.freecam)return;
  const Actor* local=nullptr;
  for(const auto& actor:f.players)if(actor.local&&actor.object==f.local&&actor.hp>0){local=&actor;break;}
  if(!local||!local->look||name(local->look)!="MouseLook")return;
  float yaw=0;
  if(!val(local->look+0x50,yaw)||!std::isfinite(yaw))return;
  f.model_yaw=yaw;
  f.model_heading_valid=true;
  f.model_spin=spin_angle_;
  const auto time=now();
  if(!o.spin||o.paused||!f.input_unlocked||time<f.time||time-f.time>120)return;
  spin_time_=time;
  if(!previous||time<=previous||time-previous>120)return;
  const float step=std::clamp(o.spin_speed,30,720)*std::min(time-previous,50LL)*.001f;
  if(o.custom_model){
   spin_angle_=std::remainder(spin_angle_+step,360.f);
   f.model_spin=spin_angle_;
   return;
  }

 }
 std::vector<ShotSegment> shot_segments_;
 long long last_aim_trace_=0;uint64_t last_trace_identity_=0;
 uint64_t trace_weapon_=0,trace_counter_=0,trace_local_=0;int trace_count_=-1;float trace_stamp_=-1;V trace_direction_{};long long trace_direction_time_=0;
 void sample_tracers(Frame& f,const Options& o){
  if(!o.shot_tracers||!f.local||!f.camera){shot_segments_.clear();trace_weapon_=trace_counter_=trace_local_=0;trace_count_=-1;return;}
  shot_segments_.erase(std::remove_if(shot_segments_.begin(),shot_segments_.end(),[&](const auto& line){return f.time<line.time||f.time-line.time>=o.tracer_lifetime;}),shot_segments_.end());
  const auto weapon=p(p(f.local+0xd0)+0x50),counter=p(weapon+fp_offset(0x238));int count=-1;float stamp=-1;
  if(name(weapon)!="FPHitscan"||p(weapon+0xc0)!=f.local||!counter||!val(counter+0x14,count)||!val(counter+0x18,stamp)||!std::isfinite(stamp)||count<0){trace_count_=-1;f.shot_segments=shot_segments_;return;}
  const bool changed=trace_weapon_!=weapon||trace_counter_!=counter||trace_local_!=f.local;
  const int previous=trace_count_;const float previous_stamp=trace_stamp_;trace_stamp_=stamp;trace_weapon_=weapon;trace_counter_=counter;trace_local_=f.local;trace_count_=count;
  if(!changed&&previous>=0&&(count>previous||(count>0&&stamp>=0&&stamp!=previous_stamp))){
   V forward{-f.view.v[2],-f.view.v[6],-f.view.v[10]};
   if(o.silent_aim&&f.time>=trace_direction_time_&&f.time-trace_direction_time_<120&&len(trace_direction_)>.9f)forward=trace_direction_;
   const V right{f.view.v[0],f.view.v[4],f.view.v[8]},up{f.view.v[1],f.view.v[5],f.view.v[9]},eye=origin(f.view);
   const auto start=add(add(eye,mul(forward,.45f)),add(mul(right,.18f),mul(up,-.12f)));
   V end=add(eye,mul(forward,std::clamp(o.tracer_length,10.f,500.f)));
   const auto handler=p(f.local+0xb8);const auto data=p(p(handler+0x160)+0x20);uint8_t hit=0;V point{};
   if(name(data)==profile_->ray_type&&val(data+0x10,hit)&&hit==1&&val(data+0x48,point)&&finite(point)&&len(sub(point,eye))>.5f&&len(sub(point,eye))<500)end=point;
   if(finite(start)&&finite(end)){while(shot_segments_.size()>=32)shot_segments_.erase(shot_segments_.begin());shot_segments_.push_back({start,end,f.time});}
  }
  f.shot_segments=shot_segments_;
 }
 void trace_aim(Frame& f,const Options&,const Actor&){
  if(!f.aim_point_valid)return;const auto delta=sub(f.aim_point,origin(f.view));const auto distance=len(delta);if(!finite(delta)||distance<.01f)return;
  trace_direction_=mul(delta,1.f/distance);trace_direction_time_=f.time;
 }
 struct AimSample{V position{},velocity{};long long time=0;uint32_t id=0;};
 std::unordered_map<uint64_t,AimSample> aim_samples_;
 uint64_t search_identity_=0,owner_scan_complete_=0;
 uint32_t search_id_=0;
 void update_lead(Frame& f,int lead_ms){
  if(lead_ms<=0){aim_samples_.clear();return;}
  if(aim_samples_.size()>2048)aim_samples_.clear();
  auto sample=[&](Actor& actor){
   if(actor.local||actor.hp<=0||!actor.identity||!finite(actor.feet))return;
   auto& old=aim_samples_[actor.identity];
   const auto dt=f.time-old.time;
   if(old.id!=actor.id||!old.time||dt<0||dt>200){
    old={actor.feet,{},f.time,actor.id};
    return;
   }
   if(dt>=50){
    const auto velocity=mul(sub(actor.feet,old.position),1000.f/float(dt));
    const bool valid=finite(velocity)&&len(velocity)<=14.f;V filtered=valid?add(mul(old.velocity,.35f),mul(velocity,.65f)):V{};if(len(velocity)<.15f)filtered={};old={actor.feet,filtered,f.time,actor.id};
   }
   actor.lead_velocity=old.velocity;
  };
  for(auto& actor:f.players)sample(actor);
  for(auto& actor:f.npc_targets)sample(actor);
 }
 float projectile_speed(uint64_t player){
  const auto weapon=p(p(player+0xd0)+0x50);float speed=0;
  if(name(weapon)=="FPHitscan"&&p(weapon+0xc0)==player){auto config=p(weapon+fp_offset(0x130));if(name(config)=="HitscanWeaponConfig"&&val(config+0x30,speed)&&std::isfinite(speed)&&speed>=10&&speed<=5000)return speed;}
  return 0; // Unknown weapon: latency-only prediction, never invent a ballistic speed.
 }
 bool look_unlocked(uint64_t look){
  auto locks=p(look+profile_->look_locks_offset);int count=-1;
  return name(locks)=="HashSet`1"&&val(locks+0x20,count)&&count==0;
 }
 void aim(Frame& f,const Options& shared){auto o=shared;const bool trigger_snap=o.trigger&&!o.aim;if(trigger_snap){o.aim=f.trigger_target!=0;o.activation=1;o.smooth=1;o.distance=o.trigger_distance;o.ignore_team=o.trigger_ignore_team;o.ignore_clan=o.trigger_ignore_clan;o.aim_bots=o.trigger_bots;o.aim_animals=o.trigger_animals;o.require_visibility=false;}bool keep_shot=false;bool keep_silent=false;struct Exit{std::function<void()> fn;~Exit(){fn();}} exit{[&]{if(!keep_silent)release_silent();if(!keep_shot)shot_redirect_.disable([&](uint64_t a,const void* b,size_t n){return write(a,b,n);});}};if(!o.aim||(o.spin&&!o.custom_model)||o.paused||o.freecam||now()<f.time||now()-f.time>120){aim_look_=0;activation_.reset();sticky_id_=0;sticky_identity_=0;return;}const Actor* local=nullptr;for(auto& a:f.players)if(a.local&&a.hp>0)local=&a;if(!local||!local->look||name(local->look)!="MouseLook"){activation_.reset();return;}
  auto sr=[&](uint64_t a,void* b,size_t n){return read(a,b,n);};
  auto sw=[&](uint64_t a,const void* b,size_t n){return write(a,b,n);};
  if(silent_.active()&&!silent_.matches(f.camera_native,local->look)){if(!release_silent()){f.aim_status="Silent: смена камеры ожидает восстановления";return;}}
  if(silent_.active()){
   if(!o.silent_aim||!silent_.update(sr,sw,local->feet,f.view)){release_silent();if(o.silent_aim){f.aim_status="Silent: камера недоступна";return;}}
  }
  keep_silent=o.silent_aim&&silent_.active();
  float melee_reach=0;
  const auto held=p(p(local->object+0xd0)+0x50);
  if(o.aim_melee&&name(held)=="FPMelee"){
   if(profile_!=&oxide_profile::beta||o.activation!=1||
      p(held+0xc0)!=local->object||p(held+0xc8)!=p(local->object+0xb8)||
      !val(held+profile_->melee_reach_offset,melee_reach)||!std::isfinite(melee_reach)||melee_reach<.2f||melee_reach>8.f)return;
  }
  auto activation_options=o;
  if(o.aim_360)activation_options.activation=2;
  if(!activation(*local,activation_options)){aim_look_=0;sticky_id_=0;sticky_identity_=0;f.aim_status=o.activation==0?"Ожидание прицеливания":o.activation==2?"Ожидание выстрела":"Некорректный режим активации";return;}
  // Pitch/yaw field is pinned by each profile's direct Vector2 setter guard.
  struct Angles{float pitch,yaw;};Angles current{};if(!val(local->look+0x4c,current)||!std::isfinite(current.pitch)||!std::isfinite(current.yaw)||fabsf(current.pitch)>180)return;
  if(!look_unlocked(local->look)){f.aim_status="Наведение приостановлено интерфейсом игры";return;}
  const auto visibility_clock=now();
  const Actor* selected=nullptr;V from=origin(f.view),target{};float best=1e30f;bool found=false;std::vector<const Actor*> candidates;for(const auto& a:f.players)candidates.push_back(&a);for(const auto& a:f.npc_targets)if(a.kind==Animal?(o.aim_animals&&!o.aim_360):o.aim_bots)candidates.push_back(&a);for(auto candidate:candidates){const auto& a=*candidate;if(trigger_snap&&a.object!=f.trigger_target)continue;if(o.require_visibility&&!visibly_open(a,visibility_clock))continue;if(a.local||a.hp<=0||(o.aim_360&&a.sleeping)||!affiliation_allows(*local,a,o.ignore_team,o.ignore_clan))continue;V point=o.bone?a.body:a.head;if(!o.bone&&!a.exact_head)continue;if(o.lead_ms>0)point=intercept_point(from,point,a.lead_velocity,projectile_speed(local->object),std::max(0,o.lead_ms-1)*.001f);V delta=sub(point,from);float d=len(delta);if(d<.2f||d>(melee_reach>0?std::min(o.distance,melee_reach):o.distance))continue;V v=view_point(f.view,point);if(!o.aim_360&&v.z>=-.02f)continue;float screen_error=0;if(!o.aim_360&&!aim_fov(f.projection,v,o.fov,screen_error))continue;float score=(o.sticky_aim||o.aim_360)&&a.id==sticky_id_&&a.identity==sticky_identity_?-1.f:o.aim_360?d:o.mode==1?a.hp:o.mode==2?d:screen_error;if(score<best){best=score;target=delta;selected=&a;found=true;}}
  if(!found){sticky_id_=0;sticky_identity_=0;f.aim_status=o.require_visibility?"Нет цели с подтверждённой видимостью":"Цель в FOV не найдена";return;}f.aim_point_valid=true;f.aim_point=add(from,target);sticky_id_=selected->id;sticky_identity_=selected->identity;V fw{-f.view.v[2],-f.view.v[6],-f.view.v[10]};if(!o.silent_aim&&aim_look_==local->look&&current.pitch==aim_written_[0]&&current.yaw==aim_written_[1]&&len(sub(fw,aim_camera_))<.0001f){f.aim_status=now()-aim_sent_>250?"Камера не подтвердила наведение":"Ожидание отклика камеры";return;}float desired_yaw=atan2f(target.x,target.z)*57.2957795f,desired_pitch=-atan2f(target.y,std::sqrt(target.x*target.x+target.z*target.z))*57.2957795f;
  float camera_yaw=atan2f(fw.x,fw.z)*57.2957795f,camera_pitch=-asinf(std::clamp(fw.y,-1.f,1.f))*57.2957795f;
  float t=o.aim_360?1.f:1.f/std::clamp(o.smooth,1.f,20.f);Angles next{std::clamp(current.pitch+angle_delta(desired_pitch,camera_pitch)*t,-89.f,89.f),std::remainder(current.yaw+angle_delta(desired_yaw,camera_yaw)*t,360.f)};
  uint32_t id=0;if(p(local->object+0x40)!=local->identity||p(local->object+0xb0)!=local->look||!val(local->identity+0x58,id)||id!=local->id||p(p(p(p(game_+profile_->network_client_cell))+0xb8)+0x48)!=local->identity)return;
  if(now()-f.time>120||!activation(*local,activation_options)||!selected||!fresh_eligible(*local,*selected,o))return;
  if(o.require_visibility&&!visibility_.confirm(
      [&](uint64_t address,void* bytes,size_t size){return read(address,bytes,size);},
      [&](uint64_t address){return name(address);},*selected,p(p(f.local+0xd0)+0x20),now()))return;
  if(o.silent_aim&&!direct_){
   // Root silent never reaches the MouseLook write below. Only the shot's
   // local Ray copy is redirected, on the game thread that handles the shot.
   if(o.aim_360||o.touch_aim||o.aim_melee){f.aim_status="Silent: несовместимый режим";return;}
   if(name(held)!="FPHitscan"||p(held+0xc0)!=local->object){f.aim_status="Silent: оружие не поддерживается";return;}
   keep_shot=shot_redirect_.arm(sr,sw,pid_,game_,profile_==&oxide_profile::beta,held,f.aim_point,now());
   f.aim_status=shot_redirect_.status();
   if(keep_shot){trace_direction_=mul(target,1.f/len(target));trace_direction_time_=now();trace_aim(f,o,*selected);}
   return;
  }
  if(o.silent_aim){
   if(o.aim_360||o.touch_aim||o.thirdperson||o.aim_melee){f.aim_status="Silent: несовместимый режим";return;}
   if(!silent_.capture(sr,sw,f.camera_native,local->look,f.view,local->feet)||!silent_.update(sr,sw,local->feet,f.view)){f.aim_status="Silent: захват камеры отклонён";return;}
   silent_.angles(desired_pitch,desired_yaw,next.pitch,next.yaw);
  }
  if(o.touch_aim){
   f.aim_swipe_x=angle_delta(desired_yaw,camera_yaw)*t;
   f.aim_swipe_y=angle_delta(desired_pitch,camera_pitch)*t;
   f.aim_swipe_valid=std::isfinite(f.aim_swipe_x)&&std::isfinite(f.aim_swipe_y)&&
    (std::abs(f.aim_swipe_x)>.2f||std::abs(f.aim_swipe_y)>.2f);
   if(f.aim_swipe_valid)trace_aim(f,o,*selected);
   return;
  }
  if(write(local->look+0x4c,&next,sizeof(next))){if(o.silent_aim){silent_.applied(next.pitch,next.yaw);if(!silent_.update(sr,sw,local->feet,f.view)){release_silent();f.aim_status="Silent: визуальная камера не закреплена";return;}keep_silent=true;}aim_look_=local->look;aim_written_[0]=next.pitch;aim_written_[1]=next.yaw;aim_camera_=fw;aim_sent_=now();f.aim_status=o.silent_aim?"Silent: тест разделения камеры":"Наведение активно";trace_aim(f,o,*selected);}else f.aim_status="Запись наведения отклонена";
 }
 void tick(const Options& o){if(!o.silent_aim||!o.aim||o.paused||o.freecam)shot_redirect_.disable([&](uint64_t a,const void* b,size_t n){return write(a,b,n);});if(!o.silent_aim||!o.aim||o.paused||o.freecam||o.thirdperson)release_silent();if(!o.freecam)restore();if(!o.thirdperson||o.freecam)restore_third();if(!o.custom_fov)restore_fov();Frame f;f.time=now();if(!attach()){f.status=direct_&&!direct_status_.empty()?direct_status_:"Ожидание Oxide / проверка версии библиотек";publish(std::move(f));return;}f.pid=pid_;f.vegetation_ready=vegetation(o.no_vegetation)&&o.no_vegetation;frame_limit(f,o);bool collect_ok=true;for(size_t i=0;i<profile_->patch_count;++i){auto& patch=profile_->patches[i];if(!collect_patches_[i].update([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);},game_,o.quickloot,patch.expected,patch.address))collect_ok=false;}if(o.quickloot&&!collect_ok&&now()>=collect_error_){collect_error_=now()+2000;fprintf(stderr,"OXIDE_LOOT CollectAll delay patch unavailable\n");}uint64_t local=0;if(!registry(local)){shot_redirect_.disable([&](uint64_t a,const void* b,size_t n){return write(a,b,n);});release_silent();shot_segments_.clear();last_aim_trace_=0;last_trace_identity_=0;movement_features(f,o);if(!o.sky_tint)restore_sky();weapon_values_.restore([&](uint64_t a,void* b,size_t n){return read(a,b,n);},[&](uint64_t a,const void* b,size_t n){return write(a,b,n);});scan_=0;f.status=registry_status_.empty()?"Ожидание сетевой сцены":registry_status_;publish(std::move(f));return;}
  daylight(o.always_day,o.day_hour);f.day_status=day_status_;
  f.membership_valid=true;f.membership.reserve(identities_.size());for(auto entry:identities_)f.membership.push_back(entry.first);
  if((build_.active&&build_.local!=local)||(!build_.active&&scene_local_!=local)){build_={};world_metadata_.clear();player_refs_.clear();containers_.clear();world_.clear();}
  const auto owner_identity=profile_==&oxide_profile::beta?o.search_owner_identity:0;
  if(search_identity_!=owner_identity||search_id_!=o.search_owner_id){
   search_identity_=owner_identity;search_id_=o.search_owner_id;owner_scan_complete_=0;
   build_={};scene_scan_=0;
  }
  std::string wanted_owner;
  if(owner_identity){
   for(const auto& ref:player_refs_)if(ref.identity==owner_identity&&ref.id==o.search_owner_id){
    uint32_t id=0;
    if(val(ref.identity+0x58,id)&&id==ref.id&&p(ref.object+0x40)==ref.identity)
     wanted_owner=str(p(ref.object+0x2e8));
    break;
   }
  }
  V build_origin{};
  bool collect_build_hp=false;
  if(o.building_hp&&profile_==&oxide_profile::beta){
   for(const auto& ref:player_refs_)if(ref.identity==local){
    collect_build_hp=p(ref.object+0x40)==local&&position(ref.object,build_origin);
    break;
   }
  }
  if(!build_.active&&(now()>=scene_scan_||scene_local_!=local)){build_={};build_.active=true;build_.local=local;build_.identities=identities_;}
  if(build_.active){
   auto& players=build_.players;auto& containers=build_.containers;auto& world=build_.world;long long budget=now()+6;unsigned processed=0;
   while(build_.cursor<build_.identities.size()&&processed++<128){auto [id,identity]=build_.identities[build_.cursor++];auto list=components(identity,id);uint64_t building=0,loot=0,cupboard=0;std::string piece;
    for(auto object:list){if(p(object+0x40)!=identity)continue;auto type=name(object);if(type=="PlayerManager"){if(players.size()<512){players.push_back({object,identity,id});bool known=false;for(const auto& ref:player_refs_)if(ref.object==object&&ref.id==id){known=true;break;}if(!known&&player_refs_.size()<512)player_refs_.push_back({object,identity,id});}}
     else if(type=="MineableObject"||type=="MineableStone"||type=="MineableCompositeStone"||type=="MineableTree"){auto known=world_metadata_.find(object);int kind=known!=world_metadata_.end()&&known->second.id==id?known->second.kind:resource(object,type);V position_;float hp=0;if(!kind&&o.debug&&unknown_prefabs_.size()<128&&unknown_prefabs_.insert(type+":"+gameobject_name(object)).second)fprintf(stderr,"OXIDE_UNKNOWN_RESOURCE id=%u type=%s prefab=%s\n",id,type.c_str(),gameobject_name(object).c_str());if(kind&&val(object+0x78,hp)&&std::isfinite(hp)&&hp>0&&position(object,position_)&&world.size()<8192){WorldObject record{object,identity,id,position_,kind,world_label(kind)};if(known!=world_metadata_.end()||world_metadata_.size()<16384)world_metadata_[object]=record;world.push_back(std::move(record));}}
     else if(int kind=entity_kind(type)){V position_;if(position(object,position_)&&world.size()<8192){std::string display;if(kind==Animal||kind==Bot){auto entity=p(object+0x68);display=str(p(entity+0x88));}if(kind==Animal)display=animal_label(gameobject_name(object)+" "+display);else if(display.empty())display=world_label(kind);world.push_back({object,identity,id,position_,kind,display});}}
     else if(type=="BuildingPiece"){building=object;piece=str(p(object+0x80));}else if(type=="LootObject")loot=object;else if(type=="Cupboard")cupboard=object;
    }
    if(cupboard||loot){if(!building)building=p((cupboard?cupboard:loot)+(cupboard?0xc8:0xf8));if(piece.empty()&&building)piece=str(p(building+0x80));int kind=cupboard?3:0;if(loot){auto prefab=gameobject_name(loot);kind=container_kind(prefab);if(kind==4)piece=prefab;}if(!kind)kind=container_kind(piece);if(!kind&&o.debug&&unknown_prefabs_.size()<64&&unknown_prefabs_.insert(piece).second)fprintf(stderr,"OXIDE_UNKNOWN_CONTAINER id=%u prefab=%s\n",id,piece.c_str());if(kind){V pos;if(position(cupboard?cupboard:loot,pos)&&containers.size()<4096){Container c{id,pos,kind,piece};if(building&&name(building)=="BuildingPiece")c.bounds_valid=container_corners([&](uint64_t a,void* b,size_t n){return read(a,b,n);},building,c.corners);containers.push_back(std::move(c));}}}
    if(!wanted_owner.empty()&&building&&name(building)=="BuildingPiece"&&str(p(building+0x3a0))==wanted_owner&&containers.size()<4096){
     if(!containers.empty()&&containers.back().id==id){
      containers.back().matched_owner=owner_identity;
      containers.back().matched_owner_id=o.search_owner_id;
     }else{
      V pos{};
      if(position(building,pos)){
       Container marker{id,pos,cupboard?7:6,piece};
       marker.matched_owner=owner_identity;marker.matched_owner_id=o.search_owner_id;
       containers.push_back(std::move(marker));
      }
     }
    }
    if(collect_build_hp&&building&&name(building)=="BuildingPiece"&&p(building+0x40)==identity&&containers.size()<4096){
     V pos{};
     if(position(building,pos)&&len(sub(pos,build_origin))<=60.f){
      if(containers.empty()||containers.back().id!=id)containers.push_back(Container{id,pos,8,piece});
      auto& entry=containers.back();
      entry.building=building;entry.building_identity=identity;
     }
    }
    if(now()>=budget)break;
   }
   if(build_.cursor==build_.identities.size()){world_=std::move(world);player_refs_=std::move(players);containers_=std::move(containers);scene_scan_=now()+400;scene_local_=local;owner_scan_complete_=wanted_owner.empty()?0:owner_identity;build_={};}
  }
  for(auto world:world_){if(world.kind>=Animal){uint32_t id=0;if(!val(world.identity+0x58,id)||id!=world.id||p(world.object+0x40)!=world.identity||!position(world.object,world.position))continue;if(world.kind==Animal||world.kind==Bot){auto entity=p(world.object+0x68);auto health=p(entity+0x98);float hp=0;if(health&&val(health+0x20,hp)&&std::isfinite(hp)&&hp<=0)continue;}}if(world.object==o.farm_target)hotspot(world);f.world.push_back(std::move(world));}

  refresh_item_labels();
  f.containers=containers_;f.owner_scan_complete=owner_scan_complete_;
  if(o.building_hp)for(auto& c:f.containers){
   if(!c.building||p(c.building+0x40)!=c.building_identity)continue;
   uint32_t id=0;
   float hp=0,max_hp=0;
   if(val(c.building_identity+0x58,id)&&id==c.id&&val(c.building+0x390,hp)&&val(c.building+0x394,max_hp)&&
      std::isfinite(hp)&&std::isfinite(max_hp)&&hp>0&&hp<=max_hp&&max_hp<=1000000){
    c.hp=hp;c.max_hp=max_hp;
   }
  }
  for(auto ref:player_refs_){Actor a;uint32_t id=0;if(val(ref.identity+0x58,id)&&id==ref.id&&player(ref.object,ref.identity,ref.id,local,a,o.armor_icons)){if(a.local&&a.hp>0)f.local=a.object;f.players.push_back(std::move(a));}}

  if(f.local){auto fp=p(f.local+0xd0),managed=p(fp+0x20);f.camera_native=p(managed+0x10);if(f.camera_native&&val(f.camera_native+0x70,f.view)&&val(f.camera_native+0xb0,f.projection)){V camera=origin(f.view);float norm=f.view.v[0]*f.view.v[0]+f.view.v[4]*f.view.v[4]+f.view.v[8]*f.view.v[8];f.camera=finite(camera)&&std::isfinite(norm)&&fabsf(norm-1)<.05f&&std::isfinite(f.projection.v[0])&&std::isfinite(f.projection.v[5])&&f.projection.v[0]>.01f&&f.projection.v[5]>.01f&&fabsf(f.projection.v[11]+1)<.01f;}}
  if(f.local){auto look=p(f.local+0xb0);f.input_unlocked=look_unlocked(look);auto ref=p(f.local+0x118);for(unsigned off:{0x10U,0x18U,0x20U}){auto loot=p(ref+off);if(name(loot)=="PlayerLoot"&&p(loot+0x70)==f.local){auto inventory=p(loot+0x80),target=p(loot+0x88);if(inventory&&target)f.loot_session=inventory;break;}}}
  for(const auto& world:f.world)if((world.kind==Animal&&(o.aim_animals||o.trigger_animals))||(world.kind==Bot&&(o.aim_bots||o.trigger_bots||o.show_bot_rig))){Actor a;if(npc_target(world,a))f.npc_targets.push_back(std::move(a));}
  update_lead(f,o.lead_ms);
  sample_tracers(f,o);
  sample_combat(f,o.hit_feedback);
  if(o.require_visibility&&o.aim&&f.camera){
   const auto player_count=f.players.size();f.players.insert(f.players.end(),f.npc_targets.begin(),f.npc_targets.end());
   visibility_.update([&](uint64_t address,void* bytes,size_t size){return read(address,bytes,size);},
                      [&](uint64_t address){return name(address);},f,game_modes(),p(p(f.local+0xd0)+0x20),nullptr,f.time,0x80,profile_->visibility_dictionary);
   for(size_t i=0;i<f.npc_targets.size();++i)f.npc_targets[i]=f.players[player_count+i];f.players.resize(player_count);
  }else visibility_.reset();
  sky(f,o);movement_features(f,o);weapon_features(f,o);trigger_target(f,o);
  if(f.camera){last_good_=now();fov(f,o);third_person(f,o);flight(f,o);if(o.no_recoil)recoil(f,o);aim(f,o);if(!o.no_recoil&&o.aim_recoil)recoil(f,o);avatar_heading(f,o);f.status="Oxide: сцена подключена";}else{if(now()-last_good_>1500){restore();restore_fov();restore_third();}f.status="Ожидание камеры живого персонажа";}
  publish(std::move(f));
 }
 void publish(Frame&& f){Frame previous;{std::lock_guard<std::mutex> lock(mutex_);previous=std::move(frame_);frame_=std::move(f);}}
public:
 bool probe_direct(const std::string& package,const oxide_profile::Profile& profile){
  direct_=true;direct_status_.clear();package_=package;profile_=&profile;
  if(!attach())return false;
  fprintf(stderr,"Virtual: Oxide memory read and profile verified (pid=%d).\n",pid_);
  return true;
 }
 std::string inspect_direct(const std::string& package,const oxide_profile::Profile& profile){
  const bool matched=probe_direct(package,profile);
  const std::string result=matched?"Oxide memory read and profile verified":direct_status_;
  close_process();
  return result;
 }
 void start(const std::string& package,std::function<bool()> allowed,const oxide_profile::Profile& profile=oxide_profile::current,bool direct=false){direct_=direct;profile_=&profile;package_=package;stop_=false;thread_=std::thread([this,allowed]{while(!stop_){auto began=now();Options o;{std::lock_guard<std::mutex> l(mutex_);o=options_;}if(allowed&&allowed())tick(o);else{close_process();publish(Frame{});}const bool fast=(o.aim&&!o.paused)||o.trigger||o.spin||o.freecam||o.thirdperson||o.farm_target;
 const long long period=pid_?(o.silent_aim&&o.aim&&!o.paused?8:fast?16:24):100;
 std::this_thread::sleep_for(std::chrono::milliseconds(std::max(3LL,period-(now()-began))));}close_process();});}
 void configure(const Options& o){std::lock_guard<std::mutex> l(mutex_);options_=o;}
 Frame snapshot(){std::lock_guard<std::mutex> l(mutex_);return frame_;}
 void stop(){stop_=true;if(thread_.joinable())thread_.join();}
 ~Live(){stop();}
};
}
