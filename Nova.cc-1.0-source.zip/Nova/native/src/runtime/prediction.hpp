#pragma once
#include "core.hpp"
namespace oxide {
// Solve |relative + velocity*t| = projectile_speed*t. Never extrapolate teleports.
inline V intercept_point(V origin,V target,V velocity,float speed,float latency){
 if(!finite(origin)||!finite(target)||!finite(velocity)||len(velocity)>14.f)return target;
 velocity.y=0;latency=std::clamp(latency,0.f,.18f);
 V delayed=add(target,mul(velocity,latency));
 if(!std::isfinite(speed)||speed<10.f||speed>5000.f)return delayed;
 const V r=sub(delayed,origin);float a=dot(velocity,velocity)-speed*speed,b=2*dot(r,velocity),c=dot(r,r),t=0;
 if(std::fabs(a)<.001f){if(std::fabs(b)>.001f)t=-c/b;}
 else{float disc=b*b-4*a*c;if(disc>=0){float root=std::sqrt(disc),t1=(-b-root)/(2*a),t2=(-b+root)/(2*a);t=t1>0?t1:t2;if(t2>0&&t2<t)t=t2;}}
 if(!std::isfinite(t)||t<0||t>2.f)return delayed;
 return add(delayed,mul(velocity,t));
}
template<class R>bool rig_node(R r,uint64_t data,int index,Node& result){
 auto entries=pointer(r,data+0x18),parents=pointer(r,data+0x20);if(!entries||!parents||index<0||index>1048576)return false;
 V position{};int parent=index;std::array<int,128> seen{};unsigned count=0;
 while(parent>=0){if(parent>1048576||count==seen.size())return false;for(unsigned i=0;i<count;++i)if(seen[i]==parent)return false;seen[count++]=parent;
  TRS t{};if(!get(r,entries+uint64_t(parent)*48,t))return false;float norm=dot({t.q.x,t.q.y,t.q.z},{t.q.x,t.q.y,t.q.z})+t.q.w*t.q.w;
  if(!finite({t.p[0],t.p[1],t.p[2]})||!finite({t.s[0],t.s[1],t.s[2]})||!std::isfinite(norm)||norm<.8f||norm>1.2f)return false;
  position=add(rotate(t.q,{position.x*t.s[0],position.y*t.s[1],position.z*t.s[2]}),{t.p[0],t.p[1],t.p[2]});if(!get(r,parents+uint64_t(parent)*4,parent))return false;
 }
 if(!finite(position))return false;result={data,index,position};return true;
}
}
