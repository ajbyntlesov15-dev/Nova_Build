#pragma once
#include "core.hpp"
#include <unordered_map>
namespace oxide {
// OcclusionModule caches Physics.Raycast(camera, markerPoint, obstacleMask).
// Unknown is distinct from a negative result; no cache is never called "visible".
enum class Visibility:uint8_t {Unknown=0,Visible=1,Occluded=2};
inline bool visibly_open(const Actor& a,long long clock){return a.visibility==1&&a.visibility_time>0&&clock>=a.visibility_time&&clock-a.visibility_time<=500;}
class MarkerVisibility {
 struct Observation {float stamp=0;long long changed=0;uint64_t identity=0;bool advanced=false;int mask=0;uint32_t net_id=0;};
 std::unordered_map<uint64_t,Observation> observations_;
 uint64_t presenter_=0,controller_=0;
 template<class R,class N> uint64_t presenter(R read,N name,uint64_t controller){
  auto p=[&](uint64_t a){return pointer(read,a);};
  if(controller_!=controller){controller_=controller;presenter_=0;observations_.clear();}
  auto valid=[&](uint64_t a){return name(a)=="ScreenMarkerPresenter"&&p(a+0x28)==controller;};
  if(valid(presenter_))return presenter_;
  presenter_=0;
  auto target=[&](uint64_t delegate){auto candidate=p(delegate+0x20);return valid(candidate)?candidate:uint64_t(0);};
  for(unsigned off:{0x20U,0x28U,0x30U,0x38U}){
   auto delegate=p(controller+off);if(!delegate)continue;
   if(auto result=target(delegate))return presenter_=result;
   auto list=p(delegate+0x78);uint64_t count=0;if(!get(read,list+0x18,count)||count>128)continue;
   for(uint64_t i=0;i<count;++i)if(auto result=target(p(list+0x20+i*8)))return presenter_=result;
  }
  return 0;
 }
 template<class R> int owner(R read,const Node& marker,const Actor* players,size_t count){
  auto parents=pointer(read,marker.data+0x20);int index=marker.index;
  for(unsigned depth=0;depth<64&&index>=0&&index<=1048576;++depth){
   int match=-1;for(size_t i=0;i<count;++i)if(players[i].root.data==marker.data&&players[i].root.index==index){if(match>=0)return -1;match=int(i);}
   if(match>=0)return match;
   int next=-1;if(!get(read,parents+uint64_t(index)*4,next)||next==index)return -1;index=next;
  }
  return -1;
 }
public:
 void reset(){presenter_=controller_=0;observations_.clear();}
 template<class R,class N> void update(R read,N name,Frame& frame,uint64_t modes,uint64_t camera,const char* service_type,long long clock,unsigned controller_offset=0x80,unsigned dictionary_offset=0x48){
  for(auto& a:frame.players){a.visibility=0;a.visibility_time=0;a.visibility_module=0;}
  frame.visibility_status="Видимость: нет данных";
  auto p=[&](uint64_t a){return pointer(read,a);};
  uint64_t screen=0;
  if(service_type){
   const auto controller=p(modes+controller_offset);
   if(name(controller)==service_type)screen=presenter(read,name,controller);
  }else{
   // GameModes has both a map service and the screen marker service.
   // Only a presenter with a backlink to the candidate proves ownership.
   const unsigned first=p(modes+0x80)==controller_&&controller_?0x80U:0x88U;
   for(unsigned offset:{first,first==0x80U?0x88U:0x80U}){
    const auto controller=p(modes+offset);
    if(controller&&(screen=presenter(read,name,controller)))break;
   }
  }
  if(!screen){frame.visibility_status="Видимость: экранные маркеры недоступны";return;}
  auto dict=p(screen+dictionary_offset),entries=p(dict+0x18);int count=0,version=0,after=0;uint64_t capacity=0;
  if(!get(read,dict+0x20,count)||!get(read,dict+0x24,version)||count<0||count>2048||!get(read,entries+0x18,capacity)||capacity<uint64_t(count)||capacity>4096)return;
  std::vector<unsigned char> bytes(size_t(count)*24);if(count&&!read(entries+0x20,bytes.data(),bytes.size()))return;
  if(!get(read,dict+0x24,after)||after!=version||p(dict+0x18)!=entries)return;
  unsigned available=0;
  for(int i=0;i<count;++i){
   int hash=-1;uint64_t marker=0,view=0;memcpy(&hash,bytes.data()+i*24,4);memcpy(&marker,bytes.data()+i*24+8,8);memcpy(&view,bytes.data()+i*24+16,8);marker=untag(marker);view=untag(view);
   if(hash<0||name(marker)!="Marker"||(name(view)!="NearbyPlayerScreenMarkerView"&&name(view)!="PointScreenMarkerView")||p(view+0x40)!=marker)continue;
   uint8_t active=0;if(!get(read,marker+0x18,active)||active!=1)continue;
   auto data=p(marker+0x10),follow=p(data+0x40);Node anchor;
   if(name(follow)!="Transform"||!node(read,p(follow+0x10),anchor))continue;
   int index=owner(read,anchor,frame.players.data(),frame.players.size());if(index<0)continue;auto& actor=frame.players[size_t(index)];if(actor.local||actor.hp<=0||(actor.kind==0&&name(view)!="NearbyPlayerScreenMarkerView"))continue;
   auto context=p(view+0x28),modules=p(view+0x30),array=p(modules+0x10);int size=0;uint64_t cap=0;
   if(name(context)!="ScreenMarkerModuleContext"||p(context+0x58)!=camera||!get(read,modules+0x18,size)||size<0||size>32||!get(read,array+0x18,cap)||cap<uint64_t(size)||cap>128)continue;
   uint8_t bypass=1;if(!get(read,context+0x50,bypass)||bypass!=0)continue;
   for(int j=0;j<size;++j){
    auto module=p(array+0x20+j*8);if(name(module)!="OcclusionModule"||p(module+0x20)!=context)continue;
    int mask=0;if(!get(read,module+0x28,mask)||mask==0){observations_.erase(module);continue;}float stamp=0,interval=0,again=0;uint16_t result=0,last=0;V point{};
    if(!get(read,module+0x38,stamp)||!get(read,module+0x2c,interval)||!get(read,module+0x3c,result)||!get(read,context+0x44,point)||!finite(point)||!std::isfinite(stamp)||stamp<=0||!std::isfinite(interval)||interval<.01f||interval>1||!(result==1||result==257))continue;
    // An unrelated marker offset must not act as proof for this character.
    if(len(sub(point,actor.head))>.3f&&len(sub(point,actor.body))>.3f)continue;
    if(!get(read,module+0x38,again)||again!=stamp||!get(read,module+0x3c,last)||last!=result)continue;
    auto& seen=observations_[module];
    if(seen.identity!=actor.identity||seen.net_id!=actor.id||seen.mask!=mask){seen={stamp,clock,actor.identity,false,mask,actor.id};continue;}
    if(seen.stamp!=stamp){seen.stamp=stamp;seen.changed=clock;seen.advanced=true;continue;}
    // The deadline is written before the raycast: wait one worker frame for completion.
    long long ttl=std::min(500LL,std::max(100LL,(long long)(interval*1500)+50));
    if(!seen.advanced||clock-seen.changed<16||clock-seen.changed>ttl)continue;
    if(actor.visibility==2&&result==1)continue;actor.visibility=result==1?1:2;actor.visibility_time=seen.changed;actor.visibility_module=module;actor.visibility_view=view;actor.visibility_marker=marker;actor.visibility_stamp=stamp;actor.visibility_mask=mask;actor.visibility_point=point;++available;break;
   }
  }
  if(observations_.size()>4096)observations_.clear();
  frame.visibility_status="Видимость: подтверждено "+std::to_string(available)+" / "+std::to_string(frame.players.size());
 }
 template<class R,class N> bool confirm(R read,N name,const Actor& actor,uint64_t camera,long long clock){
  if(!visibly_open(actor,clock)||name(actor.visibility_module)!="OcclusionModule")return false;
  int mask=0;V point{};uint16_t result=0;float stamp=0;auto context=pointer(read,actor.visibility_module+0x20);uint8_t bypass=1,active=0;
  auto p=[&](uint64_t a){return pointer(read,a);};
  if(p(actor.visibility_view+0x40)!=actor.visibility_marker||p(actor.visibility_view+0x28)!=context||name(actor.visibility_marker)!="Marker"||!get(read,actor.visibility_marker+0x18,active)||active!=1)return false;
  auto follow=p(p(actor.visibility_marker+0x10)+0x40);Node anchor;
  if(name(follow)!="Transform"||!node(read,p(follow+0x10),anchor)||owner(read,anchor,&actor,1)!=0)return false;
  return get(read,actor.visibility_module+0x28,mask)&&mask!=0&&mask==actor.visibility_mask&&get(read,context+0x44,point)&&finite(point)&&len(sub(point,actor.visibility_point))<.01f&&pointer(read,context+0x58)==camera&&get(read,context+0x50,bypass)&&bypass==0&&get(read,actor.visibility_module+0x3c,result)&&result==1&&get(read,actor.visibility_module+0x38,stamp)&&stamp==actor.visibility_stamp;
 }
};
}
