#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
namespace oxide_profile {
struct Guard{bool unity;uint64_t address;unsigned size;unsigned char bytes[32];};
struct Patch{uint64_t address;uint32_t expected;};
struct Profile{const char* channel;const char* version;uint64_t network_client_cell,orbit_cell;const char* camera_type;const char* ray_type;unsigned handler_sleep,handler_aim;const uint64_t* day_cells;size_t day_count;const uint64_t* mode_cells;size_t mode_count;const Patch* patches;size_t patch_count;const Guard* guards;size_t guard_count;const char* marker;unsigned controller_static,controller_modes,third_mode,item_database;const char* database_type;uint64_t sky_writer_address;uint32_t sky_writer_expected;Patch day_fraction,day_hour;uint64_t fps_target_cell,fps_manager_cell;const char* dispersion_state="QT";unsigned visibility_dictionary=0x48;unsigned fp_derived_delta=0,fp_base_delta=0,melee_reach_offset=0x130;unsigned look_locks_offset=0x80;};

inline constexpr uint64_t current_day_cells[]={0xee1bd60,0xee1bd90,0xee1c098,0xee1d4e8,0xee1e018,0xee1e038,0xee1e858,0xee3e660,0xee46b00,0xee46b08,0xee46b10,0xee49ee0};
inline constexpr uint64_t current_mode_cells[]={0xee1bd60,0xee1c988,0xee1ca70,0xee1e278,0xee1e280,0xee1e338,0xee1e340,0xee1e348,0xee1e350,0xee1e770,0xee1e788,0xee1f838,0xee20298,0xee21cf0,0xee21cf8,0xee21d00,0xee21e98,0xee22580,0xee4b510,0xee650b8,0xee650c0,0xee650c8};
inline constexpr Patch current_patches[]={{0x6609fb4,0xbd446100U},{0x750777c,0xbd446100U}};
inline constexpr Guard current_guards[]={{false,0x318,20,{204,142,91,99,234,248,255,129,99,233,21,88,225,237,203,246,6,97,102,105}},{true,0x318,8,{125,81,255,152,100,3,87,113}},{false,0xd377880,32,{254,15,30,248,244,79,1,169,180,18,1,240,83,213,0,144,136,134,95,57,115,178,67,249,200,0,0,55,64,213,0,144}},{false,0x7458b10,32,{255,3,1,209,232,11,0,253,254,87,2,169,244,79,3,169,180,10,4,176,243,3,0,170,136,70,117,57,136,1,0,55}},{false,0x86a0488,32,{254,15,30,248,244,79,1,169,212,120,3,240,51,62,3,176,136,58,125,57,115,94,64,249,200,0,0,55,32,62,3,176}},{false,0x74447b4,8,{0,132,9,45,192,3,95,214}},{true,0xe348d4,8,{8,8,84,57,243,3,0,170}},{true,0x7fccc8,8,{20,20,64,249,243,3,0,170}},{true,0x5c6e30,8,{8,16,64,249,19,5,64,249}},{true,0xe403a8,12,{96,114,65,189,254,79,193,168,192,3,95,214}},{true,0x64b600,12,{8,28,65,57,31,253,3,113,193,4,0,84}},{true,0x5b63a0,16,{8,48,16,145,0,1,192,61,32,0,128,61,192,3,95,214}},{true,0xe411b0,24,{8,8,68,185,31,1,1,107,224,0,0,84,200,80,0,240,8,129,6,145,1,8,4,185}},{true,0x7450a0,12,{232,132,0,208,0,229,73,185,192,3,95,214}}};
inline constexpr Profile current={"current","1.19.12025",0xee1f760,0xee650b8,"sq","YSL",0x1d8,0x2b8,current_day_cells,12,current_mode_cells,22,current_patches,2,current_guards,14,"yC",0x58,0xe0,0x1f8,0x40,"ItemDatabase",0x70421f0,0x95bb2f2c,{0x7458f78,0xbd00b800},{0x7458f88,0xb9003c08},0x17e39e4,0x17fee20,"sn",0x40,0,0,0x130,0x80};
// Inert internal compatibility tag; there is no beta profile or selector.
inline constexpr Profile beta{};
inline const char* marker_service_type(const Profile& p){return p.marker;}
inline const Profile* select(const char* name){return name&&!std::strcmp(name,"current")?&current:nullptr;}
}