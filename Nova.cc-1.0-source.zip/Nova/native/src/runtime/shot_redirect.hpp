#pragma once
#include "core.hpp"
#include "shot_payload_generated.hpp"
#include <asm/ptrace.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <dirent.h>
#include <unistd.h>
#include <cerrno>
#include <chrono>
#include <thread>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <cstddef>
#include <csignal>

namespace oxide {
namespace shot_detail {
inline long long clock_ms(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
inline bool regs(int tid,user_pt_regs& value,bool set=false){iovec io{&value,sizeof(value)};return ptrace(set?PTRACE_SETREGSET:PTRACE_GETREGSET,tid,reinterpret_cast<void*>(1),&io)==0&&io.iov_len==sizeof(value);}
/* All game threads are stopped only during installation. Nothing calls into
 * the game's loader or acquires a user-space lock while they are stopped. */
class StopWorld {
 struct Thread {int tid,signal=0;bool stopped=false;};
 std::vector<Thread> threads_;
 bool wait(Thread& thread){
  auto end=clock_ms()+1000;
  while(clock_ms()<end){int status=0;auto n=waitpid(thread.tid,&status,__WALL|WNOHANG);
   if(n==thread.tid){if(!WIFSTOPPED(status))return false;thread.stopped=true;thread.signal=(unsigned(status)>>16)==PTRACE_EVENT_STOP?0:WSTOPSIG(status);return true;}
   if(n<0&&errno!=EINTR)return false;
   std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }return false;
 }
public:
 bool stop(int pid){
  if(pid<=0||pid==getpid())return false;
  for(unsigned pass=0;pass<4;++pass){char path[64];snprintf(path,sizeof(path),"/proc/%d/task",pid);auto* dir=opendir(path);if(!dir)return false;std::vector<int> tids;
   while(auto* ent=readdir(dir)){int tid=atoi(ent->d_name);if(tid>0)tids.push_back(tid);}closedir(dir);
   bool added=false;
   for(int tid:tids){bool known=false;for(auto& thread:threads_)if(thread.tid==tid)known=true;if(known)continue;
    if(ptrace(PTRACE_SEIZE,tid,nullptr,nullptr)!=0){if(errno==ESRCH)continue;return false;}
    threads_.push_back({tid});auto& thread=threads_.back();
    if(ptrace(PTRACE_INTERRUPT,tid,nullptr,nullptr)!=0||!wait(thread))return false;added=true;
   }
   if(!added){for(auto& thread:threads_)if(thread.tid==pid)return true;return false;}
  }return false;
 }
 bool clear_entries(const uint64_t sites[2]){
  for(auto& thread:threads_){user_pt_regs r{};if(!regs(thread.tid,r))return false;for(unsigned i=0;i<2;++i)if(r.pc>=sites[i]&&r.pc<sites[i]+16)return false;}return true;
 }
 ~StopWorld(){for(auto& thread:threads_){if(!thread.stopped){ptrace(PTRACE_INTERRUPT,thread.tid,nullptr,nullptr);wait(thread);}ptrace(PTRACE_DETACH,thread.tid,nullptr,reinterpret_cast<void*>(intptr_t(thread.signal)));}}
 template<class R,class W> bool syscall(int tid,R read,W write,unsigned number,const uint64_t args[6],uint64_t& result){
  user_pt_regs saved{},call{},after{};if(!regs(tid,saved)||saved.pc&3)return false;
  int saved_syscall=-1;iovec io{&saved_syscall,sizeof(saved_syscall)};
  if(ptrace(PTRACE_GETREGSET,tid,reinterpret_cast<void*>(0x404),&io)!=0)return false; // NT_ARM_SYSTEM_CALL
  unsigned char backup[8]{};if(!read(saved.pc,backup,8))return false;
  const uint32_t trap[2]={0xd4000001U,0xd4200000U}; // svc #0; brk #0
  if(!write(saved.pc,trap,8))return false;
  call=saved;for(unsigned i=0;i<6;++i)call.regs[i]=args[i];call.regs[8]=number;
  // Cancel the previous syscall context before executing the injected SVC.
  int none=-1;io={&none,sizeof(none)};
  bool ok=ptrace(PTRACE_SETREGSET,tid,reinterpret_cast<void*>(0x404),&io)==0&&regs(tid,call,true);
  bool running=ok&&ptrace(PTRACE_CONT,tid,nullptr,nullptr)==0;
  bool stopped=!running;ok=running;
  if(running){auto end=clock_ms()+1000;while(clock_ms()<end){int status=0;auto n=waitpid(tid,&status,__WALL|WNOHANG);if(n==tid){stopped=WIFSTOPPED(status);ok=stopped&&WSTOPSIG(status)==SIGTRAP&&regs(tid,after)&&after.pc==saved.pc+4;break;}if(n<0&&errno!=EINTR){ok=false;break;}std::this_thread::sleep_for(std::chrono::milliseconds(1));}if(!stopped)ok=false;}
  if(!stopped){ptrace(PTRACE_INTERRUPT,tid,nullptr,nullptr);Thread thread{tid};stopped=wait(thread);}
  if(!stopped)return false;
  bool code_restored=write(saved.pc,backup,8);
  if(!code_restored){uint64_t word=0;memcpy(&word,backup,8);code_restored=ptrace(PTRACE_POKETEXT,tid,reinterpret_cast<void*>(saved.pc),reinterpret_cast<void*>(word))==0;}
  // Always attempt every restoration, including when an earlier step failed.
  bool registers_restored=regs(tid,saved,true);io={&saved_syscall,sizeof(saved_syscall)};
  bool syscall_restored=ptrace(PTRACE_SETREGSET,tid,reinterpret_cast<void*>(0x404),&io)==0;
  result=after.regs[0];return ok&&code_restored&&registers_restored&&syscall_restored;
 }
};
inline std::array<unsigned char,16> jump(uint64_t target){std::array<unsigned char,16> out{};uint32_t words[2]={0x58000050U,0xd61f0200U};memcpy(out.data(),words,8);memcpy(out.data()+8,&target,8);return out;}
}

/* Root-only shot-ray adapter. The game-side payload never reads or writes
 * MouseLook, Camera or Transform. Expired/invalid samples use the original ray. */
class ShotRedirect {
 struct State {uint64_t original[2],owner,until;V target;uint32_t sequence,enabled,reserved;};
 static_assert(sizeof(State)==56);
 uint64_t base_=0,game_=0;int pid_=0;uint32_t sequence_=0;long long retry_=0;bool disabled_=true;
 std::string status_="Silent: обработчик выстрела не подключён";
 template<class R> bool same_code(R read,uint64_t base,const oxide_shot::Site* sites,uint64_t game){
  std::vector<unsigned char> code(sizeof(oxide_shot::code));if(!read(base,code.data(),code.size()))return false;
  for(unsigned i=0;i<2;++i){auto off=oxide_shot::trampoline[i];if(off+32>code.size())return false;
   if(memcmp(code.data()+off,sites[i].expected,16))return false;auto tail=shot_detail::jump(game+sites[i].offset+16);if(memcmp(code.data()+off+16,tail.data(),16))return false;
   memcpy(code.data()+off,oxide_shot::code+off,32);
  }return !memcmp(code.data(),oxide_shot::code,code.size());
 }
 template<class R,class W> bool install(R read,W write,int pid,uint64_t game,bool beta){
  const auto* sites=beta?oxide_shot::beta:oxide_shot::current;uint64_t addresses[2]={game+sites[0].offset,game+sites[1].offset};
  unsigned char current[2][32]{};for(unsigned i=0;i<2;++i)if(!read(addresses[i],current[i],32)){status_="Silent: обработчик выстрела недоступен";return false;}
  uint64_t recovered=0;memcpy(&recovered,current[0]+8,8);
  if(recovered>=65536+oxide_shot::entry[0]){
   recovered-=oxide_shot::entry[0];bool own=true;
   for(unsigned i=0;i<2;++i){auto j=shot_detail::jump(recovered+oxide_shot::entry[i]);own=own&&!memcmp(current[i],j.data(),16)&&!memcmp(current[i]+16,sites[i].expected+16,16);}
   State state{};
   if(own&&same_code(read,recovered,sites,game)&&get(read,recovered+oxide_shot::state,state)&&state.reserved==0x53483103&&state.original[0]==recovered+oxide_shot::trampoline[0]&&state.original[1]==recovered+oxide_shot::trampoline[1]){
    base_=recovered;game_=game;pid_=pid;sequence_=state.sequence+(state.sequence&1);disabled_=false;return disable(write);
   }
  }
  for(unsigned i=0;i<2;++i)if(memcmp(current[i],sites[i].expected,32)){status_="Silent: версия обработчика выстрела не совпала";return false;}
  shot_detail::StopWorld stopped;
  if(!stopped.stop(pid)){status_="Silent: root не разрешил остановку потоков";return false;}
  if(!stopped.clear_entries(addresses)){status_="Silent: установка отложена до завершения выстрела";return false;}
  // Revalidate after stopping every thread; never overwrite another patch.
  for(unsigned i=0;i<2;++i){unsigned char guard[32]{};if(!read(addresses[i],guard,32)||memcmp(guard,sites[i].expected,32)){status_="Silent: код изменился перед установкой";return false;}}
  uint64_t args[6]={0,0x8000,3,0x22,uint64_t(-1),0},remote=0;
  if(!stopped.syscall(pid,read,write,222,args,remote)||remote>=uint64_t(-4095)||remote<65536){status_="Silent: выделение памяти отклонено";return false;}
  std::vector<unsigned char> code(std::begin(oxide_shot::code),std::end(oxide_shot::code));
  State state{};state.reserved=0x53483103;
  for(unsigned i=0;i<2;++i){auto offset=oxide_shot::trampoline[i];memcpy(code.data()+offset,sites[i].expected,16);auto tail=shot_detail::jump(addresses[i]+16);memcpy(code.data()+offset+16,tail.data(),16);state.original[i]=remote+offset;}
  bool ok=write(remote,code.data(),code.size())&&write(remote+oxide_shot::state,&state,sizeof(state));
  args[0]=remote;args[1]=0x4000;args[2]=5;uint64_t result=0;
  ok=ok&&stopped.syscall(pid,read,write,226,args,result)&&result==0;
  // Write through an executable mapping as well, so the kernel's remote-code
  // write path synchronizes the instruction cache before any entry is changed.
  ok=ok&&write(remote,code.data(),code.size())&&same_code(read,remote,sites,game);
  unsigned changed=0;
  if(ok){for(unsigned i=0;i<2;++i){auto patch=shot_detail::jump(remote+oxide_shot::entry[i]);++changed;if(!write(addresses[i],patch.data(),16)){ok=false;break;}unsigned char verify[16]{};if(!read(addresses[i],verify,16)||memcmp(verify,patch.data(),16)){ok=false;break;}}}
  if(!ok){bool restored=true;for(unsigned i=0;i<changed;++i)restored=write(addresses[i],sites[i].expected,16)&&restored;
   // Keep allocated code if restoration failed: an existing entry may use it.
   if(restored){args[0]=remote;args[1]=0x8000;stopped.syscall(pid,read,write,215,args,result);}
   status_="Silent: установка обработчика отклонена";return false;}
  base_=remote;game_=game;pid_=pid;sequence_=0;disabled_=true;status_="Silent: обработчик выстрела готов";return true;
 }
public:
 const std::string& status()const{return status_;}
 template<class W> bool disable(W write){if(!base_||disabled_)return true;uint32_t zero=0;if(!write(base_+oxide_shot::state+offsetof(State,enabled),&zero,4))return false;disabled_=true;return true;}
 void forget(){base_=game_=0;pid_=0;sequence_=0;retry_=0;disabled_=true;}
 template<class R,class W> bool arm(R read,W write,int pid,uint64_t game,bool beta,uint64_t weapon,V target,long long time){
  if(pid==getpid()){status_="Silent: новый метод доступен только в root-запуске";return false;}
  if(!ptr(weapon)||!finite(target)||time<=0)return false;
  if(base_&&(pid_!=pid||game_!=game)){disable(write);forget();}
  if(!base_){if(time<retry_)return false;retry_=time+3000;if(!install(read,write,pid,game,beta))return false;}
  uint32_t odd=(sequence_+1)|1U,even=odd+1;uint64_t at=base_+oxide_shot::state;
  struct Sample {uint64_t owner,until;V target;uint32_t sequence,enabled,reserved;} sample{weapon,uint64_t(time+150),target,odd,1,0x53483103};
  if(!write(at+offsetof(State,sequence),&odd,4)||!write(at+offsetof(State,owner),&sample,sizeof(sample))||!write(at+offsetof(State,sequence),&even,4)){disabled_=false;disable(write);status_="Silent: запись цели отклонена";return false;}
  sequence_=even;disabled_=false;status_="Silent: луч выстрела, камера без изменений";return true;
 }
};
}
