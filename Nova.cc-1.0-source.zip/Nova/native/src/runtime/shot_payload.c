/* Freestanding ARM64 shot adapter. No input, camera or network writes. */
typedef unsigned long long U64;
typedef unsigned int U32;
typedef struct { float x,y,z; } Vec;
typedef struct { Vec origin,direction; } Ray;
typedef void (*Original)(void*,const Ray*,void*);
typedef struct {
 U64 original[2],owner,until_ms;
 Vec target;
 U32 sequence,enabled,reserved;
} ShotState;
_Static_assert(sizeof(ShotState)==56,"shared ABI");
__attribute__((section(".shot_state"),visibility("hidden"),used)) volatile ShotState shot_state;

static U64 clock_ms(void) {
 struct { long sec,nsec; } stamp={0,0};
 register long a0 __asm__("x0")=1; /* CLOCK_MONOTONIC */
 register void* a1 __asm__("x1")=&stamp;
 register long number __asm__("x8")=113; /* __NR_clock_gettime */
 __asm__ volatile("svc #0":"+r"(a0):"r"(a1),"r"(number):"memory","cc");
 if(a0||stamp.sec<0||stamp.nsec<0||stamp.nsec>=1000000000L)return 0;
 return (U64)stamp.sec*1000+(U64)stamp.nsec/1000000;
}
static int valid(Vec v) {
 return __builtin_isfinite(v.x)&&__builtin_isfinite(v.y)&&__builtin_isfinite(v.z)&&
  __builtin_fabsf(v.x)<1000000&&__builtin_fabsf(v.y)<1000000&&__builtin_fabsf(v.z)<1000000;
}
static __attribute__((noinline)) void dispatch(unsigned index,void* weapon,const Ray* input,void* method) {
 Original original=(Original)shot_state.original[index];
 if(!input){original(weapon,input,method);return;}
 U32 before=__atomic_load_n(&shot_state.sequence,__ATOMIC_ACQUIRE);
 U64 owner=shot_state.owner,until=shot_state.until_ms;
 Vec target={shot_state.target.x,shot_state.target.y,shot_state.target.z};
 U32 enabled=shot_state.enabled;
 U32 after=__atomic_load_n(&shot_state.sequence,__ATOMIC_ACQUIRE);
 if((before&1)||before!=after||!enabled||owner!=(U64)weapon||!valid(target)||!valid(input->origin)){
  original(weapon,input,method);return;
 }
 U64 time=clock_ms();
 if(!time||time>until||until-time>250){original(weapon,input,method);return;}
 Vec delta={target.x-input->origin.x,target.y-input->origin.y,target.z-input->origin.z};
 float square=delta.x*delta.x+delta.y*delta.y+delta.z*delta.z;
 if(!__builtin_isfinite(square)||square<.04f||square>1000000000000.f){original(weapon,input,method);return;}
 float scale=1.f/__builtin_sqrtf(square);
 Ray result={input->origin,{delta.x*scale,delta.y*scale,delta.z*scale}};
 /* Keep the caller's ray intact. The original handles hit/spread/ballistics. */
 original(weapon,&result,method);
}
__attribute__((used,visibility("hidden"))) void shot_entry0(void* w,const Ray* r,void* m){dispatch(0,w,r,m);}
__attribute__((used,visibility("hidden"))) void shot_entry1(void* w,const Ray* r,void* m){dispatch(1,w,r,m);}
__asm__(".section .text.shot_trampolines,\"ax\",%progbits\n"
        ".balign 16\n.global shot_trampoline0\n.hidden shot_trampoline0\nshot_trampoline0:\n.space 32\n"
        ".balign 16\n.global shot_trampoline1\n.hidden shot_trampoline1\nshot_trampoline1:\n.space 32\n");
