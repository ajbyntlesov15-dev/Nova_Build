#pragma once
#include "core.hpp"
namespace oxide {
// Render-matrix override only. The Transform used by the shot ray is untouched.
class SilentView {
 uint64_t camera_=0,look_=0;int id_=0;uint8_t flag_=1;
 float display_[2]{},last_[2]{},offset_[2]{};V anchor_{},position_{};M view_{};
 bool wrote_=false;
public:
 bool active()const{return camera_!=0;}
 bool matches(uint64_t camera,uint64_t look)const{return camera_==camera&&look_==look;}
 void forget(){*this=SilentView{};}
 template<class R> bool identity(R r){int id=0;return get(r,camera_+8,id)&&id==id_;}
 template<class R,class W> bool release(R r,W w){
  if(!active())return true;
  if(!identity(r)){forget();return true;}
  float current[2]{};uint8_t flag=1;M matrix{};
  if(!get(r,look_+0x4c,current)||!get(r,camera_+0x502,flag)||!get(r,camera_+0x70,matrix))return false;
  // Restore only values still owned by this feature; preserve external changes.
  if(wrote_&&current[0]==last_[0]&&current[1]==last_[1]&&!w(look_+0x4c,display_,sizeof(display_)))return false;
  if(flag==0){
   if(!w(camera_+0x502,&flag_,1))return false;
  }
  forget();return true;
 }
 template<class R,class W> bool capture(R r,W w,uint64_t camera,uint64_t look,const M& view,V feet){
  if(active())return camera_==camera&&look_==look&&identity(r);
  int id=0;uint8_t flag=0;float angles[2]{};
  if(!camera||!look||!get(r,camera+8,id)||!get(r,camera+0x502,flag)||flag!=1||!get(r,look+0x4c,angles)||!std::isfinite(angles[0])||!std::isfinite(angles[1]))return false;
  V fw{-view.v[2],-view.v[6],-view.v[10]};
  const float pitch=-asinf(std::clamp(fw.y,-1.f,1.f))*57.2957795f,yaw=atan2f(fw.x,fw.z)*57.2957795f;
  camera_=camera;look_=look;id_=id;flag_=flag;view_=view;anchor_=feet;position_=origin(view);
  for(int i=0;i<2;++i)display_[i]=last_[i]=angles[i];
  offset_[0]=angles[0]-pitch;offset_[1]=angle_delta(angles[1],yaw);
  return true;
 }
 template<class R,class W> bool update(R r,W w,V feet,M& out){
  if(!active()||!identity(r))return false;
  float current[2]{};if(!get(r,look_+0x4c,current))return false;
  for(int i=0;i<2;++i){if(!std::isfinite(current[i]))return false;display_[i]+=angle_delta(current[i],last_[i]);last_[i]=current[i];}
  display_[0]=std::clamp(display_[0],-89.f,89.f);display_[1]=std::remainder(display_[1],360.f);
  const V delta=sub(feet,anchor_);if(!finite(delta)||len(delta)>8)return false;
  position_=add(position_,delta);anchor_=feet;
  M next=camera_view(position_,(display_[1]-offset_[1])*.01745329252f,(display_[0]-offset_[0])*.01745329252f);
  uint8_t automatic=1,zero=0;if(!get(r,camera_+0x502,automatic)||automatic>1)return false;
  if(automatic&&!w(camera_+0x502,&zero,1))return false;
  if(!w(camera_+0x70,&next,sizeof(next))){if(automatic)w(camera_+0x502,&automatic,1);return false;}
  view_=next;
  out=next;return true;
 }
 void angles(float pitch,float yaw,float& p,float& y)const{p=std::clamp(pitch+offset_[0],-89.f,89.f);y=std::remainder(yaw+offset_[1],360.f);}
 void applied(float p,float y){last_[0]=p;last_[1]=y;wrote_=true;}
};
}
