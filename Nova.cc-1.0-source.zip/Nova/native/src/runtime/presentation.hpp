#pragma once
#include "core.hpp"
#include <unordered_map>
#include <unordered_set>
namespace oxide {
// Display-only cache. It is never supplied to AIM, camera writes or input automation.
class Presentation {
 Frame held_{};long long last_complete_=0;
 struct Seen {Actor actor;long long time;};std::unordered_map<uint64_t,Seen> actors_;
 template<class T>struct Timed{T item;long long time;};std::unordered_map<uint32_t,Timed<Container>> containers_;std::unordered_map<uint64_t,Timed<WorldObject>> world_;
public:
 Frame update(const Frame& source,long long time,bool hold){
  if(!source.pid||(held_.pid&&held_.pid!=source.pid)||(source.local&&held_.local&&source.local!=held_.local)){held_={};actors_.clear();containers_.clear();world_.clear();last_complete_=0;}
  if(source.camera&&(source.time<=0||time<source.time||time-source.time>350)){
   held_={};actors_.clear();containers_.clear();world_.clear();last_complete_=0;
   Frame empty=source;empty.camera=false;empty.display_stale=true;empty.players.clear();empty.npc_targets.clear();empty.containers.clear();empty.world.clear();empty.shot_segments.clear();empty.aim_point_valid=false;return empty;
  }
  if(source.camera&&source.time>0&&time>=source.time&&time-source.time<=350){
   for(const auto& a:source.players)actors_[a.identity?a.identity:a.object]={a,source.time};
   Frame next=source;std::unordered_set<uint32_t> membership(source.membership.begin(),source.membership.end());bool partial=false;
   for(const auto& c:source.containers)containers_[c.id]={c,source.time};for(const auto& w:source.world)world_[w.object]={w,source.time};
   for(auto it=containers_.begin();it!=containers_.end();){if((source.membership_valid&&!membership.count(it->second.item.id))||source.time-it->second.time>800){it=containers_.erase(it);continue;}bool present=false;for(const auto& c:source.containers)if(c.id==it->first){present=true;break;}if(!present)next.containers.push_back(it->second.item);++it;}
   for(auto it=world_.begin();it!=world_.end();){if((source.membership_valid&&!membership.count(it->second.item.id))||source.time-it->second.time>800){it=world_.erase(it);continue;}bool present=false;for(const auto& w:source.world)if(w.object==it->first){present=true;break;}if(!present)next.world.push_back(it->second.item);++it;}

   for(auto it=actors_.begin();it!=actors_.end();){if((source.membership_valid&&!membership.count(it->second.actor.id))||source.time-it->second.time>350){it=actors_.erase(it);continue;}bool present=false;for(const auto& a:source.players)if((a.identity?a.identity:a.object)==it->first){present=true;break;}if(!present){next.players.push_back(it->second.actor);partial|=source.time-it->second.time>250;}++it;}
   next.display_stale=partial;held_=std::move(next);last_complete_=source.time;
  }
  if(!hold)return source;
  if(!held_.camera)return source;
  if(time<last_complete_||time-last_complete_>350){
   held_={};actors_.clear();containers_.clear();world_.clear();last_complete_=0;
   Frame empty=source;empty.camera=false;empty.display_stale=true;empty.players.clear();empty.npc_targets.clear();empty.containers.clear();empty.world.clear();empty.shot_segments.clear();empty.aim_point_valid=false;
   empty.status="ESP: �������� ������ ������";return empty;
  }
  Frame result=held_;result.status=source.status;result.aim_status=source.aim_status;result.camera_status=source.camera_status;result.owner_scan_complete=source.owner_scan_complete;
  result.display_stale=result.display_stale||time-last_complete_>250;return result;
 }
};
}
