#pragma once
#include <cstdint>
namespace oxide {
// One aligned instruction, guarded against the supplied binary and restored on stop.
class CollectDelayPatch {
 uint64_t address_=0;uint32_t original_=0;bool owned_=false;
public:
 static constexpr uint32_t immediate_zero=0x1e2703e0; // fmov s0, wzr: ordinary CollectAll Delay(0)
 template<class R,class W>bool update(R read,W write,uint64_t base,bool enabled,uint32_t expected,uint64_t patch_offset){
  if(address_&&address_!=base+patch_offset&&!restore(read,write))return false;
  uint32_t current=0;if(!read(base+patch_offset,&current,4))return false;
  if(current!=expected&&current!=immediate_zero)return false;
  if(current==immediate_zero){address_=base+patch_offset;original_=expected;owned_=true;}
  if(!enabled)return restore(read,write);
  address_=base+patch_offset;original_=expected;if(current==expected&&!write(address_,&immediate_zero,4))return false;
  owned_=true;uint32_t after=0;return read(address_,&after,4)&&after==immediate_zero;
 }
 template<class R,class W>bool restore(R read,W write){if(!owned_)return true;uint32_t current=0;if(!read(address_,&current,4))return false;if(current==immediate_zero&&!write(address_,&original_,4))return false;address_=0;owned_=false;return true;}
 void forget(){address_=0;owned_=false;}
};
}
