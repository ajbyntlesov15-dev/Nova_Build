#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
namespace oxide {
struct V{float x=0,y=0,z=0;};struct Q{float x=0,y=0,z=0,w=1;};struct M{float v[16]{};};struct TRS{float p[4];Q q;float s[4];};
inline V add(V a,V b){return {a.x+b.x,a.y+b.y,a.z+b.z};}inline V sub(V a,V b){return {a.x-b.x,a.y-b.y,a.z-b.z};}inline V mul(V a,float s){return {a.x*s,a.y*s,a.z*s};}inline float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}inline float len(V a){return std::sqrt(dot(a,a));}inline V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}inline V rotate(Q q,V a){V t=mul(cross({q.x,q.y,q.z},a),2);return add(a,add(mul(t,q.w),cross({q.x,q.y,q.z},t)));}
inline bool finite(V a){return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z)&&std::max({std::fabs(a.x),std::fabs(a.y),std::fabs(a.z)})<1000000;}
inline uint64_t untag(uint64_t a){return a&0x00ffffffffffffffULL;}
inline bool ptr(uint64_t a){return a>=65536&&a<0x1000000000000ULL&&!(a&7);}
template<class R,class T>bool get(R r,uint64_t a,T& v){return a>=65536&&a<UINT64_MAX-sizeof(v)&&r(a,&v,sizeof(v));}
template<class R>uint64_t pointer(R r,uint64_t a){uint64_t p=0;if(!get(r,a,p))return 0;p=untag(p);return ptr(p)?p:0;}
template<class R>std::string ascii(R r,uint64_t a){std::string s;for(unsigned i=0;i<96;++i){char c=0;if(!r(a+i,&c,1))return {};if(!c)return s;if(c<32||c>126)return {};s+=c;}return {};}
template<class R>uint64_t byte_pointer(R r,uint64_t a){uint64_t p=0;if(!get(r,a,p))return 0;p=untag(p);return p>=65536&&p<0x1000000000000ULL?p:0;}
template<class R>int discover_name_offset(R r,uint64_t k,const char* expected){
 if(!ptr(k))return -1;if(ascii(r,byte_pointer(r,k+0x10))==expected)return 0x10;
 std::array<uint64_t,72> fields{};if(!r(k,fields.data(),sizeof(fields)))for(unsigned i=0;i<fields.size();++i)get(r,k+i*8,fields[i]);int found=-1;unsigned count=0;
 for(unsigned i=1;i<fields.size();++i){uint64_t a=untag(fields[i]);if(a<65536||a>=0x1000000000000ULL)continue;if(ascii(r,a)==expected){if(i*8==0x10)return 0x10;found=int(i*8);++count;}}
 return count==1?found:-1;
}
template<class R>std::string klass(R r,uint64_t o,int offset=0x10){auto k=pointer(r,o);return k&&offset>=0?ascii(r,byte_pointer(r,k+uint64_t(offset))):std::string{};}
template<class R>std::string text(R r,uint64_t a){int n=0;if(!get(r,a+0x10,n)||n<0||n>128)return {};std::vector<uint16_t> v(n);if(n&&!r(a+0x14,v.data(),n*2))return {};std::string s;for(int i=0;i<n;++i){uint32_t c=v[i];if(c>=0xd800&&c<=0xdbff){if(i+1==n||v[i+1]<0xdc00||v[i+1]>0xdfff)return {};c=0x10000+((c-0xd800)<<10)+(v[++i]-0xdc00);}else if(c>=0xdc00&&c<=0xdfff)return {};if(c<32)continue;if(c<128)s+=char(c);else if(c<2048){s+=char(0xc0|(c>>6));s+=char(0x80|(c&63));}else if(c<65536){s+=char(0xe0|(c>>12));s+=char(0x80|((c>>6)&63));s+=char(0x80|(c&63));}else{s+=char(0xf0|(c>>18));s+=char(0x80|((c>>12)&63));s+=char(0x80|((c>>6)&63));s+=char(0x80|(c&63));}}return s;}
struct Node{uint64_t data=0;int index=-1;V position{};};
template<class R>bool node(R r,uint64_t native,Node& out){
 uint64_t data=pointer(r,native+0x28);int idx=-1;if(!data||!get(r,native+0x30,idx)||idx<0||idx>1048576)return false;
 uint64_t entries=pointer(r,data+0x18),parents=pointer(r,data+0x20);if(!entries||!parents)return false;
 TRS t{};int parent=idx;V position{};std::array<int,128> visited{};unsigned count=0;
 while(parent>=0){if(parent>1048576||count>=128)return false;for(unsigned i=0;i<count;++i)if(visited[i]==parent)return false;visited[count++]=parent;
  if(!get(r,entries+uint64_t(parent)*48,t))return false;float norm=t.q.x*t.q.x+t.q.y*t.q.y+t.q.z*t.q.z+t.q.w*t.q.w;
  if(!finite({t.p[0],t.p[1],t.p[2]})||!finite({t.s[0],t.s[1],t.s[2]})||!std::isfinite(norm)||norm<.8f||norm>1.2f)return false;
  position=add(rotate(t.q,{position.x*t.s[0],position.y*t.s[1],position.z*t.s[2]}),{t.p[0],t.p[1],t.p[2]});if(!get(r,parents+uint64_t(parent)*4,parent))return false;
 }
 if(parent!=-1||!finite(position)||pointer(r,native+0x28)!=data)return false;int after=-1;if(!get(r,native+0x30,after)||after!=idx)return false;out={data,idx,position};return true;
}
template<class R>uint64_t go_transform(R r,uint64_t go){auto entries=pointer(r,go+0x20);uint64_t count=0;if(!entries||!get(r,go+0x30,count)||count<1||count>256)return 0;return pointer(r,entries+8);}
template<class R>uint64_t component_transform(R r,uint64_t managed){auto n=pointer(r,managed+0x10);return n?go_transform(r,pointer(r,n+0x20)):0;}
template<class R>bool component_position(R r,uint64_t managed,V& p){Node n;if(!node(r,component_transform(r,managed),n))return false;p=n.position;return true;}
inline V origin(const M& m){return {-(m.v[0]*m.v[12]+m.v[1]*m.v[13]+m.v[2]*m.v[14]),-(m.v[4]*m.v[12]+m.v[5]*m.v[13]+m.v[6]*m.v[14]),-(m.v[8]*m.v[12]+m.v[9]*m.v[13]+m.v[10]*m.v[14])};}
inline V view_point(const M& m,V p){return {m.v[0]*p.x+m.v[4]*p.y+m.v[8]*p.z+m.v[12],m.v[1]*p.x+m.v[5]*p.y+m.v[9]*p.z+m.v[13],m.v[2]*p.x+m.v[6]*p.y+m.v[10]*p.z+m.v[14]};}
inline bool project(const M& v,const M& p,V point,float w,float h,float& x,float& y){V a=view_point(v,point);float cw=p.v[3]*a.x+p.v[7]*a.y+p.v[11]*a.z+p.v[15];if(!std::isfinite(cw)||cw<.02f)return false;x=w*(.5f+.5f*(p.v[0]*a.x+p.v[4]*a.y+p.v[8]*a.z+p.v[12])/cw);y=h*(.5f-.5f*(p.v[1]*a.x+p.v[5]*a.y+p.v[9]*a.z+p.v[13])/cw);return std::isfinite(x)&&std::isfinite(y)&&std::fabs(x)<w*8&&std::fabs(y)<h*8;}
inline M camera_view(V p,float yaw,float pitch){float sy=std::sin(yaw*.5f),cy=std::cos(yaw*.5f),sx=std::sin(pitch*.5f),cx=std::cos(pitch*.5f);Q q{cy*sx,sy*cx,-sy*sx,cy*cx};V r=rotate(q,{1,0,0}),u=rotate(q,{0,1,0}),f=rotate(q,{0,0,1});return {{r.x,u.x,-f.x,0,r.y,u.y,-f.y,0,r.z,u.z,-f.z,0,-dot(r,p),-dot(u,p),dot(f,p),1}};}
struct Actor{V lead_velocity{};Node root{};V visibility_point{};uint8_t visibility=0;long long visibility_time=0;uint64_t visibility_module=0,visibility_view=0,visibility_marker=0;float visibility_stamp=0;int visibility_mask=0;int kind=0;uint64_t object=0,identity=0,look=0;uint32_t id=0;bool local=false,sleeping=false;uint8_t armor_slots=0;bool armor_valid=false;float armor_protection=0;float hp=0,max_hp=0;V feet{},head{},body{};bool exact_head=false;std::vector<Node> bones;std::vector<std::pair<unsigned,unsigned>> edges;std::string name,weapon,team_id,clan_id;bool relations_valid=false;std::string clan_label;std::vector<uint64_t> hit_gameobjects;};
// Unknown affiliation reads never authorize a player target while filtering is enabled.
inline bool affiliation_allows(const Actor& local,const Actor& target,bool ignore_team,bool ignore_clan){
 if(target.kind!=0)return true;
 if(!ignore_team&&!ignore_clan)return true;
 if(!local.relations_valid||!target.relations_valid)return false;
 if(ignore_team&&!local.team_id.empty()&&local.team_id==target.team_id)return false;
 if(ignore_clan&&!local.clan_id.empty()&&local.clan_id==target.clan_id)return false;
 return true;
}
struct Container{uint32_t id=0;V position{};int kind=0;std::string prefab;std::array<V,8> corners{};bool bounds_valid=false;uint64_t matched_owner=0;uint32_t matched_owner_id=0;uint64_t building=0,building_identity=0;float hp=0,max_hp=0;}; // 1 small, 2 large, 3 cupboard
struct WorldObject{uint64_t object=0,identity=0;uint32_t id=0;V position{};int kind=0;std::string name;V hit_position{};bool hit_valid=false,hit_checked=false;};
struct ShotSegment{V from{},to{};long long time=0;};
struct Frame{bool vegetation_ready=false;long long hit_at=0;bool hit_kill=false;bool aim_swipe_valid=false;float aim_swipe_x=0,aim_swipe_y=0;uint64_t owner_scan_complete=0;std::vector<ShotSegment> shot_segments;bool third_person=false,model_heading_valid=false;float model_yaw=0,model_spin=0;bool recoil_source_active=false;std::string visibility_status;int pid=0;uint64_t local=0,camera_native=0;bool membership_valid=false;std::vector<uint32_t> membership;bool camera=false,freecam=false,display_stale=false,input_unlocked=false;uint64_t loot_session=0,trigger_target=0;bool aim_point_valid=false;V aim_point{};bool trigger_ads_active=false;M view{},projection{};long long time=0;std::vector<Actor> players,npc_targets;std::vector<Container> containers;std::vector<WorldObject> world;std::string weapon_status,fps_status;std::string status="Ожидание Oxide",aim_status="",camera_status="",recoil_status="",day_status="";};
struct Options{float tracer_length=200;int tracer_lifetime=1500;float trigger_distance=300;bool trigger_ignore_team=true,trigger_ignore_clan=true,trigger_animals=false,trigger_bots=false;bool no_vegetation=false;bool require_visibility=false;bool hit_feedback=false,armor_icons=false;bool touch_aim=false,aim_360=false,silent_aim=false;bool building_hp=false,aim_recoil=false,aim_melee=false;bool shot_tracers=false;int lead_ms=0;uint64_t search_owner_identity=0;uint32_t search_owner_id=0;bool spin=false,custom_model=false;int spin_speed=180;bool unlock_fps=false;int fps_limit=144;bool movement_boost=false;int movement_percent=130;bool sticky_aim=false,show_bot_rig=false;bool no_spread=false,fast_switch=false,fast_draw=false;bool ignore_team=true,ignore_clan=true;bool sky_tint=false;V sky_color{.2f,.3f,.6f};bool aim_animals=false,aim_bots=false,no_sway=false,fast_reload=false,rapid_fire=false,hand_position=false,trigger=false,trigger_ads=true;int fire_multiplier=2;V hand_offset{};bool always_day=false,quickloot=false;int day_hour=12;float third_height=.4f,third_shoulder=.4f;uint64_t farm_target=0;uint32_t capture_generation=0;bool custom_fov=false,thirdperson=false;float camera_fov=90,third_distance=3;bool debug=false,no_recoil=false,aim=false,paused=true,freecam=false,captured=false;int recoil_x=100,recoil_y=100,activation=1,bone=0,mode=0;float fov=60,smooth=6,distance=300,speed=4,sensitivity=.003f;float x=0,y=0,up=0,look_x=0,look_y=0;};
inline float angle_delta(float a,float b){return std::remainder(a-b,360.f);}
}
