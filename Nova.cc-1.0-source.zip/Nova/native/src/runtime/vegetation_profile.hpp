#pragma once
#include <cstdint>
namespace oxide { struct VegetationPatch {uint64_t address;unsigned char guard[16];};
inline constexpr VegetationPatch vegetation_current[]={{0xe3947d0,{254,15,28,248,248,95,1,169,246,87,2,169,244,79,3,169}},{0xe398358,{254,95,189,169,246,87,1,169,244,79,2,169,87,146,0,176}}};
inline constexpr auto& vegetation_beta=vegetation_current;
}
