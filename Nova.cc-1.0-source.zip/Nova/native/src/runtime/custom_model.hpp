#pragma once
#include "core.hpp"
#include <limits>
namespace custom_model {
using oxide::V;
using oxide::finite;
struct Joint {V rest;int parent,anchor,start,end;V direction;};
struct Vertex {float position[3],normal[3],uv[2];uint32_t joints[4];float weights[4];};
static_assert(sizeof(Vertex)==64,"vertex ABI");
struct Primitive{uint32_t first,count,material;};
struct Material{float color[4];uint32_t width,height;std::vector<uint8_t> pixels;};
struct Asset{std::vector<Joint> joints;std::vector<Vertex> vertices;std::vector<uint32_t> indices;std::vector<Primitive> primitives;std::vector<Material> materials;unsigned hips=0;};
struct Reader{const unsigned char* p;size_t n;bool take(void* out,size_t bytes){if(bytes>n)return false;std::memcpy(out,p,bytes);p+=bytes;n-=bytes;return true;}};
inline bool load(const unsigned char* bytes,size_t size,Asset& output){
 Reader r{bytes,size};uint32_t h[8];if(!r.take(h,sizeof(h))||h[0]!=0x314d4644||h[1]!=1||!h[2]||h[2]>100000||h[3]>300000||h[3]%3||!h[4]||h[4]>48||h[5]>64||!h[6]||h[6]>32||h[7]>=h[4])return false;
 Asset a;a.hips=h[7];a.joints.resize(h[4]);a.vertices.resize(h[2]);a.indices.resize(h[3]);a.primitives.resize(h[5]);a.materials.resize(h[6]);
 for(size_t i=0;i<a.joints.size();++i){Joint& j=a.joints[i];if(!r.take(&j,sizeof(j))||j.parent>=int(i)||j.parent< -1||!finite(j.rest)||!finite(j.direction)||j.anchor>=55||j.start>=55||j.end>=55)return false;}
 if(!r.take(a.vertices.data(),a.vertices.size()*sizeof(Vertex))||!r.take(a.indices.data(),a.indices.size()*4)||!r.take(a.primitives.data(),a.primitives.size()*sizeof(Primitive)))return false;
 for(auto& v:a.vertices){float sum=0;for(int k=0;k<3;++k)if(!std::isfinite(v.position[k])||!std::isfinite(v.normal[k])||std::fabs(v.position[k])>20)return false;
  for(int k=0;k<4;++k){if(v.joints[k]>=a.joints.size()||!std::isfinite(v.weights[k])||v.weights[k]<0||v.weights[k]>1.001f)return false;sum+=v.weights[k];}if(std::fabs(sum-1)>.01)return false;
  if(!std::isfinite(v.uv[0])||!std::isfinite(v.uv[1]))return false;
 }
 for(auto i:a.indices)if(i>=a.vertices.size())return false;
 for(auto p:a.primitives)if(p.material>=a.materials.size()||p.first>a.indices.size()||p.count>a.indices.size()-p.first||p.count%3)return false;
 for(auto& m:a.materials){if(!r.take(m.color,16)||!r.take(&m.width,4)||!r.take(&m.height,4)||!m.width||!m.height||m.width>1024||m.height>1024)return false;
  for(float c:m.color)if(!std::isfinite(c)||c<0||c>1)return false;
  m.pixels.resize(size_t(m.width)*m.height*4);if(!r.take(m.pixels.data(),m.pixels.size()))return false;
 }
 if(r.n)return false;output=std::move(a);return true;
}
}
