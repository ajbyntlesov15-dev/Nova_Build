-keep class cc.nova.oxide.MainActivity { public <init>(); public void onCreate(android.os.Bundle); }
-keep class cc.nova.oxide.LicenseBridge { native <methods>; }
-keep class cc.nova.oxide.OverlayService { *; }
-renamesourcefileattribute SourceFile
-keepattributes !SourceFile,!LineNumberTable,InnerClasses,EnclosingMethod

-keep class cc.nova.oxide.ScreenRecordService { *; }
-keep class cc.nova.oxide.RecordedVideoProvider { *; }
-keep class cc.nova.oxide.RecordingControlActivity { *; }


