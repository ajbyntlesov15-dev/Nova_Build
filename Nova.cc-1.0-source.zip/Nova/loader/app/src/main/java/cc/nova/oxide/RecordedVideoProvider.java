package cc.nova.oxide;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public final class RecordedVideoProvider extends ContentProvider {
    static File directory(){return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),"Nova");}
    static Uri uri(File file){return new Uri.Builder().scheme("content").authority("cc.nova.oxide.recordings").appendPath("clips").appendPath(file.getName()).build();}
    private File resolve(Uri uri)throws FileNotFoundException {
        if(!"cc.nova.oxide.recordings".equals(uri.getAuthority())||uri.getPathSegments().size()!=2||!"clips".equals(uri.getPathSegments().get(0)))throw new FileNotFoundException("Invalid recording URI");
        String name=uri.getLastPathSegment();if(name==null||!name.matches("Nova_[0-9_]+\\.mp4"))throw new FileNotFoundException("Invalid recording name");
        try{File parent=directory().getCanonicalFile(),file=new File(parent,name).getCanonicalFile();if(!parent.equals(file.getParentFile())||!file.isFile())throw new FileNotFoundException("Recording not found");return file;}catch(IOException e){throw new FileNotFoundException(e.getMessage());}
    }
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){return "video/mp4";}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {if(!"r".equals(mode))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(resolve(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){try{File file=resolve(uri);String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;MatrixCursor cursor=new MatrixCursor(columns,1);Object[] row=new Object[columns.length];for(int i=0;i<columns.length;i++){if(OpenableColumns.DISPLAY_NAME.equals(columns[i]))row[i]=file.getName();else if(OpenableColumns.SIZE.equals(columns[i]))row[i]=file.length();}cursor.addRow(row);return cursor;}catch(FileNotFoundException e){throw new IllegalArgumentException(e);}}
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only recordings provider");}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException("Read only recordings provider");}
    @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException("Read only recordings provider");}
}
