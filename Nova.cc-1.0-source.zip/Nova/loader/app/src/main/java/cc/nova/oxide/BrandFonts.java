package cc.nova.oxide;
import android.content.Context;
import android.graphics.Typeface;
final class BrandFonts {
 private static final Typeface[] cache=new Typeface[3];
 private static synchronized Typeface get(Context c,int style){
  if(cache[style]==null)try{cache[style]=Typeface.createFromAsset(c.getAssets(),"fonts/"+new String[]{"DejaVuSans.ttf","DejaVuSans-Bold.ttf","DejaVuSans-ExtraLight.ttf"}[style]);}catch(RuntimeException e){cache[style]=Typeface.create("sans-serif",style==1?Typeface.BOLD:Typeface.NORMAL);}
  return cache[style];
 }
 static Typeface regular(Context c){return get(c,0);}
 static Typeface bold(Context c){return get(c,1);}
 static Typeface display(Context c){return get(c,2);}
}
