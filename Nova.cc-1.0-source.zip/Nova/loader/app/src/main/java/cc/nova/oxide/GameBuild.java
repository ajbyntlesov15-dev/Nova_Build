package cc.nova.oxide;
final class GameBuild {
 final String id,version;final long code;
 private GameBuild(String id,String version,long code){this.id=id;this.version=version;this.code=code;}
 static final GameBuild CURRENT=new GameBuild("current","1.19.12025",12025);
 boolean matches(String version,long code){return this.version.equals(version)&&this.code==code;}
 static GameBuild fromId(String id){return CURRENT;}
}
