package cc.nova.oxide;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageInfo;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private static final ExecutorService WORKER=Executors.newSingleThreadExecutor();
    private static final String GAME="com.catsbit.oxidesurvivalisland";
    private static final int START=1,STOP=2,DIAGNOSTICS=3,ROOT_CHECK=4;
    private static final Session SESSION=new Session();
    private static final class Session {
        boolean busy,failed;int operation,completed,serial;String detail="";
        WeakReference<MainActivity> observer=new WeakReference<>(null);
        synchronized boolean begin(int action){if(busy)return false;busy=true;failed=false;operation=action;return true;}
        synchronized void finish(String result,boolean error){detail=result;failed=error;busy=false;completed=operation;serial++;MainActivity a=observer.get();if(a!=null)a.runOnUiThread(a::renderSession);}
        synchronized void attach(MainActivity a){observer=new WeakReference<>(a);}
        synchronized void detach(MainActivity a){if(observer.get()==a)observer.clear();}
    }
    private TextView status,details,statusDot;
    private Button start,stop,openGame;
    private String control;
    private boolean english,dark,haptics;
    private int bg,cardColor,ink,muted,line,primary,accent,softAccent;
    private int seenSerial;
    private Dialog settings,gameBuildPicker;private CompanionPanels companion;private boolean panelResumed;
    private EditText keyInput;private String keyDraft="";
    private boolean systemUiTransition=false;
    private void beforeSystemUi(){systemUiTransition=true;VirtualOverlay.setLauncherVisible(true);}
    private void openOutside(Intent intent){beforeSystemUi();startActivity(intent);}
    private String tx(String ru,String en){return LocaleStrings.text(ru,en,prefs().getInt("language",9));}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private android.content.SharedPreferences prefs(){return getPreferences(MODE_PRIVATE);}
    private void palette(){
        english=LocaleStrings.selected(prefs().getInt("language",9))!=0;haptics=prefs().getBoolean("haptics",true);
        int mode=prefs().getInt("theme",2);dark=mode==2||(mode==0&&(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES);
        int index=1;
        primary=new int[]{0xffc92d42,0xff704dff,0xff245bb5,0xff137b6e}[index];
        accent=dark?new int[]{0xffff8a98,0xffc3aaff,0xff9cbfff,0xff82d6c5}[index]:primary;
        bg=dark?0xff080b16:0xfff7f7fa;cardColor=dark?0xff12162a:Color.WHITE;
        ink=dark?0xfff4f4f8:0xff202027;muted=dark?0xffa8b6cc:0xff727280;line=dark?0xff2b3c56:0xffe5e5ec;
        softAccent=blend(cardColor,accent,dark?.12f:.07f);
    }
    private static int blend(int a,int b,float f){return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));}
    @Override public void onCreate(Bundle state){super.onCreate(state);control="/data/local/tmp/nova-"+android.os.Process.myUid();if(state!=null){seenSerial=state.getInt("seenSerial",0);capturePending=state.getBoolean("capturePending",false);captureDeadline=state.getLong("captureDeadline",0);companionPending=state.getBoolean("companionPending",false);}refreshPage();if(handlePanelIntent(getIntent(),true)){}else if(state==null&&hasAccess()){getWindow().getDecorView().post(this::openActivationChannel);}}
    @Override protected void onStart(){super.onStart();recordUiActive=true;recordHandler.removeCallbacks(recordUiHeartbeat);recordUiHeartbeat.run();SESSION.attach(this);renderSession();}
    @Override protected void onStop(){recordUiActive=false;syncRecordUi();recordWaitUntil=0;recordHandler.removeCallbacks(awaitRecording);SESSION.detach(this);super.onStop();}
    @Override protected void onSaveInstanceState(Bundle state){state.putInt("seenSerial",seenSerial);state.putBoolean("capturePending",capturePending);state.putLong("captureDeadline",captureDeadline);state.putBoolean("companionPending",companionPending);super.onSaveInstanceState(state);}
    @Override protected void onDestroy(){recordHandler.removeCallbacks(recordUiHeartbeat);ScreenRecordService.writeUi(this,isChangingConfigurations()&&(capturePending||companionPending));recordHandler.removeCallbacks(awaitRecording);if(recordDialog!=null)recordDialog.dismiss();if(settings!=null)settings.dismiss();if(gameBuildPicker!=null)gameBuildPicker.dismiss();if(companion!=null)companion.close();super.onDestroy();}
    private KeyAccess keyAccess(){return new KeyAccess(this);}
    private File accessFile(){return keyAccess().file();}
    private boolean hasAccess(){return keyAccess().hasAccess();}
    private void refreshPage(){palette();if(hasAccess())showMainScreen();else showKeyScreen();}
    private void tap(View v){if(haptics)v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);}
    private GradientDrawable surface(int color,int radius,int border){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(border!=0)d.setStroke(dp(1),border);return d;}
    private GradientDrawable gradient(int top,int bottom,int radius,int border){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{top,bottom});
        d.setCornerRadius(dp(radius));
        if(border!=0)d.setStroke(dp(1),border);
        return d;
    }
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");t.setTypeface(BrandFonts.regular(this));t.setIncludeFontPadding(false);return t;}
    private LinearLayout.LayoutParams lp(int width,int height,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,height);p.topMargin=dp(top);return p;}
    private void space(LinearLayout parent,int height){parent.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height)));}
    private void centered(LinearLayout parent,View view,int top){LinearLayout.LayoutParams p=lp(-2,-2,top);p.gravity=Gravity.CENTER_HORIZONTAL;parent.addView(view,p);}
    private void systemBars(){
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(Build.VERSION.SDK_INT>=29){getWindow().setStatusBarContrastEnforced(false);getWindow().setNavigationBarContrastEnforced(false);}
        int flags=View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if(!dark)flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        if(Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();if(c!=null)c.setSystemBarsAppearance(dark?0:WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);}
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
    private LinearLayout page(boolean showTitle){
        if(keyInput!=null)keyDraft=keyInput.getText().toString();keyInput=null;status=null;details=statusDot=null;start=stop=openGame=null;systemBars();
        ScrollView scroll=new ScrollView(this);if(Build.VERSION.SDK_INT>=29)scroll.setForceDarkAllowed(false);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(24),dp(12),dp(24),dp(24));
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setGravity(Gravity.CENTER_HORIZONTAL);shell.addView(root,new LinearLayout.LayoutParams(Math.min(getResources().getDisplayMetrics().widthPixels-dp(12),dp(480)),-1));scroll.addView(shell);
        android.widget.FrameLayout backdrop=new android.widget.FrameLayout(this);
        backdrop.setBackground(gradient(blend(bg,accent,dark?.08f:.04f),bg,0,0));
        backdrop.addView(new NovaBackdrop(),new android.widget.FrameLayout.LayoutParams(-1,-1));
        backdrop.addView(scroll,new android.widget.FrameLayout.LayoutParams(-1,-1));
        setContentView(backdrop);
        scroll.setOnApplyWindowInsetsListener((v,i)->{if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=i.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return i;}v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i.consumeSystemWindowInsets();});scroll.requestApplyInsets();
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=text("Nova.cc",18,ink);brand.setLetterSpacing(.04f);brand.setTypeface(BrandFonts.bold(this));bar.addView(brand,new LinearLayout.LayoutParams(0,dp(44),1));brand.setGravity(Gravity.CENTER_VERTICAL);
        View settingsIcon=icon("settings",tx("Настройки","Settings"),v->{tap(v);showSettings();});LinearLayout.LayoutParams si=new LinearLayout.LayoutParams(dp(44),dp(44));si.leftMargin=dp(8);bar.addView(settingsIcon,si);root.addView(bar);
        space(root,18);
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("Nova");logo.setBackground(surface(bg,20,0));logo.setClipToOutline(true);
        try(InputStream in=getAssets().open("nova_logo.png")){logo.setImageDrawable(Drawable.createFromStream(in,"Nova"));}catch(IOException ignored){logo.setImageDrawable(new Glyph("play",Color.WHITE,48));}
        LinearLayout.LayoutParams il=new LinearLayout.LayoutParams(dp(176),dp(108));il.gravity=Gravity.CENTER_HORIZONTAL;root.addView(logo,il);
        if(showTitle){TextView title=text("Nova.cc",32,ink);title.setTypeface(BrandFonts.display(this));centered(root,title,20);}
        root.setAlpha(0);root.animate().alpha(1).setDuration(180).start();return root;
    }
    private final class NovaBackdrop extends View {
        private final Paint snowPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
        NovaBackdrop(){
            super(MainActivity.this);
            setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            snowPaint.setStrokeCap(Paint.Cap.ROUND);
        }
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            int width=getWidth(),height=getHeight();
            if(width<=0||height<=0)return;
            float time=(android.os.SystemClock.uptimeMillis()%120000L)/1000f;
            snowPaint.setStyle(Paint.Style.STROKE);snowPaint.setStrokeWidth(dp(1));snowPaint.setColor(0xff7860e8);snowPaint.setAlpha(35);
            int step=dp(42);for(int x=0;x<width;x+=step)canvas.drawLine(x,0,x,height,snowPaint);for(int y=0;y<height;y+=step)canvas.drawLine(0,y,width,y,snowPaint);
            snowPaint.setStyle(Paint.Style.FILL);snowPaint.setAlpha(24);canvas.drawCircle(width*.85f,height*.15f,dp(180),snowPaint);
            if(isShown()&&getWindowVisibility()==View.VISIBLE)postInvalidateDelayed(33);
        }
    }
    private View icon(String glyph,String description,View.OnClickListener action){ImageView image=new ImageView(this);image.setImageDrawable(new Glyph(glyph,ink,20));image.setPadding(dp(12),dp(12),dp(12),dp(12));image.setBackground(new RippleDrawable(ColorStateList.valueOf(blend(cardColor,ink,.12f)),surface(cardColor,14,line),null));image.setContentDescription(description);image.setFocusable(true);image.setLayoutParams(new LinearLayout.LayoutParams(dp(44),dp(44)));image.setOnClickListener(action);return image;}
    private LinearLayout card(LinearLayout parent){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(20),dp(20),dp(20),dp(20));GradientDrawable panel=gradient(blend(cardColor,accent,dark?.10f:.04f),cardColor,24,line);
        if(dark)panel.setAlpha(218);
        c.setBackground(panel);parent.addView(c,lp(-1,-2,24));return c;}
    private void styleButton(Button b,int fill,int color,int border){b.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled},new int[]{}},new int[]{muted,color}));b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22808080),gradient(blend(fill,Color.WHITE,dark?.07f:.04f),fill,16,border),null));}
    private Button button(LinearLayout parent,String label,boolean primaryStyle,View.OnClickListener action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(16);b.setTypeface(BrandFonts.bold(this));b.setStateListAnimator(null);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(16),0,dp(16),0);styleButton(b,primaryStyle?primary:cardColor,primaryStyle?Color.WHITE:ink,primaryStyle?0:line);parent.addView(b,lp(-1,dp(56),12));b.setOnClickListener(v->{tap(v);action.onClick(v);});return b;}
    private void pill(LinearLayout parent,String value){TextView t=text(value,11,muted);t.setLetterSpacing(.06f);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(7),dp(12),dp(7));t.setBackground(surface(cardColor,30,line));centered(parent,t,12);}
    private void showKeyScreen(){

        LinearLayout root=page(true);pill(root,tx("ДОСТУП","ACCESS"));LinearLayout form=card(root);

        TextView caption=text(tx("Ключ доступа","Access key"),14,muted);form.addView(caption);space(form,12);

        EditText input=new EditText(this);keyInput=input;input.setText(keyDraft);input.setSelection(input.length());input.setSingleLine(true);input.setTextColor(ink);input.setTypeface(BrandFonts.regular(this));input.setTextSize(16);input.setHintTextColor(muted);input.setHint("NOVA-…");input.setPadding(dp(16),0,dp(16),0);input.setBackground(surface(bg,14,line));input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);form.addView(input,new LinearLayout.LayoutParams(-1,dp(56)));

        TextView error=text("",13,dark?0xffff97a5:0xffad2f41);error.setVisibility(View.GONE);form.addView(error,lp(-1,-2,12));

        Runnable submit=()->{try{if(!keyAccess().activate(input.getText().toString())){error.setVisibility(View.VISIBLE);error.setText(tx("Проверь ключ и подлинность сборки.","Check the key and app build."));return;}}catch(IOException e){error.setVisibility(View.VISIBLE);error.setText(tx("Не удалось сохранить доступ.","Could not save access."));return;}InputMethodManager keyboard=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(keyboard!=null)keyboard.hideSoftInputFromWindow(input.getWindowToken(),0);keyDraft="";keyInput=null;showMainScreen();openActivationChannel();};

        button(form,tx("Продолжить","Continue"),true,v->submit.run());input.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE){submit.run();return true;}return false;});footer(root);

    }

    private void showVipActivation(){

        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),dp(8),dp(20),dp(8));

        EditText key=new EditText(this);key.setHint("NOVA-…");key.setSingleLine(true);form.addView(key);

        TextView message=text(tx("Бессрочный ключ Nova.cc. Интернет для проверки не нужен.","Permanent Nova.cc key. Offline verification."),13,muted);form.addView(message);

        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(tx("Ключ Nova.cc","Nova.cc key")).setView(form).setNegativeButton(tx("Отмена","Cancel"),null).setPositiveButton(tx("Активировать","Activate"),null).create();

        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{

            final String code=key.getText().toString();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);message.setText(tx("Проверка ключа…","Checking key…"));

            WORKER.execute(()->{try{VipAccess access=new VipAccess(this);access.activate(code);runOnUiThread(()->{dialog.dismiss();showMainScreen();});}catch(Exception e){runOnUiThread(()->{message.setText(e.getMessage());dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);});}});

        }));dialog.show();

    }

    private boolean vipTab=true;
    private void showMainScreen(){
        LinearLayout root=page(false);
        TextView hero=text("Nova.cc",38,ink);hero.setTypeface(BrandFonts.display(this));root.addView(hero);space(root,8);
        TextView intro=text(tx("Твоя конфигурация. Твой стиль.","Your setup. Your style."),15,muted);root.addView(intro);space(root,12);
        String version="";boolean installed=false;
        try{PackageInfo p=getPackageManager().getPackageInfo(GAME,0);version=p.versionName==null?"":p.versionName;installed=true;}catch(Exception ignored){}
        pill(root,installed?("OXIDE"+(version.isEmpty()?"":"  ·  "+version)):tx("OXIDE НЕ НАЙДЕНА","OXIDE NOT FOUND"));
        LinearLayout actions=card(root);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        statusDot=text("●",13,muted);row.addView(statusDot,new LinearLayout.LayoutParams(dp(22),-2));status=text(tx("Готово к запуску","Ready"),14,ink);status.setTypeface(BrandFonts.bold(this));row.addView(status,new LinearLayout.LayoutParams(0,-2,1));
        details=text(tx("Подробнее","Details"),12,accent);details.setPadding(dp(8),dp(8),0,dp(8));details.setVisibility(View.GONE);details.setOnClickListener(v->{tap(v);showDetails();});row.addView(details);actions.addView(row);space(actions,8);

        start=button(actions,tx("Запустить Nova.cc","Launch Nova.cc"),true,v->{if(vipTab&&!new VipAccess(this).hasAccess()){showVipActivation();return;}runTask(ROOT_CHECK,()->root("true",60,true));});start.setCompoundDrawablePadding(dp(12));start.setCompoundDrawablesWithIntrinsicBounds(new Glyph("play",Color.WHITE,18),null,null,null);
        button(actions,tx("Запуск без рут прав","Start without root"),false,v->showGameBuildChoice(true));
        openGame=button(actions,tx("Открыть игру","Open game"),false,v->launchGame());
        stop=button(actions,tx("Остановить меню","Stop menu"),false,v->runTask(STOP,()->stopOverlay()));styleButton(stop,dark?0xff352129:0xfffcebed,dark?0xffff97a5:0xffad2f41,0);
        if(prefs().getBoolean("virtual_mode",false)){
            Button visibility=button(root,tx("Показать / скрыть окна Android","Show / hide Android overlays"),false,v->{tap(v);VirtualOverlay.toggleWindows();});
        }
        status.setContentDescription(tx("Статус. Удерживайте для копирования диагностики.","Status. Long press to copy diagnostics."));status.setOnLongClickListener(v->{tap(v);String value; synchronized(SESSION){value=SESSION.detail;}if(value.isEmpty())return false;copy(value);return true;});
        footer(root);renderSession();
    }
    private void addEditionTab(LinearLayout tabs,String title,boolean vip){
        Button tab=button(tabs,title,vipTab==vip,v->{tap(v);vipTab=vip;showMainScreen();});
        LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(0,dp(48),1);
        layout.setMargins(dp(4),0,dp(4),dp(8));
        tab.setLayoutParams(layout);
        tab.setSelected(vipTab==vip);
    }
    private void footer(LinearLayout root){
        space(root,24);
        TextView version=text("NOVA.CC  /  1.0  /  RELEASE 12025",11,muted);centered(root,version,12);
    }
    private void launchGame(){
        Intent intent=getPackageManager().getLaunchIntentForPackage(GAME);
        if(intent==null){localError(tx("Oxide не установлена.","Oxide is not installed."));return;}
        try{systemUiTransition=false;VirtualOverlay.setLauncherVisible(false);startActivity(intent);}catch(RuntimeException e){localError(e.getMessage());}
    }

    private void openActivationChannel(){}
    private void openChannelSafely(){try{openChannel();}catch(RuntimeException e){localError(tx("Не удалось открыть сообщество.","Could not open community."));}}
    private void openChannel(){Toast.makeText(this,"Nova.cc · Release 12025",Toast.LENGTH_SHORT).show();}
    private void localError(String message){synchronized(SESSION){if(!SESSION.busy){SESSION.failed=true;SESSION.detail=message==null?tx("Неизвестная ошибка","Unknown error"):message;}}renderSession();}
    private void renderSession(){
        if(status==null||isDestroyed())return;boolean busy,error;int action,serial;String detail;
        synchronized(SESSION){busy=SESSION.busy;error=SESSION.failed;action=busy?SESSION.operation:SESSION.completed;serial=SESSION.serial;detail=SESSION.detail;}
        status.setText(busy?(action==ROOT_CHECK?tx("Запрашиваем root…","Requesting root…"):tx("Выполняется…","Working…")):error?(action==ROOT_CHECK?tx("Не удалось получить root","Could not obtain root"):tx("Нужна проверка","Check required")):action==START?tx("Запуск подтверждён","Launch confirmed"):action==STOP?tx("Меню остановлено","Menu stopped"):tx("Готово к запуску","Ready"));
        statusDot.setTextColor(busy?(dark?0xffe5b76b:0xffa66a14):error?(dark?0xffff97a5:0xffad2f41):action==START?(dark?0xff82d6b4:0xff19734f):muted);
        details.setVisibility(error&&!detail.isEmpty()?View.VISIBLE:View.GONE);start.setEnabled(!busy);stop.setEnabled(!busy);openGame.setEnabled(!busy);
        start.setAlpha(busy?.55f:1);stop.setAlpha(busy?.55f:1);openGame.setAlpha(busy?.55f:1);
        if(serial>seenSerial){seenSerial=serial;if(!busy&&!error){
            if(action==DIAGNOSTICS)copy(detail);
            if(action==ROOT_CHECK&&!isFinishing())showGameBuildChoice(false);
        }}
    }
    private AlertDialog.Builder dialogBuilder(){return new AlertDialog.Builder(new ContextThemeWrapper(this,dark?android.R.style.Theme_Material_Dialog_Alert:android.R.style.Theme_Material_Light_Dialog_Alert));}
    private void showDetails(){String detail;synchronized(SESSION){detail=SESSION.detail;}if(detail.isEmpty())detail=tx("Пока нет данных.","No details yet.");final String value=detail;AlertDialog dialog=dialogBuilder().setTitle(tx("Подробности","Details")).setMessage(value).setPositiveButton(tx("Скопировать","Copy"),(d,w)->copy(value)).setNegativeButton(tx("Готово","Done"),null).create();dialog.setOnShowListener(d->{TextView message=dialog.findViewById(android.R.id.message);if(message!=null)message.setTextIsSelectable(true);});dialog.show();polishDialog(dialog);}
    private void copy(String value){ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(clipboard!=null){clipboard.setPrimaryClip(ClipData.newPlainText("Nova diagnostics",value));Toast.makeText(this,tx("Скопировано","Copied"),Toast.LENGTH_SHORT).show();}}
    private void settingRow(LinearLayout parent,String title,String value,View.OnClickListener action){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),dp(16),dp(4),dp(16));TextView name=text(title,15,ink);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));TextView current=text(value+"  ›",13,muted);row.addView(current);row.setBackground(new RippleDrawable(ColorStateList.valueOf(blend(cardColor,accent,.12f)),null,surface(Color.WHITE,12,0)));row.setOnClickListener(v->{tap(v);action.onClick(v);});parent.addView(row,new LinearLayout.LayoutParams(-1,dp(56)));}
    private void choose(String title,String[] options,int selected,java.util.function.IntConsumer changed){AlertDialog dialog=dialogBuilder().setTitle(title).setSingleChoiceItems(options,selected,(d,index)->{changed.accept(index);d.dismiss();if(settings!=null)settings.dismiss();refreshPage();}).setNegativeButton(tx("Отмена","Cancel"),null).create();dialog.show();polishDialog(dialog);}
    private void polishDialog(AlertDialog dialog){for(int id:new int[]{AlertDialog.BUTTON_POSITIVE,AlertDialog.BUTTON_NEGATIVE,AlertDialog.BUTTON_NEUTRAL}){Button button=dialog.getButton(id);if(button!=null)button.setTextColor(accent);}ListView list=dialog.getListView();if(list!=null)list.post(()->{for(int i=0;i<list.getChildCount();i++){View child=list.getChildAt(i);if(child instanceof CheckedTextView){CheckedTextView row=(CheckedTextView)child;row.setTextColor(ink);row.setCheckMarkTintList(ColorStateList.valueOf(accent));}}});}
    private CompanionPanels tools(){if(companion==null)companion=new CompanionPanels(this,this::root,control,english,cardColor,ink,muted,accent);companion.configure(english,cardColor,ink,muted,accent);return companion;}
    private boolean handlePanelIntent(Intent intent,boolean deferred){String page=intent.getStringExtra("recorder_action");if(!"config".equals(page)&&!"profiles".equals(page)&&!"layout".equals(page)&&!"history".equals(page))return false;intent.removeExtra("recorder_action");getSharedPreferences("navigation",MODE_PRIVATE).edit().putString("pending_panel",page).commit();getWindow().getDecorView().post(this::openPendingPanel);return true;}
    private void openPendingPanel(){if(!panelResumed||isFinishing()||isDestroyed()||!hasAccess())return;android.content.SharedPreferences p=getSharedPreferences("navigation",MODE_PRIVATE);String page=p.getString("pending_panel","");if(page.isEmpty())return;p.edit().remove("pending_panel").commit();if("config".equals(page))showRecording();else if("profiles".equals(page)||"layout".equals(page)||"history".equals(page)){if(settings==null||!settings.isShowing())showSettings();tools().show(page);}}
    @Override protected void onResume(){super.onResume();systemUiTransition=false;VirtualOverlay.setLauncherVisible(true);panelResumed=true;getWindow().getDecorView().post(this::openPendingPanel);}
    @Override protected void onPause(){if(!systemUiTransition)VirtualOverlay.setLauncherVisible(false);panelResumed=false;super.onPause();}
    private void showSettings(){
        if(settings!=null&&settings.isShowing())return;
        settings=new Dialog(new ContextThemeWrapper(this,dark?android.R.style.Theme_Material_Dialog:android.R.style.Theme_Material_Light_Dialog));settings.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);if(Build.VERSION.SDK_INT>=29)body.setForceDarkAllowed(false);body.setPadding(dp(24),dp(24),dp(24),dp(32));GradientDrawable back=surface(cardColor,28,0);back.setCornerRadii(new float[]{dp(28),dp(28),dp(28),dp(28),0,0,0,0});body.setBackground(back);
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);TextView title=text(tx("Настройки","Settings"),24,ink);title.setTypeface(BrandFonts.bold(this));heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));heading.addView(icon("close",tx("Готово","Done"),v->{tap(v);settings.dismiss();}));body.addView(heading);space(body,16);
        String[] themes={tx("Системная","System"),tx("Светлая","Light"),tx("Тёмная","Dark")};int theme=Math.max(0,Math.min(2,prefs().getInt("theme",2)));
        settingRow(body,tx("Тема","Theme"),themes[theme],v->choose(tx("Тема","Theme"),themes,theme,index->prefs().edit().putInt("theme",index).apply()));
        settingRow(body,tx("Язык","Language"),LocaleStrings.NAMES[Math.max(0,Math.min(9,prefs().getInt("language",9)))],v->choose(tx("Язык","Language"),LocaleStrings.NAMES,prefs().getInt("language",9),index->prefs().edit().putInt("language",index).apply()));
        LinearLayout feedback=new LinearLayout(this);feedback.setGravity(Gravity.CENTER_VERTICAL);TextView feedbackTitle=text(tx("Тактильный отклик","Haptic feedback"),15,ink);feedback.addView(feedbackTitle,new LinearLayout.LayoutParams(0,dp(56),1));feedbackTitle.setGravity(Gravity.CENTER_VERTICAL);Switch vibration=new Switch(this);vibration.setContentDescription(feedbackTitle.getText());vibration.setChecked(haptics);vibration.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{accent,muted}));vibration.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{softAccent,line}));vibration.setOnCheckedChangeListener((b,checked)->{haptics=checked;prefs().edit().putBoolean("haptics",checked).apply();tap(b);});feedback.addView(vibration);body.addView(feedback);
        View rule=new View(this);rule.setBackgroundColor(line);body.addView(rule,lp(-1,dp(1),16));
        settingRow(body,tx("Профили настроек","Settings profiles"),tx("Открыть","Open"),v->{tools().show("profiles");});
        settingRow(body,tx("Редактор интерфейса","Interface editor"),tx("Предпросмотр","Preview"),v->{tools().show("layout");});
        settingRow(body,tx("История записей","Recording history"),tx("Смотреть","Browse"),v->{tools().show("history");});
        settingRow(body,tx("Запись экрана","Screen recording"),ScreenRecordService.SESSION.busy()?tx("REC","REC"):tx("Настроить","Configure"),v->{settings.dismiss();showRecording();});
        settingRow(body,tx("Диагностика","Diagnostics"),tx("Скопировать","Copy"),v->{settings.dismiss();runTask(DIAGNOSTICS,()->prefs().getBoolean("virtual_mode",false)?virtualLog():root("if [ -f "+q(control+"/overlay.log")+" ]; then tail -n 120 "+q(control+"/overlay.log")+"; else echo 'No overlay log. Start the menu first.'; fi"));});
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);scroll.addView(body);settings.setContentView(scroll);Window window=settings.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams attrs=window.getAttributes();attrs.dimAmount=.45f;attrs.gravity=Gravity.BOTTOM;window.setAttributes(attrs);}
        settings.show();if(window!=null){int limit=(int)(getResources().getDisplayMetrics().heightPixels*.85f);body.measure(View.MeasureSpec.makeMeasureSpec(getResources().getDisplayMetrics().widthPixels,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));window.setLayout(-1,Math.min(body.getMeasuredHeight(),limit));window.setNavigationBarColor(cardColor);}
    }
    private interface Job{String execute() throws Exception;}
    private void runTask(int action,Job job){
        if(!hasAccess()){showKeyScreen();return;}if(!SESSION.begin(action))return;renderSession();
        WORKER.execute(()->{String result;boolean error=false;try{result=job.execute();if(action==START&&!(result.contains("меню запущено")||result.contains("Меню уже запущено")||result.equals(tx("Виртуальный модуль запущен в лоадере.","Virtual module started inside the launcher."))))error=true;if(action==STOP&&result.contains("ещё не подтверждено"))error=true;}catch(Exception e){error=true;result=tx("Ошибка: ","Error: ")+e.getMessage();}SESSION.finish(result,error);});
    }
    private final class Glyph extends Drawable {
        private final String type;private final int color,size;private int alpha=255;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Glyph(String type,int color,int size){this.type=type;this.color=color;this.size=dp(size);}
        @Override public int getIntrinsicWidth(){return size;}@Override public int getIntrinsicHeight(){return size;}
        @Override public void draw(Canvas canvas){Rect r=getBounds();canvas.save();canvas.translate(r.left,r.top);canvas.scale(r.width()/24f,r.height()/24f);p.setColor(color);p.setAlpha(alpha);p.setStrokeWidth(1.7f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);
            if(type.equals("play")){p.setStyle(Paint.Style.FILL);Path path=new Path();path.moveTo(8,4);path.lineTo(20,12);path.lineTo(8,20);path.close();canvas.drawPath(path,p);}
            else if(type.equals("telegram")){Path plane=new Path();plane.moveTo(2,10);plane.lineTo(22,3);plane.lineTo(18,21);plane.lineTo(12,16);plane.lineTo(8,19);plane.lineTo(7,13);plane.close();canvas.drawPath(plane,p);canvas.drawLine(7,13,18,7,p);canvas.drawLine(12,16,18,7,p);}
            else if(type.equals("close")){canvas.drawLine(6,6,18,18,p);canvas.drawLine(18,6,6,18,p);}
            else if(type.equals("sun")){canvas.drawCircle(12,12,4,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;canvas.drawLine(12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10,p);}}
            else if(type.equals("moon")){Path moon=new Path();moon.moveTo(19.6f,15.3f);moon.cubicTo(8,19,4,8,11,3);moon.cubicTo(1,4,0,17,9,21);moon.cubicTo(14,23,18,20,19.6f,15.3f);canvas.drawPath(moon,p);}
            else{Path gear=new Path();for(int i=0;i<32;i++){double angle=i*Math.PI/16-Math.PI/2;float radius=(i%4==1||i%4==2)?10:8;float x=12+(float)Math.cos(angle)*radius,y=12+(float)Math.sin(angle)*radius;if(i==0)gear.moveTo(x,y);else gear.lineTo(x,y);}gear.close();canvas.drawPath(gear,p);canvas.drawCircle(12,12,3.2f,p);}
            canvas.restore();
        }
        @Override public void setAlpha(int alpha){this.alpha=alpha;invalidateSelf();}@Override public void setColorFilter(ColorFilter filter){p.setColorFilter(filter);}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
    private static final int CAPTURE_REQUEST=1440,MIC_REQUEST=1441,STORAGE_REQUEST=1442,NOTIFICATION_REQUEST=1443;
    private android.app.Dialog recordDialog;
    private long recordWaitUntil,captureDeadline,recordCompletionBase;private boolean capturePending,recordUiActive,companionPending;
    private final Runnable recordUiHeartbeat=new Runnable(){public void run(){if(isDestroyed())return;if(capturePending&&android.os.SystemClock.uptimeMillis()>captureDeadline)capturePending=false;ScreenRecordService.writeUi(MainActivity.this,recordUiActive||capturePending||companionPending);if(recordUiActive||capturePending||companionPending)recordHandler.postDelayed(this,1000);}};
    private void syncRecordUi(){recordHandler.removeCallbacks(recordUiHeartbeat);if(recordUiActive||capturePending||companionPending)recordUiHeartbeat.run();else ScreenRecordService.writeUi(this,false);}
    void startCompanionIntent(Intent intent,int request){if(companionPending)return;companionPending=true;syncRecordUi();try{startActivityForResult(intent,request);}catch(RuntimeException e){companionPending=false;syncRecordUi();throw e;}}
    private void requestRecording(){if(capturePending)return;capturePending=true;captureDeadline=android.os.SystemClock.uptimeMillis()+300000;syncRecordUi();continueRecordingRequest();}

    private final android.os.Handler recordHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable awaitRecording=new Runnable(){public void run(){
        if(isDestroyed()||recordWaitUntil==0)return;
        int state=ScreenRecordService.SESSION.state();
        if(state==RecordingSession.RECORDING){recordWaitUntil=0;launchGame();return;}
        if(state==RecordingSession.IDLE&&ScreenRecordService.SESSION.completions()!=recordCompletionBase){recordWaitUntil=0;showRecording();return;}
        if(state==RecordingSession.ERROR){recordWaitUntil=0;Toast.makeText(MainActivity.this,tx("Запись не началась. Открой подробности.","Recording failed. Open recording details."),Toast.LENGTH_LONG).show();showRecording();return;}
        if(android.os.SystemClock.uptimeMillis()>=recordWaitUntil){recordWaitUntil=0;startService(new Intent(MainActivity.this,ScreenRecordService.class).setAction(ScreenRecordService.STOP));Toast.makeText(MainActivity.this,tx("Подготовка записи заняла слишком много времени.","Recording setup timed out."),Toast.LENGTH_LONG).show();showRecording();return;}
        recordHandler.postDelayed(this,100);
    }};
    private android.content.SharedPreferences recordingPrefs(){return getSharedPreferences(ScreenRecordService.PREFS,MODE_PRIVATE);}
    private void recordingChoice(String key,String title,String[] values,int fallback){int selected=ScreenRecordService.index(recordingPrefs(),key,values.length,fallback);AlertDialog dialog=dialogBuilder().setTitle(title).setSingleChoiceItems(values,selected,(d,i)->{recordingPrefs().edit().putInt(key,i).apply();d.dismiss();if(recordDialog!=null)recordDialog.dismiss();showRecording();}).setNegativeButton(tx("Отмена","Cancel"),null).create();dialog.show();polishDialog(dialog);}
    private void showRecording(){
        if(!hasAccess()){showKeyScreen();return;}palette();
        if(recordDialog!=null)recordDialog.dismiss();LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(8),dp(20),dp(16));
        android.content.SharedPreferences p=recordingPrefs();boolean busy=ScreenRecordService.SESSION.busy();
        String[] quality={"720p","1080p",tx("Исходное","Native")},fps={"24 FPS","30 FPS","60 FPS"},rate={"4 Mbps","6 Mbps","8 Mbps","12 Mbps","16 Mbps","24 Mbps","32 Mbps"},orientation={tx("Альбомная · для игры","Landscape · game"),tx("Как экран","Match display")};
        if(!busy){
            settingRow(content,tx("Качество","Quality"),quality[ScreenRecordService.index(p,"quality",3,0)],v->recordingChoice("quality",tx("Качество","Quality"),quality,0));
            settingRow(content,"FPS",fps[ScreenRecordService.index(p,"fps",3,1)],v->recordingChoice("fps","FPS",fps,1));
            settingRow(content,tx("Битрейт","Bitrate"),rate[ScreenRecordService.index(p,"bitrate",7,2)],v->recordingChoice("bitrate",tx("Битрейт","Bitrate"),rate,2));
            settingRow(content,tx("Ориентация","Orientation"),orientation[ScreenRecordService.index(p,"orientation",2,0)],v->recordingChoice("orientation",tx("Ориентация","Orientation"),orientation,0));
            LinearLayout audio=new LinearLayout(this);audio.setGravity(Gravity.CENTER_VERTICAL);TextView mic=text(tx("Микрофон","Microphone"),15,ink);audio.addView(mic,new LinearLayout.LayoutParams(0,dp(52),1));mic.setGravity(Gravity.CENTER_VERTICAL);Switch toggle=new Switch(this);toggle.setContentDescription(mic.getText());toggle.setChecked(p.getBoolean("mic",false));toggle.setOnCheckedChangeListener((b,value)->p.edit().putBoolean("mic",value).apply());audio.addView(toggle);content.addView(audio);
            TextView caption=text(tx("Видео всего экрана с оверлеем. Без микрофона — без звука. Если кодек не поддерживает режим, параметры будут снижены.","Full screen video with overlay. Audio is off unless microphone is enabled. Unsupported encoder settings are reduced."),12,muted);caption.setPadding(0,dp(8),0,dp(8));content.addView(caption);
        }else{String label=ScreenRecordService.SESSION.state()==RecordingSession.RECORDING?tx("Идёт запись","Recording"):tx("Подготовка / сохранение…","Preparing / saving…");TextView active=text(label,18,accent);content.addView(active);RecordingProfile actual=ScreenRecordService.actual;if(actual!=null){TextView format=text(actual.width+" × "+actual.height+" · "+actual.fps+" FPS · "+(actual.bitrate/1000000f)+" Mbps",13,muted);content.addView(format,lp(-1,-2,12));}}
        String error=ScreenRecordService.SESSION.error();if(error.isEmpty())error=p.getString("last_error","");if(!error.isEmpty()){TextView failure=text(error,12,dark?0xffff97a5:0xffad2f41);failure.setTextIsSelectable(true);content.addView(failure,lp(-1,-2,12));}
        button(content,tx("История записей","Recording history"),false,v->{if(recordDialog!=null)recordDialog.dismiss();tools().show("history");});
        String last=p.getString("last_uri","");if(!last.isEmpty())button(content,tx("Последняя запись ↗","Last recording ↗"),false,v->{try{Intent open=new Intent(Intent.ACTION_VIEW).setDataAndType(android.net.Uri.parse(last),"video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);openOutside(open);}catch(RuntimeException e){Toast.makeText(this,tx("Не удалось открыть видео","Cannot open video"),Toast.LENGTH_LONG).show();}});
        ScrollView captureScroll=new ScrollView(this);captureScroll.addView(content);AlertDialog dialog=dialogBuilder().setTitle(tx("Запись экрана","Screen recording")).setView(captureScroll).setNegativeButton(tx("Готово","Done"),null).setPositiveButton(busy?tx("Остановить","Stop"):tx("Начать запись","Start recording"),null).create();recordDialog=dialog;dialog.setOnShowListener(d->{polishDialog(dialog);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{tap(v);dialog.dismiss();if(busy)startService(new Intent(this,ScreenRecordService.class).setAction(ScreenRecordService.STOP));else requestRecording();});});dialog.show();
    }
    private void continueRecordingRequest(){
        if(!hasAccess()||ScreenRecordService.SESSION.busy()){capturePending=false;syncRecordUi();return;}
        if(Build.VERSION.SDK_INT<29&&checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!=android.content.pm.PackageManager.PERMISSION_GRANTED){beforeSystemUi();requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},STORAGE_REQUEST);return;}
        if(recordingPrefs().getBoolean("mic",false)&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){beforeSystemUi();requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},MIC_REQUEST);return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED&&!recordingPrefs().getBoolean("notification_asked",false)){recordingPrefs().edit().putBoolean("notification_asked",true).apply();beforeSystemUi();requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST);return;}
        android.media.projection.MediaProjectionManager manager=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        try{Intent consent=Build.VERSION.SDK_INT>=34?manager.createScreenCaptureIntent(android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()):manager.createScreenCaptureIntent();beforeSystemUi();startActivityForResult(consent,CAPTURE_REQUEST);}catch(RuntimeException e){capturePending=false;syncRecordUi();Toast.makeText(this,tx("Запись экрана недоступна","Screen capture unavailable"),Toast.LENGTH_LONG).show();}
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] granted){super.onRequestPermissionsResult(request,permissions,granted);if(request==CompanionPanels.HISTORY_PERMISSION){tools().permissionResult(granted);return;}if(request!=MIC_REQUEST&&request!=STORAGE_REQUEST&&request!=NOTIFICATION_REQUEST)return;if(!capturePending)return;if(request==NOTIFICATION_REQUEST||(granted.length>0&&granted[0]==android.content.pm.PackageManager.PERMISSION_GRANTED))continueRecordingRequest();else{capturePending=false;syncRecordUi();Toast.makeText(this,tx("Разрешение не выдано","Permission denied"),Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==CompanionPanels.IMPORT||request==CompanionPanels.EXPORT||request==CompanionPanels.PLAYER){companionPending=false;syncRecordUi();}if(tools().activityResult(request,result,data))return;if(request!=CAPTURE_REQUEST||!capturePending)return;capturePending=false;syncRecordUi();if(result!=RESULT_OK||data==null){Toast.makeText(this,tx("Запись отменена","Recording canceled"),Toast.LENGTH_SHORT).show();return;}if(ScreenRecordService.SESSION.busy())return;try{recordCompletionBase=ScreenRecordService.SESSION.completions();startForegroundService(new Intent(this,ScreenRecordService.class).setAction(ScreenRecordService.START).putExtra("resultCode",result).putExtra("consent",data));recordWaitUntil=android.os.SystemClock.uptimeMillis()+15000;recordHandler.post(awaitRecording);}catch(RuntimeException e){Toast.makeText(this,tx("Не удалось запустить запись","Could not start recording"),Toast.LENGTH_LONG).show();}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handlePanelIntent(intent,false);}

    private static String q(String value) { return "'"+value.replace("'","'\\''")+"'"; }
    private static final String ROOT_OK="NOVA_ROOT_OK";
    private static final String ROOT_DENIED="NOVA_ROOT_DENIED";
    private Process startSu(String command,File output,boolean interactive) throws IOException {
        IOException failure=null;
        for(String executable:new String[]{"su","/system/bin/su","/system/xbin/su"}){
            try{
                ProcessBuilder builder=interactive?new ProcessBuilder(executable):new ProcessBuilder(executable,"-c",command);
                return builder.redirectErrorStream(true).redirectOutput(output).start();
            }catch(IOException e){
                if(failure==null)failure=e;
                else failure.addSuppressed(e);
            }
        }
        throw new IOException(tx("Не удалось запустить su. Проверь доступ Nova в Magisk или KernelSU.",
                                 "Could not start su. Check Nova access in Magisk or KernelSU."),failure);
    }
    private String root(String command) throws Exception {return root(command,30,false);}
    private String root(String command,int timeoutSeconds,boolean interactive) throws Exception {
        File output=File.createTempFile("nova-su-",".txt",getCacheDir());
        Process p=null;
        try {
            String wrapped="uid=$(/system/bin/id -u) || exit 78; " +
                "if [ \"$uid\" != 0 ]; then printf '%s\\n' "+ROOT_DENIED+"; exit 77; fi; " +
                "printf '%s\\n' "+ROOT_OK+"; "+command;
            p=startSu(wrapped,output,interactive);
            IOException shellInputError=null;
            if(interactive){
                try(java.io.OutputStream input=p.getOutputStream()){
                    input.write((wrapped+"\nexit\n").getBytes(StandardCharsets.UTF_8));
                }catch(IOException e){shellInputError=e;}
            }
            if(!p.waitFor(timeoutSeconds,TimeUnit.SECONDS)){
                throw new IOException(tx("Истекло время ожидания root (с): ","Root request timed out (s): ")+timeoutSeconds);
            }
            String result;
            try(InputStream stream=new FileInputStream(output)){
                byte[] bytes=new byte[24000];int used=0,n;
                while(used<bytes.length&&(n=stream.read(bytes,used,bytes.length-used))>0)used+=n;
                result=new String(bytes,0,used,StandardCharsets.UTF_8).trim();
            }
            java.util.regex.Matcher handshake=java.util.regex.Pattern.compile("(?m)^("+ROOT_OK+"|"+ROOT_DENIED+")\\r?$").matcher(result);
            if(!handshake.find()){
                throw new IOException(tx("Root не выдан. Проверь разрешение Nova в Magisk или KernelSU. ","Root access was not granted. Check Nova permissions in Magisk or KernelSU. ")+tx("Код ","Exit code ")+p.exitValue()+": "+result,shellInputError);
            }
            if(handshake.group(1).equals(ROOT_DENIED))throw new IOException(tx("Команда su запустилась без UID 0.","The su command started without UID 0."));
            result=(result.substring(0,handshake.start())+result.substring(handshake.end())).trim();
            if(p.exitValue()!=0)throw new IOException(tx("Root подтверждён. Ошибка команды, код ","Root confirmed. Command failed, exit code ")+p.exitValue()+": "+result);
            return result;
        } finally { if(p!=null && p.isAlive())p.destroyForcibly(); output.delete(); }
    }
    private void showGameBuildChoice(boolean direct){
        if(gameBuildPicker!=null&&gameBuildPicker.isShowing())return;
        synchronized(SESSION){if(SESSION.busy)return;}
        if(!hasAccess()){showKeyScreen();return;}
        final boolean vip=vipTab;
        if(vip&&!new VipAccess(this).hasAccess()){showVipActivation();return;}
        GameBuild build=GameBuild.CURRENT;prefs().edit().putString("game_build",build.id).apply();runTask(START,()->startOverlay(build,direct,vip));
    }
    private String startOverlay(GameBuild build,boolean direct,boolean vip) throws Exception {
        if(!hasAccess())throw new IOException(tx("Сначала введи ключ","Enter the key first"));
        if(vip)new VipAccess(this).prepare();
        startForegroundService(new Intent(this,OverlayService.class));
        PackageInfo installed;
        try{installed=getPackageManager().getPackageInfo(GAME,0);}catch(android.content.pm.PackageManager.NameNotFoundException e){throw new IOException(tx("Не найден пакет игры: ","Game package not found: ")+GAME);}
        long installedCode=Build.VERSION.SDK_INT>=28?installed.getLongVersionCode():installed.versionCode;
        if(!build.matches(installed.versionName,installedCode))throw new IOException(tx("Выбран профиль ","Selected profile ")+build.version+tx(", установлена ",", installed ")+installed.versionName+tx(". Выбери соответствующую версию.",". Select the matching version."));
        boolean arm=false; for(String abi:Build.SUPPORTED_ABIS) if("arm64-v8a".equals(abi))arm=true;
        if(!arm)throw new IOException(tx("нужен ARM64 Android","ARM64 Android is required"));
        File source=new File(getApplicationInfo().nativeLibraryDir,"libnova_exec.so");
        if(!source.isFile())throw new IOException(tx("ARM64-модуль отсутствует в APK","ARM64 module is missing from the APK"));
        if(direct)return startVirtual(build,vip);
        if(virtualWorker!=null&&virtualWorker.isAlive())throw new IOException(tx("Сначала останови режим виртуалки.","Stop virtual mode first."));
        prefs().edit().putBoolean("virtual_mode",false).apply();
        String launchProfile=build.id+(vip?"-vip":"");
        String d=q(control), ready=q(control+"/ready"), bin=q(control+"/Nova"), log=q(control+"/overlay.log");
        return root("set -eu; " +
            "[ ! -L "+d+" ] || exit 1; mkdir -p "+d+"; [ \"$(stat -c %u "+d+")\" = 0 ] || exit 1; chmod 700 "+d+"; " +
            "if [ -f "+ready+" ]; then pid=$(cat "+ready+"); case \"$pid\" in ''|*[!0-9]*) ;; *) if kill -0 \"$pid\" 2>/dev/null; then if cmp -s "+q(source.getAbsolutePath())+" \"/proc/$pid/exe\" && [ \"$(cat "+q(control+"/game.profile")+" 2>/dev/null)\" = "+q(launchProfile)+" ]; then echo 'Меню уже запущено'; exit 0; fi; touch "+q(control+"/stop")+"; n=0; while kill -0 \"$pid\" 2>/dev/null && [ \"$n\" -lt 8 ]; do sleep 1; n=$((n+1)); done; if kill -0 \"$pid\" 2>/dev/null; then echo 'Старая версия не завершилась'; exit 1; fi; fi ;; esac; fi; " +
            "cp "+q(source.getAbsolutePath())+" "+bin+".new; chmod 700 "+bin+".new; mv -f "+bin+".new "+bin+"; " +
            "rm -f "+q(control+"/stop")+" "+ready+"; " +
            "printf '%s\\n' "+q(launchProfile)+" > "+q(control+"/game.profile")+"; nohup "+bin+" --live "+(vip?"--vip ":"")+"--game-build "+q(build.id)+" --game-package "+q(GAME)+" --apk-path "+q(getApplicationInfo().sourceDir)+" --control-dir "+d+" --access-file "+q(accessFile().getAbsolutePath())+" --record-state-file "+q(new File(getFilesDir(),"recording.status").getAbsolutePath())+" > "+log+" 2>&1 < /dev/null & " +
            "child=$!; n=0; while [ \"$n\" -lt 10 ]; do " +
            "if [ -s "+ready+" ] && kill -0 \"$child\" 2>/dev/null; then echo 'Nova: меню запущено. Профиль Oxide подключён.'; exit 0; fi; " +
            "if ! kill -0 \"$child\" 2>/dev/null; then tail -n 30 "+log+"; exit 1; fi; sleep 1; n=$((n+1)); done; " +
            "touch "+q(control+"/stop")+"; echo 'Меню не подтвердило запуск за 10 секунд. Остановка запрошена.'; tail -n 30 "+log+"; exit 1");
    }
    private static volatile Thread virtualWorker;
    private static volatile String virtualResult="";
    private File virtualDir(){return new File(getFilesDir(),"virtual-runtime");}
    private String virtualLog(){
        StringBuilder report=new StringBuilder(virtualResult==null?"":virtualResult);
        if(android.os.Build.VERSION.SDK_INT>=30)try{
            android.app.ActivityManager manager=getSystemService(android.app.ActivityManager.class);
            report.append("\nAndroid process exits:\n");
            for(android.app.ApplicationExitInfo exit:manager.getHistoricalProcessExitReasons(null,0,5)){
                report.append(exit.getTimestamp()).append(" ").append(exit.getProcessName())
                    .append(" reason=").append(exit.getReason()).append(" status=").append(exit.getStatus())
                    .append(" pss_kb=").append(exit.getPss()).append(" ").append(exit.getDescription()).append("\n");
            }
        }catch(RuntimeException error){report.append("\nExit history unavailable: ").append(error.getClass().getSimpleName());}
        return report.toString();
    }
    private String nativePath(File file,boolean directory){
        String path=file.getAbsolutePath();
        int flags=android.system.OsConstants.O_RDONLY|android.system.OsConstants.O_CLOEXEC|
            android.system.OsConstants.O_NOFOLLOW;
        try{
            FileDescriptor fd=android.system.Os.open(path,flags,0);
            try(android.os.ParcelFileDescriptor copy=android.os.ParcelFileDescriptor.dup(fd)){
                String target=android.system.Os.readlink("/proc/self/fd/"+copy.getFd());
                if(!target.startsWith("/")||target.endsWith(" (deleted)"))return path;
                android.system.StructStat opened=android.system.Os.fstat(fd);
                if(directory?!android.system.OsConstants.S_ISDIR(opened.st_mode):!android.system.OsConstants.S_ISREG(opened.st_mode))return path;
                android.system.StructStat resolved=android.system.Os.lstat(target);
                return opened.st_dev==resolved.st_dev&&opened.st_ino==resolved.st_ino?target:path;
            }finally{android.system.Os.close(fd);}
        }catch(IOException|android.system.ErrnoException e){return path;}
    }
    private String startVirtual(GameBuild build,boolean vip) throws Exception{
        if(!android.provider.Settings.canDrawOverlays(this)){
            runOnUiThread(()->{
                try{openOutside(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:"+getPackageName())));}catch(RuntimeException ignored){}
            });
            throw new IOException(tx("Разреши показ поверх других приложений и повтори запуск.",
                                     "Allow display over other apps and start again."));
        }
        Thread existing=virtualWorker;
        if(existing!=null&&existing.isAlive())throw new IOException(tx("Виртуальный модуль уже запущен.","The virtual module is already running."));
        File dir=virtualDir();
        if(!dir.mkdir()&&!dir.isDirectory())throw new IOException(tx("Не удалось создать каталог виртуального режима.","Could not create the virtual runtime directory."));
        android.system.Os.chmod(dir.getAbsolutePath(),0700);
        File ready=new File(dir,"ready"),stopFile=new File(dir,"stop");
        Files.deleteIfExists(ready.toPath());Files.deleteIfExists(stopFile.toPath());
        prefs().edit().putBoolean("virtual_mode",true).apply();
        String nativeDir=nativePath(dir,true),nativeReceipt=nativePath(accessFile(),false);
        virtualResult="";
        VirtualOverlay overlay=new VirtualOverlay(this,stopFile);
        Thread worker=new Thread(()->{
            int code;
            try{code=LicenseBridge.virtualRun(build.id+(vip?"-vip":""),nativeDir,nativeReceipt,overlay.awaitSurface());}
            catch(Exception e){virtualResult="Android overlay: "+e;return;}
            finally{overlay.close();}
            String reason;
            switch(code){
                case 64:reason=tx("Приватный каталог недоступен из JNI.","Private directory unavailable from JNI.");break;
                case 70:reason=tx("Не удалось создать поверхность оверлея.","Could not create the overlay surface.");break;
                case 71:reason=tx("Недоступен ввод через /dev/input.","Input through /dev/input is unavailable.");break;
                case 72:
                    reason=LicenseBridge.virtualProbe(false);
                    if("Oxide PID not visible".equals(reason)){
                        virtualResult=tx("Oxide не запущен, запустите игру","Oxide is not running. Launch the game.");
                        return;
                    }
                    break;
                case 73:reason=tx("Каталог занят или недоступен для записи.","The runtime directory is busy or not writable.");break;
                case 74:reason=tx("Графический интерфейс системы недоступен процессу лоадера.","System graphics interface unavailable to the launcher process.");break;
                case 75:reason=tx("JNI-модуль не загрузился.","JNI module did not load.");break;
                case 77:reason=tx("JNI-модуль не смог прочитать активацию.","JNI module could not read the activation receipt.");break;
                default:reason=tx("Модуль завершился.","Module stopped.");
            }
            virtualResult=tx("JNI, код ","JNI, code ")+code+". "+reason;
        },"nova-virtual");
        virtualWorker=worker;
        worker.start();
        for(int n=0;n<40;n++){
            worker.join(250);
            if(!worker.isAlive())throw new IOException(virtualResult);
            if(ready.isFile()&&ready.length()>0){overlay.startInput();return tx("Виртуальный модуль запущен в лоадере.","Virtual module started inside the launcher.");}
        }
        stopFile.createNewFile();overlay.close();
        throw new IOException(tx("JNI-модуль не подтвердил запуск. Остановка запрошена.","JNI module did not confirm startup. Stop requested."));
    }
    private String stopOverlay() throws Exception {
        if(prefs().getBoolean("virtual_mode",false)){
            File dir=virtualDir();Thread worker=virtualWorker;
            if(dir.isDirectory())new File(dir,"stop").createNewFile();
            if(worker!=null){worker.join(5000);if(worker.isAlive())return tx("Остановка запрошена.","Stop requested.");}
            return tx("Виртуальный модуль остановлен.","Virtual module stopped.");
        }
        return root("set -eu; if [ ! -d "+q(control)+" ]; then echo 'Меню не запущено'; exit 0; fi; " +
            "touch "+q(control+"/stop")+"; n=0; while [ -f "+q(control+"/ready")+" ] && [ \"$n\" -lt 5 ]; do sleep 1; n=$((n+1)); done; " +
            "if [ -f "+q(control+"/ready")+" ]; then echo 'Остановка запрошена; завершение ещё не подтверждено.'; else echo 'Меню остановлено'; fi");
    }
}
