package cc.nova.oxide;
final class LicenseBridge {
    private static final boolean LOADED;
    static {boolean ok=false;try{System.loadLibrary("nova_license");ok=true;}catch(LinkageError|SecurityException ignored){}LOADED=ok;}
    static boolean available(){return LOADED;}
    static String virtualProbe(boolean beta){
        if(!LOADED)return "JNI module unavailable";
        try{return probeVirtual(beta);}catch(LinkageError e){return "JNI probe unavailable: "+e.getMessage();}
    }
    static int virtualRun(String build,String dir,String receipt,android.view.Surface surface){
        if(!LOADED)return 75;
        try{return runVirtual(build,dir,receipt,surface);}catch(LinkageError e){return 75;}
    }
    static native boolean localCheck(String key);
    private static native int runVirtual(String build,String dir,String receipt,android.view.Surface surface);
    static native boolean virtualHideRequested();
    static native void virtualSuspend(boolean paused);
    static native void virtualPointer(float x,float y,boolean down);
    static native boolean virtualMenuOpen();
    static native boolean virtualFullVisuals();
    static native void virtualInputBounds(int[] bounds);
    static native void virtualViewport(int width,int height,int x,int y);
    static native int virtualFreecamState();
    static native void toggleVirtualFreecam();
    static native void virtualFlight(float x,float y,float lookX,float lookY);
    static native void toggleVirtualMenu();
    private static native String probeVirtual(boolean beta);
}
