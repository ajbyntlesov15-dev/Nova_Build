package cc.nova.oxide;
import android.content.*;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.*;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.io.*;
import java.util.*;

final class VideoCatalog {
 static final class Clip {final Uri uri;final String name;final long size,duration,date;final File file;Clip(Uri uri,String name,long size,long duration,long date,File file){this.uri=uri;this.name=name;this.size=size;this.duration=duration;this.date=date;this.file=file;}}
 static List<Clip> list(Context context)throws IOException {
  List<Clip> clips=new ArrayList<>();
  if(Build.VERSION.SDK_INT>=29){
   String[] columns={MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,MediaStore.Video.Media.SIZE,MediaStore.Video.Media.DURATION,MediaStore.Video.Media.DATE_ADDED};
   String where=MediaStore.Video.Media.RELATIVE_PATH+"=? AND "+MediaStore.Video.Media.DISPLAY_NAME+" LIKE ? AND "+MediaStore.Video.Media.IS_PENDING+"=0 AND "+MediaStore.MediaColumns.OWNER_PACKAGE_NAME+"=?";
   try(Cursor c=context.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,columns,where,new String[]{"Movies/Nova/","Nova_%",context.getPackageName()},MediaStore.Video.Media.DATE_ADDED+" DESC")){
    if(c!=null)while(c.moveToNext()&&clips.size()<200){String name=c.getString(1);if(!name.matches("Nova_[0-9_]+\\.mp4"))continue;clips.add(new Clip(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,c.getLong(0)),name,c.getLong(2),c.getLong(3),c.getLong(4)*1000,null));}
   }
  }else{
   File folder=RecordedVideoProvider.directory().getCanonicalFile();File[] files=folder.listFiles();if(files==null)return clips;
   Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
   String pending=context.getSharedPreferences(ScreenRecordService.PREFS,Context.MODE_PRIVATE).getString("pending_path","");
   for(File f:files){if(clips.size()>=200)break;if(!f.getName().matches("Nova_[0-9_]+\\.mp4")||!f.isFile()||java.nio.file.Files.isSymbolicLink(f.toPath())||!folder.equals(f.getCanonicalFile().getParentFile())||f.getAbsolutePath().equals(pending))continue;clips.add(new Clip(RecordedVideoProvider.uri(f),f.getName(),f.length(),0,f.lastModified(),f));}
  }
  return clips;
 }
 static Bitmap thumbnail(Context context,Clip clip){
  if(clip.file!=null)return ThumbnailUtils.createVideoThumbnail(clip.file.getAbsolutePath(),MediaStore.Video.Thumbnails.MINI_KIND);
  try{return context.getContentResolver().loadThumbnail(clip.uri,new android.util.Size(320,180),null);}catch(IOException|RuntimeException e){return null;}
 }
 static void delete(Context context,Clip clip)throws IOException{
  if(ScreenRecordService.SESSION.busy())throw new IOException("Stop recording before deleting videos");
  if(clip.file!=null){File dir=RecordedVideoProvider.directory().getCanonicalFile(),f=clip.file.getCanonicalFile();if(java.nio.file.Files.isSymbolicLink(clip.file.toPath())||!f.equals(clip.file.getAbsoluteFile())||!dir.equals(f.getParentFile())||!f.getName().matches("Nova_[0-9_]+\\.mp4")||!f.delete())throw new IOException("Cannot delete recording");MediaScannerConnection.scanFile(context,new String[]{f.getAbsolutePath()},null,null);}
  else if(context.getContentResolver().delete(clip.uri,MediaStore.Video.Media.DISPLAY_NAME+"=? AND "+MediaStore.Video.Media.RELATIVE_PATH+"=? AND "+MediaStore.MediaColumns.OWNER_PACKAGE_NAME+"=? AND "+MediaStore.Video.Media.IS_PENDING+"=0",new String[]{clip.name,"Movies/Nova/",context.getPackageName()})!=1)throw new IOException("Recording not found or cannot be deleted");
  android.content.SharedPreferences p=context.getSharedPreferences(ScreenRecordService.PREFS,Context.MODE_PRIVATE);if(clip.uri.toString().equals(p.getString("last_uri","")))p.edit().remove("last_uri").apply();
 }
}
