package cc.nova.oxide;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.util.*;

final class ProfileStore {
 static final int LIMIT=32;
 static final class Entry {final String id,name;final byte[] config;final long modified;Entry(String id,String name,byte[] config,long modified){this.id=id;this.name=name;this.config=config;this.modified=modified;}}
 private final File directory;
 ProfileStore(File directory)throws IOException{this.directory=directory.getCanonicalFile();if(!this.directory.isDirectory()&&!this.directory.mkdirs())throw new IOException("Cannot create profiles");}
 static String name(String input)throws IOException{String s=Normalizer.normalize(input==null?"":input.trim(),Normalizer.Form.NFKC);if(s.isEmpty()||s.codePointCount(0,s.length())>48)throw new IOException("Name must contain 1–48 characters");for(int i=0;i<s.length();i++)if(Character.isISOControl(s.charAt(i))||s.charAt(i)=='/'||s.charAt(i)=='\\')throw new IOException("Invalid profile name");return s;}
 static byte[] pack(String name,byte[] config)throws IOException {ConfigDocument.parse(config);return ("NovaProfile 1\n"+Base64.getEncoder().encodeToString(name(name).getBytes(StandardCharsets.UTF_8))+"\n"+new String(config,StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8);}
 static Entry unpack(byte[] bytes)throws IOException{if(bytes.length>20000)throw new IOException("Profile too large");String s=new String(bytes,StandardCharsets.UTF_8);int a=s.indexOf('\n'),b=s.indexOf('\n',a+1);if(a<0||b<0||!s.substring(0,a).equals("NovaProfile 1"))throw new IOException("Invalid profile file");String name;try{name=name(new String(Base64.getDecoder().decode(s.substring(a+1,b)),StandardCharsets.UTF_8));}catch(IllegalArgumentException e){throw new IOException("Invalid profile name");}byte[] config=s.substring(b+1).getBytes(StandardCharsets.UTF_8);ConfigDocument.parse(config);return new Entry("",name,config,0);}
 synchronized List<Entry> list()throws IOException {List<Entry> result=new ArrayList<>();File[] files=directory.listFiles();if(files==null)throw new IOException("Cannot list profiles");for(File file:files){if(!file.getName().matches("[a-f0-9-]{36}\\.dofprofile")||Files.isSymbolicLink(file.toPath()))continue;try{Entry e=unpack(read(file,20000));result.add(new Entry(file.getName(),e.name,e.config,file.lastModified()));}catch(IOException ignored){}}result.sort((a,b)->Long.compare(b.modified,a.modified));return result;}
 synchronized Entry save(String input,byte[] config,boolean replace)throws IOException{String name=name(input);List<Entry> entries=list();Entry existing=null;for(Entry e:entries)if(e.name.equalsIgnoreCase(name))existing=e;if(existing!=null&&!replace)throw new IOException("A profile with this name already exists");if(existing==null&&entries.size()>=LIMIT)throw new IOException("Profile limit: "+LIMIT);String id=existing==null?UUID.randomUUID()+".dofprofile":existing.id;atomic(new File(directory,id),pack(name,config));return new Entry(id,name,config,System.currentTimeMillis());}
 synchronized void delete(Entry e)throws IOException{File file=resolve(e.id);if(!file.delete())throw new IOException("Cannot delete profile");}
 private File resolve(String id)throws IOException{if(!id.matches("[a-f0-9-]{36}\\.dofprofile"))throw new IOException("Invalid profile id");File f=new File(directory,id);if(Files.isSymbolicLink(f.toPath())||!directory.equals(f.getCanonicalFile().getParentFile()))throw new IOException("Invalid profile path");return f;}
 static byte[] read(File file,int max)throws IOException{try(InputStream in=new FileInputStream(file)){return ConfigDocument.bounded(in,max);}}
 static void atomic(File file,byte[] bytes)throws IOException{File temp=File.createTempFile("profile-",".tmp",file.getParentFile());try{if(!temp.setReadable(false,false)||!temp.setWritable(false,false)||!temp.setReadable(true,true)||!temp.setWritable(true,true))throw new IOException("Cannot protect file");try(FileOutputStream out=new FileOutputStream(temp)){out.write(bytes);out.getFD().sync();}try{Files.move(temp.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(temp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);}}finally{temp.delete();}}
}
