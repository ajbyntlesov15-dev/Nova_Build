package cc.nova.oxide;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
public final class RecordingControlActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);if(!new KeyAccess(this).hasAccess()){finish();return;}
        if("stop".equals(getIntent().getStringExtra("action"))){startService(new Intent(this,ScreenRecordService.class).setAction(ScreenRecordService.STOP));Intent game=getPackageManager().getLaunchIntentForPackage("com.catsbit.oxidesurvivalisland");if(game!=null)try{startActivity(game);}catch(RuntimeException ignored){}}
        else {String action=getIntent().getStringExtra("action");String page="profiles".equals(action)||"layout".equals(action)||"history".equals(action)?action:"config";getSharedPreferences("navigation",MODE_PRIVATE).edit().putString("pending_panel",page).commit();startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("recorder_action",page));}
        finish();
    }
}
