package cc.nova.oxide;

/** Remove overlay opacity and input while the launcher or system permissions are in use. */
final class OverlayVisibilityPolicy {
    private boolean launcherVisible,userHidden;
    synchronized boolean hidden(){return launcherVisible||userHidden;}
    synchronized void launcher(boolean visible){launcherVisible=visible;}
    synchronized void toggle(){
        if(hidden()){launcherVisible=false;userHidden=false;}
        else userHidden=true;
    }
}
