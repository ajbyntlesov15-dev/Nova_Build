package cc.nova.oxide;

/** Actual Android window bounds; drawing transparency alone does not shrink a window. */
final class VirtualOverlayLayout {
    final int x,y,width,height;
    final boolean inputActive,renderVisible;
    private VirtualOverlayLayout(int x,int y,int width,int height,boolean input,boolean visible){
        this.x=x;this.y=y;this.width=width;this.height=height;inputActive=input;renderVisible=visible;
    }
    static VirtualOverlayLayout render(int sw,int sh,boolean open,boolean flight,boolean full,boolean hidden,int[] bounds){
        if(hidden)return tiny();
        // Rendering and hit testing have different bounds. Keep the surface stable
        // while dragging; only input() follows the menu. Never accepts touches.
        return new VirtualOverlayLayout(0,0,Math.max(1,sw),Math.max(1,sh),false,true);
    }
    static VirtualOverlayLayout input(int sw,int sh,boolean open,boolean flight,boolean hidden,int[] bounds){
        if(hidden)return tiny();
        if(flight&&!open)return new VirtualOverlayLayout(0,0,Math.max(1,sw),Math.max(1,sh),true,false);
        if(!open||bounds==null||bounds.length<4||sw<=0||sh<=0||bounds[2]<=0||bounds[3]<=0)return tiny();
        int x=Math.max(0,Math.min(sw,bounds[0])),y=Math.max(0,Math.min(sh,bounds[1]));
        int right=(int)Math.max(0,Math.min((long)sw,(long)bounds[0]+bounds[2]));
        int bottom=(int)Math.max(0,Math.min((long)sh,(long)bounds[1]+bounds[3]));
        if(right<=x||bottom<=y)return tiny();
        return new VirtualOverlayLayout(x,y,right-x,bottom-y,true,false);
    }
    private static VirtualOverlayLayout tiny(){return new VirtualOverlayLayout(0,0,1,1,false,false);}
}
