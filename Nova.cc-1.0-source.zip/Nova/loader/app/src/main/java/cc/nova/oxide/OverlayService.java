package cc.nova.oxide;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.io.File;

/** Keeps the user-visible non-root overlay session alive while the launcher is backgrounded. */
public final class OverlayService extends Service {
    private File stop;
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int id){
        new VipAccess(this);
        if(intent!=null&&intent.hasExtra("stop"))stop=new File(intent.getStringExtra("stop"));
        if(intent!=null&&"stop".equals(intent.getAction())){requestStop();stopSelf();return START_NOT_STICKY;}
        if(intent!=null&&"visibility".equals(intent.getAction()))VirtualOverlay.toggleWindows();
        boolean hidden=VirtualOverlay.windowsHidden();
        String channel="nonroot_overlay";
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel(channel,"Меню поверх игры",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent close=PendingIntent.getService(this,1,new Intent(this,OverlayService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent visibility=PendingIntent.getService(this,1,new Intent(this,OverlayService.class).setAction("visibility"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification=new Notification.Builder(this,channel)
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Nova · меню активно")
            .setContentText(hidden?"Окна скрыты: системные экраны доступны":"Перед системными разрешениями скройте окна")
            .setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(null,hidden?"Показать окна":"Скрыть окна",visibility).build())
            .addAction(new Notification.Action.Builder(null,"Остановить",close).build()).build();
        if(Build.VERSION.SDK_INT>=34)startForeground(730,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(730,notification);
        return START_NOT_STICKY;
    }
    private void requestStop(){new VipAccess(this).revokeRuntime();if(stop!=null)try{stop.createNewFile();}catch(java.io.IOException ignored){}}
    @Override public void onDestroy(){requestStop();super.onDestroy();}
}
