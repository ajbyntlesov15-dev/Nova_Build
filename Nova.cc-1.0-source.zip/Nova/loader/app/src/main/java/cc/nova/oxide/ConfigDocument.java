package cc.nova.oxide;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class ConfigDocument {
 static final int MAX=16384;
 static final Set<String> BOOLS=new HashSet<>(Arrays.asList("nonroot_full_visuals vip_predict armor death_loot unlock_fps menu_animations menu_dim_background spin movement_boost player_arrows player_clan player_status hide_allies bot_lines bot_rig bot_names bot_distance bot_arrows world_distance sticky_aim aim_marker no_spread fast_switch fast_draw ignore_team ignore_clan sky_tint aim_animals aim_bots no_sway fast_reload rapid_fire hand_position trigger trigger_ads container_boxes cupboard_boxes box name health distance lines skeleton weapon small large cupboard rgb aim no_recoil draw_fov freecam debug watermark free_button custom_fov thirdperson sulfur stone metal barrels wood highmetal animals autofarm quickloot calibration always_day farm_sulfur farm_stone farm_metal farm_barrels farm_wood farm_highmetal bots vehicles sleepers turrets aim_visibility vip_box_glow vip_chams_glow vip_hit_mark vip_kill_sound vip_touch_aim vip_aim_360 vip_silent vip_chams vip_autoheal vip_build_hp vip_loot_contents vip_melee vip_tracers vip_daylight vip_home_search vip_player_outline vip_loot_outline name_background distance_background actor_badge".split(" ")));
 static final Set<String> INTS=new HashSet<>(Arrays.asList("ui_revision fps_limit menu_animation_percent spin_speed player_model movement_percent arrow_radius world_limit world_range world_mode day_hour box_style line_weight fire_multiplier hand_x hand_y hand_z trigger_delay trigger_interval max_distance aim_distance fov smooth target_bone target_mode free_speed scrollbar menu_theme open_method activation recoil_x recoil_y language camera_fov third_distance third_height third_shoulder watermark_style joy_x joy_y joy_radius look_x look_y hit_x hit_y turn_scale farm_reach menu_scale menu_opacity menu_x menu_y vip_c4_damage vip_rocket_damage aim_area_ax aim_area_ay aim_area_bx aim_area_by aim_touch_gain heal_slot_x heal_slot_y heal_use_x heal_use_y vip_lead_ms vip_animals snow_size snow_speed caption_transparency actor_badge_scale line_origin".split(" ")));
 static { for(String key:"trigger_ignore_team trigger_ignore_clan trigger_animals trigger_bots".split(" "))BOOLS.add(key);for(String key:"trigger_distance heal_threshold heal_interval tracer_length tracer_lifetime tracer_width".split(" "))INTS.add(key);for(String prefix:new String[]{"silent_","touch_","aim360_"}){for(String key:"visibility animals bots ignore_team ignore_clan predict sticky draw_fov marker".split(" "))BOOLS.add(prefix+key);for(String key:"fov distance bone mode activation smooth lead_ms".split(" "))INTS.add(prefix+key);}}
 final LinkedHashMap<String,String> rows=new LinkedHashMap<>();
 private String magic;
 static byte[] bounded(InputStream in,int max)throws IOException {ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[2048];int n;while((n=in.read(b))!=-1){if(out.size()+n>max)throw new IOException("File too large");out.write(b,0,n);}return out.toByteArray();}
 static ConfigDocument parse(byte[] bytes)throws IOException {
  if(bytes.length==0||bytes.length>MAX)throw new IOException("Invalid config size");
  String text=new String(bytes,StandardCharsets.UTF_8);if(text.indexOf('\0')>=0)throw new IOException("Invalid config");String[] lines=text.split("\n",-1);
  if(!lines[0].matches("OxideConfig [1-6]")||lines.length>514)throw new IOException("Unsupported config");
  ConfigDocument d=new ConfigDocument();d.magic=lines[0];
  for(int line=1;line<lines.length;line++){
   String row=lines[line].trim();if(row.isEmpty())continue;if(row.length()>256)throw new IOException("Config row too long");
   String[] p=row.split("\\s+");String key=p[0],id=key;
   try{
    if(BOOLS.contains(key)){if(p.length!=2||(!p[1].equals("0")&&!p[1].equals("1")))throw new IllegalArgumentException();}
    else if(INTS.contains(key)){if(p.length!=2)throw new IllegalArgumentException();int n=Integer.parseInt(p[1]);if(n<0||n>10000)throw new IllegalArgumentException();}
    else if(key.equals("free_position")){if(p.length!=3)throw new IllegalArgumentException();range(p[1],0,1);range(p[2],0,1);}
    else if(key.equals("point")){if(p.length!=4)throw new IllegalArgumentException();int n=Integer.parseInt(p[1]);if(n<0||n>7)throw new IllegalArgumentException();range(p[2],-1,100);range(p[3],-1,100);id+=" "+n;}
    else if(key.equals("color")){if(p.length!=6)throw new IllegalArgumentException();int n=Integer.parseInt(p[1]);if(n<0||n>24)throw new IllegalArgumentException();for(int j=2;j<6;j++)range(p[j],0,1);id+=" "+n;}
    else throw new IllegalArgumentException();
   }catch(IllegalArgumentException e){throw new IOException("Invalid config row: "+key);}
   if(d.rows.put(id,row)!=null)throw new IOException("Duplicate config field");
  }
  if(d.rows.isEmpty())throw new IOException("Empty config");return d;
 }
 private static void range(String s,float low,float high){float v=Float.parseFloat(s);if(!Float.isFinite(v)||v<low||v>high)throw new IllegalArgumentException();}
 int number(String key,int fallback){String r=rows.get(key);return r==null?fallback:Integer.parseInt(r.substring(key.length()+1));}
 void setNumber(String key,int value){if(!INTS.contains(key))throw new IllegalArgumentException();rows.put(key,key+" "+value);}
 byte[] bytes()throws IOException{StringBuilder s=new StringBuilder(magic).append('\n');for(String row:rows.values())s.append(row).append('\n');byte[] b=s.toString().getBytes(StandardCharsets.UTF_8);parse(b);return b;}
}
