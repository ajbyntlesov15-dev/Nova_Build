package cc.nova.oxide;

final class RecordingSession {
    static final int IDLE=0,STARTING=1,RECORDING=2,STOPPING=3,ERROR=4;
    private long completions;private int state=IDLE;private String error="";
    synchronized boolean begin(){if(busy())return false;state=STARTING;error="";return true;}
    synchronized boolean markRecording(){if(state!=STARTING)return false;state=RECORDING;return true;}
    synchronized void requestStop(){if(busy())state=STOPPING;}
    synchronized void finish(String message){error=message==null?"":message;state=error.isEmpty()?IDLE:ERROR;completions++;}
    synchronized boolean busy(){return state==STARTING||state==RECORDING||state==STOPPING;}
    synchronized int state(){return state;}
    synchronized long completions(){return completions;}
    synchronized String error(){return error;}
}
