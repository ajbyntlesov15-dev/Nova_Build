package cc.nova.oxide;
import android.content.Context;import android.content.pm.PackageInfo;import android.content.pm.PackageManager;
import java.io.*;import java.nio.charset.StandardCharsets;import java.nio.file.Files;import java.security.MessageDigest;
final class KeyAccess {
 static final String CHANNEL="";
 private final Context context;private final File file;
 KeyAccess(Context c){context=c.getApplicationContext();file=new File(context.getFilesDir(),"nova-access-v1");}
 File file(){return file;}
 private static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes){s.append("0123456789abcdef".charAt((b>>4)&15));s.append("0123456789abcdef".charAt(b&15));}return s.toString();}
    private String certificate(){try{PackageInfo info=context.getPackageManager().getPackageInfo(context.getPackageName(),PackageManager.GET_SIGNATURES);if(info.signatures==null||info.signatures.length!=1)return "";return hex(MessageDigest.getInstance("SHA-512").digest(info.signatures[0].toByteArray()));}catch(Exception e){return "";}}
    private boolean moduleMatches(){
        File module=new File(context.getApplicationInfo().nativeLibraryDir,"libnova_exec.so");
        if(!module.isFile()||module.length()<=0||module.length()>32*1024*1024)return false;
        try(InputStream input=new FileInputStream(module)){MessageDigest digest=MessageDigest.getInstance("SHA-512");byte[] b=new byte[16384];int n;while((n=input.read(b))!=-1)digest.update(b,0,n);return BuildSecrets.NATIVE_SHA512.equals(hex(digest.digest()));}catch(Exception e){return false;}
    }
    private boolean trustedBuild(){return BuildSecrets.CERT_SHA512.equals(certificate())&&moduleMatches();}

 boolean hasAccess(){try{return trustedBuild()&&LicenseBridge.available()&&!Files.isSymbolicLink(file.toPath())&&file.isFile()&&file.length()<=128&&LicenseBridge.localCheck(new String(Files.readAllBytes(file.toPath()),StandardCharsets.US_ASCII));}catch(Exception e){return false;}}
 synchronized boolean activate(String entered)throws IOException{
  String value=entered==null?"":entered.trim().toUpperCase(java.util.Locale.ROOT);
  if(!trustedBuild()||!LicenseBridge.available()||!LicenseBridge.localCheck(value))return false;
  byte[] data=(value+"\n").getBytes(StandardCharsets.US_ASCII);save(file,data);save(new File(file.getPath()+".vip"),data);return true;
 }
 boolean openChannelOnce(Runnable opener){return false;}
 static void save(File target,byte[] data)throws IOException{File temp=File.createTempFile("nova-",".tmp",target.getParentFile());try{temp.setReadable(false,false);temp.setWritable(false,false);if(!temp.setReadable(true,true)||!temp.setWritable(true,true))throw new IOException("Не удалось защитить ключ");try(FileOutputStream stream=new FileOutputStream(temp)){stream.write(data);stream.getFD().sync();}if(!temp.renameTo(target))throw new IOException("Не удалось сохранить ключ");}finally{temp.delete();}}
}
