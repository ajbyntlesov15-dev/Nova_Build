package cc.nova.oxide;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.graphics.SurfaceTexture;
import android.view.WindowManager;
import android.view.ViewConfiguration;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

final class VirtualOverlay {
    private static final OverlayVisibilityPolicy VISIBILITY=new OverlayVisibilityPolicy();
    private static volatile VirtualOverlay current;
    static boolean windowsHidden(){return VISIBILITY.hidden();}
    static void setLauncherVisible(boolean visible){VISIBILITY.launcher(visible);refreshVisibility();}
    static void toggleWindows(){VISIBILITY.toggle();refreshVisibility();}
    private static void refreshVisibility(){VirtualOverlay overlay=current;if(overlay!=null)overlay.handler.post(()->{if(!overlay.closed&&overlay.attached){overlay.applyWindowVisibility();overlay.refreshNotification();}});}
    private void refreshNotification(){try{context.startService(new android.content.Intent(context,OverlayService.class).setAction("refresh"));}catch(RuntimeException ignored){}}
    private void applyWindowVisibility(){
        boolean hidden=VISIBILITY.hidden();LicenseBridge.virtualSuspend(hidden);
        if(hidden&&params!=null&&view!=null)placeRender(VirtualOverlayLayout.render(screenWidth,screenHeight,false,false,false,true,null));
        if(hidden&&touchable){manager.removeView(inputView);touchable=false;pointerDown=false;LicenseBridge.virtualPointer(0,0,false);resetFlight();}
        for(android.view.View control:new android.view.View[]{opener,freecam})if(control!=null){
            WindowManager.LayoutParams layout=(WindowManager.LayoutParams)control.getLayoutParams();float alpha=hidden?0f:1f;int flags=hidden?layout.flags|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE:layout.flags&~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            if(layout.alpha!=alpha||layout.flags!=flags){layout.alpha=alpha;layout.flags=flags;manager.updateViewLayout(control,layout);}
        }
    }

    private final Context context;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final CountDownLatch ready=new CountDownLatch(1);
    private final File stop;
    private WindowManager manager;
    private TextureView view;
    private int screenWidth,screenHeight;
    private float visualAlpha=1f;
    private android.view.View inputView;
    private WindowManager.LayoutParams inputParams;
    private final int[] inputBounds=new int[4];
    private ImageButton opener;
    private android.widget.TextView freecam;
    private boolean flying,touchable,fullVisuals,pointerDown;
    private int moveId=-1,lookId=-1;
    private float moveStartX,moveStartY,lastLookX,lastLookY,moveX,moveY,lookX,lookY;
    private int openerX=-1,openerY=-1;
    private WindowManager.LayoutParams params;
    private volatile Surface surface;
    private volatile Exception failure;
    private boolean closed,menuOpen,attached;
    private final Runnable sync=new Runnable(){
        @Override public void run(){
            if(closed||!attached)return;
            if(LicenseBridge.virtualHideRequested()&&!VISIBILITY.hidden()){VISIBILITY.toggle();refreshNotification();}
            try{applyWindowVisibility();}catch(RuntimeException e){stopAndClose();return;}
            if(VISIBILITY.hidden()){handler.postDelayed(this,60);return;}
            boolean open=LicenseBridge.virtualMenuOpen();
            try{
                int flight=LicenseBridge.virtualFreecamState();
                boolean nextFlying=(flight&2)!=0;
                if(flying&&!nextFlying)resetFlight();
                flying=nextFlying;
                menuOpen=open;
                fullVisuals=LicenseBridge.virtualFullVisuals();
                syncInput(open,flying);
                if(opener==null)addOpener();
                if((flight&1)!=0&&freecam==null)addFreecam();
                if((flight&1)==0&&freecam!=null)removeFreecam();
                if(freecam!=null){freecam.setSelected(flying);freecam.setText(flying?"FC ON":"FC");freecam.setContentDescription(flying?"Выключить фрикам":"Включить фрикам");}
                handler.postDelayed(this,open||flying?16:32);
            }catch(RuntimeException e){stopAndClose();}
        }
    };
    VirtualOverlay(Context context,File stop){
        this.context=context.getApplicationContext();current=this;
        this.stop=stop;
    }
    Surface awaitSurface() throws Exception{
        handler.post(this::show);
        if(!ready.await(5,TimeUnit.SECONDS))throw new IOException("Android overlay surface timed out.");
        if(failure!=null)throw failure;
        if(surface==null||!surface.isValid())throw new IOException("Android overlay surface unavailable.");
        return surface;
    }
    void startInput(){handler.post(sync);}
    void close(){handler.post(this::remove);}
    private WindowManager.LayoutParams window(int width,int height,int flags){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED|flags,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;
        p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        return p;
    }
    private void show(){
        if(closed)return;
        try{
            manager=context.getSystemService(WindowManager.class);
            if(manager==null)throw new IOException("Android WindowManager unavailable.");
            android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();
            manager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth=metrics.widthPixels;screenHeight=metrics.heightPixels;
            LicenseBridge.virtualViewport(screenWidth,screenHeight,0,0);
            if(android.os.Build.VERSION.SDK_INT>=31){
                android.hardware.input.InputManager input=context.getSystemService(android.hardware.input.InputManager.class);
                visualAlpha=input==null?0f:OverlayOpacity.renderAlpha(input.getMaximumObscuringOpacityForTouch());
            }
            // TextureView stays in the parent window's opacity hierarchy. A
            // separate on-top SurfaceView can introduce another input layer.
            view=new TextureView(context);view.setOpaque(false);
            view.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
                @Override public void onSurfaceTextureAvailable(SurfaceTexture texture,int width,int height){surface=new Surface(texture);ready.countDown();}
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture texture,int width,int height){}
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture texture){if(!closed)stopAndClose();return true;}
                @Override public void onSurfaceTextureUpdated(SurfaceTexture texture){}
            });
            inputView=new android.view.View(context);
            inputView.setOnTouchListener((v,original)->{
                MotionEvent event=MotionEvent.obtain(original);
                // Raw coordinates belong to this event, unlike LayoutParams which
                // may already describe the next asynchronous window position.
                event.offsetLocation(original.getRawX()-original.getX(),original.getRawY()-original.getY());
                try {
                if(flying&&!menuOpen)return flightTouch(event);
                int action=event.getActionMasked();
                if(action==MotionEvent.ACTION_DOWN)pointerDown=true;
                if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)pointerDown=false;
                if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE||
                   action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
                    LicenseBridge.virtualPointer(event.getX(),event.getY(),
                        action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE);
                }
                return true;
                } finally {event.recycle();}
            });
            params=window(1,1,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            params.alpha=0f;
            LicenseBridge.virtualSuspend(VISIBILITY.hidden());
            manager.addView(view,params);
            attached=true;
            context.startForegroundService(new android.content.Intent(context,OverlayService.class)
                .putExtra("stop",stop.getAbsolutePath()));
        }catch(Exception e){failure=e;ready.countDown();remove();}
    }
    private void syncInput(boolean open,boolean flight){
        android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();
        manager.getDefaultDisplay().getRealMetrics(metrics);
        screenWidth=metrics.widthPixels;screenHeight=metrics.heightPixels;
        LicenseBridge.virtualInputBounds(inputBounds);
        VirtualOverlayLayout render=VirtualOverlayLayout.render(screenWidth,screenHeight,open,flight,fullVisuals,VISIBILITY.hidden(),inputBounds);
        VirtualOverlayLayout input=VirtualOverlayLayout.input(screenWidth,screenHeight,open,flight,VISIBILITY.hidden(),inputBounds);
        placeRender(render);
        int x=input.x,y=input.y,width=input.width,height=input.height;
        boolean active=input.inputActive;
        if(!active){if(touchable){manager.removeView(inputView);touchable=false;pointerDown=false;LicenseBridge.virtualPointer(0,0,false);}return;}
        // The View has no background and draws nothing. Keep the WINDOW visible
        // to input dispatch; window alpha=0 can remove it from hit testing.
        if(!touchable){inputParams=window(width,height,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);inputParams.alpha=1f;inputParams.x=x;inputParams.y=y;manager.addView(inputView,inputParams);touchable=true;raiseControls();}
        // Android retains the current touch stream outside the initial bounds.
        // Relocate the hit window after release, avoiding relayout during drag.
        else if(!pointerDown&&(inputParams.x!=x||inputParams.y!=y||inputParams.width!=width||inputParams.height!=height)){inputParams.x=x;inputParams.y=y;inputParams.width=width;inputParams.height=height;manager.updateViewLayout(inputView,inputParams);}
    }
    private void placeRender(VirtualOverlayLayout layout){
        LicenseBridge.virtualViewport(screenWidth,screenHeight,layout.x,layout.y);
        float alpha=layout.renderVisible?visualAlpha:0f;
        if(params.width!=layout.width||params.height!=layout.height||params.x!=layout.x||params.y!=layout.y||params.alpha!=alpha){
            params.width=layout.width;params.height=layout.height;params.x=layout.x;params.y=layout.y;params.alpha=alpha;manager.updateViewLayout(view,params);
        }
    }
    private void raiseControls(){
        // New overlay windows are placed above existing ones. Keep both escape
        // controls above the full-screen flight input window.
        for(android.view.View control:new android.view.View[]{opener,freecam})if(control!=null){
            WindowManager.LayoutParams layout=(WindowManager.LayoutParams)control.getLayoutParams();
            manager.removeViewImmediate(control);
            manager.addView(control,layout);
        }
    }
    private void addFreecam(){
        android.widget.TextView button=new android.widget.TextView(context);
        button.setText("FC");
        button.setTextColor(0xfff6f7ff);
        button.setTextSize(16);
        button.setGravity(Gravity.CENTER);
        button.setContentDescription("Freecam");
        GradientDrawable background=new GradientDrawable();
        background.setCornerRadius(14*context.getResources().getDisplayMetrics().density);
        background.setColor(0xe51a202e);
        background.setStroke(2,0xffdf566e);
        GradientDrawable active=new GradientDrawable();
        active.setCornerRadius(14*context.getResources().getDisplayMetrics().density);
        active.setColor(0xff167443);
        active.setStroke(2,0xff78f0ac);
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_selected},active);
        states.addState(new int[]{},background);
        button.setBackground(states);
        button.setOnClickListener(v->LicenseBridge.toggleVirtualFreecam());
        int size=Math.round(48*context.getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams p=window(size,size,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        p.gravity=Gravity.TOP|Gravity.RIGHT;
        p.x=size/3;
        p.y=size*2;
        manager.addView(button,p);
        freecam=button;
    }
    private void removeFreecam(){
        if(freecam!=null){manager.removeView(freecam);freecam=null;}
    }
    private void resetFlight(){
        moveId=lookId=-1;
        moveX=moveY=0;
        LicenseBridge.virtualFlight(0,0,lookX,lookY);
    }
    private boolean flightTouch(MotionEvent event){
        int action=event.getActionMasked(),index=event.getActionIndex();
        int id=event.getPointerId(index);
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            float x=event.getX(index),y=event.getY(index);
            if(x<screenWidth*.5f&&moveId==-1){moveId=id;moveStartX=x;moveStartY=y;}
            else if(lookId==-1){lookId=id;lastLookX=x;lastLookY=y;}
        }else if(action==MotionEvent.ACTION_MOVE){
            int move=event.findPointerIndex(moveId),look=event.findPointerIndex(lookId);
            if(move>=0){
                float radius=70*context.getResources().getDisplayMetrics().density;
                moveX=Math.max(-1,Math.min(1,(event.getX(move)-moveStartX)/radius));
                moveY=Math.max(-1,Math.min(1,(moveStartY-event.getY(move))/radius));
            }
            if(look>=0){
                float x=event.getX(look),y=event.getY(look);
                lookX+=x-lastLookX;lookY+=y-lastLookY;lastLookX=x;lastLookY=y;
            }
        }else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP){
            if(id==moveId){moveId=-1;moveX=moveY=0;}
            if(id==lookId)lookId=-1;
        }else if(action==MotionEvent.ACTION_CANCEL){
            resetFlight();
        }
        LicenseBridge.virtualFlight(moveX,moveY,lookX,lookY);
        return true;
    }
    private void addOpener(){
        ImageButton button=new ImageButton(context);
        button.setContentDescription("Nova");
        GradientDrawable circle=new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xff111111);
        button.setBackground(circle);
        button.setClipToOutline(true);
        button.setPadding(0,0,0,0);
        button.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try(java.io.InputStream in=context.getAssets().open("nova_logo.png")){
            button.setImageDrawable(Drawable.createFromStream(in,null));
        }catch(IOException e){button.setImageResource(android.R.drawable.ic_menu_view);}
        button.setOnClickListener(v->LicenseBridge.toggleVirtualMenu());
        int size=Math.round(60*context.getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams p=window(size,size,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        p.x=clamp(openerX<0?size/4:openerX,screenWidth-size);
        p.y=clamp(openerY<0?size:openerY,screenHeight-size);
        int slop=ViewConfiguration.get(context).getScaledTouchSlop();
        button.setOnTouchListener(new android.view.View.OnTouchListener(){
            float downX,downY;
            int startX,startY;
            boolean dragged;
            @Override public boolean onTouch(android.view.View v,MotionEvent event){
                switch(event.getActionMasked()){
                    case MotionEvent.ACTION_DOWN:
                        downX=event.getRawX();downY=event.getRawY();
                        startX=p.x;startY=p.y;dragged=false;button.setPressed(true);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=event.getRawX()-downX,dy=event.getRawY()-downY;
                        if(!dragged&&dx*dx+dy*dy<=slop*slop)return true;
                        dragged=true;button.setPressed(false);
                        p.x=openerX=clamp(startX+Math.round(dx),screenWidth-size);
                        p.y=openerY=clamp(startY+Math.round(dy),screenHeight-size);
                        manager.updateViewLayout(button,p);
                        return true;
                    case MotionEvent.ACTION_UP:
                        button.setPressed(false);
                        if(!dragged)button.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        button.setPressed(false);
                        return true;
                    default:return true;
                }
            }
        });
        manager.addView(button,p);
        opener=button;
    }
    private static int clamp(int value,int max){return Math.max(0,Math.min(value,max));}
    private void removeOpener(){
        if(opener!=null){manager.removeView(opener);opener=null;}
    }
    private void stopAndClose(){
        try{stop.createNewFile();}catch(IOException ignored){}
        remove();
    }
    private void remove(){
        if(closed)return;
        closed=true;
        if(current==this)current=null;
        LicenseBridge.virtualSuspend(true);
        handler.removeCallbacks(sync);
        if(touchable){manager.removeView(inputView);touchable=false;pointerDown=false;}
        removeOpener();
        removeFreecam();
        if(attached){attached=false;manager.removeView(view);}
        context.stopService(new android.content.Intent(context,OverlayService.class));
        ready.countDown();
    }
}
