package cc.nova.oxide;
import android.content.Context;import java.io.*;import java.nio.file.Files;
final class VipAccess {
 static final String CHANNEL="";private final KeyAccess access;
 VipAccess(Context context){access=new KeyAccess(context);}
 File file(){return new File(access.file().getPath()+".vip");}
 boolean hasAccess(){return access.hasAccess();}
 boolean activate(String key)throws IOException{return access.activate(key);}
 void prepare()throws IOException{if(!access.hasAccess())throw new IOException("Введите ключ Nova.cc");KeyAccess.save(file(),Files.readAllBytes(access.file().toPath()));}
 void revokeRuntime(){file().delete();}
 boolean openChannelOnce(Runnable opener){return false;}
}
