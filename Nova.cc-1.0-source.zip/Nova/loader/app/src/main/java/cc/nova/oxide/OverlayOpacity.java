package cc.nova.oxide;
/** One full-screen, non-touchable drawing window; bounded controls intercept their own touches. */
final class OverlayOpacity {
 static float renderAlpha(float maximum){if(Float.isNaN(maximum)||maximum<=0)return 0;return Math.min(.75f,Math.max(0f,maximum-.05f));}
}
