package cc.nova.oxide;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/** Launcher tools; root commands only address the loader's own configuration. */
final class CompanionPanels {
 static final int IMPORT=1730,EXPORT=1731,HISTORY_PERMISSION=1732,PLAYER=1733;
 interface Command {String run(String script)throws Exception;}
 interface Work<T>{T run()throws Exception;}
 interface Done<T>{void accept(T value)throws Exception;}
 private final Activity a;private final Command command;private final String control;private boolean english;
 private int background,ink,muted,accent;
 private final ExecutorService io=Executors.newSingleThreadExecutor(),thumbs=Executors.newSingleThreadExecutor();
 private final Handler main=new Handler(Looper.getMainLooper());
 private Dialog panel;private int epoch;private boolean closed,busy;
 CompanionPanels(Activity a,Command command,String control,boolean english,int background,int ink,int muted,int accent){this.a=a;this.command=command;this.control=control;this.english=english;this.background=background;this.ink=ink;this.muted=muted;this.accent=accent;}
 void configure(boolean english,int background,int ink,int muted,int accent){this.english=english;this.background=background;this.ink=ink;this.muted=muted;this.accent=accent;}
 private String t(String ru,String en){return english?en:ru;}
 private int dp(int n){return Math.round(n*a.getResources().getDisplayMetrics().density);}
 private void toast(String message){Toast.makeText(a,message,Toast.LENGTH_LONG).show();}
 private boolean alive(){return !closed&&!a.isFinishing()&&!a.isDestroyed();}
 private static String q(String value){return "'"+value.replace("'","'\\''")+"'";}
 private GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
 private TextView text(String value,int size,int color){TextView v=new TextView(a);v.setText(value);v.setTypeface(size>=17?BrandFonts.bold(a):BrandFonts.regular(a));v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(6),0,dp(6));return v;}
 private Button button(LinearLayout parent,String title,Runnable action){Button b=new Button(a);b.setText(title);b.setTypeface(BrandFonts.bold(a));b.setAllCaps(false);b.setTextColor(accent);b.setTextSize(14);b.setOnClickListener(v->action.run());parent.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));return b;}
 private AlertDialog.Builder builder(){boolean dark=Color.red(background)<90;return new AlertDialog.Builder(new ContextThemeWrapper(a,dark?android.R.style.Theme_Material_Dialog_Alert:android.R.style.Theme_Material_Light_Dialog_Alert));}
 private LinearLayout window(String title){epoch++;if(panel!=null)panel.dismiss();LinearLayout body=new LinearLayout(a);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(20),dp(10),dp(20),dp(18));body.setBackgroundColor(background);ScrollView scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.addView(body);panel=builder().setTitle(title).setView(scroll).setNegativeButton(t("Готово","Done"),null).create();panel.setOnDismissListener(d->{if(panel==d){epoch++;panel=null;}});panel.show();return body;}
 private <T> void run(Work<T> work,Done<T> done){if(busy){toast(t("Подожди завершения операции","Wait for the current operation"));return;}busy=true;int generation=epoch;io.execute(()->{T result=null;Exception error=null;try{result=work.run();}catch(Exception e){error=e;}final T value=result;final Exception failure=error;main.post(()->{busy=false;if(!alive()||generation!=epoch)return;try{if(failure!=null)throw failure;done.accept(value);}catch(Exception e){toast(t("Не удалось выполнить: ","Could not complete: ")+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}});});}
 private ProfileStore store()throws IOException{return new ProfileStore(new File(a.getFilesDir(),"profiles"));}
 private byte[] current()throws Exception {String value=command.run("set -eu; [ -f "+q(control+"/oxide.conf")+" ] || { echo 'Start the menu first'; exit 1; }; cat "+q(control+"/oxide.conf"));byte[] data=value.getBytes(StandardCharsets.UTF_8);ConfigDocument.parse(data);return data;}
 private String apply(byte[] data)throws Exception {
  ConfigDocument.parse(data);File staging=File.createTempFile("config-import-",".tmp",a.getFilesDir());
  try{ProfileStore.atomic(staging,data);String temp=q(control+"/config-import.pending"),config=q(control+"/oxide.conf"),reload=q(control+"/oxide.conf.reload"),bin=q(control+"/Nova");
   return command.run("set -eu; [ -x "+bin+" ] || { echo 'Start the menu first'; exit 1; }; trap 'rm -f "+temp+"' EXIT; cp "+q(staging.getAbsolutePath())+" "+temp+"; chmod 600 "+temp+"; "+bin+" --check-config "+temp+" || { echo 'Restart the menu with this version'; exit 1; }; mv -f "+temp+" "+config+"; touch "+reload+"; if [ -s "+q(control+"/ready")+" ]; then n=0; while [ -f "+reload+" ] && [ \"$n\" -lt 20 ]; do sleep 0.1; n=$((n+1)); done; fi; if [ -f "+reload+" ]; then echo SAVED; else echo APPLIED; fi");
  }finally{staging.delete();}
 }
 private void applied(String result){toast(result.endsWith("APPLIED")?t("Настройки применены","Settings applied"):t("Настройки сохранены. Будут применены при запуске меню.","Settings saved. They will apply when the menu starts."));}
 void show(String page){if(!alive())return;if(page.equals("profiles"))profiles();else if(page.equals("layout"))layout();else if(page.equals("history"))history();}
 private void profiles(){
  LinearLayout body=window(t("Профили настроек","Settings profiles"));
  button(body,t("Сохранить текущие настройки","Save current settings"),()->nameProfile());
  button(body,t("Импортировать файл","Import file"),()->{if(busy)return;try{((MainActivity)a).startCompanionIntent(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),IMPORT);}catch(RuntimeException e){toast(t("Выбор файла недоступен","File picker unavailable"));}});
  TextView loading=text(t("Загрузка…","Loading…"),13,muted);body.addView(loading);
  run(()->store().list(),entries->{body.removeView(loading);if(entries.isEmpty())body.addView(text(t("Профилей пока нет","No profiles yet"),14,muted));for(ProfileStore.Entry entry:entries){
   LinearLayout card=new LinearLayout(a);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackground(shape(Color.argb(18,128,128,128)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(12);body.addView(card,lp);
   card.addView(text(entry.name,17,ink));card.addView(text(new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date(entry.modified)),12,muted));
   button(card,t("Применить","Apply"),()->run(()->apply(entry.config),this::applied));
   button(card,t("Экспортировать","Export"),()->export(entry));
   button(card,t("Удалить профиль","Delete profile"),()->builder().setTitle(t("Удалить профиль?","Delete profile?")).setMessage(entry.name).setPositiveButton(t("Удалить","Delete"),(d,w)->run(()->{store().delete(entry);return true;},ok->profiles())).setNegativeButton(t("Отмена","Cancel"),null).show());
  }});
 }
 private void nameProfile(){if(busy)return;EditText name=new EditText(a);name.setSingleLine(true);name.setText(t("Профиль ","Profile ")+new SimpleDateFormat("dd.MM HH.mm",Locale.getDefault()).format(new Date()));builder().setTitle(t("Название профиля","Profile name")).setView(name).setPositiveButton(t("Сохранить","Save"),(d,w)->{String title=name.getText().toString();run(()->store().save(title,current(),false),entry->profiles());}).setNegativeButton(t("Отмена","Cancel"),null).show();}
 private File exportFile(){return new File(a.getFilesDir(),"profile-export.pending");}
 private void export(ProfileStore.Entry entry){run(()->{ProfileStore.atomic(exportFile(),ProfileStore.pack(entry.name,entry.config));return entry.name;},name->{try{((MainActivity)a).startCompanionIntent(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,name+".dofprofile"),EXPORT);}catch(RuntimeException e){exportFile().delete();toast(t("Экспорт недоступен","Export unavailable"));}});}
 boolean activityResult(int request,int result,Intent data){
  if(request==PLAYER)return true;if(request!=IMPORT&&request!=EXPORT)return false;
  if(result!=Activity.RESULT_OK||data==null||data.getData()==null){if(request==EXPORT)exportFile().delete();return true;}
  Uri uri=data.getData();
  if(request==IMPORT)run(()->{byte[] bytes;try(InputStream in=a.getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("Cannot open file");bytes=ConfigDocument.bounded(in,20000);}ProfileStore.Entry entry=ProfileStore.unpack(bytes);return store().save(entry.name,entry.config,false);},entry->{toast(t("Профиль импортирован","Profile imported"));profiles();});
  else run(()->{try{byte[] bytes=ProfileStore.read(exportFile(),20000);ProfileStore.unpack(bytes);try(OutputStream out=a.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Cannot write file");out.write(bytes);out.flush();}return true;}finally{exportFile().delete();}},ok->toast(t("Профиль экспортирован","Profile exported")));
  return true;
 }
 private interface Changed{void set(int value);}
 private void slider(LinearLayout body,String title,int value,int low,int high,Changed changed){TextView label=text(title+"  "+value,14,ink);body.addView(label);SeekBar seek=new SeekBar(a);seek.setMax(high-low);seek.setProgress(Math.max(0,Math.min(high-low,value-low)));seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int n,boolean user){int v=n+low;label.setText(title+"  "+v);changed.set(v);}});body.addView(seek,new LinearLayout.LayoutParams(-1,dp(44)));}
 private void layout(){
  LinearLayout body=window(t("Редактор интерфейса","Interface editor"));TextView loading=text(t("Чтение настроек…","Reading settings…"),14,muted);body.addView(loading);
  run(()->ConfigDocument.parse(current()),doc->{body.removeView(loading);LayoutPreview preview=new LayoutPreview(a,doc);body.addView(preview,new LinearLayout.LayoutParams(-1,dp(190)));body.addView(text(t("Предпросмотр меню на экране","Menu preview on screen"),12,muted));
   String[] keys={"menu_scale","menu_opacity","menu_x","menu_y"};String[] titles={t("Размер меню (%)","Menu size (%)"),t("Непрозрачность (%)","Opacity (%)"),t("Положение X (%)","Position X (%)"),t("Положение Y (%)","Position Y (%)")};int[] defaults={100,100,50,50},low={70,50,0,0},high={110,100,100,100};
   for(int i=0;i<keys.length;i++){final String key=keys[i];slider(body,titles[i],Math.max(low[i],Math.min(high[i],doc.number(key,defaults[i]))),low[i],high[i],v->{doc.setNumber(key,v);preview.invalidate();});}
   button(body,t("Применить к меню","Apply to menu"),()->run(()->apply(doc.bytes()),this::applied));
   button(body,t("Сбросить расположение","Reset layout"),()->{for(int i=0;i<keys.length;i++)doc.setNumber(keys[i],defaults[i]);run(()->apply(doc.bytes()),result->{applied(result);layout();});});
  });
 }
 private static final class LayoutPreview extends View {
  private final ConfigDocument doc;private final Paint p=new Paint(3);private final int[] colors={0xffe0262b,0xffff6e1f,0xffffba21,0xffa6e62b,0xff2ecc61,0xff1abfa1,0xff21cced,0xff4085ff,0xff6e59f5,0xffb34de6,0xfff54db3,0xffdedee6};
  LayoutPreview(Context c,ConfigDocument d){super(c);doc=d;p.setTypeface(BrandFonts.regular(c));setContentDescription("Menu layout preview");}
  protected void onDraw(Canvas c){super.onDraw(c);float density=getResources().getDisplayMetrics().density;c.scale(density,density);float w=getWidth()/density,h=getHeight()/density;p.setColor(0xff11151d);c.drawRoundRect(0,0,w,h,20,20,p);float scale=Math.max(.7f,Math.min(1.1f,doc.number("menu_scale",100)/100f)),mw=Math.min(w*.94f,w*.72f*scale),mh=Math.min(h*.92f,h*.8f*scale);float x=(w-mw)*Math.max(0,Math.min(100,doc.number("menu_x",50)))/100f,y=(h-mh)*Math.max(0,Math.min(100,doc.number("menu_y",50)))/100f;int alpha=Math.max(128,Math.min(255,doc.number("menu_opacity",100)*255/100));p.setColor(Color.argb(alpha,36,38,48));c.drawRoundRect(x,y,x+mw,y+mh,12,12,p);p.setColor(((colors[Math.max(0,Math.min(11,doc.number("menu_theme",0)))]&0xffffff)|(alpha<<24)));c.drawRoundRect(x+8,y+8,x+mw-8,y+23,5,5,p);p.setTextSize(11*getResources().getConfiguration().fontScale);p.setColor(Color.argb(alpha,245,245,250));c.drawText("Nova · Oxide",x+14,y+20,p);for(int i=0;i<3;i++){p.setColor(Color.argb(alpha,100,104,125));float yy=y+37+i*(mh-64)/3;c.drawRoundRect(x+12,yy,x+mw*.43f,yy+6,3,3,p);p.setColor(((colors[Math.max(0,Math.min(11,doc.number("menu_theme",0)))]&0xffffff)|(alpha<<24)));c.drawRoundRect(x+mw*.62f,yy,x+mw-14,yy+9,5,5,p);}p.setColor(Color.argb(alpha,64,68,86));c.drawRoundRect(x+8,y+mh-23,x+mw-8,y+mh-7,5,5,p);}
 }
 private void history(){
  if(Build.VERSION.SDK_INT<29&&a.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){a.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},HISTORY_PERMISSION);return;}
  LinearLayout body=window(t("История записей","Recording history"));TextView loading=text(t("Загрузка…","Loading…"),14,muted);body.addView(loading);int generation=epoch;
  run(()->VideoCatalog.list(a),clips->{body.removeView(loading);if(clips.isEmpty())body.addView(text(t("Сохранённых записей пока нет","No saved recordings yet"),14,muted));else body.addView(text(t("Последние записи: ","Recent recordings: ")+clips.size(),12,muted));
   for(int i=0;i<clips.size();i++){VideoCatalog.Clip clip=clips.get(i);LinearLayout card=new LinearLayout(a);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(12));card.setBackground(shape(Color.argb(18,128,128,128)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(12);body.addView(card,lp);
    if(i<24){ImageView image=new ImageView(a);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setContentDescription(clip.name);card.addView(image,new LinearLayout.LayoutParams(-1,dp(144)));thumbs.execute(()->{Bitmap bitmap=null;try{bitmap=VideoCatalog.thumbnail(a,clip);}catch(RuntimeException ignored){}final Bitmap result=bitmap;main.post(()->{if(alive()&&epoch==generation&&result!=null)image.setImageBitmap(result);else if(result!=null)result.recycle();});});}
    card.addView(text(clip.name,14,ink));String duration=clip.duration>0?String.format(Locale.ROOT,"%d:%02d · ",clip.duration/60000,clip.duration/1000%60):"";card.addView(text(duration+String.format(Locale.getDefault(),"%.1f MB",clip.size/1000000d)+" · "+new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date(clip.date)),12,muted));
    button(card,t("Смотреть","Play"),()->{try{((MainActivity)a).startCompanionIntent(new Intent(Intent.ACTION_VIEW).setDataAndType(clip.uri,"video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),PLAYER);}catch(RuntimeException e){toast(t("Не найден видеоплеер или файл недоступен","No video player or file unavailable"));}});
    button(card,t("Удалить запись","Delete recording"),()->builder().setTitle(t("Удалить запись?","Delete recording?")).setMessage(clip.name).setPositiveButton(t("Удалить","Delete"),(d,w)->run(()->{VideoCatalog.delete(a,clip);return true;},ok->history())).setNegativeButton(t("Отмена","Cancel"),null).show());
   }
  });
 }
 void permissionResult(int[] results){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)history();else toast(t("Нет доступа к записям","Recording access denied"));}
 void close(){closed=true;epoch++;if(panel!=null)panel.dismiss();io.shutdown();thumbs.shutdownNow();main.removeCallbacksAndMessages(null);}
}
