package cc.nova.oxide;

final class RecordingProfile {
    interface Limits { int widthAlignment(); int heightAlignment(); boolean supports(int width,int height,int fps); int minBitrate(); int maxBitrate(); }
    final int width,height,fps,bitrate;
    RecordingProfile(int width,int height,int fps,int bitrate){this.width=width;this.height=height;this.fps=fps;this.bitrate=bitrate;}
    static RecordingProfile choose(int displayWidth,int displayHeight,int shortEdge,int requestedFps,int bitrate,boolean landscape,Limits caps){
        if(displayWidth<1||displayHeight<1||displayWidth>16384||displayHeight>16384||requestedFps<1||requestedFps>60||bitrate<100000||bitrate>50000000)throw new IllegalArgumentException("Invalid recording profile");
        int sourceW=landscape?Math.max(displayWidth,displayHeight):displayWidth,sourceH=landscape?Math.min(displayWidth,displayHeight):displayHeight;
        double scale=Math.min(1.0,shortEdge>0?(double)shortEdge/Math.min(sourceW,sourceH):1.0);scale=Math.min(scale,4096.0/Math.max(sourceW,sourceH));
        int wa=Math.max(2,caps.widthAlignment()),ha=Math.max(2,caps.heightAlignment());if(wa>256||ha>256||caps.minBitrate()>caps.maxBitrate())throw new IllegalArgumentException("Invalid encoder limits");
        double[] sizes={1,.75,2.0/3,.5,.375,.25};int[] rates={requestedFps,30,24,15};
        for(double factor:sizes){int w=(int)(sourceW*scale*factor)/wa*wa,h=(int)(sourceH*scale*factor)/ha*ha;if(Math.min(w,h)<240)continue;
            for(int rate:rates)if(rate<=requestedFps&&caps.supports(w,h,rate))return new RecordingProfile(w,h,rate,Math.max(caps.minBitrate(),Math.min(caps.maxBitrate(),bitrate)));
        }
        throw new IllegalArgumentException("No supported H.264 recording profile");
    }
}
