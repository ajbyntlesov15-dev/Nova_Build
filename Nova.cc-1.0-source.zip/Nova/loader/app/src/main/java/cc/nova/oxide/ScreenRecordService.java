package cc.nova.oxide;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.*;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class ScreenRecordService extends Service {
    static final String START="cc.nova.oxide.RECORD_START",STOP="cc.nova.oxide.RECORD_STOP";
    static final String PREFS="recording";
    static final int[] EDGES={720,1080,0},RATES={24,30,60},MBPS={4,6,8,12,16,24,32};
    static final RecordingSession SESSION=new RecordingSession();
    static volatile RecordingProfile actual;
    private static final int NOTIFICATION=1401;
    private HandlerThread thread;private Handler worker;
    private MediaRecorder recorder;private MediaProjection projection;private VirtualDisplay display;
    private ParcelFileDescriptor output;private Uri uri;private File legacyFile;
    private boolean started,closing;private long startUptime;
    private final MediaProjection.Callback callback=new MediaProjection.Callback(){@Override public void onStop(){finish(null);}};
    private final Runnable heartbeat=new Runnable(){@Override public void run(){if(closing)return;writeStatus();worker.postDelayed(this,1000);}};
    private SharedPreferences preferences(){return getSharedPreferences(PREFS,MODE_PRIVATE);}
    private boolean english(){return getSharedPreferences("MainActivity",MODE_PRIVATE).getInt("language",0)==1;}
    private String tx(String ru,String en){return english()?en:ru;}
    static int index(SharedPreferences preferences,String name,int size,int fallback){return Math.max(0,Math.min(size-1,preferences.getInt(name,fallback)));}
    @Override public void onCreate(){super.onCreate();thread=new HandlerThread("NovaRecorder");thread.start();worker=new Handler(thread.getLooper());}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null){stopSelf();return START_NOT_STICKY;}
        if(STOP.equals(intent.getAction())){SESSION.requestStop();worker.post(()->finish(null));return START_NOT_STICKY;}
        if(!START.equals(intent.getAction())||!new KeyAccess(this).hasAccess()){stopSelf();return START_NOT_STICKY;}
        if(closing){SESSION.finish("Recorder is stopping; try again");stopSelf();return START_NOT_STICKY;}if(!SESSION.begin())return START_NOT_STICKY;actual=null;
        boolean microphone=preferences().getBoolean("mic",false);
        try{
            NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);manager.createNotificationChannel(new NotificationChannel("nova_recording",tx("Запись экрана","Screen recording"),NotificationManager.IMPORTANCE_LOW));
            int type=Build.VERSION.SDK_INT>=29?ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION:0;
            if(microphone&&Build.VERSION.SDK_INT>=30)type|=ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION,notification(false),type);else startForeground(NOTIFICATION,notification(false));
        }catch(RuntimeException e){worker.post(()->finish(e));return START_NOT_STICKY;}
        final int code=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED);final Intent consent=intent.getParcelableExtra("consent");
        worker.post(()->{try{if(code!=Activity.RESULT_OK||consent==null)throw new IOException("Screen capture consent missing");startRecording(code,consent,microphone);}catch(Exception e){finish(e);}});
        return START_NOT_STICKY;
    }
    private Notification notification(boolean recording){
        Intent open=new Intent(this,MainActivity.class).putExtra("recorder_action","config").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content=PendingIntent.getActivity(this,1401,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,1402,new Intent(this,ScreenRecordService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder=new Notification.Builder(this,"nova_recording").setSmallIcon(android.R.drawable.presence_video_online).setContentTitle("Nova").setContentText(recording?tx("Идёт запись экрана","Recording screen"):tx("Подготовка записи…","Preparing recording…")).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(content).addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,tx("Остановить","Stop"),stop).build());
        if(recording)builder.setUsesChronometer(true).setWhen(System.currentTimeMillis());return builder.build();
    }
    private void cleanupOrphan(){
        SharedPreferences p=preferences();String pending=p.getString("pending_uri","");
        if(!pending.isEmpty())try{Uri old=Uri.parse(pending);if("media".equals(old.getAuthority())){boolean published=false;if(Build.VERSION.SDK_INT>=29)try(android.database.Cursor cursor=getContentResolver().query(old,new String[]{MediaStore.Video.Media.IS_PENDING},null,null,null)){published=cursor!=null&&cursor.moveToFirst()&&cursor.getInt(0)==0;}if(published||validVideo(old)){if(!published&&Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(old,values,null,null);}p.edit().putString("last_uri",old.toString()).apply();}else getContentResolver().delete(old,null,null);}}catch(RuntimeException e){Log.w("NovaRecorder","Cannot recover incomplete recording",e);}
        String path=p.getString("pending_path","");if(!path.isEmpty())try{File f=new File(path).getCanonicalFile();if(RecordedVideoProvider.directory().getCanonicalFile().equals(f.getParentFile())&&f.getName().startsWith("Nova_")){Uri previous=RecordedVideoProvider.uri(f);if(previous.toString().equals(p.getString("last_uri",""))||validVideo(previous)){p.edit().putString("last_uri",previous.toString()).apply();MediaScannerConnection.scanFile(this,new String[]{f.getAbsolutePath()},new String[]{"video/mp4"},null);}else f.delete();}}catch(IOException ignored){}
        p.edit().remove("pending_uri").remove("pending_path").apply();
    }
    private RecordingProfile profile(DisplayMetrics metrics){
        SharedPreferences p=preferences();int edge=EDGES[index(p,"quality",EDGES.length,0)],fps=RATES[index(p,"fps",RATES.length,1)],bitrate=MBPS[index(p,"bitrate",MBPS.length,2)]*1000000;boolean landscape=p.getInt("orientation",0)==0;
        RuntimeException last=null;for(MediaCodecInfo codec:new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()){
            if(!codec.isEncoder())continue;boolean avc=false;for(String mime:codec.getSupportedTypes())if("video/avc".equalsIgnoreCase(mime))avc=true;if(!avc)continue;
            try{MediaCodecInfo.CodecCapabilities c=codec.getCapabilitiesForType("video/avc");boolean surface=false;for(int format:c.colorFormats)if(format==MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)surface=true;if(!surface)continue;final MediaCodecInfo.VideoCapabilities limits=c.getVideoCapabilities();
                return RecordingProfile.choose(metrics.widthPixels,metrics.heightPixels,edge,fps,bitrate,landscape,new RecordingProfile.Limits(){public int widthAlignment(){return limits.getWidthAlignment();}public int heightAlignment(){return limits.getHeightAlignment();}public boolean supports(int w,int h,int rate){return limits.areSizeAndRateSupported(w,h,rate);}public int minBitrate(){return limits.getBitrateRange().getLower();}public int maxBitrate(){return limits.getBitrateRange().getUpper();}});
            }catch(RuntimeException e){last=e;}
        }throw new IllegalStateException("No supported H.264 encoder",last);
    }
    private void openOutput()throws IOException {
        String name="Nova_"+new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date())+".mp4";
        if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Video.Media.DISPLAY_NAME,name);values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");values.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/Nova");values.put(MediaStore.Video.Media.IS_PENDING,1);uri=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("Cannot create recording");if(!preferences().edit().putString("pending_uri",uri.toString()).commit())throw new IOException("Cannot track recording output");output=getContentResolver().openFileDescriptor(uri,"rw");}
        else{File folder=RecordedVideoProvider.directory();if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("Cannot create Movies/Nova");legacyFile=new File(folder,name);uri=RecordedVideoProvider.uri(legacyFile);if(!preferences().edit().putString("pending_path",legacyFile.getAbsolutePath()).commit())throw new IOException("Cannot track recording output");output=ParcelFileDescriptor.open(legacyFile,ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE|ParcelFileDescriptor.MODE_READ_WRITE);}
        if(output==null)throw new IOException("Recording output is unavailable");
    }
    private void startRecording(int result,Intent consent,boolean microphone)throws Exception {
        if(SESSION.state()!=RecordingSession.STARTING){finish(null);return;}
        cleanupOrphan();DisplayMetrics metrics=new DisplayMetrics();((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(metrics);actual=profile(metrics);
        long available=new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath()).getAvailableBytes()-64L*1024*1024;if(available<32L*1024*1024)throw new IOException(tx("Недостаточно свободного места","Not enough free space"));
        openOutput();recorder=Build.VERSION.SDK_INT>=31?new MediaRecorder(this):new MediaRecorder();if(microphone)recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);recorder.setVideoSize(actual.width,actual.height);recorder.setVideoFrameRate(actual.fps);recorder.setVideoEncodingBitRate(actual.bitrate);
        if(microphone){recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioSamplingRate(44100);recorder.setAudioChannels(1);recorder.setAudioEncodingBitRate(128000);}
        recorder.setOutputFile(output.getFileDescriptor());recorder.setMaxFileSize(Math.min(available,0xffffffffL));recorder.setOnErrorListener((r,what,extra)->worker.post(()->finish(new IOException("MediaRecorder error "+what+"/"+extra))));recorder.setOnInfoListener((r,what,extra)->{if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED)worker.post(()->finish(null));});recorder.prepare();
        projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(result,consent);if(projection==null)throw new IOException("Screen capture unavailable");projection.registerCallback(callback,worker);
        display=projection.createVirtualDisplay("Nova recording",actual.width,actual.height,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,recorder.getSurface(),null,worker);if(display==null)throw new IOException("Capture display unavailable");
        if(SESSION.state()!=RecordingSession.STARTING){finish(null);return;}
        recorder.start();started=true;startUptime=SystemClock.uptimeMillis();if(!SESSION.markRecording()){finish(null);return;}
        preferences().edit().putInt("actual_width",actual.width).putInt("actual_height",actual.height).putInt("actual_fps",actual.fps).putInt("actual_bitrate",actual.bitrate).remove("last_error").apply();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION,notification(true));heartbeat.run();
    }
    private boolean validVideo(){return validVideo(uri);}
    private boolean validVideo(Uri target){
        if(target==null)return false;MediaMetadataRetriever metadata=new MediaMetadataRetriever();try{metadata.setDataSource(this,target);String video=metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO),duration=metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);return "yes".equals(video)&&duration!=null&&Long.parseLong(duration)>0;}catch(RuntimeException e){return false;}finally{try{metadata.release();}catch(IOException|RuntimeException ignored){}}
    }
    private void finish(Throwable failure){
        if(closing)return;closing=true;SESSION.requestStop();worker.removeCallbacks(heartbeat);writeStatus();Throwable stopError=null;
        if(started&&recorder!=null)try{recorder.stop();}catch(RuntimeException e){stopError=e;}
        if(display!=null){try{display.release();}catch(RuntimeException ignored){}display=null;}
        if(recorder!=null){try{recorder.release();}catch(RuntimeException ignored){}recorder=null;}
        if(projection!=null){try{projection.unregisterCallback(callback);projection.stop();}catch(RuntimeException ignored){}projection=null;}
        if(output!=null){try{output.close();}catch(IOException ignored){}output=null;}
        boolean saved=started&&validVideo();if(started&&!saved){for(int attempt=0;attempt<3&&!saved;attempt++){try{Thread.sleep(150);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}saved=validVideo();}}
        try{
            if(saved){if(Build.VERSION.SDK_INT>=29){ContentValues values=new ContentValues();values.put(MediaStore.Video.Media.IS_PENDING,0);if(getContentResolver().update(uri,values,null,null)!=1)throw new IOException("Cannot publish recording");}else MediaScannerConnection.scanFile(this,new String[]{legacyFile.getAbsolutePath()},new String[]{"video/mp4"},null);preferences().edit().putString("last_uri",uri.toString()).apply();}
            else if(uri!=null){if(Build.VERSION.SDK_INT>=29)getContentResolver().delete(uri,null,null);else if(legacyFile!=null)legacyFile.delete();}
        }catch(Exception e){saved=false;if(failure==null)failure=e;}
        if(started&&!saved&&failure==null)failure=stopError==null?new IOException(tx("Нет корректных видеокадров","No valid video frames")):stopError;
        if(!saved&&uri!=null){try{if(Build.VERSION.SDK_INT>=29)getContentResolver().delete(uri,null,null);else if(legacyFile!=null)legacyFile.delete();}catch(RuntimeException ignored){}}
        String error=failure==null?"":failure.getClass().getSimpleName()+": "+String.valueOf(failure.getMessage());SESSION.finish(error);preferences().edit().remove("pending_uri").remove("pending_path").putString("last_error",error).apply();writeStatus();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    static void writeUi(Context context,boolean active){
        File temp=null;try{File destination=new File(context.getFilesDir(),"recording.ui");temp=File.createTempFile("record-ui-",".tmp",context.getFilesDir());if(!temp.setReadable(false,false)||!temp.setWritable(false,false)||!temp.setReadable(true,true)||!temp.setWritable(true,true))throw new IOException("Cannot protect UI state");String data="NovaCaptureUi 1\n"+android.os.Process.myPid()+" "+SystemClock.uptimeMillis()+" "+(active?1:0)+"\n";try(FileOutputStream out=new FileOutputStream(temp)){out.write(data.getBytes(java.nio.charset.StandardCharsets.US_ASCII));}if(!temp.renameTo(destination))throw new IOException("Cannot save UI state");}catch(IOException e){Log.w("NovaRecorder","UI state update failed",e);}finally{if(temp!=null)temp.delete();}
    }
    private void writeStatus(){
        File temp=null;try{File destination=new File(getFilesDir(),"recording.status");temp=File.createTempFile("record-",".tmp",getFilesDir());if(!temp.setReadable(false,false)||!temp.setWritable(false,false)||!temp.setReadable(true,true)||!temp.setWritable(true,true))throw new IOException("Cannot protect recorder state");RecordingProfile p=actual;String data="NovaRecording 1\n"+SESSION.state()+" "+android.os.Process.myPid()+" "+SystemClock.uptimeMillis()+" "+startUptime+" "+(p==null?0:p.width)+" "+(p==null?0:p.height)+" "+(p==null?0:p.fps)+" "+(p==null?0:p.bitrate)+"\n";try(FileOutputStream out=new FileOutputStream(temp)){out.write(data.getBytes(java.nio.charset.StandardCharsets.US_ASCII));out.getFD().sync();}if(!temp.renameTo(destination))throw new IOException("Cannot save recorder state");}catch(IOException e){Log.w("NovaRecorder","Recorder state update failed",e);}finally{if(temp!=null)temp.delete();}
    }
    @Override public void onDestroy(){if(worker!=null){worker.post(()->finish(null));thread.quitSafely();}super.onDestroy();}
}
