package cc.nova.oxide;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
public final class LocalVipProbe {
    private static void require(boolean b){if(!b)throw new AssertionError("Local VIP JNI check failed");}
    public static void main(String[] args)throws Exception{
        require(LicenseBridge.available());String device=new String(new char[64]).replace('\0','a'),build=new String(new char[128]).replace('\0','b'),next=new String(new char[128]).replace('\0','c');int count=0;long now=1800000000L;
        for(String row:Files.readAllLines(Paths.get(args[0]),StandardCharsets.UTF_8)){
            String key=row.trim();if(!key.startsWith("Nova-"))continue;
            String receipt=LicenseBridge.localIssue(key,device,build,now);require(receipt!=null&&LicenseBridge.localCheck(receipt,device,build,now));require(!LicenseBridge.localCheck(receipt,device,next,now));require(!LicenseBridge.localCheck(receipt,"bad",build,now));require(!LicenseBridge.localCheck(receipt,device,build,now-1));require(!LicenseBridge.localCheck(receipt+"x",device,build,now));
            String migrated=LicenseBridge.localMigrate(receipt,device,next,now+10);require(migrated!=null&&LicenseBridge.localCheck(migrated,device,next,now+10));String[] a=receipt.split("\n"),b=migrated.split("\n");require(a[1].equals(b[1])&&a[2].equals(b[2])&&a[3].equals(b[3]));long end=Long.parseLong(a[3]);if(end!=0)require(!LicenseBridge.localCheck(receipt,device,build,end));count++;
        }
        require(count==250);require(LicenseBridge.localIssue("Nova-!!!!!!!!!!",device,build,now)==null);require(LicenseBridge.localIssue(null,device,build,now)==null);require(!LicenseBridge.localCheck(null,device,build,now));require(LicenseBridge.localMigrate("bad",device,next,now)==null);System.out.println("PASS: actual Java/JNI localIssue/localCheck/localMigrate for all 250 keys, expiry and preserved dates");
    }
}
