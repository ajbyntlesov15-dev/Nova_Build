#!/usr/bin/env python3
"""Runs the actual Java access class with host Android API fixtures and the native receipt gate."""
import hashlib,os,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def run(args,**kw):return subprocess.run(list(map(str,args)),check=True,text=True,capture_output=True,**kw)
with tempfile.TemporaryDirectory(prefix='oxide-common-access-') as folder:
 t=Path(folder);native=t/'native';native.mkdir();payload=b'host module fixture';(native/'libnova_exec.so').write_bytes(payload)
 sources={
 'android/content/Context.java':'''package android.content; import java.io.File; public class Context { final File files; final String nativeDir; public Context(File f,String n){files=f;nativeDir=n;} public Context getApplicationContext(){return this;} public File getFilesDir(){return files;} public String getPackageName(){return "cc.nova.oxide";} public android.content.pm.PackageManager getPackageManager(){return new android.content.pm.PackageManager();} public android.content.pm.ApplicationInfo getApplicationInfo(){android.content.pm.ApplicationInfo info=new android.content.pm.ApplicationInfo(); info.nativeLibraryDir=nativeDir;return info;} }''',
 'android/content/pm/PackageManager.java':'''package android.content.pm; public class PackageManager { public static final int GET_SIGNATURES=64; public PackageInfo getPackageInfo(String p,int flags){return new PackageInfo();} }''',
 'android/content/pm/PackageInfo.java':'''package android.content.pm; public class PackageInfo { public Signature[] signatures={new Signature()}; }''',
 'android/content/pm/Signature.java':'''package android.content.pm; public class Signature { public byte[] toByteArray(){return new byte[]{1,2,3};} }''',
 'android/content/pm/ApplicationInfo.java':'''package android.content.pm; public class ApplicationInfo { public String nativeLibraryDir; }''',
 'com/nova/oxide/BuildSecrets.java':'package cc.nova.oxide; final class BuildSecrets {static final String CERT_SHA512="'+hashlib.sha512(bytes([1,2,3])).hexdigest()+'";static final String NATIVE_SHA512="'+hashlib.sha512(payload).hexdigest()+'";}',
 'com/nova/oxide/AccessProbe.java':'''package cc.nova.oxide; import java.io.*; import java.nio.file.*; import java.nio.charset.StandardCharsets; import java.util.concurrent.atomic.AtomicInteger; public class AccessProbe {static void check(boolean value){if(!value)throw new AssertionError();}public static void main(String[] args)throws Exception {File one=new File(args[0],"one"),two=new File(args[0],"two");one.mkdir();two.mkdir();KeyAccess a=new KeyAccess(new android.content.Context(one,args[1])),b=new KeyAccess(new android.content.Context(two,args[1]));check(!a.hasAccess()&&!a.activate(null)&&!a.activate("wrong"));check(!a.openChannelOnce(()->{throw new AssertionError("opened before activation");}));check(a.activate("  https://t.me/NovaCheat  ")&&a.hasAccess());check(b.activate("https://t.me/NovaCheat")&&b.hasAccess());check(java.util.Arrays.equals(Files.readAllBytes(a.file().toPath()),Files.readAllBytes(b.file().toPath())));try{b.openChannelOnce(()->{throw new IllegalStateException("no handler");});throw new AssertionError();}catch(IllegalStateException expected){}AtomicInteger retries=new AtomicInteger();check(new KeyAccess(new android.content.Context(two,args[1])).openChannelOnce(()->retries.incrementAndGet()));check(!b.openChannelOnce(()->retries.incrementAndGet())&&retries.get()==1);AtomicInteger opens=new AtomicInteger();check(a.openChannelOnce(()->opens.incrementAndGet()));check(!a.openChannelOnce(()->opens.incrementAndGet())&&opens.get()==1);Files.write(a.file().toPath(),"tampered".getBytes(StandardCharsets.US_ASCII));check(!a.hasAccess());check(a.activate(KeyAccess.KEY)&&a.hasAccess());File module=new File(args[1],"libnova_exec.so");Files.write(module.toPath(),new byte[]{0});check(!a.hasAccess()&&!a.activate(KeyAccess.KEY));System.out.println("PASS: actual Java KeyAccess: same old key activates two installations, null/wrong key and modified receipt/module rejected, trimmed key accepted, channel opens once; no device ID/expiry required");} }'''
 }
 files=[]
 for name,data in sources.items():
  path=t/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(data);files.append(path)
 files.append(root/'loader/app/src/main/java/com/nova/oxide/KeyAccess.java')
 run(['java','com.sun.tools.javac.Main','-d',t,*files]);print(run(['java','-cp',t,'cc.nova.oxide.AccessProbe',t,native]).stdout.strip())
 probe=t/'receipt.cpp';probe.write_text('''#include "runtime/access_receipt.hpp"
#include <iostream>
int main(int n,char** v){if(n!=2)return 64;access_receipt::Lease access;if(!access.start(v[1],getuid()))return 77;if(!access.allows(dof_license::All))return 78;std::cout<<"OK"<<std::endl;std::string s;std::getline(std::cin,s);if(!access.valid())return 79;}
''')
 exe=t/'receipt';run(['g++','-std=c++17','-O1','-pthread','-I',root/'native/src',probe,'-o',exe]);receipt=t/'receipt-v1';receipt.write_text('NovaAccess 1\n0085fd0bfc0204e3c266961d328d710a2d7371370829882059a1821ac54c5056\n');receipt.chmod(0o600)
 assert run([exe,receipt],input='\n').stdout.strip()=='OK'
 child=subprocess.Popen([str(exe),str(receipt)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True);assert child.stdout.readline().strip()=='OK';receipt.write_text('bad');import time;time.sleep(1.1);child.communicate('\n',timeout=5);assert child.returncode==79
 assert subprocess.run([str(exe),str(receipt)],input='\n',text=True,capture_output=True).returncode==77
 print('PASS: standalone native common receipt accepts all functions without device/clock data, rejects corruption at startup and during operation')
