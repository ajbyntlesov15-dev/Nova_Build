#include <cstdlib>
#include <string>
#include <vector>
#include "security/license.hpp"
#include "runtime/access_receipt.hpp"
#include <cassert>
#include <cstdio>
#include <random>
using namespace dof_license;
int main(){
 uint32_t uid=0;assert(access_receipt::control_uid("/data/local/tmp/nova-10123",uid)&&uid==10123);assert(!access_receipt::control_uid("/data/local/tmp/nova-0",uid)&&!access_receipt::control_uid("/data/local/tmp/nova-4294967296",uid));
 std::string tmp_pattern=std::string(std::getenv("TMPDIR")?std::getenv("TMPDIR"):"/tmp")+"/oxide-license-XXXXXX";std::vector<char> tmp_buffer(tmp_pattern.begin(),tmp_pattern.end());tmp_buffer.push_back(0);char* path=tmp_buffer.data();int fd=mkstemp(path);assert(fd>=0);assert(write(fd,"test",4)==4);close(fd);std::string text;assert(access_receipt::read_owned(path,getuid(),4,text)&&text=="test");chmod(path,0644);assert(!access_receipt::read_owned(path,getuid(),4,text));chmod(path,0600);assert(!access_receipt::read_owned(path,getuid(),3,text));std::string link=std::string(path)+"-link";assert(symlink(path,link.c_str())==0);assert(!access_receipt::read_owned(link,getuid(),4,text));unlink(link.c_str());unlink(path);
 puts("PASS: common access private file, symlink, size and UID checks");
}
