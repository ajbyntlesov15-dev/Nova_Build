package cc.nova.oxide;
import java.nio.charset.StandardCharsets;
public final class MenuConfigProbe {
 public static void main(String[] args)throws Exception {
  StringBuilder text=new StringBuilder("OxideConfig 6\nfov 40\n");
  for(String prefix:new String[]{"silent_","touch_","aim360_"}){
   for(String key:"visibility animals bots ignore_team ignore_clan predict sticky draw_fov marker".split(" "))text.append(prefix).append(key).append(" 1\n");
   for(String key:"fov distance bone mode activation smooth lead_ms".split(" "))text.append(prefix).append(key).append(" 1\n");
  }
  text.append("trigger_distance 200\ntrigger_ignore_team 1\nheal_threshold 50\nheal_interval 1800\ntracer_length 200\ntracer_lifetime 1500\ntracer_width 20\n");
  ConfigDocument d=ConfigDocument.parse(text.toString().getBytes(StandardCharsets.UTF_8));
  d.setNumber("silent_fov",90);d.setNumber("touch_fov",65);
  ConfigDocument saved=ConfigDocument.parse(d.bytes());
  if(saved.number("fov",0)!=40||saved.number("silent_fov",0)!=90||saved.number("touch_fov",0)!=65)throw new AssertionError();
  try{ConfigDocument.parse("OxideConfig 6\nsilent_visibility 2\n".getBytes(StandardCharsets.UTF_8));throw new AssertionError();}catch(java.io.IOException expected){}
  try{ConfigDocument.parse("OxideConfig 6\nsilent_fov 90\nsilent_fov 20\n".getBytes(StandardCharsets.UTF_8));throw new AssertionError();}catch(java.io.IOException expected){}
  System.out.println("PASS: all mode settings accepted, independent import/export, invalid values and duplicates rejected");
 }
}
