package cc.nova.oxide;
public final class OverlayOpacityProbe {
 public static void main(String[] args){for(float max:new float[]{0,.1f,.4f,.8f,1}){float a=OverlayOpacity.renderAlpha(max);if(a<0||a>.75f||a>max)throw new AssertionError("touch opacity budget");}if(OverlayOpacity.renderAlpha(Float.NaN)!=0||Math.abs(OverlayOpacity.renderAlpha(.8f)-.75f)>.0001f)throw new AssertionError();System.out.println("PASS: one drawing window stays below touch blocking threshold; default opacity 75%");}
}
