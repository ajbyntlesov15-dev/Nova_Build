#include "runtime/profile.hpp"
using namespace oxide_profile;
static_assert(current.fp_derived_delta==0&&current.fp_base_delta==0,"release 12016 keeps its old weapon layout");
static_assert(beta.fp_derived_delta==8&&beta.fp_base_delta==12,"beta 12024 has two distinct layout shifts");
static_assert(0x130+beta.fp_derived_delta==0x138,"FPHitscan.config verified in 12024 dump");
static_assert(0x238+beta.fp_derived_delta==0x240,"shot counter verified in 12024 dump");
static_assert(0x104+beta.fp_base_delta==0x110,"reload period verified in 12024 dump");
static_assert(beta.melee_reach_offset==0x13c&&current.melee_reach_offset==0x130,"melee has a separate field shift");
static_assert(beta.guard_count==14&&current.guard_count==14,"both profiles keep their integrity checks");
static_assert(beta.look_locks_offset==0x88&&current.look_locks_offset==0x80,"MouseLook lock list moved in beta 12024");
int main(){}
