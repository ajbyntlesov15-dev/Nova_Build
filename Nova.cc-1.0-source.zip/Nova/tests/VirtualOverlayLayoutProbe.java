package cc.nova.oxide;
public final class VirtualOverlayLayoutProbe {
 public static void main(String[] args){
  int[] menu={180,90,1400,800};
  VirtualOverlayLayout p=VirtualOverlayLayout.render(2400,1080,false,false,false,false,menu);
  check(p.width==2400&&p.height==1080&&p.renderVisible&&!p.inputActive,"ESP renderer remains visible without accepting touches");
  p=VirtualOverlayLayout.input(2400,1080,false,false,false,menu);check(!p.inputActive,"closed menu must have no input window");
  p=VirtualOverlayLayout.render(2400,1080,true,false,false,false,menu);check(p.x==0&&p.y==0&&p.width==2400&&p.height==1080&&p.renderVisible,"renderer stays fixed while menu moves");
  p=VirtualOverlayLayout.input(2400,1080,true,false,false,menu);check(p.inputActive&&p.x==180&&p.width==1400,"input bounded to menu");
  p=VirtualOverlayLayout.render(2400,1080,false,false,true,false,menu);check(p.width==2400&&p.height==1080,"legacy switch does not suppress ESP");
  p=VirtualOverlayLayout.input(2400,1080,false,false,false,menu);check(!p.inputActive,"full visuals must not enable full input");
  p=VirtualOverlayLayout.render(2400,1080,true,true,true,true,menu);check(!p.renderVisible&&p.width==1,"hide overrides every rendering mode");
  p=VirtualOverlayLayout.input(2400,1080,false,true,true,menu);check(!p.inputActive,"hide releases flight input");
  p=VirtualOverlayLayout.input(2400,1080,false,true,false,menu);check(p.inputActive&&p.width==2400,"flight deliberately captures its controls");
  p=VirtualOverlayLayout.input(1080,2400,true,false,false,new int[]{900,2200,600,500});check(p.width==180&&p.height==200,"orientation and clipping");
  p=VirtualOverlayLayout.input(1080,2400,true,false,false,new int[]{Integer.MAX_VALUE,0,Integer.MAX_VALUE,50});check(!p.inputActive,"overflow and offscreen bounds rejected");
  p=VirtualOverlayLayout.input(2400,1080,true,false,false,new int[]{0,0,0,0});check(p.width==1&&!p.inputActive,"pending bounds never create a fullscreen fallback");
  System.out.println("PASS: stable ESP surface, compact input, absent closed-menu input, legacy switch independence, hide, flight, rotation and invalid bounds");
 }
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
