#include "runtime/loot_classification.hpp"
#include <cassert>
int main(){using oxide::container_kind;
 assert(container_kind("Player_Loot_Bag(Clone)")==4);
 assert(container_kind("BackPack(Clone)")==4);
 assert(container_kind("death-loot") == 4);
 assert(container_kind("SmallWoodBox") == 1);
 assert(container_kind("LargeWoodBox") == 2);
 assert(container_kind("Cupboard") == 3);
 assert(container_kind("unknown_prefab") == 0);
}
