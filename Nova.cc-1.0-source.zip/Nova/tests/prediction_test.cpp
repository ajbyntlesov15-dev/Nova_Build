#include "runtime/prediction.hpp"
#include <cassert>
using namespace oxide;
int main(){
 V from{},target{0,0,100};auto still=intercept_point(from,target,{},200,0);assert(len(sub(still,target))<.001f);
 auto lateral=intercept_point(from,target,{5,0,0},200,0);assert(lateral.x>2.49f&&lateral.x<2.51f);
 float flight=len(sub(lateral,from))/200;assert(len(sub(lateral,add(target,mul(V{5,0,0},flight))))<.001f);
 auto near=intercept_point(from,{0,0,20},{5,0,0},200,0);assert(near.x<lateral.x);
 auto fast=intercept_point(from,target,{5,0,0},400,0);assert(fast.x<lateral.x);
 auto teleport=intercept_point(from,target,{1000,0,0},200,.1f);assert(len(sub(teleport,target))<.001f);
 assert(len(sub(intercept_point(from,target,{5,0,0},0,0),target))<.001f);
 auto latency=intercept_point(from,target,{5,0,0},200,.1f);assert(latency.x>lateral.x);
}
