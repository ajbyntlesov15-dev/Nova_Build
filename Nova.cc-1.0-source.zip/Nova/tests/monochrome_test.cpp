#include "ui/ui.hpp"
#include <cassert>
int main(int argc,char** argv){
 assert(argc==2);ui::cfg={};assert(ui::cfg.smooth==1&&ui::cfg.language==9);
 ui::cfg.caption_transparency=2;ui::cfg.actor_badge_scale=70;ui::cfg.silent_distance=500;ui::cfg.aim_distance=999;ui::cfg.sticky_aim=true;ui::cfg.aim_marker=true;ui::cfg.always_day=true;ui::cfg.player_status=true;
 ui::fixed_settings(ui::cfg);assert(ui::cfg.caption_transparency==50&&ui::cfg.actor_badge_scale==150&&ui::cfg.actor_badge);assert(ui::cfg.silent_distance==350&&ui::cfg.aim_distance==350&&!ui::cfg.sticky_aim&&!ui::cfg.aim_marker&&!ui::cfg.player_status&&!ui::cfg.always_day);
 assert(ui::cfg.trigger_delay==0&&ui::cfg.trigger_interval==0&&ui::cfg.watermark_style==1);
 auto c=ui::accent();assert(c.x==c.y&&c.y==c.z);
 {std::ofstream f(argv[1]);f<<"OxideConfig 6\nsmooth 6\nlanguage 0\n";}assert(ui::load(argv[1]));assert(ui::cfg.smooth==1&&ui::cfg.language==9&&ui::cfg.ui_revision==90);
 ui::cfg.language=7;assert(ui::save(argv[1]));assert(ui::load(argv[1])&&ui::cfg.language==7);unlink(argv[1]);
 for(int i=2;i<=8;++i){assert(std::string(oxide_ui_strings::translated("Визуалы",i))!="Визуалы");assert(std::string(oxide_ui_strings::translated("Настройки",i))!="Настройки");}
 for(auto& row:oxide_ui_strings::catalog())for(auto& translation:row.second)assert(!translation.empty());
 assert(oxide_ui_strings::arabic_display("test 123")=="test 123");
}
