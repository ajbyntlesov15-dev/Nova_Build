#include "runtime/visibility.hpp"
#include "runtime/world.hpp"
#include <cassert>
#include <unordered_map>
#include <cstdio>
using namespace oxide;
struct Memory {
 std::vector<unsigned char> bytes=std::vector<unsigned char>(2*1024*1024);uint64_t cursor=0x10000;std::unordered_map<uint64_t,std::string> names;
 uint64_t alloc(size_t n=0x100){auto a=cursor;cursor+=(n+15)&~size_t(15);assert(cursor<0x10000+bytes.size());return a;}
 bool read(uint64_t a,void* out,size_t n){if(a<0x10000||a+n>0x10000+bytes.size())return false;memcpy(out,bytes.data()+a-0x10000,n);return true;}
 template<class T>void put(uint64_t a,T v){assert(a>=0x10000&&a+sizeof(v)<=0x10000+bytes.size());memcpy(bytes.data()+a-0x10000,&v,sizeof(v));}
 uint64_t obj(const char* n){auto a=alloc();names[a]=n;return a;}
 uint64_t array(std::vector<uint64_t> v){auto a=alloc(0x20+v.size()*8);put(a+0x18,uint64_t(v.size()));for(size_t i=0;i<v.size();++i)put(a+0x20+i*8,v[i]);return a;}
};
int main(){for(bool beta:{false,true}){
 Memory m;MarkerVisibility visibility;Frame f;f.time=1000;Actor a;a.identity=0x12345000;a.id=42;a.hp=100;a.head={0,1.7f,10};a.body={0,1,10};
 auto data=m.alloc(),trs=m.alloc(),parents=m.alloc();m.put(data+0x18,trs);m.put(data+0x20,parents);m.put(trs,TRS{{0,1.7f,10,0},{0,0,0,1},{1,1,1,0}});m.put(parents,int(-1));a.root={data,0,{0,1.7f,10}};f.players={a};
 auto modes=m.obj("GameModes"),controller=m.obj(beta?"uA":"OG"),presenter=m.obj("ScreenMarkerPresenter"),delegate=m.obj("Action`1"),leaf=m.obj("Action`1");m.put(modes+(beta?0x88:0x80),controller);m.put(controller+0x20,delegate);m.put(delegate+0x78,m.array({leaf}));m.put(leaf+0x20,presenter);m.put(presenter+0x28,controller);
 auto dictionary=m.alloc(),entries=m.alloc(),marker=m.obj("Marker"),view=m.obj("NearbyPlayerScreenMarkerView"),context=m.obj("ScreenMarkerModuleContext"),camera=m.obj("Camera"),marker_data=m.obj("MarkerData"),follow=m.obj("Transform"),native=m.alloc(),module=m.obj("OcclusionModule"),modules=m.alloc();
 m.put(presenter+(beta?0x40:0x48),dictionary);m.put(dictionary+0x18,entries);m.put(dictionary+0x20,int(1));m.put(dictionary+0x24,int(1));m.put(entries+0x18,uint64_t(1));m.put(entries+0x20,int(0));m.put(entries+0x28,marker);m.put(entries+0x30,view);m.put(view+0x40,marker);m.put(marker+0x18,uint8_t(1));m.put(marker+0x10,marker_data);m.put(marker_data+0x40,follow);m.put(follow+0x10,native);m.put(native+0x28,data);m.put(native+0x30,int(0));m.put(view+0x28,context);m.put(view+0x30,modules);m.put(modules+0x10,m.array({module}));m.put(modules+0x18,int(1));m.put(context+0x58,camera);m.put(context+0x44,a.head);m.put(context+0x50,uint8_t(0));m.put(module+0x20,context);m.put(module+0x28,int(-1));m.put(module+0x2c,float(.2));m.put(module+0x38,float(5));m.put(module+0x3c,uint16_t(1));
 auto r=[&](uint64_t a,void* b,size_t n){return m.read(a,b,n);};auto name=[&](uint64_t a){auto i=m.names.find(a);return i==m.names.end()?std::string():i->second;};auto step=[&](long long time){visibility.update(r,name,f,modes,camera,beta?"uA":"OG",time,beta?0x88:0x80,beta?0x40:0x48);return f.players[0].visibility;};
 assert(step(1000)==0&&step(1100)==0); // Existing snapshot alone is not a fresh raycast.
 m.put(module+0x38,float(5.2));assert(step(1200)==0&&step(1208)==0&&step(1216)==1);assert(visibly_open(f.players[0],1220)&&visibility.confirm(r,name,f.players[0],camera,1220));
 auto visible=f.players[0];m.put(module+0x3c,uint16_t(257));assert(!visibility.confirm(r,name,visible,camera,1221));m.put(module+0x38,float(5.4));assert(step(1400)==0&&step(1416)==2);assert(!visibly_open(f.players[0],1416));
 assert(step(1800)==0); // Expired game cache.
 m.put(module+0x38,float(5.6));m.put(module+0x3c,uint16_t(1));assert(step(1900)==0&&step(1916)==1);
 m.put(context+0x50,uint8_t(1));assert(step(1920)==0);m.put(context+0x50,uint8_t(0));m.put(context+0x58,uint64_t(0));assert(step(1921)==0);m.put(context+0x58,camera);
 m.put(view+0x40,uint64_t(0));assert(step(1922)==0);m.put(view+0x40,marker);m.put(marker+0x18,uint8_t(0));assert(step(1923)==0);m.put(marker+0x18,uint8_t(1));
 m.put(context+0x44,V{100,100,100});assert(step(1924)==0);m.put(context+0x44,a.head);
 m.put(native+0x30,int(1));m.put(parents+4,int(1));assert(step(1925)==0);m.put(native+0x30,int(0));
 m.put(module+0x38,float(5.8));assert(step(2000)==0&&step(2016)==1);visible=f.players[0];m.put(marker_data+0x40,uint64_t(0));assert(!visibility.confirm(r,name,visible,camera,2017));m.put(marker_data+0x40,follow);
 m.put(module+0x28,int(0));assert(step(2018)==0);m.put(module+0x28,int(-1));assert(step(2019)==0);m.put(dictionary+0x20,int(5000));assert(step(2018)==0);m.put(dictionary+0x20,int(1));m.put(module+0x3c,uint16_t(256));assert(step(2019)==0);
 f.players[0].id++;m.put(module+0x3c,uint16_t(1));assert(step(2020)==0);visibility.reset();m.put(module+0x3c,uint16_t(1));assert(step(2020)==0); // PID/scene reset cannot reuse prior evidence.
 f.players[0].kind=Bot;m.names[view]="PointScreenMarkerView";m.put(module+0x38,float(6));assert(step(2030)==0&&step(2046)==1);assert(visibility.confirm(r,name,f.players[0],camera,2046));
 f.players[0].kind=0;assert(step(2047)==0); // A generic point marker cannot prove player visibility.

 }
 puts("PASS: release/beta marker service and multicast lookup, exact transform ancestry, camera and active-marker binding, canonical Nullable<bool>, empty-mask rejection, first-sample rejection, fresh visible/occluded/unknown states, expiry, bypass and wrong-camera rejection, recycled-view/net-ID rejection and final pre-aim validation");
}
