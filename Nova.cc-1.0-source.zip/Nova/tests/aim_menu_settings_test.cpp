#include "ui/ui.hpp"
#include <cassert>
int main(int argc,char** argv){
 assert(argc==2);const std::string path=argv[1];ui::vip_mode=true;ui::cfg={};
 ui::cfg.fov=40;ui::cfg.silent_fov=95;ui::cfg.touch_fov=65;ui::cfg.aim360_distance=125;
 ui::enable_aim_kind(1,true);assert(ui::aim_kind()==1&&!ui::cfg.aim);
 assert(ui::active_aim_controls().fov==95);
 ui::enable_aim_kind(2,true);assert(ui::aim_kind()==2&&!ui::cfg.vip_silent&&ui::active_aim_controls().fov==65);
 ui::enable_aim_kind(0,true);assert(ui::aim_kind()==0&&ui::cfg.aim&&!ui::cfg.vip_touch_aim&&ui::active_aim_controls().fov==40);
 assert(ui::save(path));ui::cfg={};assert(ui::load(path));
 assert(ui::cfg.fov==40&&ui::cfg.silent_fov==95&&ui::cfg.touch_fov==65&&ui::cfg.aim360_distance==125);
 {std::ofstream file(path);file<<"OxideConfig 6\naim 1\nvip_silent 1\nfov 73\naim_distance 222\naim_visibility 1\n";}
 assert(ui::load(path)&&ui::cfg.vip_silent&&!ui::cfg.aim);
 assert(ui::cfg.silent_fov==73&&ui::cfg.silent_distance==222&&ui::cfg.silent_visibility);
 auto changed=ui::aim_controls(1);changed.fov=99;ui::store_aim_controls(1,changed);
 assert(ui::cfg.fov==73&&ui::cfg.silent_fov==99&&ui::cfg.touch_fov==73);
 assert(ui::save(path));ui::cfg={};assert(ui::load(path)&&ui::cfg.silent_fov==99&&ui::cfg.fov==73);
 unlink(path.c_str());std::puts("PASS: independent AIM profiles, exclusive activation, legacy migration and round-trip");
}
