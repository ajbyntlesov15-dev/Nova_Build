#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
g++ -std=c++17 -O1 -I "$ROOT/native/src" -I "$ROOT/native/includes/internal/ImGui" "$ROOT/tests/config_interop.cpp" -o "$BUILD/config"
"$BUILD/config" emit "$BUILD/native.conf"
java com.sun.tools.javac.Main -d "$BUILD" "$ROOT/loader/app/src/main/java/com/nova/oxide/ConfigDocument.java" "$ROOT/loader/app/src/main/java/com/nova/oxide/ProfileStore.java" "$ROOT/tests/ProfileProbe.java"
java -cp "$BUILD" cc.nova.oxide.ProfileProbe "$BUILD/native.conf" "$BUILD/import.conf"
"$BUILD/config" read "$BUILD/import.conf"
