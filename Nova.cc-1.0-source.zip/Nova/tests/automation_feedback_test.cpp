#include "runtime/automation.hpp"
#include <cassert>
#include <deque>
#include <cstdio>
using namespace oxide;
// Closed-loop touch/engine fixture: delayed view feedback, joystick movement,
// changing bonus marker and uneven scheduling. No game/input driver required.
static void run(int period){
 Automation farm;AutomationConfig c;c.paused=false;c.farm=true;
 Frame f;f.pid=1;f.local=1;f.camera=f.input_unlocked=true;
 Actor local;local.local=true;local.hp=100;f.players={local};
 f.world={{10,11,3,{4,0,18},Stone,"Камень"}};f.world[0].hit_checked=true;f.world[0].hit_valid=true;
 float yaw=1.1f,pitch=0;ScreenContact oldlook{};std::deque<std::pair<float,float>> pending(2,{yaw,pitch});
 int strikes=0,starts=0,approach_frames=0;bool previous_joy=false;float max_jump=0;ScreenContact previous{};long long clock=1000,drag_ms=0,longest_drag=0;
 for(int i=0;i<20000/period;++i){
  int elapsed=period+(i%13==0?7:0);float dt=elapsed*.001f;clock+=elapsed;f.time=clock;
  auto viewed=pending.front();pending.pop_front();f.view=camera_view(add(local.feet,{0,1.6f,0}),viewed.first,viewed.second);
  float sweep=std::sin(i*period*.001f*2.3f);
  f.world[0].hit_position={4+sweep*.5f,1.25f+std::cos(i*period*.001f)*.2f,17.6f};
  f.players[0]=local;auto cmd=farm.step(f,c,f.time);
  if(cmd[1].down&&oldlook.down){yaw+=(cmd[1].x-oldlook.x)/(.35f*57.2957795f);pitch+=(cmd[1].y-oldlook.y)/(.35f*57.2957795f);}
  drag_ms=cmd[1].down?drag_ms+elapsed:0;longest_drag=std::max(longest_drag,drag_ms);
  oldlook=cmd[1];pending.push_back({yaw,pitch});
  if(cmd[0].down){if(!previous_joy)++starts;else max_jump=std::max(max_jump,std::hypot(cmd[0].x-previous.x,cmd[0].y-previous.y));++approach_frames;float side=(cmd[0].x-c.joy_x)*c.aspect/10,forward=(c.joy_y-cmd[0].y)/10;local.feet.x+=(std::cos(yaw)*side+std::sin(yaw)*forward)*4*dt;local.feet.z+=(-std::sin(yaw)*side+std::cos(yaw)*forward)*4*dt;}
  previous_joy=cmd[0].down;previous=cmd[0];if(cmd[2].down)++strikes;
 }
 V delta=sub(local.feet,f.world[0].position);delta.y=0;
 printf("feedback period=%dms distance=%.2f strikes=%d contacts=%d largest-joystick-step=%.2f\n",period,len(delta),strikes,starts,max_jump);
 assert(len(delta)<3&&strikes>100/period*16&&approach_frames>10&&starts<=2&&max_jump<6&&longest_drag>500);
 // Arrival hysteresis does not chatter around reach, spark changes cannot move the feet.
 for(int i=0;i<40;++i){f.time+=period;f.players[0].feet={4,0,15.5f+(i%2?.08f:0)};auto cmd=farm.step(f,c,f.time);assert(!cmd[0].down);}
}
int main(){run(8);run(16);run(33);run(50);puts("PASS: delayed closed-loop approach and moving spark tracking at 125/62/30/20 Hz, bounded steering steps, continuous joystick hold and arrival hysteresis");}
