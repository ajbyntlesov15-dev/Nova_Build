package cc.nova.oxide;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
public final class LoaderSessionProbe {
    private static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args)throws Exception {
        Class<?> type=Class.forName("cc.nova.oxide.MainActivity$Session");
        Constructor<?> constructor=type.getDeclaredConstructor();constructor.setAccessible(true);Object state=constructor.newInstance();
        Method begin=type.getDeclaredMethod("begin",int.class),finish=type.getDeclaredMethod("finish",String.class,boolean.class);begin.setAccessible(true);finish.setAccessible(true);
        Field busy=type.getDeclaredField("busy"),failed=type.getDeclaredField("failed"),detail=type.getDeclaredField("detail"),completed=type.getDeclaredField("completed"),serial=type.getDeclaredField("serial");
        for(Field field:new Field[]{busy,failed,detail,completed,serial})field.setAccessible(true);
        ExecutorService pool=Executors.newFixedThreadPool(12);CountDownLatch gate=new CountDownLatch(1);AtomicInteger accepted=new AtomicInteger();java.util.List<Future<?>> jobs=new java.util.ArrayList<>();
        for(int i=0;i<24;i++)jobs.add(pool.submit(()->{try{gate.await();if((Boolean)begin.invoke(state,1))accepted.incrementAndGet();}catch(Exception e){throw new RuntimeException(e);}}));
        gate.countDown();for(Future<?> job:jobs)job.get();pool.shutdown();check(accepted.get()==1&&busy.getBoolean(state));
        finish.invoke(state,"started",false);check(!busy.getBoolean(state)&&!failed.getBoolean(state)&&completed.getInt(state)==1&&serial.getInt(state)==1&&"started".equals(detail.get(state)));
        check((Boolean)begin.invoke(state,2));check(!(Boolean)begin.invoke(state,1));finish.invoke(state,"root timeout",true);
        check(!busy.getBoolean(state)&&failed.getBoolean(state)&&completed.getInt(state)==2&&serial.getInt(state)==2&&"root timeout".equals(detail.get(state)));
        check((Boolean)begin.invoke(state,3));check(!failed.getBoolean(state));finish.invoke(state,"log",false);check(completed.getInt(state)==3&&serial.getInt(state)==3);
        System.out.println("PASS: actual launcher session: concurrent taps schedule one command; completion/failure clears busy and preserves details; diagnostics can run afterwards without an Activity observer");
    }
}
