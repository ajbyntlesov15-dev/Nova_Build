#include "imgui.h"
#include "imgui_internal.h"
#include "fonts/menu/bold.hpp"
#include <cassert>
#include <cstdio>
#include <unistd.h>
int main(){
 assert(ImFontAtlasValidateFontData(zir,sizeof(zir)));
 assert(!ImFontAtlasValidateFontData(zir,64));
 unsigned char invalid[128]{};assert(!ImFontAtlasValidateFontData(invalid,sizeof(invalid)));
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;
 ImFontConfig embedded;embedded.FontDataOwnedByAtlas=false;
 assert(io.Fonts->AddFontFromMemoryTTF(zir,sizeof(zir),28,&embedded,io.Fonts->GetGlyphRangesCyrillic()));
 char path[]="/data/local/tmp/nova-font-XXXXXX";int fd=mkstemp(path);assert(fd>=0);assert(write(fd,invalid,sizeof(invalid))==sizeof(invalid));close(fd);
 int before=io.Fonts->ConfigData.Size;assert(io.Fonts->AddFontFromFileTTF(path,28)==nullptr);assert(io.Fonts->ConfigData.Size==before);unlink(path);
 unsigned char* pixels=nullptr;int w=0,h=0;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);assert(pixels&&w>0&&h>0);
 ImGui::DestroyContext();puts("PASS: unsupported file skipped before registration; embedded atlas still builds");
}
