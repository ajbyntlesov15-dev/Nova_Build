package cc.nova.oxide;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
public final class ProfileProbe {
 interface Checked{void run()throws Exception;}
 static void check(boolean value){if(!value)throw new AssertionError();}
 static void rejects(Checked work)throws Exception{try{work.run();throw new AssertionError("Accepted malformed data");}catch(IOException expected){}}
 public static void main(String[] args)throws Exception {
  byte[] original=Files.readAllBytes(Paths.get(args[0]));ConfigDocument d=ConfigDocument.parse(original);check(d.rows.size()>100);
  d.setNumber("menu_scale",85);d.setNumber("menu_opacity",65);d.setNumber("menu_x",0);d.setNumber("menu_y",100);byte[] changed=d.bytes();Files.write(Paths.get(args[1]),changed);
  check(ConfigDocument.parse(changed).number("menu_opacity",100)==65);
  String[] bad={"OxideConfig 7\nbox 1\n","OxideConfig 6\nbox 2\n","OxideConfig 6\nbox 1\nbox 0\n","OxideConfig 6\nunknown 1\n","OxideConfig 6\ncolor 0 NaN 0 0 1\n","OxideConfig 6\ncolor 25 1 0 0 1\n","OxideConfig 6\nfree_position 2 0\n","OxideConfig 6\npoint -1 0 0\n","OxideConfig 6\n"};
  for(String s:bad)rejects(()->ConfigDocument.parse(s.getBytes(StandardCharsets.UTF_8)));
  rejects(()->ConfigDocument.bounded(new ByteArrayInputStream(new byte[20001]),20000));
  File dir=Files.createTempDirectory("oxide-profiles-").toFile();ProfileStore store=new ProfileStore(dir);
  try{
   ProfileStore.Entry e=store.save("  Профиль ночь  ",changed,false);check(store.list().size()==1&&e.name.equals("Профиль ночь"));
   ProfileStore.Entry decoded=ProfileStore.unpack(ProfileStore.pack(e.name,e.config));check(decoded.name.equals(e.name)&&Arrays.equals(decoded.config,changed));
   rejects(()->store.save("Профиль ночь",original,false));store.save(e.name,original,true);check(store.list().size()==1);
   for(String n:new String[]{"../other","a/b","a\\b","\n","a\nb",""})rejects(()->store.save(n,original,false));
   ExecutorService pool=Executors.newFixedThreadPool(2);try{Future<?> one=pool.submit(()->{try{for(int i=0;i<20;i++)store.save(e.name,changed,true);}catch(Exception x){throw new RuntimeException(x);}});Future<?> two=pool.submit(()->{try{for(int i=0;i<20;i++){List<ProfileStore.Entry> all=store.list();check(all.size()==1);ConfigDocument.parse(all.get(0).config);}}catch(Exception x){throw new RuntimeException(x);}});one.get();two.get();}finally{pool.shutdownNow();}
   Path link=dir.toPath().resolve("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa.dofprofile");Files.createSymbolicLink(link,Paths.get(args[0]));check(store.list().size()==1);Files.delete(link);
   for(int i=1;i<ProfileStore.LIMIT;i++)store.save("Slot "+i,original,false);check(store.list().size()==ProfileStore.LIMIT);rejects(()->store.save("Overflow",original,false));store.delete(store.list().get(0));check(store.list().size()==ProfileStore.LIMIT-1);
   rejects(()->ProfileStore.unpack(new byte[20001]));rejects(()->ProfileStore.unpack("NovaProfile 1\n$$\nOxideConfig 6\nbox 1\n".getBytes(StandardCharsets.UTF_8)));
  }finally{for(File f:Objects.requireNonNull(dir.listFiles()))f.delete();dir.delete();}
  System.out.println("PASS: production native config roundtrip, profile import/export, Unicode names, duplicate/malformed/oversize rejection, limits, symlink exclusion, atomic replacement under concurrent read and deletion");
 }
}
