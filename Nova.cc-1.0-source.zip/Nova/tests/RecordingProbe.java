package cc.nova.oxide;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
public final class RecordingProbe {
    private static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args)throws Exception {
        RecordingProfile.Limits limits=new RecordingProfile.Limits(){public int widthAlignment(){return 16;}public int heightAlignment(){return 16;}public boolean supports(int w,int h,int fps){return w<=1920&&h<=1080&&w>=240&&h>=240&&fps<=30;}public int minBitrate(){return 1000000;}public int maxBitrate(){return 8000000;}};
        RecordingProfile p=RecordingProfile.choose(1080,2400,720,60,16000000,true,limits);check(p.width>p.height&&p.width%16==0&&p.height%16==0&&p.height<=720&&p.fps==30&&p.bitrate==8000000);
        p=RecordingProfile.choose(1440,3200,1080,30,2000000,true,limits);check(p.width<=1920&&p.height<=1080&&p.fps==30);
        RecordingProfile.Limits portrait=new RecordingProfile.Limits(){public int widthAlignment(){return 2;}public int heightAlignment(){return 2;}public boolean supports(int w,int h,int fps){return w<=1080&&h<=2400&&fps<=30;}public int minBitrate(){return 1000000;}public int maxBitrate(){return 16000000;}};
        p=RecordingProfile.choose(1080,2400,720,24,8000000,false,portrait);check(p.height>p.width&&p.width==720&&p.fps==24);
        boolean rejected=false;try{RecordingProfile.choose(0,2400,720,30,8000000,true,limits);}catch(IllegalArgumentException expected){rejected=true;}check(rejected);
        RecordingSession session=new RecordingSession();ExecutorService pool=Executors.newFixedThreadPool(8);CountDownLatch gate=new CountDownLatch(1);AtomicInteger accepted=new AtomicInteger();java.util.List<Future<?>> tasks=new java.util.ArrayList<>();
        for(int i=0;i<24;i++)tasks.add(pool.submit(()->{try{gate.await();if(session.begin())accepted.incrementAndGet();}catch(InterruptedException e){throw new RuntimeException(e);}}));gate.countDown();for(Future<?> task:tasks)task.get();pool.shutdown();check(accepted.get()==1&&session.state()==RecordingSession.STARTING);
        session.requestStop();check(!session.markRecording()&&session.state()==RecordingSession.STOPPING);session.finish(null);check(session.completions()==1);check(!session.busy()&&session.begin());check(session.markRecording());check(!session.begin());session.requestStop();session.finish("encoder error");check(session.state()==RecordingSession.ERROR&&"encoder error".equals(session.error()));check(session.begin()&&session.error().isEmpty());session.finish(null);
        System.out.println("PASS: actual recording profile alignment/aspect/codec fallback/bitrate bounds; one concurrent start; cancel-before-record, stop, failure and retry state transitions");
    }
}
