package cc.nova.oxide;
public final class GameBuildProbe {
 public static void main(String[] args){
  if(!GameBuild.BETA.matches("1.20.12024",12024))throw new AssertionError("new beta rejected");
  if(GameBuild.BETA.matches("1.19.12018",12018))throw new AssertionError("stale beta accepted");
  if(!GameBuild.CURRENT.matches("1.18.12016",12016))throw new AssertionError("release changed");
  if(GameBuild.BETA.matches("1.20.12024",12018))throw new AssertionError("code mismatch accepted");
  System.out.println("PASS: beta 12024 and unchanged release 12016; stale and mismatched versions rejected");
 }
}
