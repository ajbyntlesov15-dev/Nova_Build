package cc.nova.oxide;
import java.util.Locale;
public final class LocaleProbe {
 public static void main(String[] args)throws Exception {
  String[] codes={"ru","en","zh","es","uk","ar","pl","fr","tr"};
  for(int i=0;i<codes.length;i++){Locale.setDefault(Locale.forLanguageTag(codes[i]));if(LocaleStrings.selected(9)!=i)throw new AssertionError(codes[i]);}
  Locale.setDefault(Locale.JAPANESE);if(LocaleStrings.selected(9)!=1)throw new AssertionError("fallback");
  for(String[] row:LocaleStrings.WORDS.values()){if(row.length!=7)throw new AssertionError("column count");for(String text:row)if(text.isEmpty())throw new AssertionError("empty translation");}
  ConfigDocument config=ConfigDocument.parse("OxideConfig 6\nui_revision 90\nlanguage 9\n".getBytes("UTF-8"));if(config.number("language",0)!=9)throw new AssertionError("automatic language");
  System.out.println("PASS: 9 locale mappings, automatic fallback, translation table and config roundtrip");
 }
}
