#include "runtime/core.hpp"
#include <cassert>
#include <cstdio>
int main(){
 alignas(16) unsigned char memory[2048]{};auto base=uint64_t(memory),object=base+1024,klass=base,name=base+1603;
 memcpy((void*)object,&klass,8);memcpy((void*)(klass+0x10),&name,8);memcpy((void*)name,"NetworkClient",14);
 auto read=[&](uint64_t a,void* b,size_t n){if(a<base||n>sizeof(memory)||a-base>sizeof(memory)-n)return false;memcpy(b,(void*)a,n);return true;};
 if(oxide::klass(read,object)!="NetworkClient")return 4;
 assert(oxide::discover_name_offset(read,klass,"NetworkClient")==0x10);
 uint64_t zero=0;memcpy((void*)(klass+0x10),&zero,8);uint64_t tagged=name|0xb400000000000000ULL;memcpy((void*)(klass+0x198),&tagged,8);
 assert(oxide::discover_name_offset(read,klass,"NetworkClient")==0x198);assert(oxide::klass(read,object,0x198)=="NetworkClient");
 puts("PASS: unaligned class name at +0x10, shifted name at +0x198, tagged string address, object/string alignment separation");
}
