#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tests/common_access_test.py"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
gcc -O1 -c "$ROOT/native/vendor/monocypher/monocypher.c" -o "$BUILD/monocypher.o"
gcc -O1 -c "$ROOT/native/vendor/monocypher/monocypher-ed25519.c" -o "$BUILD/ed25519.o"
g++ -std=c++17 -O1 -pthread -I "$ROOT/native/src" "$ROOT/tests/license_test.cpp" "$BUILD/monocypher.o" "$BUILD/ed25519.o" -o "$BUILD/license"
"$BUILD/license"
g++ -std=c++17 -O1 -I "$ROOT/native/src" "$ROOT/tests/class_name_test.cpp" -o "$BUILD/class_name"
"$BUILD/class_name"
g++ -std=c++17 -O1 -I "$ROOT/native/src" "$ROOT/tests/world_test.cpp" -o "$BUILD/world"
"$BUILD/world"
g++ -std=c++17 -O1 -I "$ROOT/native/src" "$ROOT/tests/automation_feedback_test.cpp" -o "$BUILD/feedback"
"$BUILD/feedback"
g++ -std=c++17 -O1 -g -pthread -I "$ROOT/native/src" "$ROOT/tests/runtime_test.cpp" -o "$BUILD/runtime"
"$BUILD/runtime" beta
"$BUILD/runtime" current
g++ -std=c++17 -O1 -I "$ROOT/native/src" -I "$ROOT/native/includes" -I "$ROOT/native/includes/internal/ImGui" -I "$ROOT/native/includes/internal" \
 "$ROOT/tests/ui_test.cpp" "$ROOT/native/includes/draw/ImGui/imgui.cpp" "$ROOT/native/includes/draw/ImGui/imgui_draw.cpp" \
 "$ROOT/native/includes/draw/ImGui/imgui_tables.cpp" "$ROOT/native/includes/draw/ImGui/imgui_widgets.cpp" -o "$BUILD/ui"
"$BUILD/ui"

g++ -std=c++17 -O1 -I "$ROOT/native/src" "$ROOT/tests/container_box_test.cpp" -o "$BUILD/container_box"
"$BUILD/container_box"

g++ -std=c++17 -O1 -I "$ROOT/native/src" "$ROOT/tests/trigger_test.cpp" -o "$BUILD/trigger"
"$BUILD/trigger"

g++ -std=c++17 -O1 -pthread -I "$ROOT/native/src" "$ROOT/tests/recording_bridge_test.cpp" -o "$BUILD/recording_bridge"
"$BUILD/recording_bridge"

g++ -std=c++17 -O1 -I "$ROOT/native/src" "$ROOT/tests/visibility_test.cpp" -o "$BUILD/visibility"
"$BUILD/visibility"

g++ -std=c++17 -O1 -pthread -I "$ROOT/native/src" "$ROOT/tests/vegetation_runtime_test.cpp" -o "$BUILD/vegetation"
"$BUILD/vegetation" current
"$BUILD/vegetation" beta

