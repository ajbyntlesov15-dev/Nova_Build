#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_HOME:?Set ANDROID_HOME to SDK with platform 35}"
CLASSES="$(mktemp -d)"
trap 'rm -rf "$CLASSES"' EXIT
PLATFORM="$ANDROID_HOME/platforms/android-35/android.jar"
java com.sun.tools.javac.Main -source 8 -target 8 -encoding UTF-8 -classpath "$PLATFORM" -d "$CLASSES" \
 "$ROOT"/loader/app/src/main/java/com/nova/oxide/*.java \
 "$ROOT/tests/GameBuildProbe.java" "$ROOT/tests/LoaderSessionProbe.java" "$ROOT/tests/RecordingProbe.java"
java -cp "$CLASSES:$PLATFORM" cc.nova.oxide.LoaderSessionProbe

java -cp "$CLASSES:$PLATFORM" cc.nova.oxide.RecordingProbe

java -cp "$CLASSES:$PLATFORM" cc.nova.oxide.GameBuildProbe
