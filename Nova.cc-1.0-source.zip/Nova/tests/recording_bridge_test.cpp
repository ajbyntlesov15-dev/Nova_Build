#include <cstdlib>
#include <string>
#include <vector>
#include "runtime/recording_bridge.hpp"
#include <cassert>
#include <cstdio>
#include <sys/stat.h>
#include <unistd.h>
int main(){recording_bridge::Status s;assert(recording_bridge::parse("NovaRecording 1\n2 123 10000 9000 1280 720 30 8000000\n",11000,s)&&s.fps==30);assert(!recording_bridge::parse("NovaRecording 1\n2 123 10000 9000 1280 720 30 8000000\n",15001,s));assert(!recording_bridge::parse("NovaRecording 1\n2 123 10000 9000 0 0 0 0\n",11000,s));assert(!recording_bridge::parse("NovaRecording 1\n2 123 10000 12000 1280 720 30 8000000\n",11000,s));assert(!recording_bridge::parse("NovaRecording 1\n2 123 10000 9000 1280 720 30 8000000 extra\n",11000,s));assert(!recording_bridge::parse(std::string(1024,'x'),11000,s));std::string tmp_pattern=std::string(std::getenv("TMPDIR")?std::getenv("TMPDIR"):"/tmp")+"/nova-record-ui-XXXXXX";std::vector<char> tmp_buffer(tmp_pattern.begin(),tmp_pattern.end());tmp_buffer.push_back(0);char* path=tmp_buffer.data();int fd=mkstemp(path);assert(fd>=0);const char data[]="NovaCaptureUi 1\n123 10000 1\n";assert(write(fd,data,sizeof(data)-1)==sizeof(data)-1);close(fd);assert(recording_bridge::ui_active(path,getuid(),11000));assert(!recording_bridge::ui_active(path,getuid()+1,11000));assert(!recording_bridge::ui_active(path,getuid(),15001));std::string link=std::string(path)+".link";assert(symlink(path,link.c_str())==0);assert(!recording_bridge::ui_active(link,getuid(),11000));unlink(link.c_str());unlink(path);puts("PASS: recording bridge rejects stale, malformed, oversized and impossible status; valid active profile accepted");}
