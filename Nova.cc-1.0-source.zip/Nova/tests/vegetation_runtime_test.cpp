// Reuse the existing remote-process fixture; execute the real Live worker before any registry exists.
#define main inherited_runtime_main
#include "runtime_test.cpp"
#undef main
int main(int argc,char** argv){
 if(argc==4)return inherited_runtime_main(argc,argv);
 assert(argc==2);test_profile=oxide_profile::select(argv[1]);assert(test_profile);
 int channel[2];assert(pipe(channel)==0);pid_t child=fork();assert(child>=0);
 std::string package="com.test.vegetation."+std::to_string(now());
 if(!child){close(channel[0]);char self[4096],fd[32];auto n=readlink("/proc/self/exe",self,sizeof(self)-1);assert(n>0);self[n]=0;snprintf(fd,sizeof(fd),"%d",channel[1]);execl(self,package.c_str(),"--game",fd,PROFILE.channel,(char*)nullptr);_exit(127);}
 close(channel[1]);Info info{};assert(read(channel[0],&info,sizeof(info))==sizeof(info));close(channel[0]);
 std::string path="/proc/"+std::to_string(child)+"/mem";int fd=open(path.c_str(),O_RDWR);assert(fd>=0);
 auto read=[&](uint64_t a,void* p,size_t n){return pread(fd,p,n,a)==ssize_t(n);};
 auto write=[&](uint64_t a,const void* p,size_t n){assert(pwrite(fd,p,n,a)==ssize_t(n));};
 const auto* patches=test_profile==&oxide_profile::beta?vegetation_beta:vegetation_current;
 for(int i=0;i<2;++i)write(info.game+patches[i].address,patches[i].guard,16);
 uint64_t slot=0;assert(read(info.game+PROFILE.network_client_cell,&slot,8));uint64_t zero=0;write(info.game+PROFILE.network_client_cell,&zero,8);
 Live live;std::atomic<bool> allowed{true};Options options;options.no_vegetation=true;live.configure(options);live.start(package,[&]{return allowed.load();},PROFILE);
 auto word=[&](int i){uint32_t x=0;assert(read(info.game+patches[i].address,&x,4));return x;};
 for(int n=0;n<100&&(word(0)!=0xd65f03c0U||word(1)!=0xd65f03c0U);++n)usleep(10000);
 assert(word(0)==0xd65f03c0U&&word(1)==0xd65f03c0U);assert(live.snapshot().players.empty()&&live.snapshot().vegetation_ready);
 options.no_vegetation=false;live.configure(options);usleep(80000);
 uint32_t original0=0,original1=0;memcpy(&original0,patches[0].guard,4);memcpy(&original1,patches[1].guard,4);assert(word(0)==original0&&word(1)==original1);
 auto broken=uint32_t(0xdeadbeef);write(info.game+patches[0].address+4,&broken,4);options.no_vegetation=true;live.configure(options);usleep(80000);assert(word(0)==original0);assert(word(1)==original1&&!live.snapshot().vegetation_ready);
 options.no_vegetation=false;live.configure(options);usleep(80000);write(info.game+patches[0].address,patches[0].guard,16);write(info.game+PROFILE.network_client_cell,&slot,8);
 options.no_vegetation=true;live.configure(options);usleep(100000);assert(word(0)==0xd65f03c0U);allowed=false;usleep(100000);assert(word(0)==original0&&word(1)==original1);
 live.stop();close(fd);kill(child,SIGTERM);waitpid(child,nullptr,0);std::filesystem::remove_all(info.directory);
 puts("PASS: real remote-memory vegetation patch before registry/camera, both profiles, mismatch rejection, disabling and license-loss restoration");
}
