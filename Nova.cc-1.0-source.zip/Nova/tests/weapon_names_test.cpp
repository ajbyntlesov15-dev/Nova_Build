#include "runtime/weapon_names.hpp"
#include <cassert>
int main(){
 assert(oxide::weapon_name_ru("AK-47")=="АК-47");
 assert(oxide::weapon_name_ru("M4A1")=="М4А1");
 assert(oxide::weapon_name_ru("MP5")=="МП5");
 assert(oxide::weapon_name_ru("rifle.ak")=="АК-47");
 assert(oxide::weapon_name_ru(" AK_47 ")=="АК-47");
 assert(oxide::weapon_name_ru("Hunting Bow")=="Охотничий лук");
 assert(oxide::weapon_name_ru("Неизвестная модель")=="Неизвестная модель");
}
