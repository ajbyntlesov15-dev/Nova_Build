#include "runtime/container_box.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
int main(){
 using namespace oxide;
 std::vector<unsigned char> memory(8192);uint64_t base=untag(reinterpret_cast<uint64_t>(memory.data()));
 auto put=[&](unsigned off,const auto& value){memcpy(memory.data()+off,&value,sizeof(value));};
 auto read=[&](uint64_t a,void* out,size_t n){if(a<base||a-base>memory.size()||n>memory.size()-(a-base))return false;memcpy(out,memory.data()+a-base,n);return true;};
 // managed -> native -> game object -> components -> transform -> TRS hierarchy
 put(0x10,base+0x300);put(0x320,base+0x400);put(0x420,base+0x500);put(0x430,uint64_t(1));put(0x508,base+0x600);
 put(0x628,base+0x700);put(0x630,int(0));put(0x718,base+0x800);put(0x720,base+0x900);
 put(0xd0,V{1,0,0});put(0xdc,V{.5f,1,.25f});
 float half=std::sqrt(.5f);TRS t{{10,2,3,0},{0,half,0,half},{2,1,1,0}};put(0x800,t);put(0x900,int(-1));
 std::array<V,8> corners{};assert(container_corners(read,base,corners));
 assert(std::fabs(corners[0].x-9.75f)<.001f&&std::fabs(corners[0].y-1)<.001f&&std::fabs(corners[0].z-2)<.001f);
 put(0x900,int(0));assert(!container_corners(read,base,corners));put(0x900,int(-1));
 put(0xdc,V{std::numeric_limits<float>::quiet_NaN(),1,1});assert(!container_corners(read,base,corners));put(0xdc,V{0,1,1});assert(!container_corners(read,base,corners));
 M view=camera_view({},0,0),projection{};projection.v[0]=projection.v[5]=1;projection.v[11]=-1;
 float ax,ay,bx,by;
 assert(project_edge(view,projection,{-1,0,4},{1,0,4},1920,1080,ax,ay,bx,by));assert(ax<bx&&ay==540&&by==540);
 assert(!project_edge(view,projection,{-1,0,-2},{1,0,-1},1920,1080,ax,ay,bx,by));
 assert(project_edge(view,projection,{0,0,-1},{1,0,4},1920,1080,ax,ay,bx,by));
 for(float v:{ax,bx})assert(std::isfinite(v)&&v>=-.1f&&v<=1920.1f);
 assert(!project_edge(view,projection,{10,0,1},{20,0,1},1920,1080,ax,ay,bx,by));
 puts("PASS: oriented container bounds, scale/rotation, corrupt data and hierarchy cycles; clipped front/behind/near-plane/offscreen edges");
}
