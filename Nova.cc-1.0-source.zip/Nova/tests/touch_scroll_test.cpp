#include "ui/ui.hpp"
#include "fonts/menu/bold.hpp"
#include <cassert>
int main(){
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;io.DisplaySize={900,600};io.DeltaTime=1.f/60;
 ImFontConfig font;font.FontDataOwnedByAtlas=false;io.FontDefault=io.Fonts->AddFontFromMemoryTTF(zir,sizeof(zir),24,&font,io.Fonts->GetGlyphRangesCyrillic());unsigned char* pixels;int w,h;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);
 bool feature=false,open=true;int value=50;ImVec2 header_pos{},slider_pos{},toggle_pos{};ImGuiWindow* pane=nullptr;
 auto frame=[&]{
  ImGui::NewFrame();ui::style();ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize({900,600});ImGui::Begin("##oxide_menu",nullptr,ImGuiWindowFlags_NoSavedSettings);
  dof_menu::touch_scroll().begin(ImGui::GetCurrentWindow(),true);
  ImGui::BeginChild("pane",{700,350},true);pane=ImGui::GetCurrentWindow();
  open=ui::collapsible(ui::label("Цели и фильтры"),ImGuiTreeNodeFlags_DefaultOpen);auto p=ImGui::GetItemRectMin();header_pos={p.x+150,p.y+25};
  if(open){ui::setting_int(ui::label("FOV"),&value,0,100);p=ImGui::GetItemRectMin();slider_pos={p.x+200,p.y+12};
   ui::toggle("Рамки",feature);p=ImGui::GetItemRectMin();toggle_pos={p.x+150,p.y+25};
   for(int i=0;i<20;++i){ImGui::PushID(i);bool state=false;ui::toggle("Дистанция",state);ImGui::PopID();}}
  ui::scroll_end();ImGui::End();dof_menu::touch_scroll().finish();ImGui::Render();
 };
 frame();frame();assert(open&&pane->ScrollMax.y>500);
 auto press=[&](ImVec2 p){io.AddMousePosEvent(p.x,p.y);frame();io.AddMouseButtonEvent(0,true);frame();};
 auto release=[&]{io.AddMouseButtonEvent(0,false);frame();};
 auto top=[&]{dof_menu::touch_scroll().reset();ImGui::SetScrollY(pane,0);frame();frame();};
 // Swiping a section header scrolls instead of collapsing or blocking the list.
 auto p=header_pos;press(p);io.AddMousePosEvent(p.x,p.y-80);frame();assert(open&&pane->Scroll.y>0);release();float y=pane->Scroll.y;for(int i=0;i<8;++i)frame();assert(pane->Scroll.y>y);
 // Vertical movement across a slider restores its initial value.
 top();value=50;p=slider_pos;press(p);io.AddMousePosEvent(p.x,p.y-80);frame();release();assert(value==50&&pane->Scroll.y>0);
 // A real horizontal slider drag remains a normal edit, without list movement.
 top();value=50;p=slider_pos;press(p);io.AddMousePosEvent(p.x+240,p.y);frame();release();assert(value!=50&&pane->Scroll.y==0);
 // A toggle must not change merely because the swipe started on its row.
 top();feature=false;p=toggle_pos;press(p);io.AddMousePosEvent(p.x,p.y-80);frame();release();assert(!feature&&pane->Scroll.y>0);
 top();p=header_pos;press(p);release();assert(!open);
 dof_menu::touch_scroll().reset();ImGui::DestroyContext();
}
