#include "runtime/trigger.hpp"
#include <cassert>
#include <cstdio>
using namespace oxide;
int main(){
 Trigger trigger;TriggerConfig c;c.enabled=true;c.paused=false;c.delay=100;c.interval=150;c.scoped_only=true;
 Frame f;f.pid=4;f.local=123;f.camera=f.input_unlocked=f.trigger_ads_active=true;f.trigger_target=456;
 auto step=[&](long long time){f.time=time;return trigger.step(f,c,time,false).down;};
 assert(!step(1000));assert(!step(1050));assert(step(1100));assert(step(1116));assert(!step(1140));assert(!step(1200));assert(!step(1249));assert(step(1250));
 f.trigger_target=789;assert(!step(1260));assert(!step(1310));assert(step(1360));
 f.trigger_target=0;assert(!step(1370));f.trigger_target=789;assert(!step(1380));f.trigger_ads_active=false;assert(!step(1480));f.trigger_ads_active=true;assert(!step(1490));assert(step(1590));
 f.time=1590;assert(!trigger.step(f,c,1700,false).down);assert(!step(1710));
 f.time=1810;assert(!trigger.step(f,c,1810,true).down);assert(!step(1820));assert(step(1920));
 f.pid=5;assert(!step(1930));c.paused=true;assert(!step(2030));c.paused=false;assert(!step(2040));
 c.x=100;assert(!step(2140));c.x=88;assert(!step(2150));f.loot_session=42;assert(!step(2250));f.loot_session=0;assert(!step(2260));assert(step(2360));f.input_unlocked=false;assert(!step(2370));
 puts("PASS: trigger dwell and tap/cooldown, target/PID changes, scoped/physical/menu/loot locks, stale frames and invalid coordinates");
}
