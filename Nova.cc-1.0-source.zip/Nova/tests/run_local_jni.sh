#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${DOF_LOCAL_VIP_KEY_FILE:?Set private MAC key file}"
: "${DOF_LOCAL_VIP_KEYS_FILE:?Set original 250-key text file}"
: "${JAVA_HOME:?Set JDK}"
: "${ANDROID_HOME:?Set Android SDK}"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
python3 "$ROOT/tools/generate_local_private.py" --key "$DOF_LOCAL_VIP_KEY_FILE" --out "$BUILD/local_vip_private.hpp"
gcc -O1 -fPIC -c "$ROOT/native/vendor/monocypher/monocypher.c" -o "$BUILD/mono.o"
gcc -O1 -fPIC -c "$ROOT/native/vendor/monocypher/monocypher-ed25519.c" -o "$BUILD/ed.o"
g++ -std=c++17 -O1 -fPIC -shared -I "$BUILD" -I "$JAVA_HOME/include" -I "$JAVA_HOME/include/linux" "$ROOT/native/src/security/license_jni.cpp" "$BUILD/mono.o" "$BUILD/ed.o" -o "$BUILD/libnova_license.so"
javac -cp "$ANDROID_HOME/platforms/android-35/android.jar" -d "$BUILD" "$ROOT/loader/app/src/main/java/com/nova/oxide/LicenseBridge.java" "$ROOT/tests/LocalVipProbe.java"
java -Djava.library.path="$BUILD" -cp "$BUILD:$ANDROID_HOME/platforms/android-35/android.jar" cc.nova.oxide.LocalVipProbe "$DOF_LOCAL_VIP_KEYS_FILE"
