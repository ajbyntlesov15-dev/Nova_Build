#include <cstdlib>
#include <string>
#include <vector>
#define OXIDE_TESTING
#include "ui/ui.hpp"
#include "fonts/menu/bold.hpp"
#include "../native/includes/draw/Android_touch/Touch.cpp"
#include <cassert>
#include <cstdio>
int main(){
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;io.DisplaySize={1920,1080};io.DeltaTime=1.f/60;ImFontConfig fc;fc.FontDataOwnedByAtlas=false;io.FontDefault=io.Fonts->AddFontFromMemoryTTF(zir,sizeof(zir),24,&fc,io.Fonts->GetGlyphRangesCyrillic());unsigned char* pixels;int w,h;io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);
 touch::virtual_allowed=false;touch::Device device;device.ax.minimum=device.ay.minimum=0;device.ax.maximum=1000;device.ay.maximum=500;touch::screen_w=1000;touch::screen_h=500;touch::rotation=0;touch::captured=true;
 std::array<touch::Contact,10> contacts{};contacts[0].active=true;contacts[0].x=100;contacts[0].y=400;touch::report(contacts,device);contacts[0].x=150;contacts[0].y=350;contacts[1].active=true;contacts[1].x=700;contacts[1].y=200;touch::report(contacts,device);contacts[1].x=730;contacts[1].y=190;touch::report(contacts,device);auto flight=touch::flight_input();assert(flight.x>0&&flight.y>0&&flight.look_x==30&&flight.look_y==-10);
 contacts[2].active=true;contacts[2].x=880;contacts[2].y=200;touch::report(contacts,device);assert(touch::flight_input().vertical==1);contacts[2].active=false;touch::report(contacts,device);assert(touch::flight_input().vertical==0);touch::capture_flight(false,1000,500,88,40,88,68);assert(!touch::capture_flight(true,1000,500,88,40,88,68));for(int i=0;i<300;++i)touch::enqueue({0,0,false});assert(touch::queue.size()<=256);touch::pump();assert(touch::queue.empty());touch::shutdown();
 // Inspect emitted protocol-B frames through a pipe, including inverse display rotation.
 int pipefd[2];assert(pipe(pipefd)==0);auto injected=std::make_unique<touch::Device>();injected->fd=pipefd[1];injected->ax.minimum=10;injected->ax.maximum=1010;injected->ay.minimum=20;injected->ay.maximum=2020;injected->slot_base=2;touch::devices.push_back(std::move(injected));
 auto batch=[&](){std::array<input_event,64> events{};int n=int(read(pipefd[0],events.data(),sizeof(events)));assert(n>0&&n%sizeof(input_event)==0);return std::vector<input_event>(events.begin(),events.begin()+n/sizeof(input_event));};
 for(int rotation=0;rotation<4;++rotation){touch::rotation=rotation;std::array<touch::SyntheticContact,3> c{};c[0]={true,50,25};assert(touch::synthetic(c));auto events=batch();int x=-1,y=-1,slot=-1;for(auto e:events){if(e.type==EV_ABS&&e.code==ABS_MT_POSITION_X)x=e.value;if(e.type==EV_ABS&&e.code==ABS_MT_POSITION_Y)y=e.value;if(e.type==EV_ABS&&e.code==ABS_MT_SLOT)slot=e.value;}int expected_x[]={510,760,510,260},expected_y[]={520,1020,1520,1020};assert(x==expected_x[rotation]&&y==expected_y[rotation]&&slot==2);assert(touch::synthetic({}));events=batch();bool released=false;for(auto e:events)if(e.code==ABS_MT_TRACKING_ID&&e.value==-1)released=true;assert(released);}
 std::array<touch::SyntheticContact,3> contact{};contact[0]={true,50,50};assert(touch::synthetic(contact));batch();touch::devices[0]->physical=1;assert(!touch::synthetic(contact));auto release=batch();bool touch_held=false;for(auto e:release)if(e.type==EV_KEY&&e.code==BTN_TOUCH&&e.value==1)touch_held=true;assert(touch_held);std::array<touch::SyntheticContact,3> concurrent{};concurrent[1]={true,70,40,true};assert(touch::synthetic(concurrent));auto shared_events=batch();bool shared_held=false;for(auto e:shared_events)if(e.type==EV_KEY&&e.code==BTN_TOUCH&&e.value==1)shared_held=true;assert(shared_held);assert(touch::synthetic({}));batch();touch::devices[0]->physical=1U<<3;assert(!touch::synthetic(concurrent));touch::devices[0]->physical=0;touch::devices.clear();close(pipefd[0]);touch::rotation=0;
 // A virtual touchscreen owns its slots: repeated frames never release a held finger.
 int virtual_pipe[2];assert(pipe(virtual_pipe)==0);touch::virtual_touch.adopt_pipe(virtual_pipe[1]);touch::virtual_allowed=true;std::array<touch::SyntheticContact,3> continuous{};continuous[0]={true,20,70};int starts=0,releases=0;
 for(int i=0;i<120;++i){assert(touch::synthetic(continuous));input_event emitted[32]{};int n=int(read(virtual_pipe[0],emitted,sizeof(emitted)));assert(n>0);for(int j=0;j<n/int(sizeof(input_event));++j)if(emitted[j].type==EV_ABS&&emitted[j].code==ABS_MT_TRACKING_ID){starts+=emitted[j].value>=0;releases+=emitted[j].value==-1;}}
 assert(starts==1&&releases==0);assert(touch::synthetic({}));input_event released[32]{};int release_size=int(read(virtual_pipe[0],released,sizeof(released)));for(int j=0;j<release_size/int(sizeof(input_event));++j)if(released[j].type==EV_ABS&&released[j].code==ABS_MT_TRACKING_ID&&released[j].value==-1)++releases;assert(releases==1);touch::virtual_touch.close_device();close(virtual_pipe[0]);touch::virtual_allowed=false;
 oxide::Frame f;f.camera=true;f.time=1000;f.view=oxide::camera_view({0,1.6f,0},0,0);f.projection.v[0]=.5625f;f.projection.v[5]=1;f.projection.v[10]=-1;f.projection.v[11]=-1;f.projection.v[14]=-.2f;
 oxide::Actor a;a.hp=75;a.max_hp=100;a.name="Игрок";a.feet={0,0,10};a.head={0,1.7f,10};a.weapon="rifle.ak";a.bones={oxide::Node{1,0,{0,1,10}},oxide::Node{1,1,{0,1.7f,10}}};a.edges={{0,1}};f.players={a};f.containers={{1,{1,0,8},1,"wooden_box_small"},{2,{2,0,8},2,"wooden_box_large"},{3,{3,0,8},3,"cupboard"}};
 auto frame=[&](long long time,bool menu){ImGui::NewFrame();ui::esp(f,1920,1080,time);if(menu)ui::render(1920,1080,f);ImGui::Render();for(const auto& v:ImGui::GetBackgroundDrawList()->VtxBuffer)assert(std::isfinite(v.pos.x)&&std::isfinite(v.pos.y));return ImGui::GetDrawData()->TotalVtxCount;};
 assert(frame(1000,false)>0);assert(frame(1121,false)>0);assert(frame(60000,false)==0);ui::cfg.skeleton=ui::cfg.lines=ui::cfg.rgb=ui::cfg.draw_fov=true;assert(frame(1000,false)>0);assert(frame(1000,true)>0);
 auto child=[](const char* part){for(auto* window:ImGui::GetCurrentContext()->Windows)if(window->Active&&strstr(window->Name,part))return window;return (ImGuiWindow*)nullptr;};
 auto* esp=child("/ESP_");auto* tabs=child("/##oxide_tabs_");auto* title=child("/##oxide_title_");assert(esp&&tabs&&title&&title->Pos.y<esp->Pos.y&&tabs->Pos.x+tabs->Size.x<=esp->Pos.x);
 ImVec4 previous{};for(int theme=0;theme<12;++theme){ui::cfg.menu_theme=theme;frame(1000,true);auto color=ImGui::GetStyle().Colors[ImGuiCol_SliderGrab];assert(color.x==color.y&&color.y==color.z);if(theme)assert(memcmp(&color,&previous,sizeof(color))==0);previous=color;}
 ui::cfg.open_method=0;frame(1000,true);assert(ImGui::FindWindowByName("##oxide_bottom_strip")->Active&&!ImGui::FindWindowByName("##oxide_opener")->Active);
 auto click=[&](ImVec2 p){io.AddMousePosEvent(p.x,p.y);frame(1000,true);io.AddMouseButtonEvent(0,true);frame(1000,true);io.AddMouseButtonEvent(0,false);frame(1000,true);};
 auto* strip=ImGui::FindWindowByName("##oxide_bottom_strip");click({strip->Pos.x+strip->Size.x*.5f,strip->Pos.y+40});assert(!ui::opened);for(int i=0;i<30;++i)frame(1000,true);
 ui::cfg.open_method=1;frame(1000,true);auto* icon=ImGui::FindWindowByName("##oxide_opener");assert(icon->Active&&!strip->Active);ImVec2 center(icon->Pos.x+icon->Size.x*.5f,icon->Pos.y+icon->Size.y*.5f);
 io.AddMousePosEvent(center.x,center.y);frame(1000,true);io.AddMouseButtonEvent(0,true);frame(1000,true);io.AddMousePosEvent(center.x+30,center.y+20);frame(1000,true);io.AddMouseButtonEvent(0,false);frame(1000,true);assert(!ui::opened);icon=ImGui::FindWindowByName("##oxide_opener");click({icon->Pos.x+icon->Size.x*.5f,icon->Pos.y+icon->Size.y*.5f});assert(ui::opened);for(int i=0;i<20;++i)frame(1000,true);
 // Calibrate at full precision, with the menu hidden and automation paused.
 ui::begin_pick(0);assert(!ui::opened&&ui::menu_alpha==0&&ui::automation_config().paused);ui::accept_pick({333.25f,777.5f},1920,1080);assert(ui::opened&&ui::pick_target<0);auto calibrated=ui::automation_config();assert(std::fabs(calibrated.joy_x-333.25f/19.2f)<.0001f&&std::fabs(calibrated.joy_y-777.5f/10.8f)<.0001f);
 // The release of the button opening the picker must not become the selection.
 ui::begin_pick(1);io.AddMousePosEvent(1300,400);io.AddMouseButtonEvent(0,true);frame(1000,true);io.AddMouseButtonEvent(0,false);frame(1000,true);assert(ui::pick_target==1);frame(1000,true);io.AddMouseButtonEvent(0,true);frame(1000,true);io.AddMouseButtonEvent(0,false);frame(1000,true);assert(ui::pick_target<0&&ui::opened&&std::fabs(ui::cfg.points[1].x-1300.f/19.2f)<.0001f);
 ui::begin_pick(5);frame(1000,true);
 const int area_x=ui::cfg.aim_area_ax,area_y=ui::cfg.aim_area_ay;
 const float drag_x=area_x*19.2f+30.f,drag_y=area_y*10.8f+20.f;
 io.AddMousePosEvent(drag_x,drag_y);frame(1000,true);
 io.AddMouseButtonEvent(0,true);frame(1000,true);
 io.AddMousePosEvent(drag_x-192.f,drag_y+108.f);frame(1000,true);
 io.AddMouseButtonEvent(0,false);frame(1000,true);
 assert(ui::cfg.aim_area_ax==area_x-10&&ui::cfg.aim_area_ay==area_y+10);
 assert(ui::cfg.aim_area_bx-ui::cfg.aim_area_ax==ui::aim_area_width);
 assert(ui::cfg.aim_area_by-ui::cfg.aim_area_ay==ui::aim_area_height);
 io.AddMousePosEvent(1800,38);frame(1000,true);
 io.AddMouseButtonEvent(0,true);frame(1000,true);
 io.AddMouseButtonEvent(0,false);frame(1000,true);
 assert(ui::pick_target<0&&ui::opened);

 ui::cfg.free_button=true;ui::cfg.freecam=false;frame(1000,true);auto* free_button=ImGui::FindWindowByName("##freecam_button");assert(free_button&&free_button->Size.x==free_button->Size.y);auto old_free=ui::cfg.free_position;ImVec2 free_center(free_button->Pos.x+free_button->Size.x*.5f,free_button->Pos.y+free_button->Size.y*.5f);io.AddMousePosEvent(free_center.x,free_center.y);frame(1000,true);io.AddMouseButtonEvent(0,true);frame(1000,true);io.AddMousePosEvent(free_center.x-80,free_center.y+80);frame(1000,true);io.AddMouseButtonEvent(0,false);frame(1000,true);assert(!ui::cfg.freecam&&ui::cfg.free_position.x<old_free.x&&ui::cfg.free_position.y>old_free.y);
 ui::cfg.watermark_style=0;auto text_vertices=frame(1000,true);ui::cfg.watermark_style=1;auto badge_vertices=frame(1000,true);assert(badge_vertices>text_vertices);
 ui::tab=3;frame(1000,true);assert(child("/Интерфейс_")&&child("/Система_"));
 ImGui::NewFrame();ImGui::Begin("ids");ui::cfg.language=0;auto id_ru=ImGui::GetID(ui::label("Когда наводиться"));ui::cfg.language=1;auto id_en=ImGui::GetID(ui::label("Когда наводиться"));assert(id_ru==id_en&&std::string(ui::tr("Когда наводиться"))=="Activation");ImGui::End();ImGui::Render();frame(1000,true);
 ui::tab=2;frame(1000,true);assert(child("/Ресурсы и животные_")&&child("/Контейнеры и техника_"));ui::cfg.free_button=false;ui::cfg.custom_fov=true;ui::cfg.camera_fov=115;ui::cfg.animals=true;ui::cfg.joy_x=21;ui::cfg.farm_sulfur=false;ui::cfg.always_day=true;ui::cfg.third_height=70;ui::cfg.third_shoulder=20;ui::cfg.watermark_style=0;ui::cfg.activation=2;ui::cfg.open_method=0;ui::cfg.menu_theme=7;ui::cfg.recoil_x=40;ui::cfg.recoil_y=80;ui::cfg.watermark=false;
 std::string tmp_pattern=std::string(std::getenv("TMPDIR")?std::getenv("TMPDIR"):"/tmp")+"/oxide-config-XXXXXX";std::vector<char> tmp_buffer(tmp_pattern.begin(),tmp_pattern.end());tmp_buffer.push_back(0);char* path=tmp_buffer.data();int fd=mkstemp(path);assert(fd>=0);close(fd);ui::cfg.ignore_team=false;ui::cfg.ignore_clan=true;ui::cfg.fov=139;ui::cfg.no_recoil=true;ui::cfg.colors[0].x=.12345678f;auto saved=ui::encoded();assert(ui::save(path));ui::cfg={};assert(ui::load(path)&&ui::encoded()==saved&&!ui::cfg.ignore_team&&ui::cfg.ignore_clan&&ui::cfg.activation==2&&ui::cfg.open_method==0&&ui::cfg.menu_theme==7&&ui::cfg.recoil_x==40&&ui::cfg.recoil_y==80&&ui::cfg.language==1&&!ui::cfg.watermark);
 {std::ofstream out(path);out<<"OxideConfig 1\nfov 9999\nsmooth 0\ntarget_bone 9999\nscrollbar 9999\n";}assert(ui::load(path)&&ui::cfg.fov==170&&ui::cfg.smooth==1&&ui::cfg.target_bone==1&&ui::cfg.scrollbar==32);
 {std::ofstream out(path);out<<"OxideConfig 1\ntarget_mode 1\n";}assert(ui::load(path)&&ui::cfg.target_mode==2);
 {std::ofstream out(path);out<<"OxideConfig 1\nbox 9\n";}auto before=ui::encoded();assert(!ui::load(path)&&ui::encoded()==before);unlink(path);
 {std::ofstream out(path);out<<"OxideConfig 3\nhold_esp 0\n";}assert(ui::load(path));assert(frame(60000,false)==0);unlink(path);
 // Additive config preserves 0.6 camera units; older overrange ESP settings are clamped.
 {std::ofstream out(path);out<<"OxideConfig 5\nmax_distance 1000\nthird_distance 300\nbots 0\nvehicles 0\nsleepers 0\nturrets 0\ncolor 18 0.4 0.5 0.6 1\n";}assert(ui::load(path)&&ui::cfg.max_distance==350&&ui::cfg.third_distance==300&&!ui::cfg.bots&&!ui::cfg.vehicles&&!ui::cfg.sleepers&&!ui::cfg.turrets);unlink(path);
 for(int kind=1;kind<=10;++kind){if(kind>=8)assert(!ui::world_enabled(kind));}assert(!ui::world_enabled(0)&&!ui::world_enabled(32));ui::cfg.bots=ui::cfg.vehicles=ui::cfg.turrets=true;assert(ui::world_enabled(oxide::Bot)&&ui::world_enabled(oxide::Vehicle)&&ui::world_enabled(oxide::Turret));ui::cfg.max_distance=1000;assert(ui::esp_range()==350);
 ui::cfg.draw_fov=false;ui::cfg.name=true;ui::cfg.sleepers=true;ui::cfg.rgb=false;f.players[0].sleeping=true;assert(frame(1000,false)>0);ui::cfg.sleepers=false;auto old_containers=f.containers;f.containers.clear();assert(frame(1000,false)==0);ui::cfg.sleepers=true;assert(frame(1000,false)>0);f.containers=old_containers;
 f.players.clear();f.containers.clear();f.world={{500,501,50,{0,0,349},oxide::Vehicle,"Машина"}};assert(frame(1000,false)>0);f.world[0].position.z=351;assert(frame(1000,false)==0);f.world[0].position.z=20;for(int kind=8;kind<=10;++kind){f.world[0].kind=kind;assert(frame(1000,false)>0);}ui::cfg.bots=ui::cfg.vehicles=ui::cfg.turrets=false;assert(frame(1000,false)==0);

 // The style tab opens directly and retains the same live preview.
 ui::cfg.language=0;ui::tab=0;ui::opened=true;ui::menu_alpha=1;frame(1000,true);
 auto* content=child("/##oxide_content_");assert(content);
 auto old_color=ui::cfg.colors[0];
 click({content->Pos.x+content->Size.x*.87f,content->Pos.y+16});
 assert(child("/Стиль_")&&child("/Предпросмотр_"));
 assert(!memcmp(&old_color,&ui::cfg.colors[0],sizeof(old_color)));
 // Drawing all twelve edges is independent from labels and from cupboard selection.
 f.world.clear();f.players.clear();f.containers={{1,{0,0,8},1,"box"},{2,{2,0,8},3,"cupboard"}};ui::cfg.small=ui::cfg.cupboard=true;
 for(auto& c:f.containers){c.bounds_valid=true;for(unsigned i=0;i<8;++i)c.corners[i]=oxide::add(c.position,{(i&1)?.5f:-.5f,(i&2)?1.f:0.f,(i&4)?.5f:-.5f});}
 ui::cfg.container_boxes=ui::cfg.cupboard_boxes=false;auto labels_only=frame(1000,false);ui::cfg.container_boxes=true;auto chest_lines=frame(1000,false);assert(chest_lines>labels_only);ui::cfg.cupboard_boxes=true;assert(frame(1000,false)>chest_lines);
 assert(ui::save(path));ui::cfg.container_boxes=ui::cfg.cupboard_boxes=false;assert(ui::load(path)&&ui::cfg.container_boxes&&ui::cfg.cupboard_boxes);unlink(path);
 ui::cfg.aim_animals=ui::cfg.aim_bots=ui::cfg.no_sway=ui::cfg.fast_reload=ui::cfg.rapid_fire=ui::cfg.hand_position=ui::cfg.sky_tint=ui::cfg.trigger=true;ui::cfg.hand_x=77;ui::cfg.hand_y=120;ui::cfg.hand_z=180;ui::cfg.trigger_delay=200;ui::cfg.colors[19]={.8f,.1f,.2f,1};assert(ui::save(path));ui::cfg={};assert(ui::load(path)&&ui::cfg.aim_animals&&ui::cfg.aim_bots&&ui::cfg.no_sway&&ui::cfg.fast_reload&&ui::cfg.rapid_fire&&ui::cfg.hand_position&&ui::cfg.sky_tint&&ui::cfg.trigger&&ui::cfg.hand_x==77&&ui::cfg.hand_y==120&&ui::cfg.hand_z==180&&ui::cfg.trigger_delay==200&&ui::cfg.colors[19].x==.8f);unlink(path);
 for(int tab=0;tab<6;++tab){ui::tab=tab;frame(1000,true);}ui::cfg.language=1;for(int tab=0;tab<6;++tab){ui::tab=tab;frame(1000,true);}
 ui::recorder_ui_active=true;assert(frame(1000,true)==0);ui::recorder_ui_active=false;
 ui::tab=3;ui::opened=true;ui::menu_alpha=1;ui::cfg.menu_scale=75;ui::cfg.menu_opacity=60;ui::cfg.menu_x=0;ui::cfg.menu_y=100;frame(1000,true);auto* layout_window=ImGui::FindWindowByName("##oxide_menu");assert(layout_window&&std::fabs(layout_window->Pos.x)<1&&layout_window->Pos.y>300&&layout_window->Size.x<=1051);assert(ui::save(path));ui::cfg={};assert(ui::load(path)&&ui::cfg.menu_scale==75&&ui::cfg.menu_opacity==60&&ui::cfg.menu_x==0&&ui::cfg.menu_y==100);unlink(path);
 assert(ui::encoded().find("esp_visibility")==std::string::npos);
 assert(ui::encoded().find("visible_only")==std::string::npos);
 assert(io.FontDefault->FindGlyphNoFallback(0x042f));ImGui::DestroyContext();puts("PASS: real ImGui menu/ESP geometry, finite vertices, Cyrillic, bounded ESP cache lifetime, fractional tap calibration, bottom tabs/title layout, 12 distinct themes, exclusive strip/avatar openers, drag cancellation, RU/EN stable IDs, restored configuration roundtrip and legacy migration; multitouch flight axes/swipe/vertical release, bounded GUI event queue and capture rejection without devices; protocol-B slot selection, inverse mapping for all rotations, release and manual-contact preservation, square draggable FC button without accidental toggle, two watermark styles, virtual-device 120-frame hold with one tracking ID; 350m render/config cap, new category/color persistence and sleep filter");
}
