package cc.nova.oxide;
public final class OverlayVisibilityProbe {
 public static void main(String[] args){
  OverlayVisibilityPolicy p=new OverlayVisibilityPolicy();
  require(!p.hidden(),"initial game state");
  p.launcher(true);require(p.hidden(),"launcher and system permissions hide windows");
  p.launcher(false);require(!p.hidden(),"return to game restores windows");
  p.toggle();require(p.hidden(),"manual hide");
  p.launcher(true);p.launcher(false);require(p.hidden(),"manual hide persists across launcher lifecycle");
  p.toggle();require(!p.hidden(),"notification can restore windows");
  p.launcher(true);p.toggle();require(!p.hidden(),"explicit restore works while launcher is visible");
  System.out.println("PASS: launcher/system-screen suspension, explicit hide persistence and restore");
 }
 private static void require(boolean ok,String name){if(!ok)throw new AssertionError(name);}
}
