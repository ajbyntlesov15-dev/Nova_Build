#!/usr/bin/env python3
"""Pinned update for supplied 1.18.12011; validates paired binaries and preserves beta."""
from pathlib import Path
import argparse,re,json,hashlib,struct
from il2cpp_inputs import Dump,Elf
from generate_dual_profiles import build,field
p=argparse.ArgumentParser();p.add_argument('--dump',required=True,type=Path);p.add_argument('--il2cpp',required=True,type=Path);p.add_argument('--unity',required=True,type=Path);p.add_argument('--root',required=True,type=Path);a=p.parse_args();r=a.root
x=build('current',a.dump,a.il2cpp,a.unity,'1.18.12011');d=Dump(a.dump);e=Elf(a.il2cpp);u=Elf(a.unity)
profile=r/'native/src/runtime/profile.hpp';s=profile.read_text();old_beta=s[s.index('inline constexpr uint64_t beta_day_cells'):s.index('inline const char* marker_service_type')]
# Native Unity field-access guards have unchanged bytes in the supplied Unity binary.
oldguards=re.search(r'current_guards\[\]=\{(.*?)\};',s)[1];unity_guards=[]
for addr,size,bytes_ in re.findall(r'\{true,(0x[\da-f]+),(\d+),\{([^}]+)\}\}',oldguards):
 raw=bytes(int(v,0) for v in bytes_.split(','));assert u.at(int(addr,16),int(size))==raw,addr;unity_guards.append((True,int(addr,16),raw))
# Preserve guard order: engine FPS instruction must remain last.
guards=x['guards'][:2]+x['guards'][2:5]+[x['guards'][-1]]+unity_guards[1:]
assert len(guards)==14
modes=d.block('GameModes');controller=d.block('GameControllerBase')
static_controller=next(int(m[1],16) for m in re.finditer(r'private static GameControllerBase [^;]+; // (0x[\da-fA-F]+)',controller))
controller_modes=field(controller,'gameModes')
third=re.search(r'private ThirdPersonMode \w+; // (0x[\da-fA-F]+)',modes);assert third
marker=re.search(r'private (\w+) \w+; // 0x80',modes)[1]
item=re.search(r'private static ItemDatabase [^;]+; // (0x[\da-fA-F]+)',controller);assert item
assert field(d.block('ItemDatabase'),'m_ById')==0x28
cam=next(b for n,b in d.blocks if n=='Camera' and b.startswith('UnityEngine.CoreModule.dll'))
bg=next(a for a,t in d.methods(cam) if 'set_backgroundColor(Color ' in t)
skies=[b for n,b in d.blocks if 'DomePosToCamera;' in b.split('// Methods')[0] and 'DomeScaleToFarClip;' in b.split('// Methods')[0] and any('void Update(' in t for _,t in d.methods(b))];assert len(skies)==1
update=next(a for a,t in d.methods(skies[0]) if 'void Update(' in t)
calls=[i for i in e.cs.disasm(e.at(update,512),update) if i.mnemonic=='bl' and i.operands[0].imm==bg];assert len(calls)==1
sky_address=calls[0].address;sky_word=int.from_bytes(calls[0].bytes,'little')
days=[]
for address,t in d.methods(d.block('TimeOfDay')):
 if '(float ' not in t:continue
 ins=list(e.cs.disasm(e.at(address,120),address));stores=[i for i in ins if i.mnemonic=='str' and i.op_str in ['s0, [x0, #0xb8]','w8, [x0, #0x3c]']]
 if len(stores)==2:days.append(stores)
assert len(days)==1
fraction,hour=[(i.address,int.from_bytes(i.bytes,'little')) for i in days[0]]
assert fraction[1]==0xbd00b800 and hour[1]==0xb9003c08
weapon=d.block('FPHitscan');dispersion=re.search(r'private (\w+) \w+; // 0x1F8',weapon)[1]
assert 'readonly DispersionConfig' in d.block(dispersion)
if 'const char* dispersion_state' not in s:s=s.replace('uint64_t fps_target_cell,fps_manager_cell;','uint64_t fps_target_cell,fps_manager_cell;const char* dispersion_state="QT";')
for name,values in [('day_cells',x['day_cells']),('mode_cells',x['mode_cells'])]:
 s=re.sub(r'inline constexpr uint64_t current_'+name+r'\[\]=\{[^;]+;', 'inline constexpr uint64_t current_'+name+'[]={'+','.join(hex(v) for v in values)+'};',s)
s=re.sub(r'inline constexpr Patch current_patches\[\]=\{[^;]+;','inline constexpr Patch current_patches[]={'+','.join('{'+hex(addr)+','+hex(word)+'U}' for addr,word in x['patches'])+'};',s)
s=re.sub(r'inline constexpr Guard current_guards\[\]=\{[^;]+;','inline constexpr Guard current_guards[]={'+','.join('{'+str(unity).lower()+','+hex(addr)+','+str(len(raw))+',{'+','.join(hex(b) for b in raw)+'}}' for unity,addr,raw in guards)+'};',s)
old=re.search(r'inline constexpr Profile current=\{([^;]+);',s)[0];tail=old.rsplit('}',1)[0];fps=re.search(r',((?:0x)[\da-f]+),((?:0x)[\da-f]+)\}?$',tail)
assert fps,tail
values=[json.dumps('current'),json.dumps(x['version']),hex(x['network_cell']),hex(x['orbit_cell']),json.dumps(x['camera_type']),json.dumps(x['ray_type']),hex(x['handler_sleep']),hex(x['handler_aim']),'current_day_cells',str(len(x['day_cells'])),'current_mode_cells',str(len(x['mode_cells'])),'current_patches','2','current_guards',str(len(guards)),json.dumps(marker),hex(static_controller),hex(controller_modes),third[1],item[1],json.dumps('ItemDatabase'),hex(sky_address),hex(sky_word),'{'+hex(fraction[0])+','+hex(fraction[1])+'}','{'+hex(hour[0])+','+hex(hour[1])+'}',fps[1],fps[2],json.dumps(dispersion)]
s=s.replace(old,'inline constexpr Profile current={'+','.join(values)+'};');assert s[s.index('inline constexpr uint64_t beta_day_cells'):s.index('inline const char* marker_service_type')]==old_beta
profile.write_text(s)
# Rebuild only the current vegetation guard pair.
veg=[]
for name in ['BrgChunkVegetationRenderer','ChunkTreeRenderer']:
 address=next(v for v,t in d.methods(d.block(name)) if 'public void OnChunkLoaded(Vector2Int coord, ChunkData chunkData,' in t);veg.append((address,e.at(address,16)))
p=r/'native/src/runtime/vegetation_profile.hpp';vs=p.read_text();vs=re.sub(r'inline constexpr VegetationPatch vegetation_current\[\]=\{[^;]+;','inline constexpr VegetationPatch vegetation_current[]={'+','.join('{'+hex(addr)+',{'+','.join(str(b) for b in raw)+'}}' for addr,raw in veg)+'};',vs);p.write_text(vs)
x['guards']=[{'unity':v,'address':hex(addr),'bytes':raw.hex()} for v,addr,raw in guards];x.update(marker=marker,database_type='ItemDatabase',dispersion_state=dispersion,sky_writer=hex(sky_address),day_fraction=hex(fraction[0]),day_hour=hex(hour[0]),beta_preserved=True)
(r/'analysis/current_12011.json').write_text(json.dumps(x,indent=2)+'\n');print('Updated current profile:',x['version'],x['camera_type'],x['ray_type'],'beta preserved')
