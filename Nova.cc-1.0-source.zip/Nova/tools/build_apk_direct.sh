#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_HOME:?Set ANDROID_HOME to SDK containing platform 35 and Build Tools 35.0.0}"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to NDK r27c}"
BT="$ANDROID_HOME/build-tools/35.0.0"
PLATFORM="$ANDROID_HOME/platforms/android-35/android.jar"
if [ "${DOF_SKIP_NATIVE_BUILD:-0}" != 1 ]; then bash "$ROOT/native/compile.sh"; fi
: "${DOF_SIGNING_KEYSTORE:?Set a private release keystore path}"
: "${DOF_SIGNING_PASSWORD_FILE:?Set the private password file path}"
keytool -exportcert --keystore "$DOF_SIGNING_KEYSTORE" --alias nova-release --storepass:file "$DOF_SIGNING_PASSWORD_FILE" -file "$ROOT/out-cert.der" >/dev/null
python3 - "$ROOT" <<'PYBUILD'
from pathlib import Path
import sys,hashlib,json
root=Path(sys.argv[1]);cert=hashlib.sha512((root/'out-cert.der').read_bytes()).hexdigest();native=hashlib.sha512((root/'native/out/arm64-v8a/Nova').read_bytes()).hexdigest()
(root/'out-cert.der').unlink()
jni=hashlib.sha512((root/'native/out/arm64-v8a/libnova_license.so').read_bytes()).hexdigest()
(root/'loader/app/src/main/java/com/nova/oxide/BuildSecrets.java').write_text('package cc.nova.oxide; final class BuildSecrets { static final String CERT_SHA512="'+cert+'"; static final String NATIVE_SHA512="'+native+'"; static final String JNI_SHA512="'+jni+'"; }\n')
(root/'analysis/license-build.json').write_text(json.dumps({'format':'panel-ed25519-v1','release':'0.99-vip-panel-only','native_sha512':native,'jni_sha512':jni,'certificate_sha512':cert},indent=2)+'\n')
PYBUILD
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/classes" "$TMP_DIR/dex" "$ROOT/out"
python3 - "$ROOT" "$TMP_DIR" <<'PY'
from pathlib import Path
import sys,xml.etree.ElementTree as E
root,tmp=map(Path,sys.argv[1:]);r=E.parse(root/'loader/app/src/main/AndroidManifest.xml').getroot();r.set('package','cc.nova.oxide');E.register_namespace('android','http://schemas.android.com/apk/res/android');E.ElementTree(r).write(tmp/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
PY
java com.sun.tools.javac.Main -source 8 -target 8 -encoding UTF-8 -classpath "$PLATFORM" -d "$TMP_DIR/classes" "$ROOT"/loader/app/src/main/java/com/nova/oxide/*.java
python3 - "$TMP_DIR" <<'PY'
from pathlib import Path
import zipfile,sys
p=Path(sys.argv[1]);r=p/'classes'
with zipfile.ZipFile(p/'classes.jar','w',zipfile.ZIP_DEFLATED) as z:
 for f in r.rglob('*.class'):z.write(f,f.relative_to(r).as_posix())
PY
java -cp "$BT/lib/d8.jar" com.android.tools.r8.R8 --release --min-api 26 --lib "$PLATFORM" --pg-conf "$ROOT/loader/proguard-rules.pro" --pg-map-output "$ROOT/analysis/loader_0_9.map" --output "$TMP_DIR/dex" "$TMP_DIR/classes.jar"
"$BT/aapt2" compile --dir "$ROOT/loader/app/src/main/res" -o "$TMP_DIR/resources.zip"
"$BT/aapt2" link "$TMP_DIR/resources.zip" -A "$ROOT/loader/app/src/main/assets" -I "$PLATFORM" --manifest "$TMP_DIR/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 35 --version-code 99 --version-name 0.99-vip-panel-only -o "$TMP_DIR/unsigned.apk"
python3 - "$ROOT" "$TMP_DIR" <<'PY'
from pathlib import Path
import zipfile,sys
r,p=map(Path,sys.argv[1:])
with zipfile.ZipFile(p/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 z.write(p/'dex/classes.dex','classes.dex');z.write(r/'native/out/arm64-v8a/libnova_license.so','lib/arm64-v8a/libnova_license.so');z.write(r/'native/out/arm64-v8a/Nova','lib/arm64-v8a/libnova_exec.so')
PY
"$BT/zipalign" -f -P 16 4 "$TMP_DIR/unsigned.apk" "$TMP_DIR/aligned.apk"
"$BT/apksigner" sign --ks "$DOF_SIGNING_KEYSTORE" --ks-key-alias nova-release --ks-pass "file:$DOF_SIGNING_PASSWORD_FILE" --out "$ROOT/out/Nova_Oxide_0.99_ARM64.apk" "$TMP_DIR/aligned.apk"
"$BT/apksigner" verify --verbose "$ROOT/out/Nova_Oxide_0.99_ARM64.apk"
"$BT/zipalign" -c -P 16 4 "$ROOT/out/Nova_Oxide_0.99_ARM64.apk"

python3 "$ROOT/tools/verify_runtime.py" "$ROOT/out/Nova_Oxide_0.99_ARM64.apk"
