#!/usr/bin/env python3
"""Generate pinned, read-verified profiles from the owner's paired APKs/dumps.
Dependencies: capstone, pyelftools. Does not run or modify the game.
"""
import argparse, hashlib, json, re, struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from il2cpp_inputs import Dump, Elf
from capstone.arm64 import ARM64_OP_REG, ARM64_OP_IMM, ARM64_OP_MEM

def field(block, name):
 m=re.search(r'\b'+re.escape(name)+r'(?:\s*=\s*[^;]+)?; // (0x[0-9A-Fa-f]+)',block)
 if not m: raise ValueError('Missing field '+name)
 return int(m[1],16)

def refs(elf, addr, size):
 # Only absolute ADRP/LDR data references; invalidate written registers.
 registers={}; out=[]
 for ins in elf.cs.disasm(elf.at(addr,size),addr):
  op=ins.operands
  if ins.mnemonic=='adrp' and len(op)==2:
   registers[op[0].reg]=op[1].imm;continue
  if ins.mnemonic=='ldr' and len(op)==2 and op[1].type==ARM64_OP_MEM and op[1].mem.base in registers:
   a=registers[op[1].mem.base]+op[1].mem.disp
   if ins.reg_name(op[0].reg).startswith('x') and any(p[3]<=a<p[3]+p[6] and p[1]&2 for p in elf.segs):out.append(a)
  try:
   _,written=ins.regs_access()
   for reg in written:registers.pop(reg,None)
  except Exception: registers.clear()
  if ins.mnemonic in ('bl','blr'):
   registers={r:v for r,v in registers.items() if ins.reg_name(r) in ['x'+str(i) for i in range(19,29)]}
 return sorted(set(out))

def build(channel,dump_path,lib_path,unity_path,base_version):
 d=Dump(dump_path);e=Elf(lib_path);u=Elf(unity_path)
 all_rvas=sorted(set(a for _,b in d.blocks for a,_ in d.methods(b) if a))
 import bisect
 def size(a,cap=8192):
  i=bisect.bisect_right(all_rvas,a);return min(cap,all_rvas[i]-a if i<len(all_rvas) else cap)
 def mtd(b,needle):
  matches=[(a,s) for a,s in d.methods(b) if needle in s]
  if len(matches)!=1:raise ValueError((needle,len(matches)))
  return matches[0][0]
 pm=d.block('PlayerManager');network=d.block('NetworkClient');tod=d.block('TimeOfDay')
 camera=re.search(r'private (\w+) <[^>]+>k__BackingField; // 0xA0',pm)[1]
 handler=re.search(r'public (\w+) playerEventHandler;',pm)[1];hb=d.block(handler)
 ray=re.search(r'public \w+<(\w+)> RaycastData;',hb)[1]
 net=mtd(network,'get_localPlayer(');nr=refs(e,net,size(net));assert len(nr)==1,nr
 cell=nr[0]
 camera_block=d.block(camera);cc=mtd(camera_block,'.cctor(');cr=refs(e,cc,size(cc));assert len(cr)==1,cr
 day=sorted(set(a for a0,_ in d.methods(tod) for a in refs(e,a0,size(a0))))
 mode=sorted(set(a for a0,_ in d.methods(camera_block) for a in refs(e,a0,size(a0))))
 # Verify public gameplay field offsets used by the existing runtime.
 expected={'mouseLook':0xb0,'playerEventHandler':0xb8,'fpManager':0xd0,'vitals':0x108,'teamName':0x2f0,'clanId':0x300}
 for n,a in expected.items():assert field(pm,n)==a,(channel,n)
 for n,a in {'Recoil':0x138,'RaycastData':0x160,'AimRaycast':0x168}.items():assert field(hb,n)==a
 # Paired collect-all state machines each contain one Delay float load.
 patches=[]
 for n,b in d.blocks:
  if n not in ('<CollectAllItems>d__12','<CollectAllItems>d__6'):continue
  move=mtd(b,'MoveNext(')
  ins=list(e.cs.disasm(e.at(move,size(move,16384)),move))
  hits=[]
  for i,x in enumerate(ins):
   if x.mnemonic=='ldr' and x.op_str.startswith('s0, [x8,') and i>=3:
    seq=ins[i-3:i+5]
    if seq[0].mnemonic=='adrp' and seq[1].op_str=='w0, #1' and seq[2].op_str=='w1, #8' and seq[4].op_str=='x2, x20':hits.append((x.address,int.from_bytes(x.bytes,'little')))
  assert len(hits)==1,(channel,n,hits)
  patches+=hits
 assert len(patches)==2
 # Exact ELF Build ID plus selected gameplay entry instructions and Unity camera checks.
 guards=[]
 for image,is_unity in [(e,False),(u,True)]:
  with Path(lib_path if not is_unity else unity_path).open('rb') as f:
   ef=ELFFile(f);note=ef.get_section_by_name('.note.gnu.build-id');assert note
   data=note.data();namesz,descsz,typ=struct.unpack_from('<III',data);off=12+((namesz+3)&~3)
   guards.append((is_unity,int(note['sh_addr'])+off,data[off:off+descsz]))
 guard_methods=[net,mtd(tod,'Update('),cc]
 for a in guard_methods: guards.append((False,a,e.at(a,32)))
 for a,n in [(0xe343f4,8),(0x7fc918,8),(0x5c6bf4,8),(0xe3fec8,12),(0x64b258,12),(0x5b6170,16),(0xe40cd0,24)]:guards.append((True,a,u.at(a,n)))
 # The Unity implementation is equivalent at every field-access guard for both APKs.
 # Pin the look setter that stores directly at +0x4c.
 looks=[b for n,b in d.blocks if n=='MouseLook' and 'm_EventHandler;' in b];assert len(looks)==1
 look_setters=[]
 for a,s in d.methods(looks[0]):
  if '(Vector2 ' in s and e.at(a,8)==bytes.fromhex('0084092dc0035fd6'):look_setters.append(a)
 assert look_setters,channel
 guards.append((False,look_setters[0],e.at(look_setters[0],8)))
 return {'channel':channel,'version':base_version,'network_cell':cell,'orbit_cell':cr[0],'camera_type':camera,'ray_type':ray,'handler_sleep':field(hb,'Sleep'),'handler_aim':field(hb,'Aim'),'day_cells':day,'mode_cells':mode,'patches':patches,'guards':guards,'il2cpp_sha256':hashlib.sha256(e.data).hexdigest(),'unity_sha256':hashlib.sha256(u.data).hexdigest(),'look_setters':look_setters}

def main():
 p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--current',nargs=3,type=Path,metavar=('DUMP','IL2CPP','UNITY'));args=p.parse_args();root=args.inputs
 profiles=[]
 for channel,df,lf,v in [('release','dump.cs','libil2cpp(1).so','1.17.12000'),('beta','dump[1].cs','либка_бета[1].so','1.18.11999')]:profiles.append(build(channel,root/df,root/lf,root/(channel+'-libunity.so'),v))
 if args.current:profiles.append(build('current',*args.current,'1.18.12003'))
 lines=['#pragma once','#include <cstdint>','#include <cstddef>','#include <cstring>','namespace oxide_profile {','struct Guard{bool unity;uint64_t address;unsigned size;unsigned char bytes[32];};','struct Patch{uint64_t address;uint32_t expected;};','struct Profile{const char* channel;const char* version;uint64_t network_client_cell,orbit_cell;const char* camera_type;const char* ray_type;unsigned handler_sleep,handler_aim;const uint64_t* day_cells;size_t day_count;const uint64_t* mode_cells;size_t mode_count;const Patch* patches;size_t patch_count;const Guard* guards;size_t guard_count;};']
 for x in profiles:
  c=x['channel']
  for name in ['day_cells','mode_cells']:lines.append('inline constexpr uint64_t '+c+'_'+name+'[]={'+','.join(hex(a) for a in x[name])+'};')
  lines.append('inline constexpr Patch '+c+'_patches[]={'+','.join('{'+hex(a)+','+hex(w)+'U}' for a,w in x['patches'])+'};')
  lines.append('inline constexpr Guard '+c+'_guards[]={'+','.join('{'+str(u).lower()+','+hex(a)+','+str(len(b))+',{'+','.join(hex(i) for i in b)+'}}' for u,a,b in x['guards'])+'};')
  lines.append('inline constexpr Profile '+c+'={'+','.join([json.dumps(c),json.dumps(x['version']),hex(x['network_cell']),hex(x['orbit_cell']),json.dumps(x['camera_type']),json.dumps(x['ray_type']),hex(x['handler_sleep']),hex(x['handler_aim']),c+'_day_cells',str(len(x['day_cells'])),c+'_mode_cells',str(len(x['mode_cells'])),c+'_patches',str(len(x['patches'])),c+'_guards',str(len(x['guards']))])+'};')
 current='if(!std::strcmp(name,\"current\"))return &current;' if args.current else ''
 lines+=['inline const char* marker_service_type(const Profile& p){if(!std::strcmp(p.channel,\"current\"))return \"OH\";return !std::strcmp(p.channel,\"beta\")?\"ot\":\"OG\";}','inline const Profile* select(const char* name){if(!name)return nullptr;if(!std::strcmp(name,"release"))return &release;if(!std::strcmp(name,"beta"))return &beta;'+current+'return nullptr;}','}']
 args.out.mkdir(parents=True,exist_ok=True);(args.out/'profile.hpp').write_text('\n'.join(lines)+'\n')
 for x in profiles:x['guards']=[{'unity':u,'address':hex(a),'bytes':b.hex()} for u,a,b in x['guards']]
 (args.out/'profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
 print('Validated profiles:',[(x['channel'],hex(x['network_cell']),len(x['day_cells']),len(x['mode_cells'])) for x in profiles])
if __name__=='__main__':main()
