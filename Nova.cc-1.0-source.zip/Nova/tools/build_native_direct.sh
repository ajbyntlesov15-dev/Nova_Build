#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../native"
: "${ANDROID_NDK_HOME:?Set Android NDK path}"
bin="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin"
cc="$bin/aarch64-linux-android26-clang"
cxx="$bin/aarch64-linux-android26-clang++"
mkdir -p build/direct out/arm64-v8a
common=(-Oz -flto=thin -ffunction-sections -fdata-sections -fvisibility=hidden -fstack-protector-strong -fPIC -DANDROID -D_FORTIFY_SOURCE=2)
cpp=(-std=c++17 -fno-exceptions -fno-rtti -fvisibility-inlines-hidden)
headers=(-Ibuild/local-private -Iincludes -Iincludes/fonts -Iincludes/internal -Iincludes/internal/ImGui -Iincludes/internal/ImGui/backends -Iincludes/draw/ImGui -Iincludes/draw/ImGui/backends -Isrc -Isrc/ui)
for file in monocypher monocypher-ed25519; do
 "$cc" "${common[@]}" -c "vendor/monocypher/$file.c" -o "build/direct/$file.o"
done
for file in src/main.cpp includes/draw/Android_draw/draw.cpp includes/draw/Android_touch/Touch.cpp includes/draw/ImGui/{imgui,imgui_draw,imgui_tables,imgui_widgets}.cpp includes/draw/ImGui/backends/{imgui_impl_android,imgui_impl_opengl3}.cpp src/security/license_jni.cpp src/security/virtual_probe.cpp; do
 name="${file##*/}"
 "$cxx" "${common[@]}" "${cpp[@]}" "${headers[@]}" -c "$file" -o "build/direct/${name%.cpp}.o"
done
"$cc" -Iassets/models -c src/ui/model_assets.S -o build/direct/model_assets.o
link=(-flto=thin -static-libstdc++ -Wl,--gc-sections -Wl,-z,max-page-size=16384 -Wl,--strip-all -Wl,-z,relro,-z,now,-z,noexecstack)
"$cxx" "${link[@]}" -pie build/direct/{main,model_assets,draw,Touch,imgui,imgui_draw,imgui_tables,imgui_widgets,imgui_impl_android,imgui_impl_opengl3,monocypher,monocypher-ed25519}.o -ldl -lz -llog -landroid -lEGL -lGLESv3 -laaudio -o out/arm64-v8a/Nova
"$cxx" "${link[@]}" -shared build/direct/{license_jni,virtual_probe,main,model_assets,draw,Touch,imgui,imgui_draw,imgui_tables,imgui_widgets,imgui_impl_android,imgui_impl_opengl3,monocypher,monocypher-ed25519}.o -ldl -lz -llog -landroid -lEGL -lGLESv3 -laaudio -o out/arm64-v8a/libnova_license.so

