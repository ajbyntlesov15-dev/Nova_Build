from pathlib import Path
import re,struct
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
class Dump:
 def __init__(self,p):
  self.blocks=[]
  for b in Path(p).read_text().split('// Dll : ')[1:]:
   m=re.search(r'^(?:public |private |internal |protected |static |sealed |abstract |partial )*(?:class|struct|interface|enum) ([^ :\n]+)[^\n]*\n\{',b,re.M)
   if m:self.blocks.append((m.group(1),b))
 def block(self,name):
  bs=[b for n,b in self.blocks if n==name and re.search(r"\bclass "+re.escape(name)+r"(?: |:|\n)",b)]
  if len(bs)!=1:raise ValueError((name,len(bs)))
  return bs[0]
 def methods(self,b):return [(int(m[1],16),m[2].strip()) for m in re.finditer(r'// RVA: (0x[\da-fA-F]+)[^\n]*\n\s*([^\n]+)',b)]
class Elf:
 def __init__(self,p):
  self.data=Path(p).read_bytes();d=self.data;o=struct.unpack_from('<Q',d,32)[0];sz,n=struct.unpack_from('<HH',d,54);self.segs=[struct.unpack_from('<IIQQQQQQ',d,o+i*sz) for i in range(n) if struct.unpack_from('<I',d,o+i*sz)[0]==1]
  self.cs=Cs(CS_ARCH_ARM64,CS_MODE_ARM);self.cs.detail=True
 def at(self,va,n):
  for p in self.segs:
   if p[3]<=va and va+n<=p[3]+p[5]:return self.data[p[2]+va-p[3]:p[2]+va-p[3]+n]
  raise ValueError(hex(va))
 def dis(self,va,n=160):return '\n'.join(f'{i.address:x} {i.mnemonic} {i.op_str}' for i in self.cs.disasm(self.at(va,n),va))
