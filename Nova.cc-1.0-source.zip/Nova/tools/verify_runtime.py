import sys,zipfile
from pathlib import Path
with zipfile.ZipFile(Path(sys.argv[1])) as z:
 native=z.read('lib/arm64-v8a/libnova_exec.so');jni=z.read('lib/arm64-v8a/libnova_license.so');dex=z.read('classes.dex')
 assert b'Nova.cc runtime 1.0' in native and b'1.19.12025' in native
 assert b'Java_cc_nova_oxide_LicenseBridge_localCheck' in jni
 assert b'Lcc/nova/oxide/MainActivity;' in dex
 assert b'p1084164.ihc.xyz' not in dex+jni+native
 assert z.read('assets/nova_logo.png').startswith(b'\x89PNG')
print('PASS: Nova.cc ARM64 release 12025 and local licensing')
