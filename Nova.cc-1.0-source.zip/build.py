from pathlib import Path
import subprocess, zipfile, hashlib, shutil, sys, json, concurrent.futures
import xml.etree.ElementTree as ET

base=Path(__file__).resolve().parent
import os
tmp=base/"checks/temp-build-090";tmp.mkdir(exist_ok=True);os.environ["TEMP"]=str(tmp);os.environ["TMP"]=str(tmp)
root=base/'Nova'
build=base/'build'
private=base/'private'
build.mkdir(exist_ok=True)
private.mkdir(exist_ok=True)
sdk=Path(r'C:\Users\vladi\AppData\Local\Android\Sdk')
llvm=sdk/'ndk/30.0.16248370/toolchains/llvm/prebuilt/windows-x86_64'
bt=sdk/'build-tools/36.0.0'
jdk=Path(r'C:\Program Files\Android\Android Studio\jbr\bin')
compiler=base.parent/'checks/clang++.exe'
linker=base.parent/'checks/ld.lld.exe'
log=build/'build.log'
log.write_text('',encoding='utf-8')

def run(args):
    proc=subprocess.run(list(map(str,args)),capture_output=True,text=True,encoding='utf-8',errors='replace')
    with log.open('a',encoding='utf-8') as f: f.write(proc.stdout+proc.stderr)
    if proc.returncode:
        raise RuntimeError(str(args[0])+' failed:\n'+proc.stdout+proc.stderr)
    return proc.stdout+proc.stderr

if not (private/'nova-release.jks').exists():
    import secrets
    (private/'password.txt').write_text(secrets.token_urlsafe(36),encoding='ascii')
    run([jdk/'keytool.exe','-genkeypair','-keystore',private/'nova-release.jks','-alias','nova-release','-keyalg','RSA','-keysize','3072','-validity','10000','-storepass:file',private/'password.txt','-keypass:file',private/'password.txt','-dname','CN=Nova.cc, O=Nova Software, C=US'])
run([jdk/'keytool.exe','-exportcert','--keystore',private/'nova-release.jks','--alias','nova-release','--storepass:file',private/'password.txt','-file',build/'cert.der'])
certificate=hashlib.sha512((build/'cert.der').read_bytes()).hexdigest()
old_secrets=''
expected=certificate
print('Nova.cc independent signing identity loaded',flush=True)
objects=build/'objects'
objects.mkdir(exist_ok=True)
common=['--target=aarch64-linux-android26','--sysroot='+str(llvm/'sysroot'),'-resource-dir='+str(llvm/'lib/clang/21'),'-Oz','-flto=thin','-fPIC','-fvisibility=hidden','-fstack-protector-strong','-D_FORTIFY_SOURCE=2','-ffunction-sections','-fdata-sections','-DANDROID']
includes=['-I'+str(build)]+['-I'+str(root/p) for p in ['native/includes','native/includes/fonts','native/includes/internal','native/includes/internal/ImGui','native/includes/internal/ImGui/backends','native/includes/draw/ImGui','native/includes/draw/ImGui/backends','native/src','native/src/ui']]
sources=['src/main.cpp','src/security/license_jni.cpp','src/security/virtual_probe.cpp','includes/draw/Android_draw/draw.cpp','includes/draw/Android_touch/Touch.cpp']
sources+=['includes/draw/ImGui/'+n+'.cpp' for n in ['imgui','imgui_draw','imgui_tables','imgui_widgets']]
sources+=['includes/draw/ImGui/backends/'+n+'.cpp' for n in ['imgui_impl_android','imgui_impl_opengl3']]
sources+=['vendor/monocypher/monocypher.c','vendor/monocypher/monocypher-ed25519.c','src/ui/model_assets.S']

def compile_one(rel):
    src=root/'native'/rel
    options=list(common)
    if src.suffix=='.cpp':
        options+=['-std=c++17','-fno-rtti','-fvisibility-inlines-hidden','-fexceptions' if src.stem=='lulu_bootstrap' else '-fno-exceptions',*includes]
    else:
        options+=['-x','assembler-with-cpp' if src.suffix=='.S' else 'c','-I'+str(root/'native/assets/models')]
    run([compiler,*options,'-c',src,'-o',objects/(src.stem+'.o')])
    return rel

print('Compiling optimized ARM64 modules with server public-key verification',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(compile_one,s) for s in sources]
    for f in concurrent.futures.as_completed(futures): print('Compiled '+f.result(),flush=True)

shared=[objects/(n+'.o') for n in ['main','model_assets','draw','Touch','imgui','imgui_draw','imgui_tables','imgui_widgets','imgui_impl_android','imgui_impl_opengl3','monocypher','monocypher-ed25519']]
links=[*common,'--ld-path='+str(linker),'-static-libstdc++','-Wl,--no-undefined,--gc-sections,--strip-all,-z,max-page-size=16384,-z,relro,-z,now,-z,noexecstack']
libraries=['-ldl','-lz','-llog','-landroid','-lEGL','-lGLESv3','-laaudio']
run([compiler,*links,'-pie',*shared,*libraries,'-o',build/'Nova'])
run([compiler,*links,'-shared',objects/'license_jni.o',objects/'virtual_probe.o',*shared,*libraries,'-o',build/'libnova_license.so'])
print('Both ARM64 modules linked',flush=True)

native_hash=hashlib.sha512((build/'Nova').read_bytes()).hexdigest()
secrets='package cc.nova.oxide; final class BuildSecrets { static final String CERT_SHA512="'+certificate+'"; static final String NATIVE_SHA512="'+native_hash+'"; static final String JNI_SHA512="'+hashlib.sha512((build/"libnova_license.so").read_bytes()).hexdigest()+'"; }\n'
(root/'loader/app/src/main/java/cc/nova/oxide/BuildSecrets.java').write_text(secrets,encoding='utf-8')
# Keep the visible version consistent with the packaged version.
main=root/'loader/app/src/main/java/cc/nova/oxide/MainActivity.java'
main.write_text(main.read_text(encoding='utf-8'),encoding='utf-8')
classes=build/'classes'
dex=build/'dex'
classes.mkdir(exist_ok=True)
dex.mkdir(exist_ok=True)
javafiles=sorted((root/'loader/app/src/main/java/cc/nova/oxide').glob('*.java'))
run([jdk/'java.exe','-cp',base.parent/'checks/java','CompileAndroid',base.parent/'checks/android.jar',classes,*javafiles])
with zipfile.ZipFile(build/'classes.jar','w',zipfile.ZIP_DEFLATED) as z:
    for f in classes.rglob('*.class'): z.write(f,f.relative_to(classes).as_posix())
run([jdk/'java.exe','-cp',bt/'lib/d8.jar','com.android.tools.r8.R8','--release','--min-api','26','--lib',base.parent/'checks/android.jar','--pg-conf',root/'loader/proguard-rules.pro','--pg-map-output',build/'mapping.txt','--output',dex,build/'classes.jar'])
print('Java and R8 completed',flush=True)

ns='http://schemas.android.com/apk/res/android'
manifest=ET.parse(root/'loader/app/src/main/AndroidManifest.xml')
manifest.getroot().set('package','cc.nova.oxide')
ET.register_namespace('android',ns)
manifest.write(build/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
for name in ['aapt2.exe','zipalign.exe']:
    shutil.copy2(bt/name,build/name)
for dll in bt.glob('*.dll'): shutil.copy2(dll,build/dll.name)
run([build/'aapt2.exe','compile','--dir',root/'loader/app/src/main/res','-o',build/'resources.zip'])
run([build/'aapt2.exe','link',build/'resources.zip','-A',root/'loader/app/src/main/assets','-I',base.parent/'checks/android.jar','--manifest',build/'AndroidManifest.xml','--min-sdk-version','26','--target-sdk-version','35','--version-code','100','--version-name','1.0-nova-release','-o',build/'unsigned.apk'])
with zipfile.ZipFile(build/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
    z.write(dex/'classes.dex','classes.dex')
    for src,name in [('Nova','libnova_exec.so'),('libnova_license.so','libnova_license.so')]:
        z.write(build/src,'lib/arm64-v8a/'+name)
run([build/'zipalign.exe','-f','-P','16','4',build/'unsigned.apk',build/'aligned.apk'])
dest=base.parent.parent/'outputs/Nova.cc/Nova.cc-1.0-release12025-arm64.apk'
run([jdk/'java.exe','-jar',bt/'lib/apksigner.jar','sign','--ks',private/'nova-release.jks','--ks-key-alias','nova-release','--ks-pass','file:'+str(private/'password.txt'),'--out',dest,build/'aligned.apk'])
verification=run([jdk/'java.exe','-jar',bt/'lib/apksigner.jar','verify','--verbose','--print-certs',dest])
run([build/'zipalign.exe','-c','-P','16','4',dest])
run([sys.executable,base/'verify_apk.py',dest])
(build/'signature-verification.txt').write_text(verification,encoding='utf-8')
report={'apk':dest.name,'version':'1.0-nova-release','version_code':100,'package':'cc.nova.oxide','architecture':'arm64-v8a','min_sdk':26,'target_sdk':35,'signing_identity':'Nova.cc independent certificate','signature_verification':'PASS','alignment_16k':'PASS','runtime_package_validation':'PASS','sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'device_installation':'NOT PERFORMED','game_and_lulubox_end_to_end':'NOT TESTED'}
(dest.parent/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
