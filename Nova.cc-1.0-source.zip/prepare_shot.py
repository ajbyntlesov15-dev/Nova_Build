from pathlib import Path
import subprocess,sys,struct,json
base=Path(__file__).resolve().parent
root=base/'Nova'
sys.path[:0]=[str(base.parent/'profile-libs-12024'),str(root/'tools')]
from il2cpp_inputs import Dump,Elf
from elftools.elf.elffile import ELFFile
out=base/'checks/shot';out.mkdir(parents=True,exist_ok=True)
llvm=Path('C:/Users/vladi/AppData/Local/Android/Sdk/ndk/30.0.16248370/toolchains/llvm/prebuilt/windows-x86_64')
def run(args):subprocess.run(list(map(str,args)),check=True,capture_output=True)
src=root/'native/src/runtime/shot_payload.c'
run([base.parent/'checks/clang++.exe','--target=aarch64-linux-android26','--sysroot='+str(llvm/'sysroot'),'-resource-dir='+str(llvm/'lib/clang/21'),'-x','c','-std=c11','-Oz','-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-unwind-tables','-fno-asynchronous-unwind-tables','-fvisibility=hidden','-fno-math-errno','-fno-pic','-c',src,'-o',out/'payload.o'])
run([base.parent/'checks/ld.lld.exe','-T',src.with_suffix('.ld'),'--no-undefined',out/'payload.o','-o',out/'payload.elf'])
with (out/'payload.elf').open('rb') as f:
 e=ELFFile(f);symbols={s.name:int(s['st_value']) for s in e.get_section_by_name('.symtab').iter_symbols()}
 assert not any(s.num_relocations() for s in e.iter_sections() if s['sh_type'] in ('SHT_RELA','SHT_REL'))
 text=e.get_section_by_name('.text');assert text['sh_addr']==0 and text['sh_size']<0x4000
 blob=text.data()
 assert symbols['shot_state']==0x4000
 (out/'payload.bin').write_bytes(blob)
meta={n:symbols[n] for n in ('shot_entry0','shot_entry1','shot_trampoline0','shot_trampoline1','shot_state')}
meta['text_size']=len(blob)
profiles={}
for name,folder in [('current',next(Path('C:/Users/vladi/Downloads').glob('*12025')).name)]:
 p=Path('C:/Users/vladi/Downloads')/folder;d=Dump(p/'dump.cs');elf=Elf(p/'libil2cpp.so')
 candidates=[(a,t) for a,t in d.methods(d.block('FPHitscan')) if 'void ' in t and '(Ray ' in t and ',' not in t]
 assert len(candidates)==2,(name,candidates)
 entries=[]
 for a,t in sorted(candidates):
  instructions=list(elf.cs.disasm(elf.at(a,16),a))
  assert len(instructions)==4
  # Relocation-free entry sequence, identical stack layout for both handlers.
  assert [(i.mnemonic,i.op_str) for i in instructions]==[
   ('stp','d15, d14, [sp, #-0xa0]!'),('stp','d13, d12, [sp, #0x10]'),
   ('stp','d11, d10, [sp, #0x20]'),('stp','d9, d8, [sp, #0x30]')],(hex(a),elf.dis(a,16))
  body=elf.dis(a,1400)
  assert 'mov x23, x1' in body and 'ldp s12, s13, [x23]' in body and 'ldp s10, s8, [x23, #0x10]' in body
  entries.append({'address':a,'guard':elf.at(a,32).hex(),'method':t})
 profiles[name]=entries
meta['profiles']=profiles
(out/'payload.json').write_text(json.dumps(meta,indent=2))
def data(raw):return ','.join('0x%02x'%b for b in raw)
h='#pragma once\n#include <cstdint>\nnamespace oxide_shot {\n'
h+='inline constexpr unsigned char code[]={'+data(blob)+'};\n'
h+='inline constexpr uint32_t entry[2]={%d,%d},trampoline[2]={%d,%d},state=0x4000;\n'%tuple(meta[k] for k in ('shot_entry0','shot_entry1','shot_trampoline0','shot_trampoline1'))
h+='struct Site { uint64_t offset; unsigned char expected[32]; };\n'
for name,sites in profiles.items():
 h+='inline constexpr Site '+name+'[2]={'+','.join('{0x%x,{%s}}'%(s['address'],data(bytes.fromhex(s['guard']))) for s in sites)+'};\n'
h+='inline constexpr auto& beta=current;\n}\n'
(root/'native/src/runtime/shot_payload_generated.hpp').write_text(h)
print(json.dumps(meta,indent=2))
