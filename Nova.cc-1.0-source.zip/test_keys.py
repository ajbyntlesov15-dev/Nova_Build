from pathlib import Path
import subprocess,sys,json,struct,hashlib
b=Path(__file__).resolve().parent;r=b/'Nova';out=b/'checks/keys';out.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(b.parent/'checks/shot103/python'),str(b.parent/'profile-libs-12024')]
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
llvm=Path('C:/Users/vladi/AppData/Local/Android/Sdk/ndk/30.0.16248370/toolchains/llvm/prebuilt/windows-x86_64')
fixture='''#include "local_key_core.hpp"
extern "C" void* memcpy(void* d,const void* s,size_t n){auto a=(unsigned char*)d;auto b=(const unsigned char*)s;for(size_t i=0;i<n;++i)a[i]=b[i];return d;}
extern "C" void* memset(void* d,int c,size_t n){auto a=(unsigned char*)d;for(size_t i=0;i<n;++i)a[i]=(unsigned char)c;return d;}
extern "C" bool nova_check(const char* s,size_t n){return nova_license::verify_bytes(s,n);}
'''
(out/'fixture.cpp').write_text(fixture)
common=['--target=aarch64-linux-android26','--sysroot='+str(llvm/'sysroot'),'-resource-dir='+str(llvm/'lib/clang/21'),'-O2','-fno-builtin','-ffreestanding','-fno-stack-protector','-ffunction-sections','-fdata-sections']
objects=[]
for source in [out/'fixture.cpp',r/'native/vendor/monocypher/monocypher.c',r/'native/vendor/monocypher/monocypher-ed25519.c']:
 target=out/(source.stem+'.o');options=['-std=c++17','-fno-rtti','-fno-exceptions'] if source.suffix=='.cpp' else ['-x','c']
 p=subprocess.run(list(map(str,[b.parent/'checks/clang++.exe',*common,*options,'-I'+str(r/'native/src/security'),'-c',source,'-o',target])),capture_output=True,text=True);assert p.returncode==0,p.stderr;objects.append(target)
(out/'link.ld').write_text('SECTIONS { . = 0; .text : { *(.text*) *(.rodata*) *(.data*) } /DISCARD/ : { *(.eh_frame*) *(.comment) *(.note*) } }')
p=subprocess.run(list(map(str,[b.parent/'checks/ld.lld.exe','-T',out/'link.ld','--gc-sections','-e','nova_check','--no-undefined',*objects,'-o',out/'fixture.elf'])),capture_output=True,text=True);assert p.returncode==0,p.stderr
with (out/'fixture.elf').open('rb') as f:
 e=ELFFile(f);code=e.get_section_by_name('.text').data();entry=next(s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols() if s.name=='nova_check')
B=0x1000000;D=0x2000000;S=0x3000000;RET=0x4000000
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
for address,size in [(B,0x100000),(D,0x1000),(S,0x10000),(RET,0x1000)]:u.mem_map(address,size)
u.mem_write(B,code)
def check(raw):
 u.mem_write(D,raw+b'\x00');u.reg_write(UC_ARM64_REG_X0,D);u.reg_write(UC_ARM64_REG_X1,len(raw));u.reg_write(UC_ARM64_REG_SP,S+0xf000);u.reg_write(UC_ARM64_REG_LR,RET);u.emu_start(B+entry,RET,count=1000000);return bool(u.reg_read(UC_ARM64_REG_X0))
keys=(b/'private/nova-keys.txt').read_text().splitlines();assert len(keys)==len(set(keys))==250
tests=0
for key in keys:
 raw=key.encode('ascii');assert check(raw);assert check(raw+b'\n');tests+=2
 changed=raw[:-1]+(b'0' if raw[-1:]!=b'0' else b'1');assert not check(changed);tests+=1
for raw in [b'',b'NOVA-',b'NOVA-'+b'G'*32,b'NOVA-'+b'0'*32,b'DFM-'+b'A'*32,keys[0].encode()+b'\n\n',keys[0].lower().encode()]:assert not check(raw);tests+=1
report={'result':'PASS','tests':tests,'scope':'actual ARM64 local key verifier and SHA512 implementation in Unicorn','valid_keys':250,'expiry':'none','device_binding':False,'online_requests':False,'plaintext_keys_in_APK':False}
(b/'checks/key-tests.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
