from pathlib import Path
import sys,re,json,struct,hashlib
b=Path(__file__).resolve().parent;r=b/'Nova';sys.path[:0]=[str(b.parent/'profile-libs-12024'),str(r/'tools')]
from il2cpp_inputs import Dump,Elf
from generate_dual_profiles import field
p=next(Path('C:/Users/vladi/Downloads').glob('*12025'));d=Dump(p/'dump.cs');e=Elf(p/'libil2cpp.so');u=Elf(b/'inputs/libunity.so');old=Elf(b.parent/'update-12016-12018/current/libunity.so')
x=json.loads((b/'inputs/generated-base.json').read_text())
original=(b.parent/'update-12016-12018/Oxide/native/src/runtime/profile.hpp').read_text()
def method(block,needle):
 matches=[a for a,t in d.methods(block) if needle in t];assert len(matches)==1,(needle,matches);return matches[0]
def typed(block,typ,static=False):
 lines=[line for line in block.split('// Methods')[0].splitlines() if re.search(r'\b'+re.escape(typ)+r'\s+[^;]+;',line) and '// 0x' in line and ('static ' in line)==static]
 assert len(lines)==1,(typ,lines);return int(re.search(r'// (0x[\da-fA-F]+)',lines[0])[1],16)
def sig(elf,a,n=64,globals=False):
 out=[]
 for i in elf.cs.disasm(elf.at(a,n),a):
  op=i.op_str
  if i.mnemonic in ('adr','adrp'):op=op.split(',')[0]+', PAGE'
  elif i.mnemonic=='bl':op='CALL'
  elif i.mnemonic.startswith('b.') or i.mnemonic in ('b','cbz','cbnz','tbz','tbnz'):op=re.sub(r'#0x([0-9a-f]+)',lambda m:'#rel'+str(int(m[1],16)-i.address),op)
  if globals and i.mnemonic in ('ldr','str','add'):op=re.sub(r', #0x[0-9a-f]+',', #GLOBAL',op)
  out.append((i.mnemonic,op))
 return out
def hits(raw):
 result=[]
 for seg in u.segs:
  if not seg[1]&1:continue
  data=u.data[seg[2]:seg[2]+seg[5]];i=data.find(raw)
  while i>=0:result.append(seg[3]+i);i=data.find(raw,i+1)
 return result
oldguards=re.search(r'current_guards\[\]=\{(.*?)\};',original)[1];mapped=[]
for address,n,values in re.findall(r'\{true,(0x[\da-f]+),(\d+),\{([^}]+)\}\}',oldguards):
 a=int(address,16);n=int(n)
 if a==0x318:continue
 raw=old.at(a,n);global_load=a==0x744cf0
 if global_load:
  # Frame-rate getter is ADRP / LDR S0 / RET. Find unique relocated context.
  candidates=[h-8 for h in hits(bytes.fromhex('c0035fd6')) if abs(h-8-a)<0x10000 and sig(u,h-8,12,True)==sig(old,a,12,True)]
 else:
  candidates=hits(raw[:12] if a==0xe40cd0 else raw);matches=[h for h in candidates if sig(u,h,64,a==0xe40cd0)==sig(old,a,64,a==0xe40cd0)]
  if not matches:matches=[h for h in candidates if sig(u,h,n,a==0xe40cd0)==sig(old,a,n,a==0xe40cd0)]
  candidates=matches
 assert len(candidates)==1,(hex(a),[hex(h) for h in candidates[:10]])
 na=candidates[0];mapped.append({'unity':True,'address':na,'bytes':u.at(na,n).hex()});print('UNITY',hex(a),'->',hex(na),flush=True)
 if global_load:
  ins=list(u.cs.disasm(u.at(na,8),na));fps=ins[0].operands[1].imm+ins[1].operands[1].mem.disp
# Locate the QualitySettings static pointer from the equivalent getter using
# verified ADRP/LDR context and a unique segment relocation. Do not guess it.
def data_refs(elf,pc):
 regs={};result=[]
 for index,i in enumerate(elf.cs.disasm(elf.at(pc,32),pc)):
  op=i.operands
  if i.mnemonic=='adrp':regs[op[0].reg]=op[1].imm
  elif i.mnemonic=='add' and len(op)==3 and op[1].reg in regs:regs[op[0].reg]=regs[op[1].reg]+op[2].imm
  elif i.mnemonic=='ldr' and len(op)==2 and op[1].mem.base in regs:result.append((index,regs[op[1].mem.base]+op[1].mem.disp));regs.pop(op[0].reg,None)
 return result
quality_matches=[];quality_refs=[]
for seg in old.segs:
 if not seg[1]&1:continue
 for off in range(seg[2],seg[2]+seg[5]-32,4):
  word=struct.unpack_from('<I',old.data,off)[0]
  if word&0x9f000000!=0x90000000:continue
  pc=seg[3]+off-seg[2];imm=(((word>>5)&0x7ffff)<<2)|((word>>29)&3);imm=imm-(1<<21) if imm&(1<<20) else imm
  page=(pc&~4095)+(imm<<12)
  if page!=0x17fe000:continue
  for index,cell in data_refs(old,pc):
   if cell==0x17fe8e0:quality_refs.append((pc,index,0))
   elif cell==0x17fe8e0-88:quality_refs.append((pc,index,88))
print('QUALITY REFS',[(hex(a),i,delta) for a,i,delta in quality_refs[:8]],flush=True)
for pc,index,delta in quality_refs[:8]:
 pattern=sig(old,pc,32,True)
 for newpc in range(pc-0x10000,pc+0x10000,4):
  word=struct.unpack('<I',u.at(newpc,4))[0]
  if word&0x9f000000!=0x90000000:continue
  if sig(u,newpc,32,True)==pattern:quality_matches.extend(cell+delta for idx,cell in data_refs(u,newpc) if idx==index)
 if quality_matches:break
assert quality_matches and len(set(quality_matches))==1,quality_matches
quality=quality_matches[0];print('FPS',hex(fps),hex(quality),flush=True)
# Retain new Build IDs and gameplay guards produced from the supplied images.
guards=x['guards'][:5]+[x['guards'][-1]]+mapped
assert len(guards)==14
cam=next(block for name,block in d.blocks if name=='Camera' and block.startswith('UnityEngine.CoreModule.dll'))
bg=method(cam,'set_backgroundColor(Color ')
skies=[block for _,block in d.blocks if 'DomePosToCamera' in block.split('// Methods')[0] and 'DomeScaleToFarClip' in block.split('// Methods')[0] and any('void Update(' in t for _,t in d.methods(block))];assert len(skies)==1
sky=method(skies[0],'void Update(');calls=[i for i in e.cs.disasm(e.at(sky,512),sky) if i.mnemonic=='bl' and i.operands[0].imm==bg];assert len(calls)==1
days=[]
for a,t in d.methods(d.block('TimeOfDay')):
 if '(float ' not in t:continue
 stores=[i for i in e.cs.disasm(e.at(a,120),a) if i.mnemonic=='str' and i.op_str in ('s0, [x0, #0xb8]','w8, [x0, #0x3c]')]
 if len(stores)==2:days.append(stores)
assert len(days)==1
modes=d.block('GameModes');controller=d.block('GameControllerBase');marker=re.search(r'private (\w+) [^;]+; // 0x80\b',modes)[1]
dispersion=re.search(r'private (\w+) [^;]+; // 0x[12][0-9A-Fa-f]+',d.block('FPHitscan'))
dispersion=next(name for name,block in d.blocks if 'readonly DispersionConfig' in block and re.search(r'private '+re.escape(name)+r' [^;]+; // 0x',d.block('FPHitscan')))
marker_dict=typed(d.block('ScreenMarkerPresenter'),'Dictionary<Marker, ScreenMarkerView>')
base_delta=field(d.block('FPMelee'),'m_MaxReach')-0x130
fp_base=field(d.block('FPHitscan'),'config')-0x130
derived=field(d.block('FPWeaponBase'),'weaponType')-0xd8
looks=next(block for name,block in d.blocks if name=='MouseLook' and 'm_EventHandler;' in block)
locks=typed(looks,'HashSet<LockSource>')
prefix=original[:original.index('inline constexpr uint64_t current_day_cells')]
lines=[prefix]
for key in ('day_cells','mode_cells'):lines.append('inline constexpr uint64_t current_'+key+'[]={'+','.join(hex(v) for v in x[key])+'};')
lines.append('inline constexpr Patch current_patches[]={'+','.join('{'+hex(a)+','+hex(w)+'U}' for a,w in x['patches'])+'};')
lines.append('inline constexpr Guard current_guards[]={'+','.join('{'+str(g['unity']).lower()+','+hex(g['address'])+','+str(len(bytes.fromhex(g['bytes'])))+',{'+','.join(str(v) for v in bytes.fromhex(g['bytes']))+'}}' for g in guards)+'};')
values=['"current"','"1.19.12025"',hex(x['network_cell']),hex(x['orbit_cell']),json.dumps(x['camera_type']),json.dumps(x['ray_type']),hex(x['handler_sleep']),hex(x['handler_aim']),'current_day_cells',str(len(x['day_cells'])),'current_mode_cells',str(len(x['mode_cells'])),'current_patches','2','current_guards',str(len(guards)),json.dumps(marker),hex(typed(controller,'GameControllerBase',True)),hex(field(controller,'gameModes')),hex(typed(modes,'ThirdPersonMode')),hex(typed(controller,'ItemDatabase',True)),'"ItemDatabase"',hex(calls[0].address),hex(int.from_bytes(calls[0].bytes,'little'))]
values+=['{'+hex(i.address)+','+hex(int.from_bytes(i.bytes,'little'))+'}' for i in days[0]]
values += [hex(fps),hex(quality),json.dumps(dispersion),hex(marker_dict),str(fp_base),str(derived),hex(field(d.block('FPMelee'),'m_MaxReach')),hex(locks)]
lines+=['inline constexpr Profile current={'+','.join(values)+'};','// Inert internal compatibility tag; there is no beta profile or selector.','inline constexpr Profile beta{};','inline const char* marker_service_type(const Profile& p){return p.marker;}','inline const Profile* select(const char* name){return name&&!std::strcmp(name,"current")?&current:nullptr;}','}']
(r/'native/src/runtime/profile.hpp').write_text('\n'.join(lines),encoding='utf-8')
veg=[]
for name in ('BrgChunkVegetationRenderer','ChunkTreeRenderer'):
 a=method(d.block(name),'public void OnChunkLoaded(Vector2Int coord, ChunkData chunkData,');veg.append((a,e.at(a,16)))
vp=r/'native/src/runtime/vegetation_profile.hpp';vs=vp.read_text();vs=re.sub(r'inline constexpr VegetationPatch vegetation_current\[\]=\{[^;]+;','inline constexpr VegetationPatch vegetation_current[]={'+','.join('{'+hex(a)+',{'+','.join(str(v) for v in raw)+'}}' for a,raw in veg)+'};',vs);vs=re.sub(r'inline constexpr VegetationPatch vegetation_beta\[\]=\{[^;]+;','inline constexpr auto& vegetation_beta=vegetation_current;',vs);vp.write_text(vs)
pjava=r/'loader/app/src/main/java/cc/nova/oxide/GameBuild.java';pjava.write_text(pjava.read_text().replace('1.20.12025','1.19.12025'))
vp=r/'native/src/security/virtual_probe.cpp';vp.write_text(vp.read_text().replace('beta?oxide_profile::beta:oxide_profile::current','oxide_profile::current'))
report={'version':'1.19.12025','code':12025,'guards':guards,'camera':x['camera_type'],'orbit_cell':hex(x['orbit_cell']),'fp_base_delta':fp_base,'fp_derived_delta':derived,'look_locks':hex(locks),'fps':hex(fps),'quality':hex(quality),'beta_selector':False}
(b/'inputs/release12025-report.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='guards'},indent=2))
